﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;#Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
Array_ItemExist(ThisArray, CheckThis) ; Array_ItemExist(ThisArray, CheckThis) ; > Number of times in Array
{
  ; Returns the number of times CheckThis is in the ThisArray
  IsInArray := 0
  for Index, ThisItem in ThisArray
  {
    if (ThisItem == CheckThis)
    {
      IsInArray := IsInArray + 1
    } ; End (ThisItem == CheckThis)
  } ; End for Index, ThisItem in ThisArray
  return IsInArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
