﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_523: ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
{
  ; -------------------------------------------
  ; Jackhammer
  ; -------------------------------------------
  ;
  ; (_w480 x h270_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ;
  ; if (137_3)(Message Image 4: Image Path) Exist (Original Image)
  ; Returns (137_3)(Message Image 4: Image Path) to (Original Image)
  ; Otherwise Hides (137)(Message Image 4)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
  ; global n_523 := 1 ; Start Frame Number
  ; global s_523 := 1 ; Show
  ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Jackhammer)
  ; global s_523 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Jackhammer)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Image_ExeToPng.ahk
  ;
  ; -------------------------------------------
  ; Previous Ok State (Enable/Disable)
  ; (004_2)(Obj_ok_Sel [0,1,3])
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 160
  ; -------------------------------------------
  if (s_523 == 1) ; run animation
  {
    ; -------------------------------------------
    if (n_523 > Total_Images) ; 1 Less than Number of Images
    {
      global n_523 := 1
    }
    else
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_137, C:\Program Files\PopUpMenu_PUM\image\gui\(523)_%n_523%.png ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
      Gui_ObjectSize("137", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_523 := n_523 + 1
      ; -------------------------------------------
    }
  } ; End run animation
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
    SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
