﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\l_521.ahk ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
#Include C:\Program Files\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_157(DataArray) ; (157_1)(Obj_Pum_Setting)
{
  ; -------------------------------------------
  GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
  ; -------------------------------------------
  if (DataArray.157.2 == "" or DataArray.157.2 == 1) ; (157_2)(Obj_Pum_Setting_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
    DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
    DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
    ; -------------------------------------------
    DataArray := Image_GuiControl("154", 1, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
    DataArray := Image_GuiControl("155", 1, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
    DataArray := Image_GuiControl("156", 1, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
    if (n_521 == 170)
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ; -------------------------------------------
    } ; [End] if (n_521 == 170)
    else
    {
      global s_521 := 1 ; Show
      SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    } ; [End] else
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [START UP]  Vars
      ; -------------------------------------------
      { ; [GET] Vars
        ; -------------------------------------------
        UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
        ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
        XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
        XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
        ; -------------------------------------------
        Img_W          := DataArray.362.34 ; (362_34)(Img_W)
        Img_H          := DataArray.362.35 ; (362_35)(Img_H)
        Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
        Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
        bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
        Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
        Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
        Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
        PumBody_H      := DataArray.362.43 ; (362_43)((ImgChange_Array [Image Change [Array])
        Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
        Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
        Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
        Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
        Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
        Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
        Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
        Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
        bg_Selected_Rotate    := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
        ; -------------------------------------------
        Mobile_OnOff              := DataArray.362.24 ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
        Mobile_TextColor_HexColor := DataArray.362.25 ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
        Mobile_BgColor_HexColor   := DataArray.362.26 ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
        ; -------------------------------------------
        XmlBgColor      := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
        XmlBgType       := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
        BgColor_Opicity := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
        Color_Array := Pum_ColorVarConvert("HexColor", Mobile_TextColor_HexColor, DataArray)
        Mobile_TextColor_DataArrayNum := Color_Array.1
        Mobile_TextColor_GridNum      := Color_Array.2
        ; -------------------------------------------
        ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
        Color_Array := Pum_ColorVarConvert("HexColor", Mobile_BgColor_HexColor, DataArray)
        Mobile_BgColor_DataArrayNum := Color_Array.1
        Mobile_BgColor_GridNum      := Color_Array.2
        ; -------------------------------------------
        ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
        Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
        Pum_BgColor_DataArrayNum := Color_Array.1
        Pum_BgColor_GridNum      := Color_Array.2
        ; -------------------------------------------
      } ; End [GET] Vars
      ; -------------------------------------------
      ImagePath := "C:\Program Files\PopUpMenu_PUM\image\gui"
      ; -------------------------------------------
      Info_bg     := ThisPumProcessFolder "\image\Info_bg.txt" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      File_PumFrame := "C:\Program Files\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
      ; -------------------------------------------
      bg_Selected_Bmp     := ThisPumProcessFolder "\image\bg_Selected_Bmp.bmp" ; (361)(8)(Pum [Specific Folder Path])
      bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      bg_Selected_Fit     := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
      Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      bg_Display_Img       := ThisPumProcessFolder "\image\bg_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      bg_Display_Txt_Col   := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
      bg_Display_Txt_Img   := ThisPumProcessFolder "\image\bg_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
      Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      File_Pum_Gui       := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
    } ; End [START UP] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    ImageFolderCheck := ThisPumProcessFolder "\image"
    if !FileExist(ImageFolderCheck)
    {
      FileCreateDir, %ImageFolderCheck%
      Sleep, 10
    } ; [End] if !FileExist(ImageFolderCheck)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSetting" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    DataArray := Image_GuiControl("157", 2, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
    ; -------------------------------------------
    AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
    ; -------------------------------------------
    v_365_2 := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ThisPumProcessXml := DataArray.361.9 ; (361)(9)(ThisPumProcessXml [Full File Path])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (AppProcessName == "windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
      DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161_1)(Obj_Pum_Del)
      ; -------------------------------------------
    } ; End (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    else if (InStr(ThisPumProcessXml, "\pumdefault\") > 0) ; Default Pum Active (Application Pum)
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161_1)(Obj_Pum_Del)
      DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160_1)(Obj_Pum_App))
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
      DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    HasConnection := InternetConnectCheck()
    ; -------------------------------------------
    if (HasConnection == 1) ; Has Internet Connection
    {
      DataArray := Image_GuiControl("159", 1, 1, DataArray) ; (159_1)(Obj_Pum_Contact)
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if FileExist(Info_bg) ; [READ] (Info_bg.txt)
    {
      ; -------------------------------------------
      if (Img_W == "")
      {
        FileReadLine, Img_W, %Info_bg%, 1
        DataArray.362.34 := Img_W ; (362_34)(Img_W)
      }
      if (Img_H == "")
      {
        FileReadLine, Img_H, %Info_bg%, 2
        DataArray.362.35 := Img_H ; (362_35)(Img_H)
      }
      if (Pum_W == "")
      {
        FileReadLine, Pum_W, %Info_bg%, 3
        DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
      }
      if (Pum_H == "")
      {
        FileReadLine, Pum_H, %Info_bg%, 4
        DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
      }
      if (bg_Image_Type == "")
      {
        FileReadLine, bg_Image_Type, %Info_bg%, 5
        DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
      }
      if (Img_Gui_W == "")
      {
        FileReadLine, Img_Gui_W, %Info_bg%, 6
        DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
      }
      if (Img_Gui_H == "")
      {
        FileReadLine, Img_Gui_H, %Info_bg%, 7
        DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
      }
      if (Img_Gui_X == "")
      {
        FileReadLine, Img_Gui_X, %Info_bg%, 8
        DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
      }
      if (Img_Gui_Y == "")
      {
        FileReadLine, Img_Gui_Y, %Info_bg%, 9
        DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
      }
      if (PumBody_H == "")
      {
        FileReadLine, PumBody_H, %Info_bg%, 10
        DataArray.362.43 := PumBody_H ; (362_43)((ImgChange_Array [Image Change [Array])
      }
      if (Pum_Gui_W == "")
      {
        FileReadLine, Pum_Gui_W, %Info_bg%, 11
        DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
      }
      if (Pum_Gui_H == "")
      {
        FileReadLine, Pum_Gui_H, %Info_bg%, 12
        DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
      }
      if (Pum_Gui_X == "")
      {
        FileReadLine, Pum_Gui_X, %Info_bg%, 13
        DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
      }
      if (Pum_Gui_Y == "")
      {
        FileReadLine, Pum_Gui_Y, %Info_bg%, 14
        DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
      }
      if (Pum_Gui_Max_W == "")
      {
        FileReadLine, Pum_Gui_Max_W, %Info_bg%, 15
        DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
      }
      if (Pum_Gui_Max_H == "")
      {
        FileReadLine, Pum_Gui_Max_H, %Info_bg%, 16
        DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
      }
      if (Pum_Gui_Min_W == "")
      {
        FileReadLine, Pum_Gui_Min_W, %Info_bg%, 17
        DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
      }
      if (Pum_Gui_Min_H == "")
      {
        FileReadLine, Pum_Gui_Min_H, %Info_bg%, 18
        DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
      }
      if (bg_Selected_Rotate == "")
      {
        FileReadLine, bg_Selected_Rotate, %Info_bg%, 19
        DataArray.362.54 := bg_Selected_Rotate ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
    } ; End [READ] (Info_bg.txt)
    else
    {
      ; -------------------------------------------
      XmlBgType == 2
      DataArray.362.28 := 2 ; (Info_bg.txt NOT Exist) (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
      ; -------------------------------------------
      ;
      Pum_W     := XmlColumnsX * XmlIconSize
      PumBody_H := XmlRowsY * XmlIconSize
      Pum_H     := PumBody_H
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Pum_[W,H]) | [SET] (Pum_Gui_[W,H]) (Pum_Gui_Max_[W,H])
      ; -------------------------------------------
      WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
      ; -------------------------------------------
      Pum_Gui_W := WinInWin_Array.1
      Pum_Gui_H := WinInWin_Array.2
      ; -------------------------------------------
      Pum_Gui_Max_W := WinInWin_Array.1
      Pum_Gui_Max_H := WinInWin_Array.2
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
      DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
      DataArray.362.43 := PumBody_H ; (362_43)((ImgChange_Array [Image Change [Array])
      DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
      DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
      DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
      DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; Hide
      ; -------------------------------------------
      ; Hide [pumBgImage]
      DataArray := Image_GuiControl("165", 0, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      DataArray := Image_GuiControl("167", 0, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
      DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
      DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
      DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
      DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
      DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
      DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      ; -------------------------------------------
      ; Hide [pumBgText]
      GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
      DataArray := Image_GuiControl("166", 0, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      DataArray := Image_GuiControl("172", 0, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
      DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      ; -------------------------------------------
      ; Hide [pumBgText] Tranparency (177)-(181)
      DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      ; -------------------------------------------
      ; Hide [pumBgText] Color Picker (291) - (238)
      Num_Hide := 190
      Loop 48
      {
        Num_Hide := Num_Hide + 1
        DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray) ; (166_1)(GUI Object: [pum] [pumBgColor])
      }
      ; -------------------------------------------
      ; Hide (Message Image 8)
      DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
      ; -------------------------------------------
      ; Hide [pumDimension]
      DataArray := Image_GuiControl("260", 0, 1, DataArray) ; (260_1)(Obj_Pum_IconSize)
      DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      DataArray := Image_GuiControl("263", 0, 1, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
      DataArray := Image_GuiControl("266", 0, 1, DataArray) ; (266_1)(Obj_Pum_PumRow)
      DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      DataArray := Image_GuiControl("269", 0, 1, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
      DataArray := Image_GuiControl("272", 0, 1, DataArray) ; (272_1)(Obj_Pum_PumColumn)
      DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      DataArray := Image_GuiControl("275", 0, 1, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      ; -------------------------------------------
      ; [pum] > [pumContact]
      DataArray := Image_GuiControl("184", 0, 1, DataArray) ; (184_1)(Obj_Pum_ImageText_EmailAddress)
      DataArray := Image_GuiControl("185", 0, 1, DataArray) ; (185_1)(Obj_Pum_ImageText_ContactName)
      DataArray := Image_GuiControl("186", 0, 0, DataArray) ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
      DataArray := Image_GuiControl("188", 0, 0, DataArray) ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      DataArray := Image_GuiControl("189", 0, 0, DataArray) ; (189_1)(Obj_Pum_EditFeild_ContactName)
      DataArray := Image_GuiControl("190", 0, 0, DataArray) ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; -------------------------------------------
      DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
      DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
      GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
      GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
      ; -------------------------------------------
    } ; End Hide
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; if Button in Normal State
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
