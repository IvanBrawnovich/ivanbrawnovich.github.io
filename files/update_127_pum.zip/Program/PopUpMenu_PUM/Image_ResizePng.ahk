﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ResizePng(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
{
  ; -------------------------------------------
  if FileExist(ImageIn)
  {
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
    RunThis := """" Support_magick """ convert """ ImageIn """ -type TrueColorMatte -define png:color-type=6 -resize " Resize_W "x" Resize_H "! """ ImageOut """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
} ; End Image_ResizeImg(Resize_W, Resize_H, ImageIn) ; > ImageOut
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
