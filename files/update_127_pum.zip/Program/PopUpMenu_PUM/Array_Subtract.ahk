﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Not Used for Multi Array's
; Removes a Item at ThisPos
; if ThisPos == 0
; Will Rwmove All entrys of that Item
; -------------------------------------------
Array_Subtract(ThisArray, SubThis, ThisPos) ; Array_Subtract(ThisArray, SubThis, ThisPos) ; > ThisArray
{
  ; -------------------------------------------
  if (!ThisPos or ThisPos == 0)
  {
    ThisPos := "All"
    LoopCount := Array_ItemExist(ThisArray, SubThis) ; ThisArray, CheckThis > Number of times in Array
  }
  else
  {
    LoopCount := 1
  }
  ; -------------------------------------------
  if SubThis
  {
    CheckThis := ThisArray[1]
    if CheckThis ; Does ThisArray have a Value in the First Postion
    {
      Loop %LoopCount%
      {
        Array_Len := ThisArray.MaxIndex() ; Highest Length
        Num := 0
        CkPos := 0
        Loop %Array_Len%
        {
          Num := Num + 1
          ThisItem := ThisArray[Num]
          if (ThisItem == SubThis)
          {
            CkPos := CkPos + 1
            if (ThisPos == "All")
            {
              ThisArray.RemoveAt(Num, 1) ; Removes 1 item Starting At (ThisPos)
            }
            else if (CkPos == ThisPos)
            {
              ThisArray.RemoveAt(Num, 1) ; Removes 1 item Starting At (ThisPos)
            } ; End (CkPos == ThisPos)
          } ; End (ThisItem == SubThis)
        } ; End Loop %Array_Len%
      } ; End Loop %LoopCount%
    } ; End if CheckThis
  } ; End if SubThis
  return ThisArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
