﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Cpl_MenuArray(DataArray) ; > DataArray
{
  ; -------------------------------------------
  MenuSize := 0
  ; -------------------------------------------
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  LangListArray := DataArray.365.4 ; (365_4)(LangListArray [Language List] [Array])
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  if (UserLang != "")
  {
    ; -------------------------------------------
    File_Menu := "C:\Program Files\PopUpMenu_PUM\menu\cpl\menu\menu_" UserLang ".txt" ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    AllMenuArray := ""
    ; -------------------------------------------
    if FileExist(File_Menu) ; Menu Exist / [SET] File_Menu(ThisFile), AllMenuArray
    {
      ; -------------------------------------------
      LineNum := 1
      FileReadLine, MenuName, %File_Menu%, LineNum
      MenuName := StrReplace(MenuName, A_Space, "")
      LineNum := LineNum + 1 ; 2
      FileReadLine, MenuArray, %File_Menu%, LineNum
      ; -------------------------------------------
      MenuArray  := StrSplit(MenuArray, "|", "")
      ; -------------------------------------------
      if (ScriptType == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh])
      {
        MenuSize := 8 ; (302_6)([mnu][cpl] Menu Size [#])
      }
      else
      {
        MenuSize := MenuArray.MaxIndex() ; (302_6)([mnu][cpl] Menu Size [#])
      }
      ; -------------------------------------------
      AllMenuArrayItem := [MenuName, MenuArray]
      MenuName  := ""
      MenuArray := ""
      AllMenuArray  := Array_Add(AllMenuArray, AllMenuArrayItem, "End")
      ; -------------------------------------------
      LineNum   := LineNum + 1 ; 3
      ; -------------------------------------------
      ThisTime := A_TickCount
      BreakTime := ThisTime + 3000
      ; -------------------------------------------
      Loop ; Infinite Loop
      {
        ; -------------------------------------------
        ThisTime := A_TickCount
        if (BreakTime == ThisTime)
        {
          break
        }
        ; -------------------------------------------
        MenuArray  := ""
        MenuName  := ""
        ComArray  := ""
        TxtArray  := ""
        EndOfFile := ""
        ; -------------------------------------------
        FileReadLine, MenuName, %File_Menu%, LineNum
        ; -------------------------------------------
        ThisLen := StrLen(MenuName)
        if (ThisLen == 0 or !MenuName)
        {
          break
        }
        ; -------------------------------------------
        MenuName := StrReplace(MenuName, A_Space, "")
        LineNum   := LineNum + 1 ; 5
        FileReadLine, ComArray, %File_Menu%, LineNum
        LineNum   := LineNum + 1 ; 6
        FileReadLine, TxtArray, %File_Menu%, LineNum
        LineNum   := LineNum + 1 ; 7
        FileReadLine, EndOfFile, %File_Menu%, LineNum
        ; -------------------------------------------
        ComArray  := StrSplit(ComArray, "|", "")
        TxtArray  := StrSplit(TxtArray, "|", "")
        ; -------------------------------------------
        for Index, ThisItem in ComArray
        {
          ; -------------------------------------------
          Decription := TxtArray[Index]
          ItemArray := [ThisItem, Decription]
          MenuArray := Array_Add(MenuArray, ItemArray, "End")
          MenuName := StrReplace(MenuName, A_Space, "")
          ; -------------------------------------------
        } ; End for Index, ThisItem in ComArray
        ; -------------------------------------------
        AllMenuArrayItem := [MenuName, MenuArray]
        AllMenuArray := Array_Add(AllMenuArray, AllMenuArrayItem, "End")
        ; -------------------------------------------        
        MenuName := ""
        ; -------------------------------------------
      } ; End Infinite Loop [SET] AllMenuArray
      ; -------------------------------------------
    } ; End FileExist(ThisFile)
    ; -------------------------------------------
    if (UserLang == "de") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.341.2 := AllMenuArray ; (341_2)([cpl] (cpl_AllMenuArray) de)
        DataArray.341.3 := 1 ; (341_3)([cpl] (cpl_MenuInstalled_de) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.341.3 := 0 ; (341_3)([cpl] (cpl_MenuInstalled_de) [1/0])
      }
    } ; End (de German)
    ; -------------------------------------------
    else if (UserLang == "en") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.342.2 := AllMenuArray ; (342_2)([cpl] (cpl_AllMenuArray) en)
        DataArray.342.3 := 1 ; (342_3)([cpl] (cpl_MenuInstalled_en) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.342.3 := 0 ; (342_3)([cpl] (cpl_MenuInstalled_en) [1/0])
      }
    } ; End (en English)
    ; -------------------------------------------
    else if (UserLang == "es") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.343.2 := AllMenuArray ; (343_2)([cpl] (cpl_AllMenuArray) es)
        DataArray.343.3 := 1 ; (343_3)([cpl] (cpl_MenuInstalled_es) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.343.3 := 0 ; (343_3)([cpl] (cpl_MenuInstalled_es) [1/0])
      }
    } ; End (es Spanish)
    ; -------------------------------------------
    else if (UserLang == "fr") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.344.2 := AllMenuArray ; (344_2)([cpl] (cpl_AllMenuArray) fr)
        DataArray.344.3 := 1 ; (344_3)([cpl] (cpl_MenuInstalled_fr) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.344.3 := 0 ; (344_3)([cpl] (cpl_MenuInstalled_fr) [1/0])
      }
    } ; End (fr French)
    ; -------------------------------------------
    else if (UserLang == "it") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.345.2 := AllMenuArray ; (345_2)([cpl] (cpl_AllMenuArray) it)
        DataArray.345.3 := 1 ; (345_3)([cpl] (cpl_MenuInstalled_it) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.345.3 := 0 ; (345_3)([cpl] (cpl_MenuInstalled_it) [1/0])
      }
    } ; End (it Italian)
    ; -------------------------------------------
    else if (UserLang == "pl") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.346.2 := AllMenuArray ; (346_2)([cpl] (cpl_AllMenuArray) pl)
        DataArray.346.3 := 1 ; (346_3)([cpl] (cpl_MenuInstalled_pl) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.346.3 := 0 ; (346_3)([cpl] (cpl_MenuInstalled_pl) [1/0])
      }
    } ; End (pl Polish)
    ; -------------------------------------------
    else if (UserLang == "pt") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.347.2 := AllMenuArray ; (347_2)([cpl] (cpl_AllMenuArray) pt)
        DataArray.347.3 := 1 ; (347_3)([cpl] (cpl_MenuInstalled_pt) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.347.3 := 0 ; (347_3)([cpl] (cpl_MenuInstalled_pt) [1/0])
      }
    } ; End (pt Portuguese)
    ; -------------------------------------------
    else if (UserLang == "ru") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.348.2 := AllMenuArray ; (348_2)([cpl] (cpl_AllMenuArray) ru)
        DataArray.348.3 := 1 ; (348_3)([cpl] (cpl_MenuInstalled_ru) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.348.3 := 0 ; (348_3)([cpl] (cpl_MenuInstalled_ru) [1/0])
      }
    } ; End (ru Russian)
    ; -------------------------------------------
    else if (UserLang == "sv") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.349.2 := AllMenuArray ; (349_2)([cpl] (cpl_AllMenuArray) sv)
        DataArray.349.3 := 1 ; (349_3)([cpl] (cpl_MenuInstalled_sv) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.349.3 := 0 ; (349_3)([cpl] (cpl_MenuInstalled_sv) [1/0])
      }
    } ; End (sv Swedish)
    ; -------------------------------------------
    else if (UserLang == "tr") ; (365_2)(UserLang [Current User language])
    {
      if AllMenuArray
      {
        DataArray.350.2 := AllMenuArray ; (350_2)([cpl] (cpl_AllMenuArray) tr)
        DataArray.350.3 := 1 ; (350_3)([cpl] (cpl_MenuInstalled_tr) [1/0])
      } ; End if AllMenuArray
      else
      {
        DataArray.350.3 := 0 ; (350_3)([cpl] (cpl_MenuInstalled_tr) [1/0])
      }
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; [End] for ThisNum, UserLang in LangListArray
  ; -------------------------------------------
  DataArray.300.6 := MenuSize ; (300_6)(Cpl_MenuSize [#])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
