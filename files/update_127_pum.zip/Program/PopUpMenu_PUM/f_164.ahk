﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_DisplayImageTxt.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_164(DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; (Background Image [Toggle])
    ;
    if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
    {
      DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
    }
    ; -------------------------------------------
    Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
    DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
    DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
    ; -------------------------------------------
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    ScriptType      := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ThisPumProcessFolder  := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    ; -------------------------------------------
    Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
    Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    ScriptType := StrReplace(ScriptType, "_pumBgColor", "")
    ScriptType := StrReplace(ScriptType, "_pumMobileTextColor", "")
    ScriptType := StrReplace(ScriptType, "_pumMobileBgColor", "")
    ; -------------------------------------------
    DataArray.366.5 := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    { ; Hide Color Panel Controls
      ; -------------------------------------------
      DataArray := Image_GuiControl("166", 1, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      ; -------------------------------------------
      DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      ; -------------------------------------------
      DataArray := Image_GuiControl("191", 0, 0, DataArray) ; (191_1)(Obj_Pum_ColorA1)
      DataArray := Image_GuiControl("192", 0, 0, DataArray) ; (192_1)(Obj_Pum_ColorA2)
      DataArray := Image_GuiControl("193", 0, 0, DataArray) ; (193_1)(Obj_Pum_ColorA3)
      DataArray := Image_GuiControl("194", 0, 0, DataArray) ; (194_1)(Obj_Pum_ColorA4)
      DataArray := Image_GuiControl("195", 0, 0, DataArray) ; (195_1)(Obj_Pum_ColorA5)
      DataArray := Image_GuiControl("196", 0, 0, DataArray) ; (196_1)(Obj_Pum_ColorA6)
      DataArray := Image_GuiControl("197", 0, 0, DataArray) ; (197_1)(Obj_Pum_ColorB1)
      DataArray := Image_GuiControl("198", 0, 0, DataArray) ; (198_1)(Obj_Pum_ColorB2)
      DataArray := Image_GuiControl("199", 0, 0, DataArray) ; (199_1)(Obj_Pum_ColorB3)
      DataArray := Image_GuiControl("200", 0, 0, DataArray) ; (200_1)(Obj_Pum_ColorB4)
      DataArray := Image_GuiControl("201", 0, 0, DataArray) ; (201_1)(Obj_Pum_ColorB5)
      DataArray := Image_GuiControl("202", 0, 0, DataArray) ; (202_1)(Obj_Pum_ColorB6)
      DataArray := Image_GuiControl("203", 0, 0, DataArray) ; (203_1)(Obj_Pum_ColorC1)
      DataArray := Image_GuiControl("204", 0, 0, DataArray) ; (204_1)(Obj_Pum_ColorC2)
      DataArray := Image_GuiControl("205", 0, 0, DataArray) ; (205_1)(Obj_Pum_ColorC3)
      DataArray := Image_GuiControl("206", 0, 0, DataArray) ; (206_1)(Obj_Pum_ColorC4)
      DataArray := Image_GuiControl("207", 0, 0, DataArray) ; (207_1)(Obj_Pum_ColorC5)
      DataArray := Image_GuiControl("208", 0, 0, DataArray) ; (208_1)(Obj_Pum_ColorC6)
      DataArray := Image_GuiControl("209", 0, 0, DataArray) ; (209_1)(Obj_Pum_ColorD1)
      DataArray := Image_GuiControl("210", 0, 0, DataArray) ; (210_1)(Obj_Pum_ColorD2)
      DataArray := Image_GuiControl("211", 0, 0, DataArray) ; (211_1)(Obj_Pum_ColorD3)
      DataArray := Image_GuiControl("212", 0, 0, DataArray) ; (212_1)(Obj_Pum_ColorD4)
      DataArray := Image_GuiControl("213", 0, 0, DataArray) ; (213_1)(Obj_Pum_ColorD5)
      DataArray := Image_GuiControl("214", 0, 0, DataArray) ; (214_1)(Obj_Pum_ColorD6)
      DataArray := Image_GuiControl("215", 0, 0, DataArray) ; (215_1)(Obj_Pum_ColorE1)
      DataArray := Image_GuiControl("216", 0, 0, DataArray) ; (216_1)(Obj_Pum_ColorE2)
      DataArray := Image_GuiControl("217", 0, 0, DataArray) ; (217_1)(Obj_Pum_ColorE3)
      DataArray := Image_GuiControl("218", 0, 0, DataArray) ; (218_1)(Obj_Pum_ColorE4)
      DataArray := Image_GuiControl("219", 0, 0, DataArray) ; (219_1)(Obj_Pum_ColorE5)
      DataArray := Image_GuiControl("220", 0, 0, DataArray) ; (220_1)(Obj_Pum_ColorE6)
      DataArray := Image_GuiControl("221", 0, 0, DataArray) ; (221_1)(Obj_Pum_ColorF1)
      DataArray := Image_GuiControl("222", 0, 0, DataArray) ; (222_1)(Obj_Pum_ColorF2)
      DataArray := Image_GuiControl("223", 0, 0, DataArray) ; (223_1)(Obj_Pum_ColorF3)
      DataArray := Image_GuiControl("224", 0, 0, DataArray) ; (224_1)(Obj_Pum_ColorF4)
      DataArray := Image_GuiControl("225", 0, 0, DataArray) ; (225_1)(Obj_Pum_ColorF5)
      DataArray := Image_GuiControl("226", 0, 0, DataArray) ; (226_1)(Obj_Pum_ColorF6)
      DataArray := Image_GuiControl("227", 0, 0, DataArray) ; (227_1)(Obj_Pum_ColorG1)
      DataArray := Image_GuiControl("228", 0, 0, DataArray) ; (228_1)(Obj_Pum_ColorG2)
      DataArray := Image_GuiControl("229", 0, 0, DataArray) ; (229_1)(Obj_Pum_ColorG3)
      DataArray := Image_GuiControl("230", 0, 0, DataArray) ; (230_1)(Obj_Pum_ColorG4)
      DataArray := Image_GuiControl("231", 0, 0, DataArray) ; (231_1)(Obj_Pum_ColorG5)
      DataArray := Image_GuiControl("232", 0, 0, DataArray) ; (232_1)(Obj_Pum_ColorG6)
      DataArray := Image_GuiControl("233", 0, 0, DataArray) ; (233_1)(Obj_Pum_ColorH1)
      DataArray := Image_GuiControl("234", 0, 0, DataArray) ; (234_1)(Obj_Pum_ColorH2)
      DataArray := Image_GuiControl("235", 0, 0, DataArray) ; (235_1)(Obj_Pum_ColorH3)
      DataArray := Image_GuiControl("236", 0, 0, DataArray) ; (236_1)(Obj_Pum_ColorH4)
      DataArray := Image_GuiControl("237", 0, 0, DataArray) ; (237_1)(Obj_Pum_ColorH5)
      DataArray := Image_GuiControl("238", 0, 0, DataArray) ; (238_1)(Obj_Pum_ColorH6)
      ; -------------------------------------------
    } ; [End] Hide Color Panel Controls
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.362.24 == 1) ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("173", 1, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 1, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("173", 0, 0, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 0, 0, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if FileExist(Temp_Selected_Img) ; [Has a Background Image]
    {
      ; -------------------------------------------
      if (DataArray.362.28 == 2) ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      {
        ; -------------------------------------------
        ; [BG with Image 1] [BG with Color 2]
        DataArray.362.28 := 1 ; (Obj_Pum_BgTxtImg Toggle CheckMark) (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
        ; -------------------------------------------
        if (DataArray.362.52 == "" or DataArray.362.52 == 0 or DataArray.362.52 == 1) ; (362_52)(bg_Selected_Change)
        {
          DataArray.362.52 := 2 ; (362_52)(bg_Selected_Change)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("164", 2, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
        ; -------------------------------------------
        if FileExist(Temp_Display_Txt_Img)
        {
          GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Img% ; (254_1)(Obj_MsgImg300x300)
          DataArray.254.3 := Temp_Display_Txt_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        }
        else
        {
          DataArray := Pum_DisplayImageTxt(DataArray) ; > DataArray
        }
        ; -------------------------------------------
      } ; (362_28)([XML][Line 19] Background type [BG Image 1 / BG Trans 2])
      ; -------------------------------------------
      else if (DataArray.362.28 == "1") ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      {
        ; -------------------------------------------
        ; [BG with Image 1] [BG with Color 2]
        DataArray.362.28 := 2 ; (Obj_Pum_BgTxtImg Toggle CheckMark) (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
        ; -------------------------------------------
        if (DataArray.362.52 == "" or DataArray.362.52 == 0 or DataArray.362.52 == 2) ; (362_52)(bg_Selected_Change)
        {
          DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("164", 1, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
        ; -------------------------------------------
        if FileExist(Temp_Display_Txt_Col)
        {
          GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Col% ; (254_1)(Obj_MsgImg300x300)
          DataArray.254.3 := Temp_Display_Txt_Col ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        }
        else
        {
          DataArray := Pum_DisplayImageTxt(DataArray) ; > DataArray
        }
        ; -------------------------------------------
      } ; (362_28)([XML][Line 19] Background type [BG Image 1 / BG Trans 2])
      ; -------------------------------------------
    } ; End [Has a Background Image]
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (164_1)(GUI Object: [pum] Background Image [Toggle])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
