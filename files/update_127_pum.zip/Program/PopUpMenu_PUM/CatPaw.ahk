﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
ThisScript := "C:\Program Files\PopUpMenu_PUM\CatPaw_Count.ahk"
DetectHiddenWindows, On
PostMessage, 0x111, 65305,,, %ThisScript% ahk_class AutoHotkey  ; Suspend
PostMessage, 0x111, 65306,,, %ThisScript% ahk_class AutoHotkey  ; Pause
WinClose, %ThisScript% ahk_class AutoHotkey
Sleep, 100
; -------------------------------------------
;
CheckFile_1 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw.png"
CheckFile_2 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPawBG.png"
if (!FileExist(CheckFile_1) or !FileExist(CheckFile_2))
{
  ExitApp
}
; -------------------------------------------
CoordMode, Mouse, Screen
MouseMove, 0, 0, 0
; -------------------------------------------
ColorTrans := "000000" ; Black
; -------------------------------------------
KeyList_1 := ["RButton", "Up", "Down", "Left", "Right", "CapsLock", "Space", "Tab", "Enter", "Esc", "Backspace", "ScrollLock", "Del", "Ins", "Home", "End", "PgUp", "PgDn", "LWin", "RWin", "Alt", "Shift", "LCtrl", "RCtrl", "LShift", "RShift", "LAlt", "RAlt", "AppsKey", "PrintScreen", "CtrlBreak", "Pause", "Help", "Sleep", "NumLock", "Numpad0", "Numpad1", "Numpad2", "Numpad3", "Numpad4", "Numpad5", "Numpad6", "Numpad7", "Numpad8", "Numpad9", "NumpadDot", "NumpadDiv", "NumpadMult", "NumpadAdd", "NumpadSub", "NumpadEnter", "NumpadIns", "NumpadEnd", "NumpadDown", "NumpadPgDn", "NumpadLeft", "NumpadClear", "NumpadRight", "NumpadHome", "NumpadUp", "NumpadPgUp", "NumpadDel", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "Browser_Back", "Browser_Forward", "Browser_Refresh", "Browser_Stop", "Browser_Search", "Browser_Favorites", "Browser_Home", "Volume_Mute", "Volume_Down", "Volume_Up", "Media_Next", "Media_Prev", "Media_Stop", "Media_Play_Pause", "Launch_Mail", "Launch_Media", "Launch_App1", "Launch_App2", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "&", "'", "(", "-", "_", ")", "=", "$", "*", "~", "#", "{", "[", "|", "``", "\", "^", "@", "]", "}", ";", ":", "!", "?", ".", "/", "<", ">", "``", """"]
KeyList_2 := ["LWin", "RWin", "Alt", "Shift", "LCtrl", "RCtrl", "LShift", "RShift", "LAlt", "RAlt"]
KeyList_3 := ["Tab", "Numpad0", "Numpad1", "Numpad2", "Numpad3", "Numpad4", "Numpad5", "Numpad6", "Numpad7", "Numpad8", "Numpad9", "NumpadDot", "NumpadDiv", "NumpadMult", "NumpadAdd", "NumpadSub", "NumpadEnter", "NumpadIns", "NumpadEnd", "NumpadDown", "NumpadPgDn", "NumpadLeft", "NumpadClear", "NumpadRight", "NumpadHome", "NumpadUp", "NumpadPgUp", "NumpadDel", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
; -------------------------------------------
for Index, Key_1 in KeyList_1
{
  Hotkey, %Key_1%, DummyLabel
}
; -------------------------------------------
for Index1, Key_2 in KeyList_2
{
  for Index2, Key_3 in KeyList_3
  {
    ; -------------------------------------------
    ThisKey := Key_2 " `& " Key_3
    Hotkey, %ThisKey%, DummyLabel
    ; -------------------------------------------
  }
}
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui Objects
; -------------------------------------------
Gui, Margin , 0, 0
; -------------------------------------------
Gui, Add, Picture, x0   y0   w389 h400 vImgBg, C:\Program Files\PopUpMenu_PUM\image\gui\CatPawBG.png
; -------------------------------------------
Gui, Add, Picture, x22  y85  w346 h289  vCancelClick gLabelCancelClick, C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw.png
; -------------------------------------------
Gui, Color, %ColorTrans%
Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, %ColorTrans%,
Gui, Show, w389 h400, CatPaw
; -------------------------------------------
return
; Gui Objects
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
DummyLabel:
{
  ; -------------------------------------------
  CoordMode, Mouse, Screen
  MouseMove, 0, 0, 0
  ; -------------------------------------------
}
Return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
LabelCancelClick:
{
  ; -------------------------------------------
  Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
  ExitApp
  ; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MButton::
{
  ; -------------------------------------------
  Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
  ExitApp
  ; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
