﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\l_523.ahk ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RwhIco.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_OflIco.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ExeToPng(AppProcessPathNameExt, DataArray) ; AppProcessPathNameExt, DataArray > DataArray
{
  ; -------------------------------------------
  Pre_102 := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  SplitPath, AppProcessPathNameExt, , , ThisExt
  StringLower, ThisExt, ThisExt
  ; -------------------------------------------
  if (ThisExt == "lnk")
  {
    ; -------------------------------------------
    FileGetShortcut, %AppProcessPathNameExt%, AppProcessPathNameExt
    ; -------------------------------------------
    SplitPath, AppProcessPathNameExt, AppProcessExtName, , , AppProcessName
    DataArray.367.1 := AppProcessName ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
    DataArray.367.2 := AppProcessExtName ; (367_2)(AppProcessExtName [Name,Ext])
    DataArray.367.5 := AppProcessPathNameExt ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
    ; -------------------------------------------
    DataArray.305.11 := AppProcessPathNameExt ; (305_11)(Run_OutTarget [PathExtName])
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Gui Active
    GuiActive := WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
    ; -------------------------------------------
    if (GuiActive == "0x0")
    {
      GuiActive := 0
    } ; [End] Gui is NOT Active
    else
    {
      GuiActive := 1
    } ; [End] Gui is Active
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Gui Active
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> UserLang
    if (GuiActive == 0) ; Gui is NOT Active
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; User Language [GET] (UserLang)
      ; -------------------------------------------
      File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileReadLINE, UserLang, %File_UserLang%, 1
      }
      if (UserLang == "")
      {
        ; -------------------------------------------
        if FileExist(File_UserLang)
        {
          FileDelete, %File_UserLang%
          Sleep, 100
        } ; [End] if FileExist(File_UserLang)
        ; -------------------------------------------
        if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
        {
          ; -------------------------------------------
          UserLang := "de"
          ; -------------------------------------------
        } ; [End] German (de)
        ; -------------------------------------------
        else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] English (en)
        ; -------------------------------------------
        else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
        {
          ; -------------------------------------------
          UserLang := "es"
          ; -------------------------------------------
        } ; [End] Spanish (es)
        ; -------------------------------------------
        else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
        {
          ; -------------------------------------------
          UserLang := "fr"
          ; -------------------------------------------
        } ; [End] French (fr)
        ; -------------------------------------------
        else if (A_Language == "0410" or A_Language == "0810")
        {
          ; -------------------------------------------
          UserLang := "it"
          ; -------------------------------------------
        } ; [End] Italian (it)
        ; -------------------------------------------
        else if (A_Language == "0415")
        {
          ; -------------------------------------------
          UserLang := "pl"
          ; -------------------------------------------
        } ; [End] Polish (pl)
        ; -------------------------------------------
        else if (A_Language == "0416" or A_Language == "0816")
        {
          ; -------------------------------------------
          UserLang := "pt"
          ; -------------------------------------------
        } ; [End] Portuguese (pt)
        ; -------------------------------------------
        else if (A_Language == "0419")
        {
          ; -------------------------------------------
          UserLang := "ru"
          ; -------------------------------------------
        } ; [End] Russian (ru)
        ; -------------------------------------------
        else if (A_Language == "041d" or A_Language == "081d")
        {
          ; -------------------------------------------
          UserLang := "sv"
          ; -------------------------------------------
        } ; [End] Swedish (sv)
        ; -------------------------------------------
        else if (A_Language == "041f")
        {
          ; -------------------------------------------
          UserLang := "tr"
          ; -------------------------------------------
        } ; [End] Turkish (tr)
        ; -------------------------------------------
        else ; English (en)
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] else ; English (en)
        ; -------------------------------------------
        FileEncoding, UTF-8
        FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
        ; -------------------------------------------
      } ; [End] if (UserLang == "")
      ; -------------------------------------------
      ; User Language [GET] (UserLang)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] Gui is NOT Active
    else ; Gui is Active
    {
      UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    } ; [End] Gui is Active
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> UserLang
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileRunIco := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileRwhIco := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileOflIco", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileOflIco := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileError440", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileError440 := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> if One or More Image(s) are Missing
    ; Changed (_14-Dec-2021_11-46-24_)
    if (!FileExist(FileRunPng) or !FileExist(FileRunIco) or !FileExist(FileRwhIco) or !FileExist(FileOflIco) or !FileExist(FileError440))
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] Vars, [ANIMATE] Start
      if (GuiActive == 1) ; Gui is Active
      {
        ; -------------------------------------------
        AnimateRunning := 1
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
        Obj_MsgImg480x270_Img := DataArray.137.3 ; (137_3)(Obj_MsgImg480x270_Img [Image Path])
        ;
        global n_523 := 1 ; Start Frame Number
        global s_523 := 1 ; Show
        ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
        SetTimer, l_523, 150 ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] [CURRENT] Select Value
        Pre_134 := DataArray.134.2 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
        Pre_135 := DataArray.135.2 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
        Pre_136 := DataArray.136.2 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
        ; -------------------------------------------
        if (Pre_134 == "")
        {
          Pre_134 := 0
          DataArray.134.2 := Pre_134 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
        } ; [End] if (Pre_134 == "")
        if (Pre_135 == "")
        {
          Pre_135 := 0
          DataArray.135.2 := Pre_135 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
        } ; [End] if (Pre_135 == "")
        if (Pre_136 == "")
        {
          Pre_136 := 0
          DataArray.136.2 := Pre_136 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
        } ; [End] if (Pre_136 == "")
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] [CURRENT] Select Value
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] Objects
        DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        DataArray := Image_GuiControl("003", 0, 0, DataArray) ; (003_1)(Obj_KeyOfl_3RAppIco)
        DataArray := Image_GuiControl("007", 0, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
        DataArray := Image_GuiControl("063", 0, 0, DataArray) ; (063_1)(Obj_SelectIconImage)
        DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        ; -------------------------------------------
        GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
        ; -------------------------------------------
        DataArray.102.3 := Pre_102 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        ; -------------------------------------------
        ; (134_1)(Obj_ImageSelect1)
        ; (135_1)(Obj_ImageSelect2)
        ; (136_1)(Obj_ImageSelect3)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] Objects
      } ; [End] if (GuiActive == 1) ; Gui is Active
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] Vars, [ANIMATE] Start
    } ; [End] if (!FileExist(FileRunPng) or !FileExist(FileRwhIco) or !FileExist(FileOflIco) or !FileExist(FileError440) or !FileExist(FileError450))
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> if One or More Image(s) are Missing
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(FileRunIco)
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileRunIco := Img_RunIco(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(FileRwhIco)
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileRwhIco := Img_RwhIco(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRwhIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(FileOflIco)
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileOflIco := Img_OflIco(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileOflIco)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (GuiActive == 1)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] [CURRENT] Select Value
      if (Pre_134 == 1)
      {
        GuiControl, PopUpMenu:Show, g_134 ; (134_1)(Obj_ImageSelect1)
      }
      if (Pre_135 == 1)
      {
        GuiControl, PopUpMenu:Show, g_135 ; (135_1)(Obj_ImageSelect2)
      }
      if (Pre_136 == 1)
      {
        GuiControl, PopUpMenu:Show, g_136 ; (136_1)(Obj_ImageSelect3)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] [CURRENT] Select Value
      ;
      if (AnimateRunning == 1)
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
        if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
        {
          global s_523 := 0 ; Hide
          SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
          global ShowAnimationChange := 0
          ;
          if FileExist(Obj_MsgImg480x270_Img)
          {
            GuiControl, PopUpMenu:, g_137, %Obj_MsgImg480x270_Img% ; (137_1)(Obj_MsgImg480x270)
            GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
          }
        } ; [End] if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
        ;
        ; -------------------------------------------
      } ; [End] if (AnimateRunning == 1)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.133.2 == 2 or DataArray.366.6 == 13 or DataArray.366.6 == 21) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(366_6)(ScriptError [Integer])
      {
        ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(004)_1.png"
        GuiControl, PopUpMenu:, g_004, %ThisImage% ; (004_1)(Obj_ok)
        GuiControl, PopUpMenu:Show, g_004 ; (004_1)(Obj_ok)
        DataArray.4.2 := 1 ; (004_2)(Obj_ok_Sel [0,1,3])
        DataArray.4.3 := ThisImage ; (004_3)(Obj_ok_Img [Image Path])
      }
      ; -------------------------------------------
    } ; [End] if (GuiActive == 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
