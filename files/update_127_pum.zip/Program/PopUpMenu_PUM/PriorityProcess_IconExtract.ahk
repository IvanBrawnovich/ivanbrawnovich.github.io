﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ThisPriorityProcess := "PopUpMenu_IconExtract.exe"
Process, Exist, %ThisPriorityProcess%
; -------------------------------------------
Breaktime := A_TickCount + 2000
; -------------------------------------------
while (ErrorLevel == 0)
{
  if (A_TickCount > Breaktime)
  {
    break
  }
  Process, Exist, %ThisPriorityProcess%
}
; -------------------------------------------
Process, Priority, %ThisPriorityProcess%, High
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
