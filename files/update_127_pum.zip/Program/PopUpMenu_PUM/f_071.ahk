﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Url_GetIcon.ahk
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
#Include C:\Program Files\PopUpMenu_PUM\l_520.ahk ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
;
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_071(DataArray) ; (071_1)(Obj_URL)
{
  ; -------------------------------------------
  if (DataArray.71.2 == 1) ; (071_2)(Obj_URL_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.122.3 := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    DataArray.366.5 := "url" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    DataArray := Image_GuiControl("081", 1, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
    DataArray := Image_GuiControl("071", 2, 1, DataArray) ; (071_1)(Obj_URL)
    DataArray := Image_GuiControl("082", 1, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
    ; -------------------------------------------
    HasConnection := InternetConnectCheck()
    ; -------------------------------------------
    if (HasConnection == 0) ; No Internet Connection
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
      ; [ScriptError = 19] (url)(No Internet Connection)
      DataArray.366.6 := 19 ; (366_6)(ScriptError [Integer])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [SET] ScriptError
    } ; [End] else ; Has Internet Connection OK
    ; -------------------------------------------
    else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; Has Internet Connection OK
      ; Is a Internet Browser OK
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      ; (367_3)(AppProcessClass)
      ; (367_4)(AppProcessTitle)
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Show/Start (Animate) URL
      global n_520 := 1 ; Start Frame Number
      global s_520 := 1 ; Show
      SetTimer, l_520, 100 ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Show/Start (Animate) URL
      ;
      ;
      ; -------------------------------------------
      ; (307_4)(Url_Title [Web Page Title])
      ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      DataArray.122.3 := DataArray.307.4
      ; -------------------------------------------
      ; ; [GET] Url_Icon
      ; (307_2)(Url_Address) Gotton in (Pum_Run.ahk)
      ; -------------------------------------------
      if (DataArray.307.2 == "")
      {
        ; -------------------------------------------
        URL_Array := Url_GetUrl(AppProcessName, AppProcessClass, AppProcessTitle) ; > [URL_Address, Url_Title, Browser_Name]
        DataArray.307.2 := URL_Array.1 ; (307_2)(Url_Address)
        DataArray.307.4 := URL_Array.2 ; (307_4)(Url_Title [Web Page Title])
        DataArray.307.11 := URL_Array.3 ; (307_11)(Url_BrowserTitle [Browser Name from Window Title])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      Url_Icon := Url_GetIcon(DataArray.307.2) ; (307_2)(Url_Address) ; > Url_Icon
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Display Icon 
      ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      if FileExist(URL_Icon)
      {
        DataArray.102.3 := URL_Icon ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) URL
      global s_520 := 0 ; Hide
      SetTimer, l_520, Off ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
      global ShowAnimationChange := 0
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) URL
      ;
      ; -------------------------------------------      
    } ; Is a Internet Browser
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (071_2)([ruf] Select URL: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; f_071(DataArray) ; (071_1)(Obj_URL)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
