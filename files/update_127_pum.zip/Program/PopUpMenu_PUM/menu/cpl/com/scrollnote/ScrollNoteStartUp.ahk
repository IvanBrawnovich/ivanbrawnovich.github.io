﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
;Script_ScrollNoteStartUp := A_Startup "\ScrollNoteStartUp.ahk"
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Scroll Note StartUp (ScrollNoteStartUp.ahk)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
Folder_ScrollNoteSupport := "C:\Program Files\PopUpMenu_PUM\menu\cpl\com\scrollnote\support"
Folder_ScrollNoteUser    := A_AppData "\PopUpMenu_PUM\scrollnote"
; -------------------------------------------
IMG_ScrollNoteSupport := "C:\Program Files\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\*.png"
Script_ScrollNoteStartUp := A_Startup "\ScrollNoteStartUp.ahk"
; -------------------------------------------
Script_ScrollNote := A_AppData "\PopUpMenu_PUM\scrollnote\*.ahk"
; -------------------------------------------
;
; -------------------------------------------
if !FileExist(IMG_ScrollNoteSupport) ; PopUpMenu Not Installed (Images Do Not Exist)
{
	; -------------------------------------------
	FileDelete, %Script_ScrollNoteStartUp% ; (DELETE) Scroll Note Auto StartUp Script
	; -------------------------------------------
} ; if !FileExist(IMG_ScrollNoteSupport)
else if !FileExist(Script_ScrollNote) ; No Current Scroll Notes in Use
{
	; -------------------------------------------
	FileDelete, %Script_ScrollNoteStartUp% ; (DELETE) Scroll Note Auto StartUp Script
	; -------------------------------------------
}
else ; All is Ok [Run] All Scroll Notes
{
	; -------------------------------------------
  Loop Files, %Folder_ScrollNoteUser%\ScrollNote_*.ahk
  {
  	; -------------------------------------------
  	Run, %A_LoopFileFullPath%
  	; -------------------------------------------
  }
	; -------------------------------------------
} ; else ; PopUpMenu is Installed
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
