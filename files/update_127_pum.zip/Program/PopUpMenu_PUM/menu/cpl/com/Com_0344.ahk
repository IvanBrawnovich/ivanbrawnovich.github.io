﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(FilePath) ; > Array
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Check] (Script_ScrollNoteStartUp) [Copy] (Script_ScouceScrollNoteStartUp)
; -------------------------------------------
Script_ScrollNoteStartUp := A_Startup "\ScrollNoteStartUp.ahk"
; -------------------------------------------
if !FileExist(Script_ScrollNoteStartUp)
{
	; -------------------------------------------
	Script_ScouceScrollNoteStartUp := "C:\Program Files\PopUpMenu_PUM\menu\cpl\com\scrollnote\ScrollNoteStartUp.ahk"
	; -------------------------------------------
	FileCopy, %Script_ScouceScrollNoteStartUp%, %Script_ScrollNoteStartUp%, 1
	; -------------------------------------------
}
; -------------------------------------------
; [Check] (Script_ScrollNoteStartUp) [Copy] (Script_ScouceScrollNoteStartUp)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Check/Create] (Folder_ScrollNoteUser)
; -------------------------------------------
Folder_ScrollNoteUser := A_AppData "\PopUpMenu_PUM\scrollnote"
; -------------------------------------------
if !FileExist(Folder_ScrollNoteUser)
{
	FileCreateDir, %Folder_ScrollNoteUser%
}
; -------------------------------------------
; [Check/Create] (Folder_ScrollNoteUser)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Get] Next Scroll Note Number, [Set] (Number_ScrollNote) (Script_ScrollNote)
; -------------------------------------------
Number_ScrollNote := 1
Script_ScrollNote := Folder_ScrollNoteUser "\ScrollNote_" Number_ScrollNote ".ahk"
while FileExist(Script_ScrollNote)
{
	Number_ScrollNote := Number_ScrollNote + 1
  Script_ScrollNote := Folder_ScrollNoteUser "\ScrollNote_" Number_ScrollNote ".ahk"
}
; -------------------------------------------
; [Get] Next Scroll Note Number, [Set] (Number_ScrollNote) (Script_ScrollNote)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Replace] Label and Var Names
; [Array_FromFile],                  [Get] (Script_SourceScrollNote) (Array_SourceScrollNote)
; [Array_ScrollNote.Push(ThisLine)], [Set] (Array_ScrollNote)
; -------------------------------------------
Script_SourceScrollNote := "C:\Program Files\PopUpMenu_PUM\menu\cpl\com\scrollnote\Scroll_Gui.ahk"
; -------------------------------------------
Array_SourceScrollNote := Array_FromFile(Script_SourceScrollNote)
; -------------------------------------------
OldLabel := "UpdateTime"
NewLabel := "ScrollNote_" Number_ScrollNote
; -------------------------------------------
Array_ScrollNote := []
; -------------------------------------------
Array_LabelVar := ["ShowAlarmTime", "ShowOldAlarmTime", "FirstTimeLoad", "ScrollGUIOfNote", "Scroll_DataArray", "ScrollTitleOfNote", "F_Scroll_UpdateText", "F_CheckTime", "F_TimeDiff", "F_TimeRightNow", "F_ScrollUpDown", "F_ScrollMove", "L_UpdateTime" ,"L_AlarmAccept" ,"L_AlarmSound" ,"L_AlarmCancel" ,"L_AlarmSet" ,"L_ScrollRoll" ,"L_ScrollEdit" ,"L_EndTL" ,"L_EndTR" ,"L_EndBL" ,"L_EndBR" ,"L_DeleteNote" ,"G_ScrollTop" ,"G_ScrollRoll" ,"G_EndTL" ,"G_ScrollEdit" ,"G_Alarm_BG" ,"G_Edit_Day" ,"G_IMG_Day" ,"G_Edit_Month" ,"G_IMG_Month" ,"G_Text_Year" ,"G_Edit_Hour" ,"G_IMG_Hour" ,"G_Edit_Minute" ,"G_IMG_Min" ,"G_Alarm_Accept" ,"G_Alarm_Sound" ,"G_Alarm_Cancel" ,"G_EndBL" ,"G_EndBR" ,"G_AlarmSet" ,"G_DeleteNote" ,"G_AlarmTime"]
; -------------------------------------------
for Index_1, ThisLine in Array_SourceScrollNote
{
	; -------------------------------------------
	for Index_2, ThisName in Array_LabelVar
	{
		; -------------------------------------------
		if (InStr(ThisLine, ThisName) > 0)
		{
			; -------------------------------------------
			NewName := ThisName "_" Number_ScrollNote
			; -------------------------------------------
			ThisLine := StrReplace(ThisLine, ThisName, NewName)
			; -------------------------------------------
		} ; if (InStr(ThisLine, ThisName) > 0)
	} ; for Index_2, ThisName in Array_LabelVar
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_ScrollNote.Push(ThisLine) ; Adds (AddThis) to End
	; -------------------------------------------
} ; for Index_1, ThisLine in Array_SourceScrollNote
; -------------------------------------------
; [Replace] Label and Var Names
; [Array_FromFile],                  [Get] (Script_SourceScrollNote) (Array_SourceScrollNote)
; [Array_ScrollNote.Push(ThisLine)], [Set] (Array_ScrollNote)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Write] (Script_ScrollNote)
; -------------------------------------------
FileEncoding, UTF-8
; -------------------------------------------
ThisFile := FileOpen(Script_ScrollNote, "rw") ; (361)(9)(Pum_Xml [toolbox0] [Full File Path])
for Index, ThisLine in Array_ScrollNote ; (361)(10)(ThisPumProcessArray)
{
	ThisLine := ThisLine "`r`n"  ; When writing a file this way, use `r`n rather than `n to start a new line.
	ThisFile.Write(ThisLine)
}
ThisFile.Close()
; -------------------------------------------
Sleep, 250
; -------------------------------------------
; [Write] (Script_ScrollNote) ("ScrollNote_" Number_ScrollNote ".ahk)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [Run] (Script_ScrollNote) ("ScrollNote_" Number_ScrollNote ".ahk)
; -------------------------------------------
Run, %Script_ScrollNote%
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
