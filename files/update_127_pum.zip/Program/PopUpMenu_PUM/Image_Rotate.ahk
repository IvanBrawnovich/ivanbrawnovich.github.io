﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Rotate(RotateAngle, Image_In, Image_Out) ; RotateAngle, Image_In, Image_Out > 1 / 0
{
  ; -------------------------------------------
  ; Img_W (Current) Width
  ; Img_H (Current) Height
  ; -------------------------------------------
  if FileExist(Image_In)
  {
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
    RunThis := """" Support_magick """ """ Image_In """ -type TrueColorMatte -define png:color-type=6 -rotate " RotateAngle " """ Image_Out """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
} ; End Image_ResizeImg(Img_W, Img_H, Image_In) ; > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
