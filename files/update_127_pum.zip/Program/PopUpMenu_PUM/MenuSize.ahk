﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MenuSize(DataArray) ; > MenuSize
{
  ; -------------------------------------------
  MenuSize := 0
  ; -------------------------------------------
  LangListArray := DataArray.365.4 ; (365_4)(LangListArray [Language List] [Array])
  ; -------------------------------------------
  ; ScriptType mnu
  AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  ; -------------------------------------------
  StringLower, Lower_AppProcessName, AppProcessName ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  ; -------------------------------------------
  for Index, ThisLang in LangListArray
  {
    ; -------------------------------------------
    File_Menu := "C:\Program Files\PopUpMenu_PUM\menu\mnu\" Lower_AppProcessName "\" ThisLang "\menu_" Lower_AppProcessName "_" ThisLang ".txt" ; (365_2)(ThisLang [Current User language])
    ; -------------------------------------------
    AllMenuArray := ""
    ; -------------------------------------------
    if FileExist(File_Menu) ; Menu Text File Exist / [SET] MenuSize
    {
      ; -------------------------------------------
      LineNum := 2
      FileReadLine, MenuArray, %File_Menu%, LineNum
      ; -------------------------------------------
      MenuArray  := StrSplit(MenuArray, "|", "")
      ; -------------------------------------------
      MenuSize := MenuArray.MaxIndex() ; (302_6)([mnu][cpl] Menu Size [#])
      ; -------------------------------------------
      ; This Process has a Addon
      ; -------------------------------------------
      break
      ; -------------------------------------------
    } ; [End] if FileExist(File_Menu) ; Menu Text File Exist / [SET] MenuSize
    ; -------------------------------------------
  } ; [End] for Index, ThisLang in LangListArray
  ; -------------------------------------------
  return MenuSize
  ; -------------------------------------------
} ; [End] Mnu_MenuSize(DataArray)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
