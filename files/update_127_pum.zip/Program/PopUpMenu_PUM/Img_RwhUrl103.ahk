﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_RwhUrl103(ArrayIn) ; > FileRwhUrl103
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileRwhUrl103 := Img_RwhUrl103(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileRwhUrl103 := Img_RwhUrl103(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileRwhUrl103 := Img_RwhUrl103(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileRwhUrl103
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5  ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn       := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRwhUrl103", UserLang, UserPictureFolder]
    ArrayOut      := Image_PathFolderOrName(ArrayIn)
    FileRwhUrl103 := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(FileRunPng)
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(FileRwhUrl103) ; (103)(Obj_RwhUrl_OpeningAppImage)
    {
      ; -------------------------------------------
      Image_ResizePng(30, 30, FileRunPng, FileRwhUrl103) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRwhUrl103)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileRwhUrl103
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
