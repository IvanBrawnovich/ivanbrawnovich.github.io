﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_544: ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
{
  ; -------------------------------------------
  ; Messure_Man
  ; -------------------------------------------
  ;
  ; (_w300 x h300_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Messure_Man)
  ; global n_544 := 1 ; Start Frame Number
  ; global s_544 := 1 ; Show
  ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Messure_Man)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Messure_Man)
  ; global s_544 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Messure_Man)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Image_PumDim.ahk
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 12
  ; -------------------------------------------
  if (s_544 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_544 > Total_Images) ; 1 Less than Number of Images
    {
      global n_544 := 3
    }
    else
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_254, C:\Program Files\PopUpMenu_PUM\image\gui\(544)_%n_544%.png ; (254_1)(Obj_MsgImg300x300)
      ; -------------------------------------------
      Gui_ObjectSize("254", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_544 := n_544 + 1
      ; -------------------------------------------
    }
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_544, Off ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; End (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
