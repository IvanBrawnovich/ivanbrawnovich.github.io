﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_SelectedColorDisplay.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_173(DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.173.2 == "" or DataArray.173.2 == 1) ; (173_2)(Obj_Pum_MobileTxtColor_Sel [0,1,2])
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumBgText_pumMobileTextColor" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("173", 2, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 1, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      DataArray := Image_GuiControl("166", 1, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      ; -------------------------------------------
    } ; End Selected
    ; -------------------------------------------
    else ; Not Selected
    {
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumBgText" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("173", 1, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      ; -------------------------------------------
    } ; End Not Selected
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    DataArray := Pum_SelectedColorDisplay(DataArray)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (173_1)(GUI Object: [pum] [pumMobileTextColor])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
