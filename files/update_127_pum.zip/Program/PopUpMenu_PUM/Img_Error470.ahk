﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include C:\Program Files\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_Error470(ArrayIn) ; > FileError470
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileError470 := Img_Error470(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileError470 := Img_Error470(ArrayIn)
; -------------------------------------------
ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
FileError470 := Img_Error470(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileError470
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5  ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn      := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileError470", UserLang, UserPictureFolder]
    ArrayOut     := Image_PathFolderOrName(ArrayIn)
    FileError470 := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>    
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\Error470\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileError470)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; -------------------------------------------
      Error470Temp := A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png" ; w52 h52
      ; -------------------------------------------
      if FileExist(Error470Temp)
      {
        FileDelete, %Error470Temp%
      } ; [End] if FileExist(Error470Temp)
      ; -------------------------------------------
      Image_ResizePng(52, 52, FileRunPng, Error470Temp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\Error470\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileError470_" UserLang ".png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; -------------------------------------------
      I1 := "C:\Program Files\PopUpMenu_PUM\image\ico\FileError470_" UserLang ".png" ; w230 h90
      X1 := 0
      Y1 := 0
      ;
      I2 := Error470Temp
      X2 := 9  ; X Position (Left)
      Y2 := 21 ; Y Postion (Down)
      ; -------------------------------------------
      Image_Array := [230, 90, FileError470, I1, X1, Y1, I2, X2, Y2]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\Error470\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] ["C:\Program Files\PopUpMenu_PUM\image\ico\FileError470_" UserLang ".png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; -------------------------------------------
      if FileExist(Error470Temp)
      {
        FileDelete, %Error470Temp%
      } ; [End] if FileExist(Error470Temp)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\Error470Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileError470)
    ; -------------------------------------------
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\Error470\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileError470
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
