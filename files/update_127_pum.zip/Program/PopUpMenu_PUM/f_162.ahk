﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_GetRestoreFile.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
;~ #Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_162(DataArray) ; (162)(Obj_Pum_Backup)
{
	; -------------------------------------------
	if (DataArray.162.2 == "" or DataArray.162.2 == 0 or DataArray.162.2 == 1) ; Was NOT Selected, [SET] to Selected
	{
		; -------------------------------------------
		DataArray := Image_GuiControl("162", 2, 1, DataArray) ; (162)(Obj_Pum_Backup)
		; -------------------------------------------
    DataArray.366.5 := "pumBackup" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    Gui, PopUpMenu:Color, 04e122 ; Green
    ; -------------------------------------------
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
	}
	else if (DataArray.162.2 == 2) ; Was Selected, [SET] to NOT Selected
	{
		; -------------------------------------------
		DataArray.162.4 := "" ; (162)(04)(Obj_Pum_Restore_Img [Zip File Path])
		; -------------------------------------------
		DataArray := Image_GuiControl("162", 1, 1, DataArray) ; (162)(Obj_Pum_Backup)
		; -------------------------------------------
		Sys_EnableDisable("Enable") ; "Enable" or "Disable"
		; -------------------------------------------
		Gui, PopUpMenu:Color, e7d8fe ; Purple
		; -------------------------------------------
	} ; Was NOT Selected, [SET] to Selected
	; -------------------------------------------
	;
	; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
