﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_126(DataArray) ; (126_1)(Obj_Cpl_Menu2)
{
  ; -------------------------------------------
  if (DataArray.126.2 == 1) ; (126_2)(Obj_Cpl_Menu2_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.300.2 := 2 ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    DataArray.300.3 := 0 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
    DataArray.300.4 := 0 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    DataArray.300.5 := 0 ; (300_5)(Cpl_Number_000x [X_X_X_#])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  GuiControl, Focus, g_116 ; (116_1)(Obj_CplMnu_List100)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
