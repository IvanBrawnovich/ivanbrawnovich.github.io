﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_PDFtoIMG(ItemIn, ItemOut) ; PDF or IMG In, PDF or IMG Out > ItemOut
{
  ; -------------------------------------------
  if FileExist(ItemIn)
  {
    ; -------------------------------------------
    Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
		RunThis := """" Support_magick """ convert """ ItemIn """ """ ItemOut """"
    Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return ItemOut
  ; -------------------------------------------
} ; End Image_ResizeImg(Resize_W, Resize_H, Image_In) ; > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
