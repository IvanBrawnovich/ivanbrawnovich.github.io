﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
;
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_086(DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
{
  ; -------------------------------------------
  v_086_2 := DataArray.86.2 ; (086_2)(Obj_Tom_MenuControlKey_Sel [0,1,2,3])
  ; -------------------------------------------
  if (v_086_2 == 1) ; (086_2)(Obj_Tom_MenuControlKey_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray.366.5 := "mnu_cpl_key" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Pum_Building_Construct
    global s_521 := 0 ; Hide
    SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    global ShowAnimationChange := 0
    ;
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Pum_Building_Construct
    ;
    ; -------------------------------------------
    HasConnection := InternetConnectCheck()
    ; -------------------------------------------
    if (HasConnection == 0)
    {
      DataArray := Image_GuiControl("084", "1b", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
    }
    else
    {
      DataArray := Image_GuiControl("084", "1a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
    }
    ; -------------------------------------------
    DataArray := Image_GuiControl("086", 2, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
    ; -------------------------------------------
    if (HasConnection == 0)
    {
      DataArray := Image_GuiControl("083", "1b", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
    }
    else
    {
      DataArray := Image_GuiControl("083", "1a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
    }
    ; -------------------------------------------
    ;
    DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
    DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
    DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
