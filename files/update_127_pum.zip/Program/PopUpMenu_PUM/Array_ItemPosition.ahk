﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Array_ItemPosition(ThisArray, CheckThis, PosCount) ; Array_ItemPosition(ThisArray, CheckThis, PosCount) ; > Position in Array
{
  ; -------------------------------------------
  ; Returns 0 if Not in Array
  ; -------------------------------------------
  if (PosCount == "")
  {
    PosCount := 1
  }
  ; Returns the number of times CheckThis is in the ThisArray
  Item_Position := 0
  PosNum := 0
  for Index, ThisItem in ThisArray
  {
    if (ThisItem == CheckThis)
    {
      PosNum := PosNum + 1
      if (PosNum == PosCount)
      {
        Item_Position := Index
      }
    } ; End (ThisItem == CheckThis)
  } ; End for Index, ThisItem in ThisArray
  return Item_Position
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
