﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Default_Application(Ext) ; > Opening Application
{
  ; -------------------------------------------
  StringLower, Lower_Ext, Ext
  ; -------------------------------------------
  if (SubStr(Lower_Ext, 1, 1) != ".")
  {
    Lower_Ext := "." Lower_Ext
  }
  ; -------------------------------------------
  DllCall("shlwapi\AssocQueryString", Int, 0, Int, 2, Str, Lower_Ext, Ptr, 0, Ptr, 0, UIntP, vChars)
  VarSetCapacity(vPath, vChars << !!A_IsUnicode, 0)
  DllCall("shlwapi\AssocQueryString", Int, 0, Int, 2, Str, Lower_Ext, Ptr, 0, Str, vPath, UIntP, vChars)
  ; -------------------------------------------
  if (vPath == "")
  {
    vPath := "NoDefault"
  }
  else if (InStr(vPath, "OpenWith.exe") > 0)
  {
    vPath := "NoDefault"
  }
  ; -------------------------------------------
  return vPath
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
