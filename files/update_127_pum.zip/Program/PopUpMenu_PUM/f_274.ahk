﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Validate.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Vars.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_PumDim.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Check.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_274(DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
{
  ; -------------------------------------------
  if (DataArray.274.2 != 3) ; (274_2)(Obj_Pum_PumColumnDown_Sel [0,1])
  {
    ; -------------------------------------------
    global PumLock
    if (PumLock == "")
    {
      ; -------------------------------------------
      global PumLock := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (PumLock == 0)
    {
      ; -------------------------------------------
      global PumLock := 1
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
      ; -------------------------------------------
      Check_I := ""
      Check_C := XmlColumnsX - 1
      Check_R := ""
      ; -------------------------------------------
      Result_Msg := Pum_Validate(Check_I, Check_C, Check_R, DataArray) ; > Result Array
      ; -------------------------------------------
      if (Result_Msg == "Ok" && Check_C > 0)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (PumColumn_Dn) (X)
        ; -------------------------------------------
        XmlColumnsX := Check_C
        DataArray.362.4 := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        XmlIconSize := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
        XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
        XmlRowsY    := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
        ; -------------------------------------------
        Pum_W := XmlColumnsX * XmlIconSize
        Pum_H := XmlRowsY * XmlIconSize
        ; -------------------------------------------
        DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
        DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      }
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; All with DoNotEnter Sign until Pum_Check
      ; Determines if Pum Size is beyond the bounds of possibility
      ; -------------------------------------------
      DataArray := Image_GuiControl("261", 3, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      DataArray := Image_GuiControl("262", 3, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      DataArray := Image_GuiControl("267", 3, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      DataArray := Image_GuiControl("268", 3, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      DataArray := Image_GuiControl("273", 3, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      DataArray := Image_GuiControl("274", 3, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (Result_Msg == "Ok")
      {
        ; -------------------------------------------
        DataArray.362.38 := "C" ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        ; -------------------------------------------
        ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        Temp_Display_Img := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
        ; -------------------------------------------
        FileDelete, %Temp_Display_Img%
        ; -------------------------------------------
        DataArray := Pum_Vars(DataArray) ; > DataArray
        ; -------------------------------------------
        ThisPumProcessFolder := DataArray.361.8  ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        Image_PumDim(DataArray) ; > Nothing
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Pum_Check(DataArray) ; > DataArray
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      global PumLock := 0
      ; -------------------------------------------
    } ; End (PumLock == 0)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
