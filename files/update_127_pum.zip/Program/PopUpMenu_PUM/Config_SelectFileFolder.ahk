﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
BreakTime := A_TickCount + 2000
SetTitleMatchMode, 1
while !WinExist("PUM -" . "ahk_class #32770")
{
  if (A_TickCount > BreakTime)
  {
    break
  }
}
; -------------------------------------------
;
; -------------------------------------------
WinSet, AlwaysOnTop, Off, Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI ; (ShortcutGui)(AlwaysOnTop)(Off)
; -------------------------------------------
SetTitleMatchMode, 1
WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Loop ; Infinite Loop
{
  ; -------------------------------------------
  Sleep, 100
  ; -------------------------------------------
  SetTitleMatchMode, 1
  if !WinExist("PUM -" . "ahk_class #32770")
  {
    ; -------------------------------------------
    if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Shortcut Gui DOES NOT Exist
    {
      ; -------------------------------------------
      WinActivate
      global AlwaysOnTop_ShortcutGui := 1
      WinSet, AlwaysOnTop, On, Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI ; (ShortcutGui)(AlwaysOnTop)(On)
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Shortcut Gui DOES NOT Exist
  {
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  } ; [End] if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Shortcut Gui DOES NOT Exist
  else if !WinExist("ahk_class ViewControlClass")
  {
    if !WinExist("ahk_class ViewControlClass")
    {
      ; -------------------------------------------
      SetTitleMatchMode, 1
      ; -------------------------------------------
      Window_Active := WinActive("PUM -" . "ahk_class #32770") ; (ShortcutGui)
      ; -------------------------------------------
      WinGet, ShortcutGui_Id, ID , Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
      WinSet, AlwaysOnTop, Off, ahk_id %ShortcutGui_Id%
      ; -------------------------------------------
      WinSet, Top, , ahk_id %FileSelectGui_Id%
      WinSet, Redraw, , ahk_id %FileSelectGui_Id%
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (High Definition Screens)(Factor := A_ScreenDPI / 100)
    ; -------------------------------------------
    if (A_ScreenDPI != 96) ; (High Definition Screens)(Factor := A_ScreenDPI / 100)
    {
      ; -------------------------------------------
      Factor := A_ScreenDPI / 100
      FactorX := Factor
      FactorY := Factor
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      FactorX := 1
      FactorY := 1
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; (High Definition Screens)(Factor := A_ScreenDPI / 100)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Center Window
    ; [SET] XmlPosX XmlPosY
    ; -------------------------------------------
    ScreenWidth := A_ScreenWidth
    ScreenHeight := A_ScreenHeight
    ; ------------------------------------------- Pum Position
    if (A_ScreenHeight > 601)
    {
      Win_W := 900 * FactorX ; 611 is Min (Cannot make Smaller)
      Win_H := 720 * FactorY
    }
    else
    {
      Win_W := 900 * FactorX
      Win_H := 590 * FactorY
    }
    ; -------------------------------------------
    Win_X := Round((A_ScreenWidth - Win_W) / 2)
    Win_Y := Round((A_ScreenHeight - Win_H) / 2)
    ; -------------------------------------------
    Win_Y := Win_Y - 20
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Center Window
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Center Window in Screen
    ; -------------------------------------------
    CoordMode, Pixel , Screen
    WinMove, ahk_id %FileSelectGui_Id%, , Win_X, Win_Y, Win_W, Win_H
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
} ; [End] Loop ; Infinite Loop
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
