﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_ReplaceItem.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Subtract.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Display.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Shortcut.ahk
#Include C:\Program Files\PopUpMenu_PUM\KeyArray_Validate.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
#Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_123(DataArray) ; (123_1)(Obj_Key_EditFeild_TextInput)
{
  ; -------------------------------------------
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------
  if (ScriptType == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    Gui, PopUpMenu:Submit, NoHide
    ; Edit Var Current Value
    Pre_Key := DataArray.123.3 ; (123_3)(Obj_Key_EditFeild_TextInput_Val [Text Value])
    Key_ArrayNumbers := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
    ; Edit Feild Current Value
    GuiControlGet, Obj_Key_EditFeild_TextInput_Val, PopUpMenu:, g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
    ; -------------------------------------------
    if (Obj_Key_EditFeild_TextInput_Val != "") ; (123_1)(Obj_Key_EditFeild_TextInput)
    {
      if (Pre_Key != "") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      {
        PreArrayKey := "~" Pre_Key "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        ArrayKey := "~" Obj_Key_EditFeild_TextInput_Val "~" ; (123_1)(Obj_Key_EditFeild_TextInput)
        Key_ArrayNumbers := Array_ReplaceItem(Key_ArrayNumbers, PreArrayKey, ArrayKey) ; (301_2)(Key_ArrayNumbers [Array])
      }
      else
      {
        ArrayKey := "~" Obj_Key_EditFeild_TextInput_Val "~" ; (123_1)(Obj_Key_EditFeild_TextInput)
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, ArrayKey, "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
    } ; (123)_(---)(Edit Text Input)_(2)Select_(3)Value
    else ; (123)(Edit Text Input) is Empty
    {
      if (Pre_Key != "") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      {
        PreArrayKey := "~" Pre_Key "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        Key_ArrayNumbers := Array_Subtract(Key_ArrayNumbers, PreArrayKey, 0) ; (301_2)(Key_ArrayNumbers [Array])
      }
    } ; End (123)(Edit Text Input) is Empty
    ; -------------------------------------------
    DataArray.301.2 := Key_ArrayNumbers ; (301_2)(Key_ArrayNumbers [Array])
    DataArray.123.3 := Obj_Key_EditFeild_TextInput_Val ; (123_3)(Obj_Key_EditFeild_TextInput_Val [Text Value])
    ; -------------------------------------------
    DataArray := KeyArray_Display(DataArray) ; > DataArray
    DataArray := KeyArray_Shortcut(DataArray) ; > DataArray
    DataArray := KeyArray_Validate(DataArray)
    ; (105_1)(GUI Object: <Displayed Text> Top 2)/(141_1)(GUI Object: <Displayed Text> Title 3)
    LimitedArray := [["v_105_1"], ["v_141_1"]] ; (105_1)(Obj_DisplayText_Top2)/(141_1)(Obj_DisplayText_Title3)
    DataArray.363.9 := LimitedArray ; (363_9)(LinitDataArray [Limited DataArray])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
    Send, {End}
    ; -------------------------------------------
  } ; (366_5)(Script Type) (key)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; (123)_(---)(Edit Text Input)_(2)Select_(3)Value
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
