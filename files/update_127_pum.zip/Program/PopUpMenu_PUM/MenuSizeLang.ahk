﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MenuSizeLang(DataArray) ; > MenuSize
{
  ; -------------------------------------------
  MenuSize := 0
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  ; -------------------------------------------
  StringLower, Lower_AppProcessName, AppProcessName ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  ; -------------------------------------------
  File_Menu := "C:\Program Files\PopUpMenu_PUM\menu\mnu\" Lower_AppProcessName "\" UserLang "\menu_" Lower_AppProcessName "_" UserLang ".txt" ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  AllMenuArray := ""
  ; -------------------------------------------
  if FileExist(File_Menu) ; Menu Text File Exist / [SET] MenuSize
  {
    ; -------------------------------------------
    LineNum := 2
    FileReadLine, MenuArray, %File_Menu%, LineNum
    ; -------------------------------------------
    MenuArray  := StrSplit(MenuArray, "|", "")
    ; -------------------------------------------
    MenuSize := MenuArray.MaxIndex() ; (302_6)([mnu][cpl] Menu Size [#])
    ; -------------------------------------------
  } ; [End] if FileExist(File_Menu) ; Menu Text File Exist / [SET] MenuSize
  ; -------------------------------------------
  return MenuSize
  ; -------------------------------------------
} ; [End] MenuSizeLang(DataArray) ; > MenuSize
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
