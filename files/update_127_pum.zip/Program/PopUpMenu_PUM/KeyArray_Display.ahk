﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyArray_Display(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ; Creates
  ; (301_7)([key] KeyArray_Display [String] [by Lang])
  ; From
  ; (301_2)([key] KeyArray_Numbers [Array])
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_301_2 := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
    v_365_2 := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  Ckeck_Array := v_301_2.1 ; (301_2)(Key_ArrayNumbers [Array])
  ; -------------------------------------------
  if (Ckeck_Array != "") ; Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
  {
    ; -------------------------------------------
    v_301_7 := "" ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
    ; -------------------------------------------
    for Index, This_KeyNum in v_301_2 ; (301_2)(Key_ArrayNumbers [Array])
    {
      ; -------------------------------------------
      AddThisKey := ""
      ; -------------------------------------------
      if (SubStr(This_KeyNum, 1, 1) == "~") ; User Written Text
      {
        ; -------------------------------------------
        This_KeyStroke := SubStr(This_KeyNum, 2, StrLen(This_KeyNum) - 2)
        AddThisKey := This_KeyStroke ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(008)") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt down]" / "[Alt Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt up]" / "[Alt Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; (008_1)(GUI Object: [key] Alt)
        {
          ; -------------------------------------------
          ; "[Alt"] / "[Alt]"
          ; -------------------------------------------
          if (v_365_2 != "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else
          {
            AddThisKey := "[Sçnk]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (008_1)(GUI Object: [key] Alt)
      ; -------------------------------------------
      else if (This_KeyNum == "(010)") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt left down]" / "[LAlt Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt links runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt left down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt izquierdo abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt gauche bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt sinistra giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt lewy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt esquerdo baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt левый вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt vänster ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk col aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt left up]" / "[LAlt Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt linke oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt left up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt izquierdo arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt gauche en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt sinistra su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt lewy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt esquerdo levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt левый bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt vänster upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk col yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; "[Alt left]" / "[LAlt]"
        {
          ; -------------------------------------------
          ; "[Alt left]" / "[LAlt]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt linke]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt left]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt izquierdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt gauche]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt sinistra]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt lewy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt esquerdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt левый]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt vänster]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk col]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (010_1)(GUI Object: [key] Alt Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(011)") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(009)") ; (009_1)(GUI Object: [key] Alt Down)
        {
          ; -------------------------------------------
          ; "[Alt right down]" / "[RAlt Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt rechte runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt right down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt derecho abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt droite bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt destro giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt prawy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt direita baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt правой вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt höger ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk sağ aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(012)") ; (012_1)(GUI Object: [key] Alt Up)
        {
          ; -------------------------------------------
          ; "[Alt right up]" / "[RAlt Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt rechte oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt right up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt derecho arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt droite en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt destro su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt prawy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt direita levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt правой bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt höger upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk sağ yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; "[Alt right]" / "[RAlt]"
        {
          ; -------------------------------------------
          ; "[Alt right]" / "[RAlt]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt rechte]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt right]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt derecho]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt droite]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt destro]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt prawy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt direita]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt правой]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Alt höger]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Sçnk sağ]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (011_1)(GUI Object: [key] Alt Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(013)") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        ; -------------------------------------------  
        ; "[Caps]" / "[CapsLock]"
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Fest]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Caps]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Bloq May]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Verr. maj]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Bloc Maiusc]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Malú]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Büyük Harf]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (This_KeyNum == "(015)") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl left down]" / "[LCtrl Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg links runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl left down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl izquierdo abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl gauche bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl sinistra giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl lewy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl esquerdo baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl левый вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl vänster ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol col aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl left up]" / "[LCtrl Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg linke oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl left up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl izquierdo arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl gauche en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl sinistra su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl lewy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl esquerdo levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl левый bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl vänster upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol col yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl left]" / "[LCtrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl left]" / "[LCtrl]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg linke]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl left]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl izquierdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl gauche]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl sinistra]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl lewy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl esquerdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl левый]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl vänster]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol col]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End "[Ctrl left]" / "[LCtrl]"
      } ; End (015_1)(GUI Object: [key] Ctrl Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(016)") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl right down]" / "[RCtrl Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg rechte runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl right down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl derecho abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl droite bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl destro giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl prawy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl direita baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl правой вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl höger ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol sağ aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl right up]" / "[RCtrl Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg rechte oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl right up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl derecho arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl droite en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl destro su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl prawy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl direita levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl правой bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl höger upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol sağ yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl right]" / "[RCtrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl right]" / "[RCtrl]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg rechte]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl right]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl derecho]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl droite]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl destro]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl prawy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl direita]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl правой]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl höger]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol sağ]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End "[Ctrl right]" / "[RCtrl]"
      } ; End (016_1)(GUI Object: [key] Ctrl Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(018)") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------  
        ; "[Enter]" / "[Enter]"
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Eingabe]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Enter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Entrar]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Entrée]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Invio]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Retur]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Giriş Tuşu]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      } ; End (018_1)(GUI Object: [key] Enter)
      ; -------------------------------------------
      else if (This_KeyNum == "(020)") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------  
        ; "[Esc]" / "[Esc]"
        ; -------------------------------------------
        if (v_365_2 == "de" or v_365_2 == "en" or v_365_2 == "es" or v_365_2 == "it" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Esc]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Éch]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Vazgeç]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      } ; End (020_1)(GUI Object: [key] Esc)
      ; -------------------------------------------
      else if (This_KeyNum == "(022)") ; (022_1)(GUI Object: [key] F1)
      {
        ; -------------------------------------------
        AddThisKey := "[F1]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (This_KeyNum == "(023)") ; (023_1)(GUI Object: [key] F2)
      {
        ; -------------------------------------------
        AddThisKey := "[F2]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(024)") ; (024_1)(GUI Object: [key] F3)
      {
        ; -------------------------------------------
        AddThisKey := "[F3]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(025)") ; (025_1)(GUI Object: [key] F4)
      {
        ; -------------------------------------------
        AddThisKey := "[F4]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(026)") ; (026_1)(GUI Object: [key] F5)
      {
        ; -------------------------------------------
        AddThisKey := "[F5]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(027)") ; (027_1)(GUI Object: [key] F6)
      {
        ; -------------------------------------------
        AddThisKey := "[F6]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(028)") ; (028_1)(GUI Object: [key] F7)
      {
        ; -------------------------------------------
        AddThisKey := "[F7]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(029)") ; (029_1)(GUI Object: [key] F8)
      {
        ; -------------------------------------------
        AddThisKey := "[F8]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(030)") ; (030_1)(GUI Object: [key] F9)
      {
        ; -------------------------------------------
        AddThisKey := "[F9]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(031)") ; (031_1)(GUI Object: [key] F10)
      {
        ; -------------------------------------------
        AddThisKey := "[F10]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(032)") ; (032_1)(GUI Object: [key] F11)
      {
        ; -------------------------------------------
        AddThisKey := "[F11]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(033)") ; (033_1)(GUI Object: [key] F12)
      {
        ; -------------------------------------------
        AddThisKey := "[F12]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(034)") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        ; -------------------------------------------
        ; "[# 0]" / "[Numpad0]"
        ; -------------------------------------------
        AddThisKey := "[# 0]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(035)") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        ; -------------------------------------------
        ; "[# 1]" / "[Numpad1]"
        ; -------------------------------------------
        AddThisKey := "[# 1]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(036)") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        ; -------------------------------------------
        ; "[# 2]" / "[Numpad2]"
        ; -------------------------------------------
        AddThisKey := "[# 2]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(037)") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        ; -------------------------------------------
        ; "[# 3]" / "[Numpad3]"
        ; -------------------------------------------
        AddThisKey := "[# 3]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(038)") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        ; -------------------------------------------
        ; "[# 4]" / "[Numpad4]"
        ; -------------------------------------------
        AddThisKey := "[# 4]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(039)") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        ; -------------------------------------------
        ; "[# 5]" / "[Numpad5]"
        ; -------------------------------------------
        AddThisKey := "[# 5]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(040)") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        ; -------------------------------------------
        ; "[# 6]" / "[Numpad6]"
        ; -------------------------------------------
        AddThisKey := "[# 6]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(041)") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        ; -------------------------------------------
        ; "[# 7]" / "[Numpad7]"
        ; -------------------------------------------
        AddThisKey := "[# 7]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(042)") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        ; -------------------------------------------
        ; "[# 8]" / "[Numpad8]"
        ; -------------------------------------------
        AddThisKey := "[# 8]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(043)") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        ; -------------------------------------------
        ; "[# 9]" / "[Numpad9]"
        ; -------------------------------------------
        AddThisKey := "[# 9]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(044)") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        ; -------------------------------------------
        ; "[# +]" / "[NumpadAdd]"
        ; -------------------------------------------
        AddThisKey := "[# +]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(045)") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        ; -------------------------------------------
        ; "[# /]" / "[NumpadDiv]"
        ; -------------------------------------------
        AddThisKey := "[# /]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(046)") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        ; -------------------------------------------
        ; "[# .]" / "[NumpadDot]"
        ; -------------------------------------------
        AddThisKey := "[# .]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(047)") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        ; -------------------------------------------  
        ; "[# Enter]" / "[NumpadEnter]"
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Eingabe]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Enter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Entrar]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Entrée]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Invio]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Retur]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[# Giriş Tuşu]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(048)") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        ; -------------------------------------------
        ; "[# *]" / "[NumpadMult]"
        ; -------------------------------------------
        AddThisKey := "[# *]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(049)") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        ; -------------------------------------------
        ; "[# -]" / "[NumpadSub]"
        ; -------------------------------------------
        AddThisKey := "[# -]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(050)") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift down]" / "[Shift Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift up]" / "[Shift Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; (050_1)(GUI Object: [key] Shift)
        {
          ; -------------------------------------------
          ; "[Shift]" / "[Shift]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (050_1)(GUI Object: [key] Shift)
      ; -------------------------------------------
      else if (This_KeyNum == "(052)") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift left down]" / "[LShift Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch links runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift left down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús izquierdo abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj gauche bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc sinistra giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift lewy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift esquerdo baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift левый вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift vänster ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst col aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift left up]" / "[LShift Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch linke oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift left up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús izquierdo arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj gauche en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc sinistra su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift lewy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift esquerdo levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift левый bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift vänster upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst col yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; "[Shift left]" / "[LShift]"
        {
          ; -------------------------------------------
          ; "[Shift left]" / "[LShift]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch linke]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift left]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch izquierdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj gauche]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc sinistra]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift lewy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift esquerdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift левый]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift vänster]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst col]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (052_1)(GUI Object: [key] Shift Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(053)") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(051)") ; (051_1)(GUI Object: [key] Shift Down)
        {
          ; -------------------------------------------
          ; "[Shift right down]" / "[RShift Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch rechte runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift right down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús derecho abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj droite bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc destro giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift prawy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift direita baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift правой вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift höger ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst sağ aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else if (Next_KeyNum_1 == "(054)") ; (054_1)(GUI Object: [key] Shift Up)
        {
          ; -------------------------------------------
          ; "[Shift right up]" / "[RShift Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch rechte oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift right up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús derecho arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj droite en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc destro su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift prawy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift direita levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift правой bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift höger upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst sağ yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
        else ; "[Shift right]" / "[RShift]"
        {
          ; -------------------------------------------
          ; "[Shift right]" / "[RShift]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Umsch rechte]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift right]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Mayús derecho]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maj droite]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Maiusc destro]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift prawy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift direita]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Shift правой]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Skift höger]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Üst sağ]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        }
      } ; End (053_1)(GUI Object: [key] Shift Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(055)") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        AddThisKey := "[]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        ; -------------------------------------------
        ; "[Tab]" / "[Tab]"
        ; -------------------------------------------
        if (v_365_2 == "de" or v_365_2 == "en" or v_365_2 == "es" or v_365_2 == "fr" or v_365_2 == "it" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Tab]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Tabb]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Sekme]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      } ; End (055_1)(GUI Object: [key] Tab)
      ; -------------------------------------------
      else if (This_KeyNum == "(057)") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win down]" / "[Win Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win up]" / "[Win Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else ; "[Win]" / "[Win]"
        {
          ; -------------------------------------------
          ; "[Win]" / "[Win]"
          ; -------------------------------------------
          AddThisKey := "[Win]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          ; -------------------------------------------
        } ; End "[Win]" / "[Win]"
      } ; End (057_1)(GUI Object: [key] Windows Key)
      ; -------------------------------------------
      else if (This_KeyNum == "(059)") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win left down]" / "[LWin Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win links runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win left down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win izquierdo abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win gauche bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sinistra giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win lewy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win esquerdo baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win левый вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win vänster ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win col aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win left up]" / "[LWin Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win linke oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win left up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win izquierdo arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win gauche en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sinistra su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win lewy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win esquerdo levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win левый bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win vänster upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win col yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else
        {
          ; -------------------------------------------
          ; "[Win left]" / "[LWin]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win linke]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win left]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win izquierdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win gauche]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sinistra]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win lewy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win esquerdo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win левый]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win vänster]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win col]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End "[Win left]" / "[LWin]"
      } ; End (059_1)(GUI Object: [key] Windows Key Left)
      ; -------------------------------------------
      else if (This_KeyNum == "(060)") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)
        {
          ; -------------------------------------------
          ; "[Win right down]" / "[RWin Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win rechte runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win right down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win derecho abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win droite bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win destro giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win prawy na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win direita baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win правой вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win höger ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sağ aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ;  -------------------------------------------
        } ; End (058_1)(GUI Object: [key] Windows Key Down)
        else if (Next_KeyNum_1 == "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)
        {
          ; -------------------------------------------
          ; "[Win right up]" / "[RWin Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win rechte oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win right up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win derecho arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win droite en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win destro su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win prawy w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win direita levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win правой bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win höger upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sağ yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (061_1)(GUI Object: [key] Windows Key Up)
        else
        {
          ; -------------------------------------------
          ; "[Win right]" / "[RWin]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win rechte]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win right]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win derecho]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win droite]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win destro]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win prawy]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win direita]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win правой]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win höger]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Win sağ]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End "[Win right]" / "[RWin]"
      } ; End (060_1)(GUI Object: [key] Windows Key Right)
      ; -------------------------------------------
      else if (This_KeyNum == "(074)") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        Next_KeyNum_1 := v_301_2[Index + 1] ; (301_2)(Key_ArrayNumbers [Array])
        ; -------------------------------------------
        if (Next_KeyNum_1 == "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)
        {
          ; -------------------------------------------
          ; "[Ctrl down]" / "[Ctrl Down]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl down]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl abajo]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl bas]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl giù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl na dół]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl baixa]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl вниз]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl ner]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol aşağı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (014_1)(GUI Object: [key] Ctrl Down)
        else if (Next_KeyNum_1 == "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)
        {
          ; -------------------------------------------
          ; "[Ctrl up]" / "[Ctrl Up]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl up]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl arriba]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl en haut]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl su]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl w górę]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl levanta]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl bверх]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Ctrl upp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol yukarı]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End (017_1)(GUI Object: [key] Ctrl Up)
        else ; "[Ctrl]" / "[Ctrl]"
        {
          ; -------------------------------------------
          ; "[Ctrl]" / "[Ctrl]"
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Strg]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            AddThisKey := "[Kontrol]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          else
          {
            AddThisKey := "[Ctrl]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
          }
          ; -------------------------------------------
        } ; End "[Ctrl]" / "[Ctrl]"
      } ; End (074_1)(GUI Object: [key] Ctrl)
      ; -------------------------------------------
      else if (This_KeyNum == "(075)") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        ; "[Del]" / "[Delete]"
        ; -------------------------------------------
        if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Del]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Entf]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Supr]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Suppr]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Canc]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Sil]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(076)") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        ; "[End]" / "[End]"
        ; -------------------------------------------
        if (v_365_2 == "de" or v_365_2 == "es" or v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Fin]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[End]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Fine]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Fim]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Son]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(077)") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        ; "[Home]" / "[Home]"
        ; -------------------------------------------
        if (v_365_2 == "en" or v_365_2 == "it" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Home]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Pos1]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Inicio]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Origine]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Önceki]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(078)") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        ; "[Insert]" / "[Insert]"
        ; -------------------------------------------
        if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Insert]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr" or v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Ins]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Einfg]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Insertar]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Inserir]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Ekle]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(079)") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        ; "[PgDn]" / "[PgDn]"
        ; -------------------------------------------
        if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PgDn]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Bild runter]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Av Pág]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PB suiv]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PgGiù]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Sonraki]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (This_KeyNum == "(080)") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        ; "[PgUp]" / "[PgUp]"
        ; -------------------------------------------
        if (v_365_2 == "en" or v_365_2 == "pl" or v_365_2 == "pt" or v_365_2 == "ru" or v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PgUp]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Bild oben]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Re Pág]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PB préc]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[PgSu]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          AddThisKey := "[Önceki]" ; (301_7)([key] KeyArray_Display [String] [by Lang])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (Index > 1) ; Add "+" to Second to Last Key Entry
      {
        if (AddThisKey != "")
        {
          AddThisKey := "+" AddThisKey
        }
      }
      ; -------------------------------------------
      v_301_7 := v_301_7 AddThisKey ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
      ; -------------------------------------------
    } ; End for Index, This_KeyNum in (301_2)([key] [Line 3] Keystroke Array)
    ; -------------------------------------------
    DataArray.301.7 := v_301_7 ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
    ; -------------------------------------------
  } ; End if (Ckeck_Array != "")
  ; -------------------------------------------
  else
  {
    DataArray.301.7 := "" ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
  }
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
