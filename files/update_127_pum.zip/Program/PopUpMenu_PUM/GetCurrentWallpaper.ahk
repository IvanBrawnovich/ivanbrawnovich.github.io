#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
BinaryToText(binaryData)
{
	; -------------------------------------------
	stringData := ""
	Loop, % StrLen(binaryData)
	{
		if (A_Index <= 24)
		{
			continue
		}
		string := ""
		hex := SubStr(binaryData, 2*A_Index - 1, 2)
		stringData .= Chr("0x" . hex)
	}
	return stringData
	; -------------------------------------------
}
; -------------------------------------------
GetCurrentWallpaper()
{
	; -------------------------------------------
  RegRead, TranscodedImageCache, HKEY_CURRENT_USER, Control Panel\Desktop, TranscodedImageCache
  WallpaperPath := % BinaryToText(TranscodedImageCache)
	return WallpaperPath
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
