﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; This Function used in CplMnu_MenuDisplay.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MkbAdobeKeyStroke(ThisMenuItem, AppProcessName, ThisLang) ; MkbAdobeKeyStroke(ThisMenuItem, AppProcessName, ThisLang) ; > Keystroke -OR- ""
{
  ; -------------------------------------------
  File_MkbKeys := ""
  Return_Keystroke := ""
  CommandName := ""
  Keystroke := ""
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Find "Keyboard Shortcuts.psp"
  ; [SET] File_MkbKeys to "Keyboard Shortcuts.psp" File Path
  ; -------------------------------------------
  Loop Files, %A_AppData%\Adobe\Keyboard Shortcuts.psp, R
  {
    ; -------------------------------------------
    ThisFilePath := A_LoopFileFullPath
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; Check if AppProcessName is in This file Path Name
    ; -------------------------------------------
    StringLower, CheckThisFilePath, ThisFilePath
    if (InStr(CheckThisFilePath, AppProcessName) > 0)
    { 
      File_MkbKeys := ThisFilePath
    } ; [End] if (InStr(CheckThisFilePath, AppProcessName) > 0)
    ; -------------------------------------------
  } ; [End] Loop Files, %A_AppData%\Adobe\Keyboard Shortcuts.psp, R
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; in the case (Keyboard Shortcuts.psp) Does Not Exist
  ; This would mean User has Never Mofilied a Photoshop Keystroke
  ;
  ; (_15-Jul-2022_14-28-39_)
  ; Currently Only Photoshop Plugin
  ; -------------------------------------------
  StringLower, Check_AppProcessName, AppProcessName
  ; -------------------------------------------
  if !FileExist(File_MkbKeys)
  {
    if (Check_AppProcessName == "photoshop")
    {
      File_MkbKeys := "C:\Program Files\PopUpMenu_PUM\menu\mnu\" AppProcessName "\" ThisLang "\Keyboard Shortcuts.psp"
    }
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  if FileExist(File_MkbKeys) ; "Keyboard Shortcuts.psp" Was NOT Found
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Find "Keyboard Shortcuts Primary.psp"
    ; [SET] File_MkbKeys to "Keyboard Shortcuts Primary.psp" File Path
    ; -------------------------------------------
    Loop Files, %A_AppData%\Adobe\Keyboard Shortcuts Primary.psp, R
    {
      ; -------------------------------------------
      ThisFilePath := A_LoopFileFullPath
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; Check if AppProcessName is in This file Path Name
      ; -------------------------------------------
      StringLower, CheckThisFilePath, ThisFilePath
      if (InStr(CheckThisFilePath, AppProcessName) > 0)
      { 
        File_MkbKeys := ThisFilePath
      } ; [End] if (InStr(CheckThisFilePath, AppProcessName) > 0)
      ; -------------------------------------------
    } ; [End] Loop Files, %A_AppData%\Adobe\Keyboard Shortcuts.psp, R
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if FileExist(File_MkbKeys) ; "Keyboard Shortcuts.psp" Was NOT Found
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ;
  ; -------------------------------------------
  if FileExist(File_MkbKeys) ; "Keyboard Shortcuts.psp" -OR- 
  {
    ; -------------------------------------------
    Array_MkbKeys := Array_FromFile(File_MkbKeys) ; > Array
    ; -------------------------------------------
    for Index, ThisLine in Array_MkbKeys
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<command ") > 0) ; <command kind="dynamic" name="Lens Correction"> (NEXT LINE) <shortcut>Shift+Ctrl+R</shortcut>
      {
        ; -------------------------------------------
        CommandName := ThisLine
        ; -------------------------------------------
        NamePos := InStr(CommandName, "name=")
        StrPos := NamePos + StrLen("name=")
        CommandName := SubStr(CommandName, StrPos)
        CommandName := StrReplace(CommandName, """", "")
        ; -------------------------------------------
        while (SubStr(CommandName, 1, 1) == A_Space)
        {
          CommandName := SubStr(CommandName, 2)
        }
        while (SubStr(CommandName, 1, 1) == A_Tab)
        {
          CommandName := SubStr(CommandName, 2)
        }
        while (SubStr(CommandName, 1, 1) == """")
        {
          CommandName := SubStr(CommandName, 2)
        }
        ; -------------------------------------------
        while (SubStr(CommandName, StrLen(CommandName)) == A_Space)
        {
          CommandName := SubStr(CommandName, 1, StrLen(CommandName) - 1)
        }
        while (SubStr(CommandName, StrLen(CommandName)) == A_Tab)
        {
          CommandName := SubStr(CommandName, 1, StrLen(CommandName) - 1)
        }
        while (SubStr(CommandName, StrLen(CommandName)) == ">")
        {
          CommandName := SubStr(CommandName, 1, StrLen(CommandName) - 1)
        }
        while (SubStr(CommandName, StrLen(CommandName)) == """")
        {
          CommandName := SubStr(CommandName, 1, StrLen(CommandName) - 1)
        }
        ; -------------------------------------------
        Keystroke := Array_MkbKeys[Index + 1]
        ; -------------------------------------------
        Keystroke := StrReplace(Keystroke, "<shortcut>", "")
        Keystroke := StrReplace(Keystroke, "</shortcut>", "")
        ; -------------------------------------------
        while (SubStr(Keystroke, 1, 1) == A_Space)
        {
          Keystroke := SubStr(Keystroke, 2)
        }
        while (SubStr(Keystroke, 1, 1) == A_Tab)
        {
          Keystroke := SubStr(Keystroke, 2)
        }
        ; -------------------------------------------
        while (SubStr(Keystroke, StrLen(Keystroke)) == A_Space)
        {
          Keystroke := SubStr(Keystroke, 1, StrLen(Keystroke) - 1)
        }
        while (SubStr(Keystroke, StrLen(Keystroke)) == A_Tab)
        {
          Keystroke := SubStr(Keystroke, 1, StrLen(Keystroke) - 1)
        }
        ; -------------------------------------------
        if (CommandName == ThisMenuItem)
        {
          Return_Keystroke := Keystroke
          break ; for Index, ThisLine in Array_MkbKeys
        }
      } ; [End] if (InStr(ThisLine, "<command ") > 0)
      ; -------------------------------------------
      else if (InStr(ThisLine, "<tool ") > 0) ; <tool name="Ruler Tool" type="1" key="1835360596">I</tool>
      {
        ; -------------------------------------------
        CommandName := ThisLine
        ;
        NamePos := InStr(CommandName, "name=")
        StrPos := NamePos + StrLen("name=")
        CommandName := SubStr(CommandName, StrPos)
        EndPos := InStr(CommandName, """",,, 2)
        CommandName := SubStr(CommandName, 1, EndPos)
        CommandName := StrReplace(CommandName, """", "")
        ; -------------------------------------------
        Keystroke := ThisLine
        ;
        StrPos := InStr(Keystroke, """>",,, 1)
        StrPos := StrPos + 2
        Keystroke := SubStr(Keystroke, StrPos)
        Keystroke := StrReplace(Keystroke, "</tool>", "")
        ; -------------------------------------------
        if (CommandName == ThisMenuItem)
        {
          Return_Keystroke := Keystroke
          break ; for Index, ThisLine in Array_MkbKeys
        }
      } ; [End] else if (InStr(ThisLine, "<tool ") > 0)
      ; -------------------------------------------
      else if (InStr(ThisLine, "<taskspace-tool ") > 0) ; <taskspace-tool name="Quick Selection Tool" type="1" key="1902867308">W</taskspace-tool>
      {
        ; -------------------------------------------
        CommandName := ThisLine
        ;
        NamePos := InStr(CommandName, "name=")
        StrPos := NamePos + StrLen("name=")
        CommandName := SubStr(CommandName, StrPos)
        EndPos := InStr(CommandName, """",,, 2)
        CommandName := SubStr(CommandName, 1, EndPos)
        CommandName := StrReplace(CommandName, """", "")
        ; -------------------------------------------
        Keystroke := ThisLine
        ;
        StrPos := InStr(Keystroke, """>",,, 1)
        StrPos := StrPos + 2
        Keystroke := SubStr(Keystroke, StrPos)
        Keystroke := StrReplace(Keystroke, "</taskspace-tool>", "")
        ; -------------------------------------------
        if (CommandName == ThisMenuItem)
        {
          Return_Keystroke := Keystroke
          break ; for Index, ThisLine in Array_MkbKeys
        }
      } ; [End] else if (InStr(ThisLine, "<tool ") > 0)
      ; -------------------------------------------
      else if (InStr(ThisLine, "<taskspace-property ") > 0) ; <taskspace-property name="Cycle Tool Mode" type="1">E</taskspace-property>
      {
        ; -------------------------------------------
        CommandName := ThisLine
        ;
        NamePos := InStr(CommandName, "name=")
        StrPos := NamePos + StrLen("name=")
        CommandName := SubStr(CommandName, StrPos)
        EndPos := InStr(CommandName, """",,, 2)
        CommandName := SubStr(CommandName, 1, EndPos)
        CommandName := StrReplace(CommandName, """", "")
        ; -------------------------------------------
        Keystroke := ThisLine
        ;
        StrPos := InStr(Keystroke, """>",,, 1)
        StrPos := StrPos + 2
        Keystroke := SubStr(Keystroke, StrPos)
        Keystroke := StrReplace(Keystroke, "</taskspace-property>", "")
        ; -------------------------------------------
        if (CommandName == ThisMenuItem)
        {
          Return_Keystroke := Keystroke
          break ; for Index, ThisLine in Array_MkbKeys
        }
      } ; [End] else if (InStr(ThisLine, "<tool ") > 0)
      ; -------------------------------------------
    } ; [End] for Index, ThisLine in Array_MkbKeys
    ; -------------------------------------------
  } ; [End] if FileExist(File_MkbKeys)
  ; -------------------------------------------
  return Return_Keystroke
  ; -------------------------------------------
} ; [End] MkbAdobeKeyStroke(ThisMenuItem, AppProcessName, ThisLang) ; MkbAdobeKeyStroke(ThisMenuItem, AppProcessName, ThisLang) ; > Keystroke -OR- ""
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
