﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Vars
; -------------------------------------------
global LockKeys := 1
; -------------------------------------------
WinGetPos , Gui_X, Gui_Y, Gui_W, Gui_H, Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
; -------------------------------------------
LangGui_X := Gui_X + 10
LangGui_Y := Gui_Y + 50
; -------------------------------------------
Nor_de := "C:\Program Files\PopUpMenu_PUM\image\gui\(143)_1_de.png"
Nor_en := "C:\Program Files\PopUpMenu_PUM\image\gui\(144)_1_en.png"
Nor_es := "C:\Program Files\PopUpMenu_PUM\image\gui\(145)_1_es.png"
Nor_fr := "C:\Program Files\PopUpMenu_PUM\image\gui\(146)_1_fr.png"
Nor_it := "C:\Program Files\PopUpMenu_PUM\image\gui\(147)_1_it.png"
Nor_pl := "C:\Program Files\PopUpMenu_PUM\image\gui\(148)_1_pl.png"
Nor_pt := "C:\Program Files\PopUpMenu_PUM\image\gui\(149)_1_pt.png"
Nor_ru := "C:\Program Files\PopUpMenu_PUM\image\gui\(150)_1_ru.png"
Nor_sv := "C:\Program Files\PopUpMenu_PUM\image\gui\(151)_1_sv.png"
Nor_tr := "C:\Program Files\PopUpMenu_PUM\image\gui\(152)_1_tr.png"
; -------------------------------------------
Sel_de := "C:\Program Files\PopUpMenu_PUM\image\gui\(143)_2_de.png"
Sel_en := "C:\Program Files\PopUpMenu_PUM\image\gui\(144)_2_en.png"
Sel_es := "C:\Program Files\PopUpMenu_PUM\image\gui\(145)_2_es.png"
Sel_fr := "C:\Program Files\PopUpMenu_PUM\image\gui\(146)_2_fr.png"
Sel_it := "C:\Program Files\PopUpMenu_PUM\image\gui\(147)_2_it.png"
Sel_pl := "C:\Program Files\PopUpMenu_PUM\image\gui\(148)_2_pl.png"
Sel_pt := "C:\Program Files\PopUpMenu_PUM\image\gui\(149)_2_pt.png"
Sel_ru := "C:\Program Files\PopUpMenu_PUM\image\gui\(150)_2_ru.png"
Sel_sv := "C:\Program Files\PopUpMenu_PUM\image\gui\(151)_2_sv.png"
Sel_tr := "C:\Program Files\PopUpMenu_PUM\image\gui\(152)_2_tr.png"
; -------------------------------------------
; Vars
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Get Current Lang
; -------------------------------------------
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
; -------------------------------------------
FileReadLINE, UserLang, %File_UserLang%, 1
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui
; -------------------------------------------
Gui, Add, Picture, x0   y0   w40 h40   vGuiFlag_de gLabel_GuiFlag_de, %Nor_de%
Gui, Add, Picture, x40  y0   w40 h40   vGuiFlag_en gLabel_GuiFlag_en, %Nor_en%
Gui, Add, Picture, x80  y0   w40 h40   vGuiFlag_es gLabel_GuiFlag_es, %Nor_es%
Gui, Add, Picture, x120 y0   w40 h40   vGuiFlag_fr gLabel_GuiFlag_fr, %Nor_fr%
Gui, Add, Picture, x160 y0   w40 h40   vGuiFlag_it gLabel_GuiFlag_it, %Nor_it%
Gui, Add, Picture, x0   y40  w40 h40   vGuiFlag_pl gLabel_GuiFlag_pl, %Nor_pl%
Gui, Add, Picture, x40  y40  w40 h40   vGuiFlag_pt gLabel_GuiFlag_pt, %Nor_pt%
Gui, Add, Picture, x80  y40  w40 h40   vGuiFlag_ru gLabel_GuiFlag_ru, %Nor_ru%
Gui, Add, Picture, x120 y40  w40 h40   vGuiFlag_sv gLabel_GuiFlag_sv, %Nor_sv%
Gui, Add, Picture, x160 y40  w40 h40   vGuiFlag_tr gLabel_GuiFlag_tr, %Nor_tr%
; -------------------------------------------
Gui, Color, e7d8fe ; Purple
Gui, -Caption
Gui, Show, x%LangGui_X% y%LangGui_Y% w200 h80, Language_Gui ; Shortcut_Pop_Up_Menu is Title
; -------------------------------------------
; Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Hide Gui from Task Bar
; -------------------------------------------
WinWait Language_Gui
DetectHiddenWindows On
WinHide
WinSet, ExStyle, +0x80 ; 0x80 is WS_EX_TOOLWINDOW
WinShow
; -------------------------------------------
; Hide Gui from Task Bar
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Select Current Language Flag
; -------------------------------------------
Sel_Flag := Sel_%UserLang%
GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
; -------------------------------------------
; Select Current Language Flag
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
SetTimer, Label_AlwaysOnTop, 100
return ; End Gui
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
Label_AlwaysOnTop:
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Always On Top
  ; -------------------------------------------
  WinGet, GuiLang_Id, ID , Language_Gui ahk_class AutoHotkeyGUI
  WinSet, AlwaysOnTop, On, ahk_id %GuiLang_Id%
  ; -------------------------------------------
}
return
Label_GuiFlag_de:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "de"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_en:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "en"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_es:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "es"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_fr:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "fr"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_it:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "it"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_pl:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "pl"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_pt:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "pt"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_ru:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "ru"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_sv:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "sv"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
Label_GuiFlag_tr:
{
  ; -------------------------------------------
  Nor_Flag := Nor_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Nor_Flag%
  ; -------------------------------------------
  UserLang := "tr"
  ; -------------------------------------------
  Sel_Flag := Sel_%UserLang%
  GuiControl, , GuiFlag_%UserLang%, %Sel_Flag%
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileDelete, %File_UserLang%
  Sleep, 100
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Esc::
{
  ExitApp
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
