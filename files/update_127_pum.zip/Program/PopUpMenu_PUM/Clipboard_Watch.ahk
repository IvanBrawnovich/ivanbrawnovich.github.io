﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, force
; -------------------------------------------
;~ Menu, Tray, Icon, C:\Program Files\PopUpMenu_PUM\image\ico\Clipboard_Watch.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; Only Used for PowerPoint Addon
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Persistent
OnClipboardChange("CurrentClipBoard")
return
CurrentClipBoard(Type)
{
  ; -------------------------------------------
  if WinExist("ahk_exe POWERPNT.EXE")
  {
    ; -------------------------------------------
    File_ClipBoardType := A_AppData "\PopUpMenu_PUM\system\ClipBoardType.txt"
    if FileExist(File_ClipBoardType)
    {
      FileDelete, %File_ClipBoardType%
    }
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %Type%, %File_ClipBoardType%
    ; -------------------------------------------
  }
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
