﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;#Include C:\Program Files\PopUpMenu_PUM\Image_CutSquare.ahk ; Image_CutSquare(TargetSize, ThisImage) ; TargetSize, ThisImage > ThisImage
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizeImg.ahk ; Image_ResizeImg(Resize_W, Resize_H, ThisImage, ThisImage) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; Cut a (TargetSize) Square from Out of Image
;
Image_CutSquare(TargetSize, ThisImage) ; TargetSize, ThisImage > ThisImage
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Get Image Size
	; -------------------------------------------
	Gui, ImageSize:Add, Picture, hwndJustForSize, %ThisImage% ; (368_5)(Selected Pum Background [Full Path])
	ControlGetPos, , , Image_W, Image_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
	; -------------------------------------------
  ; Get Image Size
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	if (Image_W > Image_H or Image_H > Image_W)
	{
		; -------------------------------------------
		if (Image_W > Image_H)
		{
			; -------------------------------------------
			Shave_X := Round((Image_W - Image_H) * 0.5)
			Shave_Y := 0 
			; -------------------------------------------
		}
		if (Image_H > Image_W)
		{
			; -------------------------------------------
			Shave_X := 0 
			Shave_Y := Round((Image_H - Image_W) * 0.5)
			; -------------------------------------------
		}
		; -------------------------------------------
		Support_magick := "C:\Program Files\PopUpMenu_PUM\support\magick\magick.exe"
		RunThis := """" Support_magick """ """ ThisImage """ -shave " Shave_X "x" Shave_Y " -flatten """ ThisImage """"
		Run, C:\Program Files\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
		RunWait, %RunThis%, , Hide
		; -------------------------------------------
		ThisImage := ThisImage
		Image_ResizeImg(TargetSize, TargetSize, ThisImage, ThisImage) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
		; -------------------------------------------
	}
	; -------------------------------------------
	return ThisImage
	; -------------------------------------------
} ; Function (Image_CutSquare)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
