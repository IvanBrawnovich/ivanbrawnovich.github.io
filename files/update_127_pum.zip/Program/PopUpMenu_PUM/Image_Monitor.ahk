﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_ResizePng.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_Combine.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Monitor(PercentNum, ThisPercent) ; > Nothing
{
  ; -------------------------------------------
  ; if File Does Not Exist (A_AppData "\PopUpMenu_PUM\system\ScreenSize.txt")
  ; -OR-
  ; Current Monitor Size Has Changed
  ;
  ; Creates 
  ; A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
  ;
  ; this image is used for
  ; "pum_pumSetting_pumDimension"
  ; (254)(GUI Object: [pum] Message Image 8)
  ; -------------------------------------------
  ; Functions Used
  ; Image_page, WinInWinMaxSize, Image_Resize_Png
  ; -------------------------------------------
  TextFile_ScreenSize := A_AppData "\PopUpMenu_PUM\system\ScreenSize.txt"
  ; -------------------------------------------
  Image_MonitorBottom := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_MonitorBottom.png"
  Image_MonitorTop    := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_MonitorTop.png"
  ; -------------------------------------------
  Temp_MonitorTop     := A_AppData "\PopUpMenu_PUM\temp\Temp_MonitorTop.png"
  DisplayMonitor      := A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
  ; -------------------------------------------
  Scr_W := A_ScreenWidth
  Scr_H := A_ScreenHeight
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(TextFile_ScreenSize)
  {
    ; -------------------------------------------
    FileReadLine, Current_Scr_W, %TextFile_ScreenSize%, 1
    FileReadLine, Current_Scr_H, %TextFile_ScreenSize%, 2
    ; -------------------------------------------
    if (Scr_W != Current_Scr_W or Scr_H != Current_Scr_H)
    {
      ; -------------------------------------------
      CreateFiles := 1
      ; -------------------------------------------
      if FileExist(DisplayMonitor)
      {
        FileDelete, %DisplayMonitor%
      }
      if FileExist(Temp_MonitorTop)
      {
        FileDelete, %Temp_MonitorTop%
      }
      ; -------------------------------------------
    }
    else
    {
      CreateFiles := 0
    }
    ; -------------------------------------------
  }
  else
  {
    ; -------------------------------------------
    CreateFiles := 1
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %Scr_W%`n, %TextFile_ScreenSize% ; 20127 us-ascii US-ASCII (7-bit)
    FileAppend, %Scr_H%`n, %TextFile_ScreenSize% ; 20127 us-ascii US-ASCII (7-bit)
    ; -------------------------------------------
    if FileExist(DisplayMonitor)
    {
      FileDelete, %DisplayMonitor%
    }
    if FileExist(Temp_MonitorTop)
    {
      FileDelete, %Temp_MonitorTop%
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if !FileExist(DisplayMonitor)
  {
    CreateFiles := 1
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (CreateFiles == 1)
  {
    ; -------------------------------------------
    WinInWin_Array := Pum_WinInWinMaxSize(280, 240, Scr_W, Scr_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
    ; -------------------------------------------
    Mon_W := Round(WinInWin_Array.1)
    Mon_H := Round(WinInWin_Array.2)
    ; -------------------------------------------
    Factor_MonX := Mon_W / Scr_W
    Factor_MonY := Mon_H / Scr_H
    ; -------------------------------------------
    Display_MonW := Mon_W + 20
    Display_MonH := Mon_H + (Factor_MonY * 10)
    ; -------------------------------------------
    Display_MonW := Round(Display_MonW)
    Display_MonH := Round(Display_MonH)
    ; -------------------------------------------
    Image_ResizePng(Display_MonW, Display_MonH, Image_MonitorTop, Temp_MonitorTop) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    Spacer_BX := 0
    Spacer_BY := 0
    Spacer_TX := 0
    Spacer_TY := 250 - Mon_H ; 10_X -50_Y 280_W 240_H is Screen display Area
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    PercentImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(277)_" PercentNum ".png"
    GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    ; -------------------------------------------
    PercentNum := PercentNum + ThisPercent
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Image_Array := [300, 300, DisplayMonitor, Image_MonitorBottom, Spacer_BX, Spacer_BY, Temp_MonitorTop, Spacer_TX, Spacer_TY]
    Image_Combine(Image_Array)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End (CreateFiles == 1)
  ; -------------------------------------------
} ; End Image_Monitor() ; > Nothing
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
