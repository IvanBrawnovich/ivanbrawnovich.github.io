﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Array_ReplaceItem(ThisArray, ReplaceThis, WithThis) ; Array_ReplaceItem(ThisArray, ReplaceThis, WithThis) ; > ThisArray
{
  for Index, ThisItem in ThisArray
  {
    if (ThisItem == ReplaceThis)
    {
      ThisArray.RemoveAt(Index) ; Removes 1 item Starting At (ThisPos)
      ThisArray.InsertAt(Index, WithThis) ; Adds (AddThis) at (ThisPos)
    }
  } ; End for Index, ThisItem in ThisArray
  return ThisArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
