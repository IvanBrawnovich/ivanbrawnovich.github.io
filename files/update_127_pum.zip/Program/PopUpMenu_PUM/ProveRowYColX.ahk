﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ProveRowYColX(ThisXmlArray) ; > ThisXmlArray
{
	; -------------------------------------------
	XmlLineSizePos := ThisXmlArray.3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (ChkRowY)
	; -------------------------------------------
	FindItem := "rows"
	; -------------------------------------------
	ItemPos := InStr(XmlLineSizePos, FindItem)
	ValStringTemp := SubStr(XmlLineSizePos, ItemPos)
	ValStartPos   := InStr(ValStringTemp, """",,, 1)
	ValStartPos   := ValStartPos + 1
	ValEndPos     := InStr(ValStringTemp, """",,, 2)
	ValLen        := ValEndPos - ValStartPos
	ThisVar       := SubStr(ValStringTemp, ValStartPos, ValLen)
	; -------------------------------------------
	ChkRowY := ThisVar
	; -------------------------------------------
	; (ChkRowY)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (ChkColX)
	; -------------------------------------------
	FindItem := "columns"
	; -------------------------------------------
	ItemPos := InStr(XmlLineSizePos, FindItem)
	ValStringTemp := SubStr(XmlLineSizePos, ItemPos)
	ValStartPos   := InStr(ValStringTemp, """",,, 1)
	ValStartPos   := ValStartPos + 1
	ValEndPos     := InStr(ValStringTemp, """",,, 2)
	ValLen        := ValEndPos - ValStartPos
	ThisVar       := SubStr(ValStringTemp, ValStartPos, ValLen)
	; -------------------------------------------
	ChkColX := ThisVar
	; -------------------------------------------
	; (ChkColX)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (CurLeft)
	; -------------------------------------------
	FindItem := "top"
	; -------------------------------------------
	ItemPos := InStr(XmlLineSizePos, FindItem)
	ValStringTemp := SubStr(XmlLineSizePos, ItemPos)
	ValStartPos   := InStr(ValStringTemp, """",,, 1)
	ValStartPos   := ValStartPos + 1
	ValEndPos     := InStr(ValStringTemp, """",,, 2)
	ValLen        := ValEndPos - ValStartPos
	ThisVar       := SubStr(ValStringTemp, ValStartPos, ValLen)
	; -------------------------------------------
	CurLeft := ThisVar
	; -------------------------------------------
	; (CurLeft)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (CurTop)
	; -------------------------------------------
	FindItem := "left"
	; -------------------------------------------
	ItemPos := InStr(XmlLineSizePos, FindItem)
	ValStringTemp := SubStr(XmlLineSizePos, ItemPos)
	ValStartPos   := InStr(ValStringTemp, """",,, 1)
	ValStartPos   := ValStartPos + 1
	ValEndPos     := InStr(ValStringTemp, """",,, 2)
	ValLen        := ValEndPos - ValStartPos
	ThisVar       := SubStr(ValStringTemp, ValStartPos, ValLen)
	; -------------------------------------------
	CurTop := ThisVar
	; -------------------------------------------
	; (CurTop)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	ExistRowY := 0
	ExistColX := 0
	; -------------------------------------------
	for Index, ThisLine in ThisXmlArray
	{
		; -------------------------------------------
		if (InStr(ThisLine, "<shortcut ") > 0)
		{
			; -------------------------------------------
			; <shortcut row="#" column="#" textcolor="0" textalign="0" paraalign="2" type="0" >
		  XmlString := ThisXmlArray[Index]
		  ; -------------------------------------------
		  ;
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ; (ExistRowY)
		  ; -------------------------------------------
		  FindItem := "row"
		  ; -------------------------------------------
		  ItemPos := InStr(XmlString, FindItem)
		  ValStringTemp := SubStr(XmlString, ItemPos)
		  ValStartPos := InStr(ValStringTemp, """",,, 1)
		  ValStartPos := ValStartPos + 1
		  ValEndPos := InStr(ValStringTemp, """",,, 2)
		  ValLen := ValEndPos - ValStartPos
		  ThisRowY  := SubStr(ValStringTemp, ValStartPos, ValLen)
		  ; -------------------------------------------
		  if (ThisRowY > ExistRowY)
		  {
  			ExistRowY := ThisRowY
		  }
		  ; -------------------------------------------
		  ; (ExistRowY)
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ;
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ; (ExistColX)
		  ; -------------------------------------------
		  FindItem := "column"
		  ; -------------------------------------------
		  ItemPos := InStr(XmlString, FindItem)
		  ValStringTemp := SubStr(XmlString, ItemPos)
		  ValStartPos := InStr(ValStringTemp, """",,, 1)
		  ValStartPos := ValStartPos + 1
		  ValEndPos := InStr(ValStringTemp, """",,, 2)
		  ValLen := ValEndPos - ValStartPos
		  ThisColX  := SubStr(ValStringTemp, ValStartPos, ValLen)
		  ; -------------------------------------------
		  if (ThisColX > ExistColX)
		  {
  			ExistColX := ThisColX
		  }
		  ; -------------------------------------------
		  ; (ExistColX)
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		} ; if (InStr(ThisLine, "<shortcut ") > 0)
		; -------------------------------------------
	} ; for Index, ThisLine in ThisXmlArray
	; -------------------------------------------
	;
	; -------------------------------------------
	if (ChkRowY < ExistRowY and ChkColX < ExistColX)
	{
		Passed := 0
		FixColX := ExistColX
		FixRowY := ExistRowY
	}
	else if (ChkRowY < ExistRowY)
	{
		Passed := 0
		FixColX := ChkColX
		FixRowY := ExistRowY
	}
	else if (ChkColX < ExistColX)
	{
		Passed := 0
		FixColX := ExistColX
		FixRowY := ChkRowY
	}
	; -------------------------------------------
	if (Passed == 0)
	{
		; -------------------------------------------
		Fix_Line_3 := "<toolbox name="""" rows=""" FixRowY """ columns=""" FixColX """ left=""" CurLeft  """ top=""" CurTop  """ stayontop=""-1"" >"
		ThisXmlArray.RemoveAt(3)
    ThisXmlArray.InsertAt(3, Fix_Line_3)
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	return ThisXmlArray
	; -------------------------------------------
} ; ProveRowYColX(ThisXmlArray, ChkRowY, ChkColX)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
