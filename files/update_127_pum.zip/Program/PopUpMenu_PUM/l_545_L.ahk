﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_545_L: ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
{
  ; -------------------------------------------
  ; Rotate Main Icon Left
  ; -------------------------------------------
  ;
  ; (w80_x_80)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Rotate Main Icon Left)
  ; global n_545_L := 0 ; Start Frame Number
  ; global s_545_L := 1 ; Show
  ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Rotate Main Icon Left)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Rotate Main Icon Left)
  ; global s_545_L := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Rotate Main Icon Left)
  ; 
  ; [ANIMATE] Start/Show in This File
  ; Image_ConvertToIco.ahk
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 24
  ; -------------------------------------------
  if (n_545_L == 0) ; 1 Less than Number of Images
  {
    global n_545_L := Total_Images
  }
  ; -------------------------------------------
  if (s_545_L == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_545_L == 0) ; 1 Less than Number of Images
    {
      global n_545_L := Total_Images
    }
    else
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_102, C:\Program Files\PopUpMenu_PUM\image\gui\(545)_%n_545%.png ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      Gui_ObjectSize("102", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_102 ; (102_1)(Obj_DisplayedIcon)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_545_L := n_545_L - 1
      ; -------------------------------------------
    }
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_545_L, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (545_1)(Display Icon (w80_x_80) Rotate Icon)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
