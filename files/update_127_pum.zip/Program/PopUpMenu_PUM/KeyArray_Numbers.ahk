﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
KeyArray_Numbers(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ; Creates
  ; (301_2)([key] KeyArray_Numbers [Array])
  ; From
  ; (301_8)([key] KeyArray_Keystroke [Array] for Shortcut)
  ; -------------------------------------------
  Key_KeyArrayShortcut := DataArray.301.8 ; (301_8)(Key_KeyArrayShortcut [Array])
  ; -------------------------------------------
  Ckeck_Array := Key_KeyArrayShortcut.1 ; (301_8)(Key_KeyArrayShortcut [Array])
  ; -------------------------------------------
  if (Ckeck_Array != "") ; Make Sure (301_8)([key] KeyArray_Keystroke for Shortcut) Has Key's in it
  {
    ; -------------------------------------------
    Key_ArrayNumbers := "" ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
    for Index, This_KeyStroke in Key_KeyArrayShortcut ; (301_8)(Key_KeyArrayShortcut [Array])
    {
      ; -------------------------------------------
      if (SubStr(This_KeyStroke, 1, 1) == "~") ; User Written Text
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, This_KeyStroke, "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt]") ; (008)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt Down]") ; (008)(009)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt Up]") ; (008)(012)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(008)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt]") ; (010)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(010)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt Down]") ; (010)(009)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(010)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt Up]") ; (010)(012)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(010)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt]") ; (011)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(011)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt Down]") ; (011)(009)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(011)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(009)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt Up]") ; (011)(012)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(011)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(012)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[CapsLock]") ; (013)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl]") ; (015)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(015)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl Down]") ; (015)(014)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(015)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl Up]") ; (015)(017)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(015)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl]") ; (016)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(016)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl Down]") ; (016)(014)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(016)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl Up]") ; (016)(017)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(016)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Enter]") ; (018) / X2 (019)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(018)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Esc]") ; (020) / X2 (021)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(020)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F1]") ; (022)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(022)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F2]") ; (023)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(023)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F3]") ; (024)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(024)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F4]") ; (025)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(025)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F5]") ; (026)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(026)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F6]") ; (027)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(027)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F7]") ; (028)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(028)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F8]") ; (029)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(029)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F9]") ; (030)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(030)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F10]") ; (031)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(031)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F11]") ; (032)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(032)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F12]") ; (033)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(033)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad0]") ; (034)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(034)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad1]") ; (035)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(035)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad2]") ; (036)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(036)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad3]") ; (037)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(037)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad4]") ; (038)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(038)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad5]") ; (039)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(039)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad6]") ; (040)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(040)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad7]") ; (041)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(041)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad8]") ; (042)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(042)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad9]") ; (043)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(043)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadAdd]") ; (044)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(044)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadDiv]") ; (045)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(045)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadDot]") ; (046)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(046)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadEnter]") ; (047)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(047)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadMult]") ; (048)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(048)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadSub]") ; (049)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(049)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift]") ; (050)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift Down]") ; (050)(051)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift Up]") ; (050)(054)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(050)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift]") ; (052)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(052)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift Down]") ; (052)(051)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(052)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift Up]") ; (052)(054)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(052)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift]") ; (053)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(053)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift Down]") ; (053)(051)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(053)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(051)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift Up]") ; (053)(054)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(053)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(054)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Tab]") ; (055) / 2X (056)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(055)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win]") ; (057)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win Down]") ; (057)(058)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win Up]") ; (057)(061)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(057)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin]") ; (059)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(059)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin Down]") ; (059)(058)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(059)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin Up]") ; (059)(061)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(059)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(061)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin]") ; (060)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(060)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin Down]") ; (060)(058)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(060)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(058)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin Up]") ; (060)(061)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(060)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(061)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl]") ; (074)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl Down]") ; (074)(014)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(014)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl Up]") ; (074)(017)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(074)", "End") ; (301_2)(Key_ArrayNumbers [Array])
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(017)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Delete]") ; (075)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(075)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[End]") ; (076)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(076)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Home]") ; (077)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(077)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Insert]") ; (078)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(078)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[PgDn]") ; (079)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(079)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[PgUp]") ; (080)
      {
        Key_ArrayNumbers := Array_Add(Key_ArrayNumbers, "(080)", "End") ; (301_2)(Key_ArrayNumbers [Array])
      }
      ; -------------------------------------------
    } ; (301_8)([key] KeyArray_Keystroke for Shortcut)
    ; -------------------------------------------
    DataArray.301.2 := Key_ArrayNumbers ; (301_2)(Key_ArrayNumbers [Array])
    ; -------------------------------------------
  } ; End (Ckeck_Array != "") ; Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Key_Array_Numbers(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
