﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
#Include C:\Program Files\PopUpMenu_PUM\Default_Browser.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Image_PathFolderOrName.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_MultIconDisplay(DataArray) ; > DataArray
{
  ; -------------------------------------------
  Obj_DisplayedIcon_Img := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Start Up Vars
  ; -------------------------------------------
  File_UserTheme := A_AppData "\PopUpMenu_PUM\system\File_UserTheme.txt"
  ; -------------------------------------------
  if FileExist(File_UserTheme)
  {
    FileReadLine, Icon_UserTheme, %File_UserTheme%, 1
  }
  else
  {
    Icon_UserTheme := ""
  }
  ; -------------------------------------------
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ORG_ScriptType := DataArray.5.1 ; (005_1)(ORG_ScriptType)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [SET] (Folder_ImageRight) and/or (Folder_ImageLeft)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      AppProcessPathNameExt := DataArray.305.11 ; (305_11)(Run_OutTarget [PathExtName])
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FolderRunIco", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageRight := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (ScriptType [run])
    else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      AppProcessPathNameExt := DataArray.305.5 ; (305_5)(Rwh_OpeningApp [Full File Path])
      ; -------------------------------------------
		  ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FolderRwhIco", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageRight := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (ScriptType [rwh])
    else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
		  ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderKey", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageRight := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (ScriptType [key])
    else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderOfl", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageLeft := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderOflIco", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageRight := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (ScriptType [ofl])
    if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; -------------------------------------------
        ; Any Browser
        ; -------------------------------------------
        AppProcessPathNameExt := DataArray.367.5 ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
        ; -------------------------------------------
      } ; Active Internet Browser
      else ; Default Internet Browser
      {
        ; -------------------------------------------
        AppProcessPathNameExt := Default_Browser()
        ; -------------------------------------------
      } ; Default Internet Browser
    } ; [End] (ScriptType [url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] [SET] (Folder_ImageRight) and/or (Folder_ImageLeft)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [SET] Image Paths for Icon_[Left,Right][1,2,3] for Display
    ; -------------------------------------------
    if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if !FileExist(Folder_ImageRight)
      {
        FileCreateDir, %Folder_ImageRight%
        Sleep, 10
      } ; [End] if !FileExist(Folder_ImageRight)
      ; -------------------------------------------
      Array_ListRunIcon := ""
      ; -------------------------------------------
      Loop, Files, %Folder_ImageRight%\*.ico
      {
        This_RunIcon := A_LoopFileFullPath
        Array_ListRunIcon := Array_Add(Array_ListRunIcon, This_RunIcon, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      } ; [End] Loop, Files, %Folder_ImageRight%\*.ico
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CountIcons_Right := Array_ListRunIcon.MaxIndex()
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      if (CountIcons_Right == 0 or CountIcons_Right == 1)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Icon_Right2 := ""
        Icon_Right3 := ""
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 0 or CountIcons_Right == 1)
      else if (CountIcons_Right == 2)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;        
        ; -------------------------------------------
        Icon_Right2 := Array_ListRunIcon.2
        if (Icon_Right2 == Icon_Right1)
        {
          Icon_Right2 := Array_ListRunIcon.1
        }
        Icon_Right3 := ""
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 2)
      else if (CountIcons_Right == 3)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Temp_Right1 := Array_ListRunIcon.1
        Temp_Right2 := Array_ListRunIcon.2
        Temp_Right3 := Array_ListRunIcon.3
        ; -------------------------------------------
        if (Icon_Right1 != Temp_Right1 && Icon_Right1 != Temp_Right2)
        {
          Icon_Right2 := Temp_Right1
          Icon_Right3 := Temp_Right2
        }
        else if (Icon_Right1 != Temp_Right1 && Icon_Right1 != Temp_Right3)
        {
          Icon_Right2 := Temp_Right1
          Icon_Right3 := Temp_Right3
        }
        else if (Icon_Right1 != Temp_Right2 && Icon_Right1 != Temp_Right3)
        {
          Icon_Right2 := Temp_Right2
          Icon_Right3 := Temp_Right3
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 3)
      else if (CountIcons_Right > 3)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Random, Icon_Right2_Num , 1, CountIcons_Right
        Icon_Right2 := Array_ListRunIcon[Icon_Right2_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right2)
        {
          ; -------------------------------------------
          Random, Icon_Right2_Num , 1, CountIcons_Right
          Icon_Right2 := Array_ListRunIcon[Icon_Right2_Num]
          ; -------------------------------------------
        } ; [End] while (Icon_Right1 == Icon_Right2)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        Random, Icon_Right3_Num , 1, CountIcons_Right
        Icon_Right3 := Array_ListRunIcon[Icon_Right3_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right3 or Icon_Right2 == Icon_Right3)
        {
          Random, Icon_Right3_Num , 1, CountIcons_Right
          Icon_Right3 := Array_ListRunIcon[Icon_Right3_Num]
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right > 3)
      ; -------------------------------------------
    } ; [End] (ScriptType [run])
    ; -------------------------------------------
    else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if !FileExist(Folder_ImageRight)
      {
        FileCreateDir, %Folder_ImageRight%
        Sleep, 10
      } ; [End] if !FileExist(Folder_ImageRight)
      ; -------------------------------------------
      Array_ListRwhIcon := ""
      ; -------------------------------------------
      Loop, Files, %Folder_ImageRight%\*.ico
      {
        This_RwhIcon := A_LoopFileFullPath
        Array_ListRwhIcon := Array_Add(Array_ListRwhIcon, This_RwhIcon, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      } ; [End] Loop, Files, %Folder_ImageRight%\*.ico
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CountIcons_Right := Array_ListRwhIcon.MaxIndex()
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      if (CountIcons_Right == 0 or CountIcons_Right == 1)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Icon_Right2 := ""
        Icon_Right3 := ""
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 0 or CountIcons_Right == 1)
      else if (CountIcons_Right == 2)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Icon_Right2 := Array_ListRwhIcon.2
        if (Icon_Right2 == Icon_Right1)
        {
          Icon_Right2 := Array_ListRwhIcon.1
        }
        Icon_Right3 := ""
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 2)
      else if (CountIcons_Right == 3)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Temp_Right1 := Array_ListRwhIcon.1
        Temp_Right2 := Array_ListRwhIcon.2
        Temp_Right3 := Array_ListRwhIcon.3
        ; -------------------------------------------
        if (Icon_Right1 != Temp_Right1 && Icon_Right1 != Temp_Right2)
        {
          Icon_Right2 := Temp_Right1
          Icon_Right3 := Temp_Right2
        }
        else if (Icon_Right1 != Temp_Right1 && Icon_Right1 != Temp_Right3)
        {
          Icon_Right2 := Temp_Right1
          Icon_Right3 := Temp_Right3
        }
        else if (Icon_Right1 != Temp_Right2 && Icon_Right1 != Temp_Right3)
        {
          Icon_Right2 := Temp_Right2
          Icon_Right3 := Temp_Right3
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right == 3)
      else if (CountIcons_Right > 3)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        Icon_Right1 := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        Random, Icon_Right2_Num , 1, CountIcons_Right
        Icon_Right2 := Array_ListRwhIcon[Icon_Right2_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right2)
        {
          ; -------------------------------------------
          Random, Icon_Right2_Num , 1, CountIcons_Right
          Icon_Right2 := Array_ListRwhIcon[Icon_Right2_Num]
          ; -------------------------------------------
        } ; [End] while (Icon_Right1 == Icon_Right2)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        Random, Icon_Right3_Num , 1, CountIcons_Right
        Icon_Right3 := Array_ListRwhIcon[Icon_Right3_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right3 or Icon_Right2 == Icon_Right3)
        {
          Random, Icon_Right3_Num , 1, CountIcons_Right
          Icon_Right3 := Array_ListRwhIcon[Icon_Right3_Num]
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right > 3)
      ; -------------------------------------------
    } ; [End] (ScriptType [run])
    ; -------------------------------------------
    else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      File_ListKeyIcon := A_AppData "\PopUpMenu_PUM\system\File_ListKeyIcon.txt"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if !FileExist(File_ListKeyIcon)
      {
        ; -------------------------------------------
        if !FileExist(Folder_ImageRight)
        {
          FileCreateDir, %Folder_ImageRight%
          Sleep, 10
        } ; [End] if !FileExist(Folder_ImageRight)
        ; -------------------------------------------
        Array_ListKeyIcon := ""
        ; -------------------------------------------
        Loop, Files, %Folder_ImageRight%\*.ico
        {
          This_KeyIcon := A_LoopFileFullPath
          Array_ListKeyIcon := Array_Add(Array_ListKeyIcon, This_KeyIcon, "End") ; ThisArray, AddThis, ThisPos > ThisArray
        } ; [End] Loop, Files, %Folder_ImageRight%\*.ico
        ; -------------------------------------------
        for Index, ThisIconPath in Array_ListKeyIcon
        {
          FileEncoding, UTF-8
          FileAppend, %ThisIconPath%`n, %File_ListKeyIcon% ; UTF-8
        } ; [End] for Index, ThisIconPath in Array_ListKeyIcon
        ; -------------------------------------------
      } ; [End] if !FileExist(File_ListKeyIcon)
      else ; [EXIST] (File_ListKeyIcon.txt)
      {
        ; -------------------------------------------
        Array_ListKeyIcon := Array_FromFile(File_ListKeyIcon) ; > Array
        ; -------------------------------------------
      } ; [End] [EXIST] (File_ListKeyIcon.txt)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CountIcons_Right := Array_ListKeyIcon.MaxIndex()
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (CountIcons_Right == 0)
      {
        Icon_Right1 := ""
        Icon_Right2 := ""
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 1)
      {
        Icon_Right1 := Array_ListKeyIcon.1
        Icon_Right2 := ""
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 2)
      {
        Icon_Right1 := Array_ListKeyIcon.1
        Icon_Right2 := Array_ListKeyIcon.2
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 3)
      {
        Icon_Right1 := Array_ListKeyIcon.1
        Icon_Right2 := Array_ListKeyIcon.2
        Icon_Right3 := Array_ListKeyIcon.3
      }
      else if (CountIcons_Right > 3)
      {
        ; -------------------------------------------
        Random, Icon_Right1_Num , 1, CountIcons_Right
        Icon_Right1 := Array_ListKeyIcon[Icon_Right1_Num]
        ; -------------------------------------------
        Random, Icon_Right2_Num , 1, CountIcons_Right
        Icon_Right2 := Array_ListKeyIcon[Icon_Right2_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right2)
        {
          ; -------------------------------------------
          Random, Icon_Right2_Num , 1, CountIcons_Right
          Icon_Right2 := Array_ListKeyIcon[Icon_Right2_Num]
          ; -------------------------------------------
        } ; [End] while (Icon_Right1 == Icon_Right2)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        Random, Icon_Right3_Num , 1, CountIcons_Right
        Icon_Right3 := Array_ListKeyIcon[Icon_Right3_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right3 or Icon_Right2 == Icon_Right3)
        {
          Random, Icon_Right3_Num , 1, CountIcons_Right
          Icon_Right3 := Array_ListKeyIcon[Icon_Right3_Num]
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right > 3)
      ; -------------------------------------------
    } ; [End] (ScriptType [key])
    ; -------------------------------------------
    else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if !FileExist(Folder_ImageRight)
      {
        FileCreateDir, %Folder_ImageRight%
        Sleep, 10
      } ; [End] if !FileExist(Folder_ImageRight)
      ; -------------------------------------------
      Array_ListOflIcon := ""
      ; -------------------------------------------
      Loop, Files, %Folder_ImageRight%\*.ico
      {
        This_OflIcon := A_LoopFileFullPath
        Array_ListOflIcon := Array_Add(Array_ListOflIcon, This_OflIcon, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      } ; [End] Loop, Files, %Folder_ImageRight%\*.ico
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CountIcons_Right := Array_ListOflIcon.MaxIndex()
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (CountIcons_Right == 0)
      {
        Icon_Right1 := ""
        Icon_Right2 := ""
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 1)
      {
        Icon_Right1 := Array_ListOflIcon.1
        Icon_Right2 := ""
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 2)
      {
        Icon_Right1 := Array_ListOflIcon.1
        Icon_Right2 := Array_ListOflIcon.2
        Icon_Right3 := ""
      }
      else if (CountIcons_Right == 3)
      {
        Icon_Right1 := Array_ListOflIcon.1
        Icon_Right2 := Array_ListOflIcon.2
        Icon_Right3 := Array_ListOflIcon.3
      }
      else if (CountIcons_Right > 3)
      {
        ; -------------------------------------------
        Random, Icon_Right1_Num , 1, CountIcons_Right
        Icon_Right1 := Array_ListOflIcon[Icon_Right1_Num]
        ; -------------------------------------------
        Random, Icon_Right2_Num , 1, CountIcons_Right
        Icon_Right2 := Array_ListOflIcon[Icon_Right2_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right2)
        {
          ; -------------------------------------------
          Random, Icon_Right2_Num , 1, CountIcons_Right
          Icon_Right2 := Array_ListOflIcon[Icon_Right2_Num]
          ; -------------------------------------------
        } ; [End] while (Icon_Right1 == Icon_Right2)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        Random, Icon_Right3_Num , 1, CountIcons_Right
        Icon_Right3 := Array_ListOflIcon[Icon_Right3_Num]
        ; -------------------------------------------
        while (Icon_Right1 == Icon_Right3 or Icon_Right2 == Icon_Right3)
        {
          Random, Icon_Right3_Num , 1, CountIcons_Right
          Icon_Right3 := Array_ListOflIcon[Icon_Right3_Num]
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Right > 3)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      File_ListFolderIcon := A_AppData "\PopUpMenu_PUM\system\File_ListFolderIcon.txt"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FolderOfl", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Folder_ImageLeft := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if !FileExist(File_ListFolderIcon)
      {
        ; -------------------------------------------
        if !FileExist(Folder_ImageLeft)
        {
          FileCreateDir, %Folder_ImageLeft%
          Sleep, 10
        } ; [End] if !FileExist(Folder_ImageLeft)
        ; -------------------------------------------
        Array_ListFolderIcon := ""
        ; -------------------------------------------
        Loop, Files, %Folder_ImageLeft%\*.ico, R
        {
          This_FolderIcon := A_LoopFileFullPath
          Array_ListFolderIcon := Array_Add(Array_ListFolderIcon, This_FolderIcon, "End") ; ThisArray, AddThis, ThisPos > ThisArray
        } ; [End] Loop, Files, %Folder_ImageLeft%\*.ico
        ; -------------------------------------------
        for Index, ThisIconPath in Array_ListFolderIcon
        {
          FileEncoding, UTF-8
          FileAppend, %ThisIconPath%`n, %File_ListFolderIcon% ; UTF-8
        } ; [End] for Index, ThisIconPath in Array_ListFolderIcon
        ; -------------------------------------------
      } ; [End] if !FileExist(File_ListFolderIcon)
      else ; [EXIST] (File_ListFolderIcon.txt)
      {
        ; -------------------------------------------
        Array_ListFolderIcon := Array_FromFile(File_ListFolderIcon) ; > Array
        ; -------------------------------------------
      } ; [End] [EXIST] (File_ListFolderIcon.txt)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CountIcons_Left := Array_ListFolderIcon.MaxIndex()
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (CountIcons_Left == 0)
      {
        Icon_Left1 := ""
        Icon_Left2 := ""
        Icon_Left3 := ""
      }
      else if (CountIcons_Left == 1)
      {
        Icon_Left1 := Array_ListFolderIcon.1
        Icon_Left2 := ""
        Icon_Left3 := ""
      }
      else if (CountIcons_Left == 2)
      {
        Icon_Left1 := Array_ListFolderIcon.1
        Icon_Left2 := Array_ListFolderIcon.2
        Icon_Left3 := ""
      }
      else if (CountIcons_Left == 3)
      {
        Icon_Left1 := Array_ListFolderIcon.1
        Icon_Left2 := Array_ListFolderIcon.2
        Icon_Left3 := Array_ListFolderIcon.3
      }
      else if (CountIcons_Left > 3)
      {
        ; -------------------------------------------
        Random, Icon_Left1_Num , 1, CountIcons_Left
        Icon_Left1 := Array_ListFolderIcon[Icon_Left1_Num]
        ; -------------------------------------------
        Random, Icon_Left2_Num , 1, CountIcons_Left
        Icon_Left2 := Array_ListFolderIcon[Icon_Left2_Num]
        ; -------------------------------------------
        while (Icon_Left1 == Icon_Left2)
        {
          ; -------------------------------------------
          Random, Icon_Left2_Num , 1, CountIcons_Left
          Icon_Left2 := Array_ListFolderIcon[Icon_Left2_Num]
          ; -------------------------------------------
        } ; [End] while (Icon_Left1 == Icon_Left2)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        Random, Icon_Left3_Num , 1, CountIcons_Left
        Icon_Left3 := Array_ListFolderIcon[Icon_Left3_Num]
        ; -------------------------------------------
        while (Icon_Left1 == Icon_Left3 or Icon_Left2 == Icon_Left3)
        {
          Random, Icon_Left3_Num , 1, CountIcons_Left
          Icon_Left3 := Array_ListFolderIcon[Icon_Left3_Num]
        }
        ; -------------------------------------------
      } ; [End] else if (CountIcons_Left > 3)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] (ScriptType [ofl])
    ; -------------------------------------------
    else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRwhIco", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Icon_Right1 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      Icon_Right2 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Icon_Right3 := ""
      ; -------------------------------------------
    }
  } ; [End] [SET] Image Paths for Icon_[Left,Right][1,2,3] for Display
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [DISPLAY] Images Right
    ; ------------------------------------------- iCON (1-3) Right
    if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      if FileExist(Icon_Right1)
      {
        DataArray.1.2 := 1 ; (001_2)(Obj_KeyOflRunRwh_1RAppIco_Sel [0,1])
        DataArray.1.3 := Icon_Right1 ; (001_3)(Obj_KeyOflRunRwh_1RAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_001, %Icon_Right1% ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        GuiControl, PopUpMenu:Show, g_001 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      if FileExist(Icon_Right2)
      {
        DataArray.2.2 := 1 ; (002_2)(Obj_KeyOflRunRwh_2RAppIco_Sel [0,1])
        DataArray.2.3 := Icon_Right2 ; (002_3)(Obj_KeyOflRunRwh_2RAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_002, %Icon_Right2% ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_002, +w40 +h40 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        GuiControl, PopUpMenu:Show, g_002 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      }
      if FileExist(Icon_Right3)
      {
        DataArray.3.2 := 1 ; (003_2)(Obj_KeyOfl_3RAppIco_Sel [0,1])
        DataArray.3.3 := Icon_Right3 ; (003_3)(Obj_KeyOfl_3RAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_003, %Icon_Right3% ; (003_1)(Obj_KeyOfl_3RAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_003, +w40 +h40 ; (003_1)(Obj_KeyOfl_3RAppIco)
        GuiControl, PopUpMenu:Show, g_003 ; (003_1)(Obj_KeyOfl_3RAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("003", 0, 0, DataArray) ; (003_1)(Obj_KeyOfl_3RAppIco)
      }
      ; -------------------------------------------
      if (CountIcons_Right > 3)
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("007", 1, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
        ; -------------------------------------------
        DataArray.106.2 := 1 ; (106_2)(Obj_KeyOfl_DisplayText_RNumberOfIcons_Sel [0,1])
        DataArray.106.3 := CountIcons_Right ; (106_3)(Obj_KeyOfl_DisplayText_RNumberOfIcons_Img [Text Value])
        ; -------------------------------------------
        GuiControl, PopUpMenu:, g_106, %CountIcons_Right% ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        GuiControl, PopUpMenu:Show, g_106 ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("007", 0, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
        DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Icon (1-3) Right
    } ; (366_5)(ScriptType [key,ofl,run,rwh])
    ; -------------------------------------------
    else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      if FileExist(Icon_Right1)
      {
        DataArray.1.2 := 1 ; (001_2)(Obj_KeyOflRunRwh_1RAppIco_Sel [0,1])
        DataArray.1.3 := Icon_Right1 ; (001_3)(Obj_KeyOflRunRwh_1RAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_001, %Icon_Right1% ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        GuiControl, PopUpMenu:Show, g_001 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      if FileExist(Icon_Right2)
      {
        DataArray.2.2 := 1 ; (002_2)(Obj_KeyOflRunRwh_2RAppIco_Sel [0,1])
        DataArray.2.3 := Icon_Right2 ; (002_3)(Obj_KeyOflRunRwh_2RAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_002, %Icon_Right2% ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_002, +w40 +h40 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        GuiControl, PopUpMenu:Show, g_002 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      }
      ; -------------------------------------------
    } ; (366_5)(ScriptType [url])
    ; -------------------------------------------
  } ; [End] [DISPLAY] Images Right
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [DISPLAY] Images Left
    ; -------------------------------------------
    if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; ------------------------------------------- Icon (1-3) Left
      if FileExist(Icon_UserTheme)
      {
        DataArray.248.2 := 1 ; (248_2)(Obj_Ofl_1LAppIco_Sel [0,1])
        DataArray.248.3 := Icon_UserTheme ; (248_3)(Obj_Ofl_1LAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_248, %Icon_UserTheme% ; (248_1)(Obj_Ofl_1LAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_248, +w40 +h40 ; (248_1)(Obj_Ofl_1LAppIco)
        GuiControl, PopUpMenu:Show, g_248 ; (248_1)(Obj_Ofl_1LAppIco)
      }
      else if FileExist(Icon_Left1)
      {
        DataArray.248.2 := 1 ; (248_2)(Obj_Ofl_1LAppIco_Sel [0,1])
        DataArray.248.3 := Icon_Left1 ; (248_3)(Obj_Ofl_1LAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_248, %Icon_Left1% ; (248_1)(Obj_Ofl_1LAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_248, +w40 +h40 ; (248_1)(Obj_Ofl_1LAppIco)
        GuiControl, PopUpMenu:Show, g_248 ; (248_1)(Obj_Ofl_1LAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("248", 0, 0, DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
      }
      if FileExist(Icon_Left2)
      {
        DataArray.249.2 := 1 ; (249_2)(Obj_Ofl_2LAppIco_Sel [0,1])
        DataArray.249.3 := Icon_Left2 ; (249_3)(Obj_Ofl_2LAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_249, %Icon_Left2% ; (249_1)(Obj_Ofl_2LAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_249, +w40 +h40 ; (249_1)(Obj_Ofl_2LAppIco)
        GuiControl, PopUpMenu:Show, g_249 ; (249_1)(Obj_Ofl_2LAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("249", 0, 0, DataArray) ; (249_1)(Obj_Ofl_2LAppIco)
      }
      if FileExist(Icon_Left3)
      {
        DataArray.250.2 := 1 ; (250_2)(Obj_Ofl_3LAppIco_Sel [0,1])
        DataArray.250.3 := Icon_Left3 ; (250_3)(Obj_Ofl_3LAppIco_Img [Image Path])
        GuiControl, PopUpMenu:, g_250, %Icon_Left3% ; (250_1)(Obj_Ofl_3LAppIco)
        GuiControl, PopUpMenu:MoveDraw, g_250, +w40 +h40 ; (250_1)(Obj_Ofl_3LAppIco)
        GuiControl, PopUpMenu:Show, g_250 ; (250_1)(Obj_Ofl_3LAppIco)
      }
      else
      {
        DataArray := Image_GuiControl("250", 0, 0, DataArray) ; (250_1)(Obj_Ofl_3LAppIco)
      }
      ; -------------------------------------------
      if (CountIcons_Left > 3)
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("252", 1, 0, DataArray) ; (252_1)(Obj_Ofl_LFolderImage)
        ; -------------------------------------------
        DataArray.251.2 := 1 ; (251_2)(Obj_Ofl_DisplayText_LNumberOfIcons_Sel [0,1])
        DataArray.251.3 := CountIcons_Left ; (251_3)(Obj_Ofl_DisplayText_LNumberOfIcons_Img [Text Value])
        ; -------------------------------------------
        GuiControl, PopUpMenu:, g_251, %CountIcons_Left% ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
        GuiControl, PopUpMenu:Show, g_251 ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
        ; -------------------------------------------
      } ; [End] if (CountIcons_Left > 3)
      ; ------------------------------------------- Icon (1-3) Left
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
  } ; [End] [DISPLAY] Images Left
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [CHECK] [SET] Obj_DisplayedIcon_Img
    ; -------------------------------------------
    ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
    SplitPath, Obj_DisplayedIcon_Img, , , , DisplayedIconName
    ; -------------------------------------------
    if (InStr(DisplayedIconName, "PopUpMenu") > 0 or Obj_DisplayedIcon_Img == "" or !FileExist(Obj_DisplayedIcon_Img))
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "run" DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (Obj_DisplayedIcon_Img == "") ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102(Icon_Right1, DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
        else if (InStr(Obj_DisplayedIcon_Img, "PopUpMenu.ico") > 0 or InStr(Obj_DisplayedIcon_Img, "PopUpMenu_Error.ico")) ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
      } ; [End] (ScriptType [run,rwh,url])
      else if (DataArray.366.5 == "key" or DataArray.366.5 == "Ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (Obj_DisplayedIcon_Img == "") ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
        else if (InStr(Obj_DisplayedIcon_Img, "PopUpMenu.ico") > 0 or InStr(Obj_DisplayedIcon_Img, "PopUpMenu_Error.ico")) ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
      } ; [End] (ScriptType [key,ofl])
    } ; [End] if (InStr(DisplayedIconName, "PopUpMenu") > 0 or Obj_DisplayedIcon_Img == "" or !FileExist(Obj_DisplayedIcon_Img))
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; User Folder Theme
      ; -------------------------------------------
      if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FolderThemes := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"
        if (InStr(ThisIcon, FolderThemes) > 0)
        {
          ; -------------------------------------------
          ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, ThisIcon, , Folder_UserTheme
          Icon_UserTheme := Folder_UserTheme "\(1).ico"
          ; -------------------------------------------
          File_UserTheme := A_AppData "\PopUpMenu_PUM\system\File_UserTheme.txt"
          if FileExist(File_UserTheme)
          {
            FileDelete, %File_UserTheme%
            Sleep, 100
          } ; [End] if FileExist(File_UserTheme)
          FileEncoding, UTF-8
          FileAppend, %Icon_UserTheme%, %File_UserTheme% ; UTF-8
          ; -------------------------------------------
        } ; [End] if (InStr(ThisIcon, FolderThemes)
        ; -------------------------------------------
      } ; [End] (ScriptType [ofl])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_102, %Obj_DisplayedIcon_Img% ; (102_1)(Obj_DisplayedIcon)
      GuiControl, PopUpMenu:Move, g_102, w80 h80 ; (102_1)(Obj_DisplayedIcon)
      GuiControl, PopUpMenu:Show, g_102 ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] [CHECK] [SET] Obj_DisplayedIcon_Img
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (DataArray.366.5 == "key" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ThisImage := "C:\Program Files\PopUpMenu_PUM\image\gui\(063)_1_" DataArray.365.2 ".png" ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    if FileExist(ThisImage)
    {
      ; -------------------------------------------
      DataArray.63.2 := 1 ; (063_2)(Obj_SelectIconImage_Sel [0,1,2,3])
      DataArray.63.3 := ThisImage ; (063_3)(Obj_SelectIconImage_Img [Image Path])
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_063, %ThisImage% ; (063_1)(Obj_SelectIconImage)
      GuiControl, PopUpMenu:Show, g_063 ; (063_1)(Obj_SelectIconImage)
      ; -------------------------------------------
    }
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
