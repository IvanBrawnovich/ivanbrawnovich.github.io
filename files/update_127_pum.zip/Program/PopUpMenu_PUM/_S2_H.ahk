﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
; -------------------------------------------
#Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
#Include C:\Program Files\PopUpMenu_PUM\InternetConnectCheck.ahk ; InternetConnectCheck() ; > 0 = No Connection, 1 Has Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
_S2_H(DataArray)
{
  ; -------------------------------------------
  HasConnection := InternetConnectCheck()
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  LimitedArray := DataArray.363.9 ; (363_9)(LinitDataArray [Limited DataArray])
  ;
  if (LimitedArray == "")
  {
    LimitedArray := DataArray
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  for Index, ThisItem in LimitedArray
  {
    ; -------------------------------------------
    ThisItem := ThisItem.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (ThisItem == "GuiVarEnd")
    {
      break
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_001_1") ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      }
      else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        }
      }
      else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 1 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        }
      }
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        }
      }
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("001", 0, 0, DataArray) ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_002_1") ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      }
      else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        }
      }
      else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 1 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        }
      }
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        }
      }
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("002", 0, 0, DataArray) ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_003_1") ; (003_1)(Obj_KeyOfl_3RAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "key" && DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("003", 0, 0, DataArray) ; (003_1)(Obj_KeyOfl_3RAppIco)
      }
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("003", 0, 0, DataArray) ; (003_1)(Obj_KeyOfl_3RAppIco)
        }
      }
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("003", 0, 0, DataArray) ; (003_1)(Obj_KeyOfl_3RAppIco)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_004_1") ; (004_1)(Obj_ok)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_005_1") ; (005_1)(ORG_ScriptType)
    {
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_006_1") ; (006_1)(Obj_ShortcutToDefaultPum)
    {
      ; -------------------------------------------
      ThisPumProcessXml := DataArray.361.9 ; (361)(9)(ThisPumProcessXml [Full File Path])
      ; -------------------------------------------
      if (InStr(ThisPumProcessXml, "\pumdefault\") > 0) ; (Default Pum Active is Active)
      {
        DataArray := Image_GuiControl("006", 0, 0, DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
      } ; [End] (Default Pum Active is Active)
      else ; App Pum is Current
      {
        if (DataArray.366.5 != "xxx" or DataArray.305.18 == 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("006", 0, 0, DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
        } ; [End] NOT (ScriptType [xxx])
      } ; [End] App Pum is Current
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_007_1") ; (007_1)(Obj_KeyOfl_RFolderImage)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "key" && DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("007", 0, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
      }
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("007", 0, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
        }
      }
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("007", 0, 0, DataArray) ; (007_1)(Obj_KeyOfl_RFolderImage)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_008_1") ; (008_1)(Obj_Key_Alt)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("008", 0, 0, DataArray) ; (008_1)(Obj_Key_Alt)
        }
      }
      else
      {
        DataArray := Image_GuiControl("008", 0, 0, DataArray) ; (008_1)(Obj_Key_Alt)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_009_1") ; (009_1)(Obj_Key_AltDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("009", 0, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
        }
      }
      else
      {
        DataArray := Image_GuiControl("009", 0, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_010_1") ; (010_1)(Obj_Key_AltLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("010", 0, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
        }
      }
      else
      {
        DataArray := Image_GuiControl("010", 0, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_011_1") ; (011_1)(Obj_Key_AltRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("011", 0, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
        }
      }
      else
      {
        DataArray := Image_GuiControl("011", 0, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_012_1") ; (012_1)(Obj_Key_AltUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("012", 0, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
        }
        else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(009)") == 0)
          {
            DataArray := Image_GuiControl("012", 0, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
          } ; [End] if (Array_ItemExist(Key_ArrayNumbers, "(009)") == 0)
        } ; [End] (ScriptType [key])
      } ; [End] (ScriptError [0, 3, 13])
      else ; NOT (ScriptError [0, 3, 13])
      {
        DataArray := Image_GuiControl("012", 0, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
      } ; [End] NOT (ScriptError [0, 3, 13])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_013_1") ; (013_1)(Obj_Key_CapsLock)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("013", 0, 0, DataArray) ; (013_1)(Obj_Key_CapsLock)
        }
      }
      else
      {
        DataArray := Image_GuiControl("013", 0, 0, DataArray) ; (013_1)(Obj_Key_CapsLock)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_014_1") ; (014_1)(Obj_Key_CtrlDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("014", 0, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
        }
      }
      else
      {
        DataArray := Image_GuiControl("014", 0, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_015_1") ; (015_1)(Obj_Key_CtrlLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("015", 0, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
        }
      }
      else
      {
        DataArray := Image_GuiControl("015", 0, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_016_1") ; (016_1)(Obj_Key_CtrlRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("016", 0, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
        }
      }
      else
      {
        DataArray := Image_GuiControl("016", 0, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_017_1") ; (017_1)(Obj_Key_CtrlUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("017", 0, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
        }
        else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(014)") == 0)
          {
            DataArray := Image_GuiControl("017", 0, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
          }
        }
      }
      else
      {
        DataArray := Image_GuiControl("017", 0, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_018_1") ; (018_1)(Obj_Key_Enter)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("018", 0, 0, DataArray) ; (018_1)(Obj_Key_Enter)
        }
      }
      else
      {
        DataArray := Image_GuiControl("018", 0, 0, DataArray) ; (018_1)(Obj_Key_Enter)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_019_1") ; (019_1)(Obj_Key_EnterX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("019", 0, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("019", 0, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_020_1") ; (020_1)(Obj_Key_Esc)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("020", 0, 0, DataArray) ; (020_1)(Obj_Key_Esc)
        }
      }
      else
      {
        DataArray := Image_GuiControl("020", 0, 0, DataArray) ; (020_1)(Obj_Key_Esc)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_021_1") ; (021_1)(Obj_Key_EscX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("021", 0, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("021", 0, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_022_1") ; (022_1)(Obj_Key_F1)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("022", 0, 0, DataArray) ; (022_1)(Obj_Key_F1)
        }
      }
      else
      {
        DataArray := Image_GuiControl("022", 0, 0, DataArray) ; (022_1)(Obj_Key_F1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_023_1") ; (023_1)(Obj_Key_F2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("023", 0, 0, DataArray) ; (023_1)(Obj_Key_F2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("023", 0, 0, DataArray) ; (023_1)(Obj_Key_F2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_024_1") ; (024_1)(Obj_Key_F3)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("024", 0, 0, DataArray) ; (024_1)(Obj_Key_F3)
        }
      }
      else
      {
        DataArray := Image_GuiControl("024", 0, 0, DataArray) ; (024_1)(Obj_Key_F3)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_025_1") ; (025_1)(Obj_Key_F4)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("025", 0, 0, DataArray) ; (025_1)(Obj_Key_F4)
        }
      }
      else
      {
        DataArray := Image_GuiControl("025", 0, 0, DataArray) ; (025_1)(Obj_Key_F4)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_026_1") ; (026_1)(Obj_Key_F5)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("026", 0, 0, DataArray) ; (026_1)(Obj_Key_F5)
        }
      }
      else
      {
        DataArray := Image_GuiControl("026", 0, 0, DataArray) ; (026_1)(Obj_Key_F5)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_027_1") ; (027_1)(Obj_Key_F6)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("027", 0, 0, DataArray) ; (027_1)(Obj_Key_F6)
        }
      }
      else
      {
        DataArray := Image_GuiControl("027", 0, 0, DataArray) ; (027_1)(Obj_Key_F6)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_028_1") ; (028_1)(Obj_Key_F7)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("028", 0, 0, DataArray) ; (028_1)(Obj_Key_F7)
        }
      }
      else
      {
        DataArray := Image_GuiControl("028", 0, 0, DataArray) ; (028_1)(Obj_Key_F7)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_029_1") ; (029_1)(Obj_Key_F8)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("029", 0, 0, DataArray) ; (029_1)(Obj_Key_F8)
        }
      }
      else
      {
        DataArray := Image_GuiControl("029", 0, 0, DataArray) ; (029_1)(Obj_Key_F8)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_030_1") ; (030_1)(Obj_Key_F9)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("030", 0, 0, DataArray) ; (030_1)(Obj_Key_F9)
        }
      }
      else
      {
        DataArray := Image_GuiControl("030", 0, 0, DataArray) ; (030_1)(Obj_Key_F9)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_031_1") ; (031_1)(Obj_Key_F10)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("031", 0, 0, DataArray) ; (031_1)(Obj_Key_F10)
        }
      }
      else
      {
        DataArray := Image_GuiControl("031", 0, 0, DataArray) ; (031_1)(Obj_Key_F10)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_032_1") ; (032_1)(Obj_Key_F11)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("032", 0, 0, DataArray) ; (032_1)(Obj_Key_F11)
        }
      }
      else
      {
        DataArray := Image_GuiControl("032", 0, 0, DataArray) ; (032_1)(Obj_Key_F11)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_033_1") ; (033_1)(Obj_Key_F12)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("033", 0, 0, DataArray) ; (033_1)(Obj_Key_F12)
        }
      }
      else
      {
        DataArray := Image_GuiControl("033", 0, 0, DataArray) ; (033_1)(Obj_Key_F12)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_034_1") ; (034_1)(Obj_Key_Numpad0)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("034", 0, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
        }
      }
      else
      {
        DataArray := Image_GuiControl("034", 0, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_035_1") ; (035_1)(Obj_Key_Numpad1)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("035", 0, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
        }
      }
      else
      {
        DataArray := Image_GuiControl("035", 0, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_036_1") ; (036_1)(Obj_Key_Numpad2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("036", 0, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("036", 0, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_037_1") ; (037_1)(Obj_Key_Numpad3)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("037", 0, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
        }
      }
      else
      {
        DataArray := Image_GuiControl("037", 0, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_038_1") ; (038_1)(Obj_Key_Numpad4)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("038", 0, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
        }
      }
      else
      {
        DataArray := Image_GuiControl("038", 0, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_039_1") ; (039_1)(Obj_Key_Numpad5)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("039", 0, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
        }
      }
      else
      {
        DataArray := Image_GuiControl("039", 0, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_040_1") ; (040_1)(Obj_Key_Numpad6)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("040", 0, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
        }
      }
      else
      {
        DataArray := Image_GuiControl("040", 0, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_041_1") ; (041_1)(Obj_Key_Numpad7)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("041", 0, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
        }
      }
      else
      {
        DataArray := Image_GuiControl("041", 0, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_042_1") ; (042_1)(Obj_Key_Numpad8)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("042", 0, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
        }
      }
      else
      {
        DataArray := Image_GuiControl("042", 0, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_043_1") ; (043_1)(Obj_Key_Numpad9)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("043", 0, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
        }
      }
      else
      {
        DataArray := Image_GuiControl("043", 0, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_044_1") ; (044_1)(Obj_Key_NumpadAdd)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("044", 0, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
        }
      }
      else
      {
        DataArray := Image_GuiControl("044", 0, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_045_1") ; (045_1)(Obj_Key_NumpadDiv)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("045", 0, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
        }
      }
      else
      {
        DataArray := Image_GuiControl("045", 0, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_046_1") ; (046_1)(Obj_Key_NumpadDot)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("046", 0, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
        }
      }
      else
      {
        DataArray := Image_GuiControl("046", 0, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_047_1") ; (047_1)(Obj_Key_NumpadEnter)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("047", 0, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
        }
      }
      else
      {
        DataArray := Image_GuiControl("047", 0, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_048_1") ; (048_1)(Obj_Key_NumpadMult)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("048", 0, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
        }
      }
      else
      {
        DataArray := Image_GuiControl("048", 0, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_049_1") ; (049_1)(Obj_Key_NumpadSub)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("049", 0, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
        }
      }
      else
      {
        DataArray := Image_GuiControl("049", 0, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_050_1") ; (050_1)(Obj_Key_Shift)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("050", 0, 0, DataArray) ; (050_1)(Obj_Key_Shift)
        }
      }
      else
      {
        DataArray := Image_GuiControl("050", 0, 0, DataArray) ; (050_1)(Obj_Key_Shift)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_051_1") ; (051_1)(Obj_Key_ShiftDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("051", 0, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
        }
      }
      else
      {
        DataArray := Image_GuiControl("051", 0, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_052_1") ; (052_1)(Obj_Key_ShiftLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("052", 0, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
        }
      }
      else
      {
        DataArray := Image_GuiControl("052", 0, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_053_1") ; (053_1)(Obj_Key_ShiftRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("053", 0, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
        }
      }
      else
      {
        DataArray := Image_GuiControl("053", 0, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_054_1") ; (054_1)(Obj_Key_ShiftUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("054", 0, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
        }
        else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(051)") == 0)
          {
            DataArray := Image_GuiControl("054", 0, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
          }
        }
      }
      else
      {
        DataArray := Image_GuiControl("054", 0, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_055_1") ; (055_1)(Obj_Key_Tab)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("055", 0, 0, DataArray) ; (055_1)(Obj_Key_Tab)
        }
      }
      else
      {
        DataArray := Image_GuiControl("055", 0, 0, DataArray) ; (055_1)(Obj_Key_Tab)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_056_1") ; (056_1)(Obj_Key_TabX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("056", 0, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("056", 0, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_057_1") ; (057_1)(Obj_Key_Win_Sel)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("057", 0, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
        }
      }
      else
      {
        DataArray := Image_GuiControl("057", 0, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_058_1") ; (058_1)(Obj_Key_WinDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("058", 0, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
        }
      }
      else
      {
        DataArray := Image_GuiControl("058", 0, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_059_1") ; (059_1)(Obj_Key_WinLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("059", 0, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
        }
      }
      else
      {
        DataArray := Image_GuiControl("059", 0, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_060_1") ; (060_1)(Obj_Key_WinRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("060", 0, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
        }
      }
      else
      {
        DataArray := Image_GuiControl("060", 0, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_061_1") ; (061_1)(Obj_Key_WinUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("061", 0, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
        }
        else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(058)") == 0)
          {
            DataArray := Image_GuiControl("061", 0, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
          }
        }
      }
      else
      {
        DataArray := Image_GuiControl("061", 0, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_062_1") ; (062_1)(Obj_Cancel)
    {
      ; Always Show 
      ; But is I do not Hide Here
      ; The Object will not display
      ; (062_1)(Obj_Cancel)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_063_1") ; (063_1)(Obj_SelectIconImage)
    {
      ; -------------------------------------------
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.4.2 == 3) ; (004_2)(Obj_ok_Sel [0,1,3])
        {
          DataArray := Image_GuiControl("063", 0, 0, DataArray) ; (063_1)(Obj_SelectIconImage)
        }
        else if (DataArray.366.5 != "key" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("063", 0, 0, DataArray) ; (063_1)(Obj_SelectIconImage)
        }
      }
      else 
      {
        DataArray := Image_GuiControl("063", 0, 0, DataArray) ; (063_1)(Obj_SelectIconImage)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_064_1") ; (064_1)(Obj_HotKey_LangArray)
    {
      ; (064_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_065_1") ; (065_1)(Obj_ImageText_StatusBar)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 15 or DataArray.366.6 == 18) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("065", 0, 0, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
        }
      }
      else
      {
        DataArray := Image_GuiControl("065", 0, 0, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_066_1") ; (066_1)(Obj_Key_ImageText_TextInput)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("066", 0, 0, DataArray) ; (066_1)(Obj_Key_ImageText_TextInput)
        }
      }
      else
      {
        DataArray := Image_GuiControl("066", 0, 0, DataArray) ; (066_1)(Obj_Key_ImageText_TextInput)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_067_1") ; (067_1)(Obj_Key_ImageText_NumericKeypad)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("067", 0, 0, DataArray) ; (067_1)(Obj_Key_ImageText_NumericKeypad)
        }
      }
      else
      {
        DataArray := Image_GuiControl("067", 0, 0, DataArray) ; (067_1)(Obj_Key_ImageText_NumericKeypad)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_068_1") ; (068_1)(Obj_RwhUrl_OpenWith)
    {
      ; -------------------------------------------
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "rwh") ; [ScriptType] is NOT "rwh"
        {
          DataArray := Image_GuiControl("068", 0, 0, DataArray) ; (068_1)(Obj_RwhUrl_OpenWith)
        }
      }
      else
      {
        DataArray := Image_GuiControl("068", 0, 0, DataArray) ; (068_1)(Obj_RwhUrl_OpenWith)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_069_1") ; (069_1)(Obj_RwhUrl_OpenWithReset)
    {
      ; -------------------------------------------
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "rwh") ; [ScriptType] is NOT "rwh"
        {
          DataArray := Image_GuiControl("069", 0, 0, DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
        }
      }
      else
      {
        DataArray := Image_GuiControl("069", 0, 0, DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_070_1") ; (070_1)(Obj_Cpl_WinControl)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (ActiveProcess = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "mnu_cpl_key" && DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("070", 0, 0, DataArray) ; (070_1)(Obj_Cpl_WinControl)
        }
      }
      else
      {
        DataArray := Image_GuiControl("070", 0, 0, DataArray) ; (070_1)(Obj_Cpl_WinControl)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_071_1") ; (071_1)(Obj_URL)
    {
      if (DataArray.366.5 != "run_rwh_url_ofl" or DataArray.366.5 != "run" or DataArray.366.5 != "rwh" or DataArray.366.5 != "url" or DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("071", 0, 0, DataArray) ; (071_1)(Obj_URL)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_072_1") ; (072_1)(Obj_Key_AppOnly)
    {
      ; -------------------------------------------
      if (DataArray.301.11  == 1) ; (301_11)(Key_ShortcutInAppPum [0,1])
      {
        DataArray := Image_GuiControl("072", 0, 0, DataArray) ; (072_1)(Obj_Key_AppOnly)
      } ; [End] (Key_ShortcutInAppPum == 1)
      else if (DataArray.301.11  == 0) ; (301_11)(Key_ShortcutInAppPum [0,1])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("072", 0, 0, DataArray) ; (072_1)(Obj_Key_AppOnly)
          }
        }
      } ; [End] (Key_ShortcutInAppPum == 0)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_073_1") ; (073_1)(Obj_Run_AsAdmin)
    {
      ; -------------------------------------------
      if (A_IsAdmin == 1) ; User is Admin (Show)
      {
        if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 != "run" && DataArray.366.5 != "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("073", 0, 0, DataArray) ; (073_1)(Obj_Run_AsAdmin)
          }
        }
        else
        {
          DataArray := Image_GuiControl("073", 0, 0, DataArray) ; (073_1)(Obj_Run_AsAdmin)
        }
      }
      else ; User is NOT Admin (Hide)
      {
        DataArray := Image_GuiControl("073", 0, 0, DataArray) ; (073_1)(Obj_Run_AsAdmin)
        DataArray.73.2 := 0 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_074_1") ; (074_1)(Obj_Key_Ctrl)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("074", 0, 0, DataArray) ; (074_1)(Obj_Key_Ctrl)
        }
      }
      else
      {
        DataArray := Image_GuiControl("074", 0, 0, DataArray) ; (074_1)(Obj_Key_Ctrl)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_075_1") ; (075_1)(Obj_Key_Delete)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("075", 0, 0, DataArray) ; (075_1)(Obj_Key_Delete)
        }
      }
      else
      {
        DataArray := Image_GuiControl("075", 0, 0, DataArray) ; (075_1)(Obj_Key_Delete)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_076_1") ; (076_1)(Obj_Key_End)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("076", 0, 0, DataArray) ; (076_1)(Obj_Key_End)
        }
      }
      else
      {
        DataArray := Image_GuiControl("076", 0, 0, DataArray) ; (076_1)(Obj_Key_End)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_077_1") ; (077_1)(Obj_Key_Home)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("077", 0, 0, DataArray) ; (077_1)(Obj_Key_Home)
        }
      }
      else
      {
        DataArray := Image_GuiControl("077", 0, 0, DataArray) ; (077_1)(Obj_Key_Home)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_078_1") ; (078_1)(Obj_Key_Insert)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("078", 0, 0, DataArray) ; (078_1)(Obj_Key_Insert)
        }
      }
      else
      {
        DataArray := Image_GuiControl("078", 0, 0, DataArray) ; (078_1)(Obj_Key_Insert)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_079_1") ; (079_1)(Obj_Key_PgDn)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("079", 0, 0, DataArray) ; (079_1)(Obj_Key_PgDn)
        }
      }
      else
      {
        DataArray := Image_GuiControl("079", 0, 0, DataArray) ; (079_1)(Obj_Key_PgDn)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_080_1") ; (080_1)(Obj_Key_PgUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("080", 0, 0, DataArray) ; (080_1)(Obj_Key_PgUp)
        }
      }
      else
      {
        DataArray := Image_GuiControl("080", 0, 0, DataArray) ; (080_1)(Obj_Key_PgUp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_081_1") ; (081_1)(Obj_RunRwh_File)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (ActiveProcess = "windows")
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 6 or DataArray.366.6 == 8 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 20 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "run_rwh_url_ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url" && DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("081", 0, 0, DataArray) ; (081_1)(Obj_RunRwh_File)
        }
      }
      else
      {
        DataArray := Image_GuiControl("081", 0, 0, DataArray) ; (081_1)(Obj_RunRwh_File)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_082_1") ; (082_1)(Obj_Ofl_Folder)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (ActiveProcess = "windows")
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 6 or DataArray.366.6 == 8 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 20 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "run_rwh_url_ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url" && DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("082", 0, 0, DataArray) ; (082_1)(Obj_Ofl_Folder)
        }
      }
      else
      {
        DataArray := Image_GuiControl("082", 0, 0, DataArray) ; (082_1)(Obj_Ofl_Folder)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_083_1") ; (083_1)(Obj_Tom_Pum)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_084_1") ; (084_1)(Obj_Tom_FileUrlFolder)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_085_1") ; (085_1)(Obj_Key_Keyboard)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (ActiveProcess = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "mnu_cpl_key" && DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("085", 0, 0, DataArray) ; (085_1)(Obj_Key_Keyboard)
        }
      }
      else
      {
        DataArray := Image_GuiControl("085", 0, 0, DataArray) ; (085_1)(Obj_Key_Keyboard)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_086_1") ; (086_1)(Obj_Tom_MenuControlKey)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_087_1") ; (087_1)(Obj_Mnu_Menu)
    {
      ; -------------------------------------------
      if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
        ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
        ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
        ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
        ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          if (DataArray.366.5 != "mnu_cpl_key" && DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("087", 0, 0, DataArray) ; (087_1)(Obj_Mnu_Menu)
          }
        }
        else
        {
          DataArray := Image_GuiControl("087", 0, 0, DataArray) ; (087_1)(Obj_Mnu_Menu)
        }
      }
      else
      {
        DataArray := Image_GuiControl("087", 0, 0, DataArray) ; (087_1)(Obj_Mnu_Menu)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_088_1") ; (088_1)(Obj_Mnu_AppMenu1)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 1) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("088", 0, 0, DataArray) ; (088_1)(Obj_Mnu_AppMenu1)
            }
          }
          else
          {
            DataArray := Image_GuiControl("088", 0, 0, DataArray) ; (088_1)(Obj_Mnu_AppMenu1)
          }
        }
        else
        {
          DataArray := Image_GuiControl("088", 0, 0, DataArray) ; (088_1)(Obj_Mnu_AppMenu1)
        }
      }
      else
      {
        DataArray := Image_GuiControl("088", 0, 0, DataArray) ; (088_1)(Obj_Mnu_AppMenu1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_089_1") ; (089_1)(Obj_Mnu_AppMenu2)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 2) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("089", 0, 0, DataArray) ; (089_1)(Obj_Mnu_AppMenu2)
            }
          }
          else
          {
            DataArray := Image_GuiControl("089", 0, 0, DataArray) ; (089_1)(Obj_Mnu_AppMenu2)
          }
        }
        else
        {
          DataArray := Image_GuiControl("089", 0, 0, DataArray) ; (089_1)(Obj_Mnu_AppMenu2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("089", 0, 0, DataArray) ; (089_1)(Obj_Mnu_AppMenu2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_090_1") ; (090_1)(Obj_Mnu_AppMenu3)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 3) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("090", 0, 0, DataArray) ; (090_1)(Obj_Mnu_AppMenu3)
            }
          }
          else
          {
            DataArray := Image_GuiControl("090", 0, 0, DataArray) ; (090_1)(Obj_Mnu_AppMenu3)
          }
        }
        else
        {
          DataArray := Image_GuiControl("090", 0, 0, DataArray) ; (090_1)(Obj_Mnu_AppMenu3)
        }
      }
      else
      {
        DataArray := Image_GuiControl("090", 0, 0, DataArray) ; (090_1)(Obj_Mnu_AppMenu3)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_091_1") ; (091_1)(Obj_Mnu_AppMenu4)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 4) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("091", 0, 0, DataArray) ; (091_1)(Obj_Mnu_AppMenu4)
            }
          }
          else
          {
            DataArray := Image_GuiControl("091", 0, 0, DataArray) ; (091_1)(Obj_Mnu_AppMenu4)
          }
        }
        else
        {
          DataArray := Image_GuiControl("091", 0, 0, DataArray) ; (091_1)(Obj_Mnu_AppMenu4)
        }
      }
      else
      {
        DataArray := Image_GuiControl("091", 0, 0, DataArray) ; (091_1)(Obj_Mnu_AppMenu4)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_092_1") ; (092_1)(Obj_Mnu_AppMenu5)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 5) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("092", 0, 0, DataArray) ; (092_1)(Obj_Mnu_AppMenu5)
            }
          }
          else
          {
            DataArray := Image_GuiControl("092", 0, 0, DataArray) ; (092_1)(Obj_Mnu_AppMenu5)
          }
        }
        else
        {
          DataArray := Image_GuiControl("092", 0, 0, DataArray) ; (092_1)(Obj_Mnu_AppMenu5)
        }
      }
      else
      {
        DataArray := Image_GuiControl("092", 0, 0, DataArray) ; (092_1)(Obj_Mnu_AppMenu5)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_093_1") ; (093_1)(Obj_Mnu_AppMenu6)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 6) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("093", 0, 0, DataArray) ; (093_1)(Obj_Mnu_AppMenu6)
            }
          }
          else
          {
            DataArray := Image_GuiControl("093", 0, 0, DataArray) ; (093_1)(Obj_Mnu_AppMenu6)
          }
        }
        else
        {
          DataArray := Image_GuiControl("093", 0, 0, DataArray) ; (093_1)(Obj_Mnu_AppMenu6)
        }
      }
      else
      {
        DataArray := Image_GuiControl("093", 0, 0, DataArray) ; (093_1)(Obj_Mnu_AppMenu6)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_094_1") ; (094_1)(Obj_Mnu_AppMenu7)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 7) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("094", 0, 0, DataArray) ; (094_1)(Obj_Mnu_AppMenu7)
            }
          }
          else
          {
            DataArray := Image_GuiControl("094", 0, 0, DataArray) ; (094_1)(Obj_Mnu_AppMenu7)
          }
        }
        else
        {
          DataArray := Image_GuiControl("094", 0, 0, DataArray) ; (094_1)(Obj_Mnu_AppMenu7)
        }
      }
      else
      {
        DataArray := Image_GuiControl("094", 0, 0, DataArray) ; (094_1)(Obj_Mnu_AppMenu7)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_095_1") ; (095_1)(Obj_Mnu_AppMenu8)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 8) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("095", 0, 0, DataArray) ; (095_1)(Obj_Mnu_AppMenu8)
            }
          }
          else
          {
            DataArray := Image_GuiControl("095", 0, 0, DataArray) ; (095_1)(Obj_Mnu_AppMenu8)
          }
        }
        else
        {
          DataArray := Image_GuiControl("095", 0, 0, DataArray) ; (095_1)(Obj_Mnu_AppMenu8)
        }
      }
      else
      {
        DataArray := Image_GuiControl("095", 0, 0, DataArray) ; (095_1)(Obj_Mnu_AppMenu8)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_096_1") ; (096_1)(Obj_Mnu_AppMenu9)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 9) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("096", 0, 0, DataArray) ; (096_1)(Obj_Mnu_AppMenu9)
            }
          }
          else
          {
            DataArray := Image_GuiControl("096", 0, 0, DataArray) ; (096_1)(Obj_Mnu_AppMenu9)
          }
        }
        else
        {
          DataArray := Image_GuiControl("096", 0, 0, DataArray) ; (096_1)(Obj_Mnu_AppMenu9)
        }
      }
      else
      {
        DataArray := Image_GuiControl("096", 0, 0, DataArray) ; (096_1)(Obj_Mnu_AppMenu9)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_097_1") ; (097_1)(Obj_Mnu_AppMenu10)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 10) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("097", 0, 0, DataArray) ; (097_1)(Obj_Mnu_AppMenu10)
            }
          }
          else
          {
            DataArray := Image_GuiControl("097", 0, 0, DataArray) ; (097_1)(Obj_Mnu_AppMenu10)
          }
        }
        else
        {
          DataArray := Image_GuiControl("097", 0, 0, DataArray) ; (097_1)(Obj_Mnu_AppMenu10)
        }
      }
      else
      {
        DataArray := Image_GuiControl("097", 0, 0, DataArray) ; (097_1)(Obj_Mnu_AppMenu10)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_098_1") ; (098_1)(Obj_Mnu_AppMenu11)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 11) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("098", 0, 0, DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
            }
          }
          else
          {
            DataArray := Image_GuiControl("098", 0, 0, DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
          }
        }
        else
        {
          DataArray := Image_GuiControl("098", 0, 0, DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
        }
      }
      else
      {
        DataArray := Image_GuiControl("098", 0, 0, DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_099_1") ; (099_1)(Obj_PopUpMenuWebLink)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_100_1") ; (100_1)(Obj_DisplayText_Top1)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (Application Target [exe] File Not Found)
      ; -------------------------------------------
      if (DataArray.366.6 != 1 or DataArray.366.5 != "run" or DataArray.366.5 != "rwh" or DataArray.366.5 != "ofl") ; (366_6)(ScriptError [Integer])/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("100", 0, 0, DataArray) ; (100_1)(Obj_DisplayText_Top1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_101_1") ; (101_1)(Obj_LangFlag)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_102_1") ; (102_1)(Obj_DisplayedIcon)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; -------------------------------------------
      if (DataArray.366.6 != 1 && DataArray.366.6 != 2 && DataArray.366.6 != 3 && DataArray.366.6 != 6) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
        ; -------------------------------------------
      }
      else if (DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_103_1") ; (103_1)(Obj_RwhUrl_OpeningAppImage)
    {
      ; -------------------------------------------
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; [ScriptError = 0], or [ScriptError = 2] (rwh)(No Application to Open File)
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "rwh") ; [ScriptType] is NOT "rwh"
        {
          DataArray := Image_GuiControl("103", 0, 0, DataArray) ; (103_1)(Obj_RwhUrl_OpeningAppImage)
        }
        ; -------------------------------------------
      } ; [ScriptError = 0], or [ScriptError = 2] (rwh)(No Application to Open File)
      else ; [ScriptError NOT = 0], or [ScriptError NOT = 2] (rwh)(No Application to Open File)
      {
        DataArray := Image_GuiControl("103", 0, 0, DataArray) ; (103_1)(Obj_RwhUrl_OpeningAppImage)
      } ; [ScriptError NOT = 0], or [ScriptError NOT = 2] (rwh)(No Application to Open File)
    } ; (103_1)(Obj_RwhUrl_OpeningAppImage)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_104_1") ; (104_1)(Obj_DisplayText_Bottom1)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 17) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
        }
      }
      else
      {
        DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_105_1") ; (105_1)(Obj_DisplayText_Top2)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("105", 0, 0, DataArray) ; (105_1)(Obj_DisplayText_Top2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("105", 0, 0, DataArray) ; (105_1)(Obj_DisplayText_Top2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_106_1") ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "key" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
      }
      else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        }
      }
      else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 1 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        }
      }
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("106", 0, 0, DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_107_1") ; (107_1)(Obj_DisplayText_Bottom2)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 17) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
        }
      }
      else
      {
        DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_108_1") ; (108_1)(Obj_Url_SameNewTab)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("108", 0, 0, DataArray) ; (108_1)(Obj_Url_SameNewTab)
        ; -------------------------------------------
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_109_1") ; (109_1)(Obj_CatPaw)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "xxx" or DataArray.305.17 == 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        DataArray := Image_GuiControl("109", 0, 0, DataArray) ; (109_1)(Obj_CatPaw)
      } ; [End] NOT (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_110_1") ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10 or DataArray.366.6 == 11) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("110", 0, 0, DataArray) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
        }
      }
      else
      {
        DataArray := Image_GuiControl("110", 0, 0, DataArray) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_111_1") ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10 or DataArray.366.6 == 11) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("111", 0, 0, DataArray) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
        }
      }
      else
      {
        DataArray := Image_GuiControl("111", 0, 0, DataArray) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_112_1") ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("112", 0, 0, DataArray) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
        }
      }
      else
      {
        DataArray := Image_GuiControl("112", 0, 0, DataArray) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_113_1") ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
    {
      ; -------------------------------------------
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "rwh") ; (366_5)(ScriptType [rwh])
        {
          DataArray := Image_GuiControl("113", 0, 0, DataArray) ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
        }
      }
      else
      {
        DataArray := Image_GuiControl("113", 0, 0, DataArray) ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_114_1") ; (114_1)(Obj_DisplayText_Title1)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_115_1") ; (115_1)(Obj_DisplayText_Title2)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_116_1") ; (116_1)(Obj_CplMnu_List100)
    {
        ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10 or DataArray.366.6 == 11) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
        }
      }
      else
      {
        DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_117_1") ; (117_1)(Obj_CplMnu_ListRight60)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10 or DataArray.366.6 == 11) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
        }
      }
      else
      {
        DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_118_1") ; (118_1)(Obj_CplMnu_ListLeft30)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10 or DataArray.366.6 == 11) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
        }
      }
      else
      {
        DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_119_1") ; (119_1)(Mkb_KeyStroke)
    {
      ; (119_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_120_1") ; (120_1)(Obj_CplMnu_ListCenter30)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
        }
      }
      else
      {
        DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_121_1") ; (121_1)(Obj_CplMnu_ListRight30)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
        }
      }
      else
      {
        DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_122_1") ; (122_1)(Obj_EditFeild_StatusBar)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "mnu" && DataArray.366.5 != "cpl" && DataArray.366.5 != "key" && DataArray.366.5 != "ofl" && DataArray.366.5 != "run" && DataArray.366.5 != "rwh" && DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("122", 0, 0, DataArray) ; (122_1)(Obj_EditFeild_StatusBar)
        }
      }
      else
      {
        DataArray := Image_GuiControl("122", 0, 0, DataArray) ; (122_1)(Obj_EditFeild_StatusBar)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_123_1") ; (123_1)(Obj_Key_EditFeild_TextInput)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("123", 0, 0, DataArray) ; (123_1)(Obj_Key_EditFeild_TextInput)
        }
      }
      else
      {
        DataArray := Image_GuiControl("123", 0, 0, DataArray) ; (123_1)(Obj_Key_EditFeild_TextInput)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_124_1") ; (124_1)(Obj_DropDownListLang)
    {
      ; Always Show
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_125_1") ; (125_1)(Obj_Cpl_Menu1)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("125", 0, 0, DataArray) ; (125_1)(Obj_Cpl_Menu1)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("125", 0, 0, DataArray) ; (125_1)(Obj_Cpl_Menu1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_126_1") ; (126_1)(Obj_Cpl_Menu2)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("126", 0, 0, DataArray) ; (126_1)(Obj_Cpl_Menu2)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("126", 0, 0, DataArray) ; (126_1)(Obj_Cpl_Menu2)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_127_1") ; (127_1)(Obj_Cpl_Menu3)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("127", 0, 0, DataArray) ; (127_1)(Obj_Cpl_Menu3)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("127", 0, 0, DataArray) ; (127_1)(Obj_Cpl_Menu3)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_128_1") ; (128_1)(Obj_Cpl_Menu4)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("128", 0, 0, DataArray) ; (128_1)(Obj_Cpl_Menu4)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("128", 0, 0, DataArray) ; (128_1)(Obj_Cpl_Menu4)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_129_1") ; (129_1)(Obj_Cpl_Menu5)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("129", 0, 0, DataArray) ; (129_1)(Obj_Cpl_Menu5)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("129", 0, 0, DataArray) ; (129_1)(Obj_Cpl_Menu5)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_130_1") ; (130_1)(Obj_Cpl_Menu6)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("130", 0, 0, DataArray) ; (130_1)(Obj_Cpl_Menu6)
        }
      }
      else if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("130", 0, 0, DataArray) ; (130_1)(Obj_Cpl_Menu6)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_131_1") ; (131_1)(Obj_DisplayText_UrlAddress)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
     
      ; -------------------------------------------
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 15 or DataArray.366.6 == 18) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("131", 0, 0, DataArray) ; (131_1)(Obj_DisplayText_UrlAddress)
        }
      }
      else
      {
        DataArray := Image_GuiControl("131", 0, 0, DataArray) ; (131_1)(Obj_DisplayText_UrlAddress)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_132_1") ; (132_1)(Empty)
    {
      ; (132_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_133_1") ; (133_1)(Obj_DeleteShortcut)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.366.5 == "xxx" or DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "pumtom") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("133", 0, 0, DataArray) ; (133_1)(Obj_DeleteShortcut)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_134_1") ; (134_1)(Obj_ImageSelect1)
    {
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 22] (No Error)(pumtom)
      ; -------------------------------------------
      if (DataArray.366.6 != 5 && DataArray.366.6 != 7 && DataArray.366.6 != 8 && DataArray.366.6 != 12 && DataArray.366.6 != 17 && DataArray.366.6 != 22) ; (366_6)(ScriptError [Integer])
      {
        DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_135_1") ; (135_1)(Obj_ImageSelect2)
    {
      ; -------------------------------------------
      ; Conditions to Hide
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 22] (No Error)(pumtom)
      ; -------------------------------------------
      if (DataArray.366.6 != 5 && DataArray.366.6 != 7 && DataArray.366.6 != 8 && DataArray.366.6 != 12 && DataArray.366.6 != 17 && DataArray.366.6 != 22) ; (366_6)(ScriptError [Integer])
      {
        DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
      }
      ; -------------------------------------------
      else if (DataArray.307.2 == "" && DataArray.366.5 == "run_rwh_url_ofl") ; (307_2)(Url_Address) is Blank
      {
        
        
        
        
        
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; (_27_Aug_2023_)(_09_20_38_)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Check is Active Application is a Browser
        ; -------------------------------------------
        if (IsInternetBrowser(AppProcessName, AppProcessClass, AppProcessTitle) == 0) ; NOT a Browser
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        ; Check is Active Application is a Browser
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        
        
        
        
        
        
        
        ;~ DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_136_1") ; (136_1)(Obj_ImageSelect3)
    {
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 22] (No Error)(pumtom)
      ; -------------------------------------------
      if (DataArray.366.6 != 5 && DataArray.366.6 != 7 && DataArray.366.6 != 8 && DataArray.366.6 != 12 && DataArray.366.6 != 17 && DataArray.366.6 != 22) ; (366_6)(ScriptError [Integer])
      {
        DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
      }
      else if (DataArray.366.6 == 22) ; (366_6)(ScriptError [Integer])
      {
        if (HasConnection == 0) ; NO Internet Connection
        {
          DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_137_1") ; (137_1)(Obj_MsgImg480x270)
    {
      DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_138_1") ; (138_1)(Obj_Cpl_Menu7)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("138", 0, 0, DataArray) ; (138_1)(Obj_Cpl_Menu7)
        }
      }
      else
      {
        DataArray := Image_GuiControl("138", 0, 0, DataArray) ; (138_1)(Obj_Cpl_Menu7)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_139_1") ; (139_1)(Obj_Cpl_Menu8)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 != "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("139", 0, 0, DataArray) ; (139_1)(Obj_Cpl_Menu8)
        }
      }
      else
      {
        DataArray := Image_GuiControl("139", 0, 0, DataArray) ; (139_1)(Obj_Cpl_Menu8)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_140_1") ; (140_1)(Obj_Mnu_AddonExtra)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 1) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              DataArray := Image_GuiControl("140", 0, 0, DataArray) ; (140_1)(Obj_Mnu_AddonExtra)
            }
          }
          else
          {
            DataArray := Image_GuiControl("140", 0, 0, DataArray) ; (140_1)(Obj_Mnu_AddonExtra)
          }
        }
        else
        {
          DataArray := Image_GuiControl("140", 0, 0, DataArray) ; (140_1)(Obj_Mnu_AddonExtra)
        }
      }
      else
      {
        DataArray := Image_GuiControl("140", 0, 0, DataArray) ; (140_1)(Obj_Mnu_AddonExtra)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_141_1") ; (141_1)(Obj_DisplayText_Title3)
    {
      ; -------------------------------------------
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.133.2 == 2) ; (366_6)(ScriptError [Integer])/(133_2)(Obj_DeleteShortcut_Sel [0,1,2])
      {
        DataArray := Image_GuiControl("141", 0, 0, DataArray) ; (141_1)(Obj_DisplayText_Title3)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_142_1") ; (142_1)(Obj_HotKeyLangFlag)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_143_1") ; (143_1)(Obj_SelFlag_de)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_144_1") ; (144_1)(Obj_SelFlag_en)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_145_1") ; (145_1)(Obj_SelFlag_es)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_146_1") ; (146_1)(Obj_SelFlag_fr)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_147_1") ; (147_1)(Obj_SelFlag_it)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_148_1") ; (148_1)(Obj_SelFlag_pl)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_149_1") ; (149_1)(Obj_SelFlag_pt)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_150_1") ; (150_1)(Obj_SelFlag_ru)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_151_1") ; (151_1)(Obj_SelFlag_sv)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_152_1") ; (152_1)(Obj_SelFlag_tr)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_153_1") ; (153_1)(Empty)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_154_1") ; (154_1)(Obj_Pum_BgImage)
    {
      if (InStr(DataArray.366.5, "pumSetting") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("154", 0, 0, DataArray) ; (154_1)(Obj_Pum_BgImage)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_155_1") ; (155_1)(Obj_Pum_BgText)
    {
      if (InStr(DataArray.366.5, "pumSetting") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("155", 0, 0, DataArray) ; (155_1)(Obj_Pum_BgText)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_156_1") ; (156_1)(Obj_Pum_BgDim)
    {
      if (InStr(DataArray.366.5, "pumSetting") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("156", 0, 0, DataArray) ; (156_1)(Obj_Pum_BgDim)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_157_1") ; (157_1)(Obj_Pum_Setting)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("157", 0, 0, DataArray) ; (157_1)(Obj_Pum_Setting)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_158_1") ; (158_1)(Empty)
    {
      ; (158_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_159_1") ; (159_1)(Obj_Pum_Contact)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("159", 0, 0, DataArray) ; (159_1)(Obj_Pum_Contact)
      }
      else if (HasConnection == 0) ; No Internet Connection
      {
        DataArray := Image_GuiControl("159", 0, 0, DataArray) ; (159_1)(Obj_Pum_Contact)
      } ; [End] No Internet Connection
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_160_1") ; (160_1)(Obj_Pum_App))
    {
      ; -------------------------------------------
      if (DataArray.367.1 == "windows") ; [Windows Desktop is Active] [HIDE] (160)(Obj_Pum_App)
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (160)(Obj_Pum_App)
        ; [Windows Desktop is Active] [HIDE] (160)(Obj_Pum_App)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
				DataArray := Image_GuiControl("160", 0, 0, DataArray) ; (160_1)(Obj_Pum_App)
        ; -------------------------------------------
      } ; [End] Windows Desktop is Active
      else if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (160)(Obj_Pum_App)
        ; [ScriptType] pum NOT inStr [HIDE] (160)(Obj_Pum_App)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("160", 0, 0, DataArray) ; (160_1)(Obj_Pum_App))
      } ; [End] NOT ScriptType [pum]
      else ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (160)(Obj_Pum_App)
        ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (InStr(DataArray.361.9, "\pumdefault\") == 0) ; [Default pum is NOT Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [HIDE] (160)(Obj_Pum_App)
          ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
          ;
          ; [Default pum is NOT Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [HIDE] (160)(Obj_Pum_App)
            ; [Windows Desktop is NOT Active]
            ; [Default pum Active]
            ;
            ; [Internet Browser Application Active]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [HIDE] (160)(Obj_Pum_App)
              ; [Windows Desktop is NOT Active]
              ; [Default pum Active]
              ; [Internet Browser Application Active]
              ;
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [Common Browser pum Exist] [HIDE] (160)(Obj_Pum_App)
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [HIDE] (160)(Obj_Pum_App)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Internet Browser Application Active]
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ;
                ; [Common Browser pum Exist] [HIDE] (160)(Obj_Pum_App)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("160", 0, 0, DataArray) ; (160_1)(Obj_Pum_App))
              } ; [Common Browser pum Exist] [HIDE] (160)(Obj_Pum_App)
              ; -------------------------------------------
            } ; [UseCommonBrowser = 1][All Browsers Same Pum]
            else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [HIDE] (160)(Obj_Pum_App)
              ; [Windows Desktop is NOT Active]
              ; [Default pum Active]
              ; [Internet Browser Application Active]
              ;
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [pum Exist] [HIDE] (160)(Obj_Pum_App)
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [HIDE] (160)(Obj_Pum_App)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Internet Browser Application Active]
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ;
                ; [pum Exist] [HIDE] (160)(Obj_Pum_App)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("160", 0, 0, DataArray) ; (160_1)(Obj_Pum_App))
              } ; [pum Exist] [HIDE] (160)(Obj_Pum_App)
              ; -------------------------------------------
            } ; [UseCommonBrowser = 2][Each Browser Different pum]
            ; -------------------------------------------
          } ; [Internet Browser Application Active]
          ; -------------------------------------------
        } ; [Default pum is NOT Active]
        ; -------------------------------------------
      } ; else ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
      ; -------------------------------------------
    } ; else if (ThisItem == "v_160_1") ; (160_1)(Obj_Pum_App))
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_161_1") ; (161_1)(Obj_Pum_Del)
    {
      ; -------------------------------------------
      if (DataArray.367.1 == "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (161)(Obj_Pum_Del)
        ; [Windows Desktop is Active] [HIDE] (161)(Obj_Pum_Del)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
      } ; [End] Windows Desktop is Active
      else if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (161)(Obj_Pum_Del)
        ; [ScriptType] pum NOT inStr [HIDE] (161)(Obj_Pum_Del)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
      } ; [End] NOT ScriptType [pum]
      else ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [HIDE] (161)(Obj_Pum_Del)
        ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; (361)(9)(ThisPumProcessXml [Full File Path])
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [HIDE] (161)(Obj_Pum_Del)
          ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
          ;
          ; [Default pum Active] [HIDE] (161)(Obj_Pum_Del)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
          ; -------------------------------------------
        } ; Default pum is Active
        else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [HIDE] (161)(Obj_Pum_Del)
          ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
          ; [Default pum NOT Active]
          ;
          ; [Internet Browser Application Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [HIDE] (161)(Obj_Pum_Del)
            ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
            ; [Default pum NOT Active]
            ; [Internet Browser Application Active]
            ;
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
            ; -------------------------------------------
            if !FileExist(ThisPum) ; [Common Browser pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [HIDE] (161)(Obj_Pum_Del)
              ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
              ; [Default pum NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ;
              ; [Common Browser pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
              ; -------------------------------------------
            } ; [Common Browser pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
            ; -------------------------------------------
          } ; [UseCommonBrowser = 1][All Browsers Same Pum]
          else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [HIDE] (161)(Obj_Pum_Del)
            ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
            ; [Default pum NOT Active]
            ; [Internet Browser Application Active]
            ;
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
            ; -------------------------------------------
            if !FileExist(ThisPum) ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [HIDE] (161)(Obj_Pum_Del)
              ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
              ; [Default pum NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ;
              ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
              ; -------------------------------------------
            } ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
          } ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; -------------------------------------------                        
        } ; [Internet Browser Application Active]
        else ; [Any Other Application (Non-Internet Browser) Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [HIDE] (161)(Obj_Pum_Del)
          ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
          ; [Default pum NOT Active]
          ;
          ; [Any Other Application (Non-Internet Browser) Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if !FileExist(ThisPum) ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [HIDE] (161)(Obj_Pum_Del)
            ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
            ; [Default pum NOT Active]
            ; [Any Other Application (Non-Internet Browser) Active]
            ;
            ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("161", 0, 0, DataArray) ; (161_1)(Obj_Pum_Del)
            ; -------------------------------------------
          } ; [pum NOT Exist] [HIDE] (161)(Obj_Pum_Del)
        } ; [Any Other Application (Non-Internet Browser) Active]
      } ; else ; [Windows Desktop is NOT Active] | [ScriptType] pum is inStr
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_162_1") ; (162)(Obj_Pum_Backup)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("162", 0, 1, DataArray) ; (162)(Obj_Pum_Backup)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_163_1") ; (163_1)(Empty)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("163", 0, 1, DataArray) ; (163)(Obj_Pum_Restore)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_164_1") ; (164_1)(Obj_Pum_BgTxtImg)
    {
      if (InStr(DataArray.366.5, "pumBgText") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_165_1") ; (165_1)(Obj_Pum_BgImageSelect)
    {
      if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        GuiControl, PopUpMenu:Hide, g_165 ; (165_1)(Obj_Pum_BgImageSelect)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_166_1") ; (166_1)(Obj_Pum_BgColor)
    {
      if (InStr(DataArray.366.5, "pumBgText") == 0 && InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("166", 0, 0, DataArray) ; (166_1)(Obj_Pum_BgColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_167_1") ; (167_1)(Obj_Pum_BgFitImage)
    {
      if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("167", 0, 0, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_168_1") ; (168_1)(Empty)
    {
      ; (168_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_169_1") ; (169_1)(Obj_CatPawAutoStart)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "xxx" or DataArray.305.17 == 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        DataArray := Image_GuiControl("169", 0, 0, DataArray) ; (169_1)(Obj_CatPawAutoStart)
      } ; [End] NOT (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_170_1") ; (170_1)(Obj_CatPawDropDown)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "xxx" or DataArray.305.17 == 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        DataArray := Image_GuiControl("170", 0, 0, DataArray) ; (170_1)(Obj_CatPawDropDown)
      } ; [End] NOT (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_171_1") ; (171_1)(Empty)
    {
      ; (171_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_172_1") ; (172_1)(Obj_Pum_MobileText)
    {
      if (InStr(DataArray.366.5, "pumBgText") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("172", 0, 0, DataArray) ; (172_1)(Obj_Pum_MobileText)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_173_1") ; (173_1)(Obj_Pum_MobileTxtColor)
    {
      if (InStr(DataArray.366.5, "pumBgText") == 0 && InStr(DataArray.366.5, "pumMobileTextColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("173", 0, 0, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_174_1") ; (174_1)(Obj_Pum_MobileBgColor)
    {
      if (InStr(DataArray.366.5, "pumBgText") == 0 && InStr(DataArray.366.5, "pumMobileBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("174", 0, 0, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_175_1") ; (175_1)(Empty)
    {
      ; (175_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_176_1") ; (176_1)(Empty)
    {
      ; (176_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_177_1") ; (177_1)(Obj_Pum_BgTrans)
    {
      if (InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_178_1") ; (178_1)(Obj_Pum_BgOpacityUp)
    {
      if (InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_179_1") ; (179_1)(Obj_Pum_BgOpacityDown)
    {
      if (InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_180_1") ; (180_1)(Obj_Pum_DisplayText_Opacity)
    {
      if (InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_181_1") ; (181_1)(Obj_Pum_Opacity)
    {
      if (InStr(DataArray.366.5, "pumBgColor") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (182)-(190) (Not Used) / (191) Color Grid Start
    else if (ThisItem == "v_182_1") ; (182_1)(Obj_Pum_BgRotateLeft)
    {
      if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    else if (ThisItem == "v_183_1") ; (183_1)(Obj_Pum_BgRotateRight)
    {
      if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_184_1") ; (184_1)(Obj_Pum_ImageText_EmailAddress)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("184", 0, 0, DataArray) ; (184_1)(Obj_Pum_ImageText_EmailAddress)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_185_1") ; (185_1)(Obj_Pum_ImageText_ContactName)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("185", 0, 0, DataArray) ; (185_1)(Obj_Pum_ImageText_ContactName)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_186_1") ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("186", 0, 0, DataArray) ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_187_1") ; (187_1)(Obj_Pum_SendEmailAnimate)
    {
      if (InStr(DataArray.366.5, "pumContact") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
        DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
        GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
        GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
        ; -------------------------------------------
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_188_1") ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
    {
      if (InStr(DataArray.366.5, "pum_pumContact") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("188", 0, 0, DataArray) ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_189_1") ; (189_1)(Obj_Pum_EditFeild_ContactName)
    {
      if (InStr(DataArray.366.5, "pum_pumContact") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("189", 0, 0, DataArray) ; (189_1)(Obj_Pum_EditFeild_ContactName)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_190_1") ; (190_1)(Obj_Pum_EditFeild_EmailBody)
    {
      if (InStr(DataArray.366.5, "pum_pumContact") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("190", 0, 0, DataArray) ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_191_1") ; (191_1)(Obj_Pum_ColorA1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("191", 0, 0, DataArray) ; (191_1)(Obj_Pum_ColorA1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_192_1") ; (192_1)(Obj_Pum_ColorA2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("192", 0, 0, DataArray) ; (192_1)(Obj_Pum_ColorA2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_193_1") ; (193_1)(Obj_Pum_ColorA3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("193", 0, 0, DataArray) ; (193_1)(Obj_Pum_ColorA3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_194_1") ; (194_1)(Obj_Pum_ColorA4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("194", 0, 0, DataArray) ; (194_1)(Obj_Pum_ColorA4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_195_1") ; (195_1)(Obj_Pum_ColorA5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("195", 0, 0, DataArray) ; (195_1)(Obj_Pum_ColorA5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_196_1") ; (196_1)(Obj_Pum_ColorA6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("196", 0, 0, DataArray) ; (196_1)(Obj_Pum_ColorA6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_197_1") ; (197_1)(Obj_Pum_ColorB1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("197", 0, 0, DataArray) ; (197_1)(Obj_Pum_ColorB1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_198_1") ; (198_1)(Obj_Pum_ColorB2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("198", 0, 0, DataArray) ; (198_1)(Obj_Pum_ColorB2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_199_1") ; (199_1)(Obj_Pum_ColorB3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("199", 0, 0, DataArray) ; (199_1)(Obj_Pum_ColorB3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_200_1") ; (200_1)(Obj_Pum_ColorB4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("200", 0, 0, DataArray) ; (200_1)(Obj_Pum_ColorB4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_201_1") ; (201_1)(Obj_Pum_ColorB5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("201", 0, 0, DataArray) ; (201_1)(Obj_Pum_ColorB5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_202_1") ; (202_1)(Obj_Pum_ColorB6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("202", 0, 0, DataArray) ; (202_1)(Obj_Pum_ColorB6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_203_1") ; (203_1)(Obj_Pum_ColorC1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("203", 0, 0, DataArray) ; (203_1)(Obj_Pum_ColorC1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_204_1") ; (204_1)(Obj_Pum_ColorC2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("204", 0, 0, DataArray) ; (204_1)(Obj_Pum_ColorC2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_205_1") ; (205_1)(Obj_Pum_ColorC3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("205", 0, 0, DataArray) ; (205_1)(Obj_Pum_ColorC3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_206_1") ; (206_1)(Obj_Pum_ColorC4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("206", 0, 0, DataArray) ; (206_1)(Obj_Pum_ColorC4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_207_1") ; (207_1)(Obj_Pum_ColorC5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("207", 0, 0, DataArray) ; (207_1)(Obj_Pum_ColorC5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_208_1") ; (208_1)(Obj_Pum_ColorC6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("208", 0, 0, DataArray) ; (208_1)(Obj_Pum_ColorC6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_209_1") ; (209_1)(Obj_Pum_ColorD1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("209", 0, 0, DataArray) ; (209_1)(Obj_Pum_ColorD1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_210_1") ; (210_1)(Obj_Pum_ColorD2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("210", 0, 0, DataArray) ; (210_1)(Obj_Pum_ColorD2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_211_1") ; (211_1)(Obj_Pum_ColorD3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("211", 0, 0, DataArray) ; (211_1)(Obj_Pum_ColorD3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_212_1") ; (212_1)(Obj_Pum_ColorD4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("212", 0, 0, DataArray) ; (212_1)(Obj_Pum_ColorD4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_213_1") ; (213_1)(Obj_Pum_ColorD5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("213", 0, 0, DataArray) ; (213_1)(Obj_Pum_ColorD5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_214_1") ; (214_1)(Obj_Pum_ColorD6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("214", 0, 0, DataArray) ; (214_1)(Obj_Pum_ColorD6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_215_1") ; (215_1)(Obj_Pum_ColorE1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("215", 0, 0, DataArray) ; (215_1)(Obj_Pum_ColorE1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_216_1") ; (216_1)(Obj_Pum_ColorE2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("216", 0, 0, DataArray) ; (216_1)(Obj_Pum_ColorE2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_217_1") ; (217_1)(Obj_Pum_ColorE3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("217", 0, 0, DataArray) ; (217_1)(Obj_Pum_ColorE3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_218_1") ; (218_1)(Obj_Pum_ColorE4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("218", 0, 0, DataArray) ; (218_1)(Obj_Pum_ColorE4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_219_1") ; (219_1)(Obj_Pum_ColorE5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("219", 0, 0, DataArray) ; (219_1)(Obj_Pum_ColorE5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_220_1") ; (220_1)(Obj_Pum_ColorE6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("220", 0, 0, DataArray) ; (220_1)(Obj_Pum_ColorE6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_221_1") ; (221_1)(Obj_Pum_ColorF1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("221", 0, 0, DataArray) ; (221_1)(Obj_Pum_ColorF1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_222_1") ; (222_1)(Obj_Pum_ColorF2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("222", 0, 0, DataArray) ; (222_1)(Obj_Pum_ColorF2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_223_1") ; (223_1)(Obj_Pum_ColorF3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("223", 0, 0, DataArray) ; (223_1)(Obj_Pum_ColorF3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_224_1") ; (224_1)(Obj_Pum_ColorF4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("224", 0, 0, DataArray) ; (224_1)(Obj_Pum_ColorF4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_225_1") ; (225_1)(Obj_Pum_ColorF5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("225", 0, 0, DataArray) ; (225_1)(Obj_Pum_ColorF5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_226_1") ; (226_1)(Obj_Pum_ColorF6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("226", 0, 0, DataArray) ; (226_1)(Obj_Pum_ColorF6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_227_1") ; (227_1)(Obj_Pum_ColorG1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("227", 0, 0, DataArray) ; (227_1)(Obj_Pum_ColorG1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_228_1") ; (228_1)(Obj_Pum_ColorG2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("228", 0, 0, DataArray) ; (228_1)(Obj_Pum_ColorG2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_229_1") ; (229_1)(Obj_Pum_ColorG3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("229", 0, 0, DataArray) ; (229_1)(Obj_Pum_ColorG3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_230_1") ; (230_1)(Obj_Pum_ColorG4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("230", 0, 0, DataArray) ; (230_1)(Obj_Pum_ColorG4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_231_1") ; (231_1)(Obj_Pum_ColorG5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("231", 0, 0, DataArray) ; (231_1)(Obj_Pum_ColorG5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_232_1") ; (232_1)(Obj_Pum_ColorG6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("232", 0, 0, DataArray) ; (232_1)(Obj_Pum_ColorG6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_233_1") ; (233_1)(Obj_Pum_ColorH1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("233", 0, 0, DataArray) ; (233_1)(Obj_Pum_ColorH1)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_234_1") ; (234_1)(Obj_Pum_ColorH2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("234", 0, 0, DataArray) ; (234_1)(Obj_Pum_ColorH2)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_235_1") ; (235_1)(Obj_Pum_ColorH3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("235", 0, 0, DataArray) ; (235_1)(Obj_Pum_ColorH3)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_236_1") ; (236_1)(Obj_Pum_ColorH4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("236", 0, 0, DataArray) ; (236_1)(Obj_Pum_ColorH4)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_237_1") ; (237_1)(Obj_Pum_ColorH5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("237", 0, 0, DataArray) ; (237_1)(Obj_Pum_ColorH5)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_238_1") ; (238_1)(Obj_Pum_ColorH6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") == 0) && (InStr(DataArray.366.5, "pumTextColor") == 0) && (InStr(DataArray.366.5, "pumMobileBgColor") == 0) && (InStr(DataArray.366.5, "pumMobileTextColor") == 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("238", 0, 0, DataArray) ; (238_1)(Obj_Pum_ColorH6)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_239_1") ; (239_1)(Empty)
    {
      ; (239_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_240_1") ; (240_1)(Empty)
    {
      ; (240_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_241_1") ; (241_1)(Obj_Pum_CropLeft)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_242_1") ; (242_1)(Obj_Pum_CropRight)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_243_1") ; (243_1)(Obj_Pum_CropUp)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_244_1") ; (244_1)(Obj_Pum_CropDown)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_245_1") ; (245_1)(Obj_Pum_CropCenter)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_246_1") ; (246_1)(Obj_Pum_ZoomIn)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_247_1") ; (247_1)(Obj_Pum_ZoomOut)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        ; -------------------------------------------
      }
      else if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_248_1") ; (248_1)(Obj_Ofl_1LAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("248", 0, 0, DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_249_1") ; (249_1)(Obj_Ofl_2LAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("249", 0, 0, DataArray) ; (249_1)(Obj_Ofl_2LAppIco)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_250_1") ; (250_1)(Obj_Ofl_3LAppIco)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("250", 0, 0, DataArray) ; (250_1)(Obj_Ofl_3LAppIco)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_251_1") ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("251", 0, 0, DataArray) ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_252_1") ; (252_1)(Obj_Ofl_LFolderImage)
    {
      ; -------------------------------------------
      if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("252", 0, 0, DataArray) ; (252_1)(Obj_Ofl_LFolderImage)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_253_1") ; (253_1)(Empty)
    {
      ; (253_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_254_1") ; (254_1)(Obj_MsgImg300x300)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
      }
      else
      {
        if ((InStr(DataArray.366.5, "pumBgColor") > 0) or (InStr(DataArray.366.5, "pumTextColor") > 0) or (InStr(DataArray.366.5, "pumMobileBgColor") > 0) or (InStr(DataArray.366.5, "pumMobileTextColor") > 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_255_1") ; (255_1)(Empty)
    {
      ; (255_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_256_1") ; (256_1)(Empty)
    {
      ; (256_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_257_1") ; (257_1)(Empty)
    {
      ; (257_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_258_1") ; (258_1)(Empty)
    {
      ; (258_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_259_1") ; (259_1)(Empty)
    {
      ; (259_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_260_1") ; (260_1)(Obj_Pum_IconSize)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("260", 0, 0, DataArray) ; (260_1)(Obj_Pum_IconSize)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_261_1") ; (261_1)(Obj_Pum_IconUp)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_262_1") ; (262_1)(Obj_Pum_IconDown)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_263_1") ; (263_1)(Obj_Pum_ImageText_IconSize)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("263", 0, 0, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_264_1") ; (264_1)(Empty)
    {
      ; (264_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_265_1") ; (265_1)(Empty)
    {
      ; (265_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_266_1") ; (266_1)(Obj_Pum_PumRow)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("266", 0, 0, DataArray) ; (266_1)(Obj_Pum_PumRow)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_267_1") ; (267_1)(Obj_Pum_PumRowUp)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_268_1") ; (268_1)(Obj_Pum_PumRowDown)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_269_1") ; (269_1)(Obj_Pum_DisplayText_Vertical)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("269", 0, 0, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_270_1") ; (270_1)(Empty)
    {
      ; (270_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_271_1") ; (271_1)(Empty)
    {
      ; (271_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_272_1") ; (272_1)(Obj_Pum_PumColumn)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("272", 0, 0, DataArray) ; (272_1)(Obj_Pum_PumColumn)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_273_1") ; (273_1)(Obj_Pum_PumColumnUp)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_274_1") ; (274_1)(Obj_Pum_PumColumnDown)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_275_1") ; (275_1)(Obj_Pum_DisplayText_Horizontal)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("275", 0, 0, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (276_1)(Empty)
    else if (ThisItem == "v_277_1") ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumDimension") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_290_1") ; (290)(Obj_BrowserPum)
    {
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("290", 0, 0, DataArray) ; (290)(Obj_BrowserPum)
      }
      else if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
        {
          GuiControl, PopUpMenu:Hide, g_290
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (276)-(299) (Not Used)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
