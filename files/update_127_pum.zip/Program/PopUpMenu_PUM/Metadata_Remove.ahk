﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;#Include C:\Program Files\PopUpMenu_PUM\Metadata_Remove.ahk ; Metadata_Remove(FileIn) ; > Nothing
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Removes All Metadata from File Overwrites (FileIn) with NO Metadata
; -------------------------------------------
Metadata_Remove(FileIn) ; > Nothing
{
  ; -------------------------------------------
  if FileExist(FileIn)
  {
    ; -------------------------------------------
    ThisProgram := "C:\Program Files\PopUpMenu_PUM\support\exiftool\exiftool.exe"
    RunThis := """" ThisProgram """ -overwrite_original_in_place -all= """ FileIn """"
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
} ; [FUNCTION] (Metadata_Remove)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
