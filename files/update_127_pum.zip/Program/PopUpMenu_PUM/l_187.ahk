﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_187: ; (187_1)(Obj_Pum_SendEmailAnimate)
{
  ; -------------------------------------------
  ; Send Email
  ; -------------------------------------------
  ;
  ; (_w138 x h192_)
  ; NO Repeat
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Send Email)
  ; global n_187 := 1 ; Start Frame Number
  ; global s_187 := 1 ; Show
  ; (187_1)(Obj_Pum_SendEmailAnimate)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Send Email)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Send Email)
  ; global s_187 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Send Email)
  ;
  ; [ANIMATE] Start/Show in This File
  ; (004_1)(Obj_ok)
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 22
  ; -------------------------------------------
  if (s_187 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_187 <= Total_Images)
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_187, C:\Program Files\PopUpMenu_PUM\image\gui\(187)_%n_187%.png ; (187_1)(Obj_Pum_SendEmailAnimate)
      ; -------------------------------------------
      Gui_ObjectSize("187", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_187 := n_187 + 1
      ; -------------------------------------------
    }
  } ; [End] Show Animation
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_187, Off ; (187_1)(Obj_Pum_SendEmailAnimate)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; End (187_1)(GUI Object: [pumContact] <Image Animate> Logo/Send Email)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
