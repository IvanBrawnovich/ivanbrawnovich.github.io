﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include C:\Program Files\PopUpMenu_PUM\File_UnZip.ahk
#Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
#Include C:\Program Files\PopUpMenu_PUM\MsgToFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
; -------------------------------------------
ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
ArrayOut   := Image_PathFolderOrName(ArrayIn)
FileRunPng := ArrayOut.1
; -------------------------------------------
ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
ArrayOut   := Image_PathFolderOrName(ArrayIn)
FileRunPng := ArrayOut.1
; -------------------------------------------
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
In_Type               := ArrayIn.4
UserLang              := ArrayIn.5 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.6 ; (DataArray.363.12)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FileOrFolder  := ArrayOut.1
ThisProcessName   := ArrayOut.2
ThisProcessExt    := ArrayOut.3
ThisProcessFolder := ArrayOut.4
UserPictureFolder := ArrayOut.5
; -------------------------------------------
ArrayOut := [FileOrFolder, ThisProcessName, ThisProcessExt, ThisProcessFolder, UserPictureFolder]
; -------------------------------------------
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_PathFolderOrName(ArrayIn)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [Image_PathFolderOrName] This Script just sets Paths
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1
  AppProcessName        := ArrayIn.2
  UseCommonBrowser      := ArrayIn.3
  In_Type               := ArrayIn.4
  UserLang              := ArrayIn.5
  UserPictureFolder     := ArrayIn.6
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (InStr(In_Type, "Folder") > 0) ; Folder Only
  {
    ; -------------------------------------------
    FileOrFolder := ""
    ; -------------------------------------------
    if (In_Type == "FolderWindows")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Windows_)"
      ; -------------------------------------------
    } ; if (In_Type == "FolderWindows")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderOfl")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderOfl")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderKey")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Keyboard_)"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderKey")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderRunPng")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderRunPng")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderRunIco")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderRunico")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderRwhIco")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderRwhIco")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderOflIco")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderOflIco")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderError440")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error440"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderError440")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderError450")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error450"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderError450")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderError460")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error460"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderError460")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderError470")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error470"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderError470")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderNew135")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\New135"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderNew135")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderDel135")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Del135"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderDel135")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderNew254")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\New254"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderNew254")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderDel254")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Del254"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderDel254")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderMnu134")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Mnu134"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderMnu134")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderMnu137")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Mnu137"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderMnu137")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (In_Type == "FolderRwhUrl103")
    {
      ; -------------------------------------------
      FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\RwhUrl103"
      ; -------------------------------------------
    } ; else if (In_Type == "FolderRwhUrl103")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (FileOrFolder != "")
    {
      if !FileExist(FileOrFolder)
      {
        FileCreateDir, %FileOrFolder%
        Sleep, 10
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; if (InStr(In_Type, "Folder") > 0) ; Folder Only
  else ; File Paths
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; UseCommonBrowser == 0 [Internet Browser NOT Active]
    ; UseCommonBrowser == 2 [Each Browser Different pum]
    if FileExist(AppProcessPathNameExt)
    {
      ; -------------------------------------------
      UseCommonBrowser := 0 ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; -------------------------------------------
      StringLower, AppProcessPathNameExt, AppProcessPathNameExt
      SplitPath, AppProcessPathNameExt, , ThisProcessFolder, ThisProcessExt, ThisProcessName
      ThisProcessName := StrReplace(ThisProcessName, A_Space, "")
      ; -------------------------------------------
      ThisProcessFolder := StrReplace(ThisProcessFolder, "\", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, "/", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, ":", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, "?", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, """", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, "<", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, ">", "")
      ThisProcessFolder := StrReplace(ThisProcessFolder, "|", "")
      ; -------------------------------------------
    } ; else if FileExist(AppProcessPathNameExt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    FileOrFolder := ""
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (FileExist(AppProcessPathNameExt) or UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; -------------------------------------------
      if (In_Type == "FileRunPng")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileRunPng") ; [FILE]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileRunIco")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Ico.ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" ThisProcessName "_(" ThisProcessFolder ").ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileRunIco") ; [FILE]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileRwhIco")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Rwh.ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)\" ThisProcessName "_(" ThisProcessFolder ").ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileRwhIco")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileOflIco")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Ofl.ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)\" ThisProcessName "_(" ThisProcessFolder ").ico"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        
        ; -------------------------------------------
      } ; else if (In_Type == "FileOflIco")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileNew135")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_New135.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\New135\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileNew135")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileDel135")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Del135.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Del135\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileDel135")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileMnu134")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Mnu134.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Mnu134\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileMnu134")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileMnu137")
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Mnu137.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Mnu137\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileMnu137")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileRwhUrl103") ; (_01_Nov_2022_)(_13:00:52_) Could Not Create for CommonBrowser No Example Exist
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_RwhUrl103.png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\RwhUrl103\" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileRwhUrl103")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileError440") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Error440_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error440\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileError440")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileError450") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Error450_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error450\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileError450")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileError460") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Error460_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error460\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileError460")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileError470") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Error470_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Error470\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileError470")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileNew254") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_New254_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\New254\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileNew254")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else if (In_Type == "FileDel254") ; With UserLang
      {
        ; -------------------------------------------
        if (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; -------------------------------------------
          FileOrFolder := "C:\Program Files\PopUpMenu_PUM\image\ico\CommonBrowser_Del254_" UserLang ".png"
          ; -------------------------------------------
        } ; (UseCommonBrowser == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else ; (UseCommonBrowser != 1)
        {
          ; -------------------------------------------
          FileOrFolder := UserPictureFolder "\(_PopUpMenu_)\System\Del254\" UserLang "_" ThisProcessName "_(" ThisProcessFolder ").png"
          ; -------------------------------------------
        } ; (UseCommonBrowser != 1)
        ; -------------------------------------------
      } ; else if (In_Type == "FileDel254")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; if FileExist(AppProcessPathNameExt)
    ; -------------------------------------------
  } ; else ; File Paths
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ArrayOut := [FileOrFolder, ThisProcessName, ThisProcessExt, ThisProcessFolder, UserPictureFolder]
  return ArrayOut
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
