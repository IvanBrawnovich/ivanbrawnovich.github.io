﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
#Include C:\Program Files\PopUpMenu_PUM\Pum_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
#Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
#Include C:\Program Files\PopUpMenu_PUM\Sys_ResetDataArray.ahk
#Include C:\Program Files\PopUpMenu_PUM\Sys_EnableDisable.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_062(DataArray) ; (062_1)(Obj_Cancel)
{
  ; -------------------------------------------
  ToolTip
  ; -------------------------------------------
  DataArray.169.2 := DataArray.169.4 ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])/(169_4)(Obj_CatPawPreviousAutoStart_Sel [1,2])
  DataArray.170.2 := DataArray.170.4 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])/(170_4)(Obj_CatPawPreviousDropDown_Time [1,2,3,4,5])
  ; -------------------------------------------
  DataArray := Image_GuiControl("062", 2, 0, DataArray) ; (062_1)(Obj_Cancel)
  ; -------------------------------------------
  KeyWait, LButton, L
  KeyWait, LButton
  BlockInput, On
  Sleep, 100
  ; -------------------------------------------
  Sys_EnableDisable("Enable") ; "Enable" or "Disable"
  ; -------------------------------------------
  Pum_Close(DataArray) ; > Nothing
  ; -------------------------------------------
  global LockKeys := 0
  ; -------------------------------------------
  DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
  ; -------------------------------------------
  DataArray := Image_GuiControl("062", 1, 0, DataArray) ; (062_1)(Obj_Cancel)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Gui_Language.ahk"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    WinSet, AlwaysOnTop, Off, Language_Gui ahk_class AutoHotkeyGUI
    Script_Close(ScriptPath)
  }
  ; -------------------------------------------  
  ;
  ; -------------------------------------------
  if (DataArray.169.2 == 2) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
  {
    ; -------------------------------------------
    Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
    ; -------------------------------------------
  }
  ; -------------------------------------------
  Send, {LButton Up}
  Sleep, 1000
  ; -------------------------------------------
  BlockInput, Off
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
