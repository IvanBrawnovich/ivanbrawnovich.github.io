﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CheckFile_1 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPawCountBG.png"
CheckFile_2 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_1.png"
CheckFile_3 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_2.png"
CheckFile_4 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_3.png"
CheckFile_5 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_4.png"
CheckFile_6 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_5.png"
CheckFile_7 := "C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw.png"
if (!FileExist(CheckFile_1) or !FileExist(CheckFile_2) or !FileExist(CheckFile_3) or !FileExist(CheckFile_4) or !FileExist(CheckFile_5) or !FileExist(CheckFile_6) or !FileExist(CheckFile_7))
{
  ExitApp
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui Objects
; -------------------------------------------
Gui, Margin , 0, 0
; -------------------------------------------
Gui, Add, Picture, x0   y0   w389 h400 vCatPawCountBg, C:\Program Files\PopUpMenu_PUM\image\gui\CatPawCountBG.png
; -------------------------------------------
Gui, Add, Picture, x22  y85  w346 h289  vCatPawCountImg, C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_5.png
; -------------------------------------------
Gui, Color, %ColorTrans%
Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, %ColorTrans%,
Gui, Show, w389 h400, CatPawCount
; -------------------------------------------
DownNum := 4 ; Start Frame Number
SetTimer, StopCountDown, 1000
SetTimer, CheckIfIdle, 10
; -------------------------------------------
return
; -------------------------------------------
CheckIfIdle:
{
  if (A_TimeIdlePhysical < 50)
  {
    ; -------------------------------------------
    ;~ SetTitleMatchMode, 2
    ;~ DetectHiddenWindows, On
    ;~ if !WinExist("CatPaw_Wait.ahk" . " ahk_class AutoHotkey") ; CatPaw_Wait.ahk (NOT Exist)
    ;~ {
      Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
    ;~ }
    ExitApp
    ; -------------------------------------------
  }
}
return
; -------------------------------------------
StopCountDown:
{
  ; -------------------------------------------
  if (DownNum == 4 or DownNum == 3 or DownNum == 2 or DownNum == 1)
  {
    GuiControl, , CatPawCountImg, C:\Program Files\PopUpMenu_PUM\image\gui\CatPaw_%DownNum%.png
    Sleep, 10
  }
  ; -------------------------------------------
  DownNum := DownNum - 1
  ; -------------------------------------------
  if (DownNum < 0)
  {
    ; -------------------------------------------
    SetTimer, StopCountDown, Off
    ; -------------------------------------------
    Run, C:\Program Files\PopUpMenu_PUM\CatPaw.ahk
    ExitApp
    ; -------------------------------------------
  } ; [End] if (DownNum < 0)
  ; -------------------------------------------
} ; [End] Animate_CountDown:
return
; -------------------------------------------
; Gui Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CloseCatPaw:
{
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
