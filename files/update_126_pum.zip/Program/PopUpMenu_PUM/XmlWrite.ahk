﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
#Include C:\Program Files\PopUpMenu_PUM\XmlValidate.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
XmlWrite(Array_PumXml, ThisPumXml) ; Array_PumXml, ThisPumXml > [0,1] 1 = Ok , 0 Xml Error
{
  ; -------------------------------------------
  SplitPath, ThisPumXml, ThisPumXml_FileExtName, ThisPumXml_Folder, ThisPumXml_Extension, ThisPumXml_Name
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CHECK] / [CREATE] (A_AppData "\PopUpMenu_PUM\tempxml\)
  ; [CHECK] / [DELETE] (A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml)
  ; -------------------------------------------
  Folder_TempPumXml := A_AppData "\PopUpMenu_PUM\tempxml"
  if !FileExist(Folder_TempPumXml)
  {
    FileCreateDir, %Folder_TempPumXml%
    Sleep, 10
  }
  ; -------------------------------------------
  File_TempPumXml := A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml"
  if FileExist(File_TempPumXml)
  {
    FileDelete, %File_TempPumXml%
    Sleep, 10
  }
  ; -------------------------------------------
  ; [CHECK] / [CREATE] (A_AppData "\PopUpMenu_PUM\tempxml\)
  ; [CHECK] / [DELETE] (A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CREATE] (New_Array_PumXml) Line Breaks
  ; -------------------------------------------
  for Index, ThisLine in Array_PumXml
  {
    ; -------------------------------------------
    ThisLine := ThisLine "`n"
    ; -------------------------------------------
    New_Array_PumXml := Array_Add(New_Array_PumXml, ThisLine, ThisPos) ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
    ; -------------------------------------------
  } ; for Index, ThisLine in Array_PumXml
  ; -------------------------------------------
  ; [CREATE] (New_Array_PumXml) Line Breaks
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Write New Xml
  ; -------------------------------------------
  X_Cen := A_ScreenWidth * 0.5
  Y_Cen := A_ScreenHeight * 0.5
  Msg := Msg "Writing pum XML`n"
  CoordMode, ToolTip, Screen
  ToolTip, %Msg%, X_Cen, Y_Cen
  Msg := ""
  ; -------------------------------------------
  ; XML MUST BE WRITTEN IN THIS ENCODING (Otherwist will not show Back Ground Image)
  FileEncoding, CP28591 ; ISO-8859-1
  ; -------------------------------------------
  file := FileOpen(ThisPumXml, "w")
  ; -------------------------------------------
  for Index, ThisLine in New_Array_PumXml
  {
    ; -------------------------------------------
    file.Write(ThisLine)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  file.Close()
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  ToolTip
  ; -------------------------------------------
  ; Write New Xml
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CHECK/CREATE] Pum Backup Folder
  ; -------------------------------------------
  BackupFile_PumXml := StrReplace(ThisPumXml, "\pums\", "\pums_backup\")
  ; -------------------------------------------
  SplitPath, BackupFile_PumXml, , Folder_BackupFile_PumXml
  if !FileExist(Folder_BackupFile_PumXml)
  {
    FileCreateDir, %Folder_BackupFile_PumXml%
  }
  ; -------------------------------------------
  ; [CHECK/CREATE] Pum Backup Folder
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Validate pum XML (if InValid Copy From Backup)
  ; -------------------------------------------
  PumIsValid := XmlValidate(ThisPumXml) ; > [1, 0]
  ; -------------------------------------------
  if (PumIsValid == 0) ; pum is InValid
  {
    ; -------------------------------------------    
    if FileExist(BackupFile_PumXml)
    {
      ; -------------------------------------------
      BackupIsValid := XmlValidate(BackupFile_PumXml) ; [1, 0]
      ; -------------------------------------------
      if (BackupIsValid == 1)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Pum is Not Valid, Copy From Backup
        ; -------------------------------------------
        FileCopy, %BackupFile_PumXml%, %ThisPumXml%, 1
        Sleep, 500
        ; -------------------------------------------
        ; Pum is Not Valid, Copy From Backup
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      }
      else ; Delete InValid Backup
      {
        FileDelete, %BackupFile_PumXml%
      }
    }
  }
  else if (PumIsValid == 1)  ; pum is Ok, Copy Backup
  {
    FileCopy, %ThisPumXml%, %BackupFile_PumXml%, 1
  }
  ; -------------------------------------------
  ; Validate pum XML (if InValid Copy From Backup)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  Sleep, 500
  ; -------------------------------------------
  return PumIsValid
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
