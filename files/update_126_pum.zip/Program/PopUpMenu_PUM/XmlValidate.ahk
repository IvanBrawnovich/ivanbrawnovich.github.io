﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
XmlValidate(File_ThisXml) ; > [1, 0]
{
  ; -------------------------------------------
  Array_ThisXml := Array_FromFile(File_ThisXml)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if Xml Structure is Correct
  ; -------------------------------------------
  XmlValidate_1 := 1
  ; -------------------------------------------
  for Index, ThisLine in Array_ThisXml
  {
    ; -------------------------------------------
    if (Index == 3)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<toolbox") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(3) <toolbox|"
      }
      if (InStr(ThisLine, ">") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(3) >|"
      }
      ; -------------------------------------------
    } ; if (Index == 2)
    ; -------------------------------------------
    if (Index == 5)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<titlebar") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(5) <titlebar|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(5) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 7)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<statusbar") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(7) <statusbar|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(7) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 9)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<displaymode") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(9) <displaymode|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(9) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 11)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<tile") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(11) <tile|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(11) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 13)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<border") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(13) <border|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(13) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 15)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<font") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(15) <font|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(15) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 17)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<hint") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(17) <hint|"
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(17) />|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 19)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<background") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(19) <background|"
      }
      if (InStr(ThisLine, ">") == 0)
      {
        XmlValidate_1 := 0
        ErrorMsg := ErrorMsg "(19) >|"
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    
    
    
    
    
    
    
    
    ;~ if (Index == 20)
    ;~ {
      ;~ ; -------------------------------------------
      ;~ if (InStr(ThisLine, "<filename>") == 0)
      ;~ {
        ;~ XmlValidate_1 := 0
        ;~ ErrorMsg := ErrorMsg "(20) <filename>|"
      ;~ }
      ;~ if (InStr(ThisLine, "</filename>") == 0)
      ;~ {
        ;~ XmlValidate_1 := 0
        ;~ ErrorMsg := ErrorMsg "(20) </filename>|"
      ;~ }
      ;~ ; -------------------------------------------
    ;~ }
    ;~ ; -------------------------------------------
    ;~ if (Index == 21)
    ;~ {
      ;~ ; -------------------------------------------
      ;~ if (InStr(ThisLine, "</background>") == 0)
      ;~ {
        ;~ XmlValidate_1 := 0
        ;~ ErrorMsg := ErrorMsg "(21) </background>|"
      ;~ }
      ;~ ; -------------------------------------------
    ;~ }
    ;~ ; -------------------------------------------
    ;~ if (Index == 23)
    ;~ {
      ;~ ; -------------------------------------------
      ;~ if (InStr(ThisLine, "<shortcuts>") == 0)
      ;~ {
        ;~ XmlValidate_1 := 0
        ;~ ErrorMsg := ErrorMsg "(23) <shortcuts>|"
      ;~ }
      ;~ ; -------------------------------------------
    ;~ }
    ;~ ; -------------------------------------------
    
    
    
    
    
    
    
    
    if (Index > 23) ; Break After Line 23
    {
      break
    }
    ; -------------------------------------------
  } ; for Index, ThisLine in Array_ThisXml
  ; -------------------------------------------
  ; Check if Xml Structure is Correct
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if "</shortcuts>" and "</toolbox>" exist
  ; -------------------------------------------
  if (XmlValidate_1 == 1) ; Structure Was CORRECT
  {
    ; -------------------------------------------
    XmlValidate_2 := 0
    ; -------------------------------------------
    for Index, ThisLine in Array_ThisXml
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "</shortcuts>") > 0)
      {
        XmlValidate_2 := XmlValidate_2 + 1
        ErrorMsg := ErrorMsg "(END) </shortcuts>|"
      }
      ; -------------------------------------------
      if (InStr(ThisLine, "</toolbox>") > 0)
      {
        XmlValidate_2 := XmlValidate_2 + 1
        ErrorMsg := ErrorMsg "(END) </toolbox>|"
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (XmlValidate_2 == 2) ; (File OK)(Both Items Exist) (Break out of Loop)
      {
        break
      }
      ; -------------------------------------------
    } ; for Index, ThisLine in Array_ThisXml
    ; -------------------------------------------
  } ; if (XmlValidate_1 == 1) ; Structure Was CORRECT
  ; Check if "</shortcuts>" and "</toolbox>" exist
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  if (XmlValidate_1 == 1 && XmlValidate_2 == 2)
  {
    ReturnThis := 1
  }
  else
  {
    ReturnThis := ErrorMsg
  }
  ; -------------------------------------------
  if (ReturnThis == "")
  {
    ReturnThis := 0
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return ReturnThis
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
