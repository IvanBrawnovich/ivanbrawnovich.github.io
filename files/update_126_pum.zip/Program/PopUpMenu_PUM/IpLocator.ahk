﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
GetIP(URL)
{
	; -------------------------------------------
  http:=ComObjCreate("WinHttp.WinHttpRequest.5.1")
  http.Open("GET",URL,1)
  http.Send()
	; -------------------------------------------
  http.WaitForResponse
  If (http.ResponseText="Error")
	{
		ReturnThis := "NoIP"
    return ReturnThis
  }
  return http.ResponseText
	; -------------------------------------------
}
; -------------------------------------------
GetLocation() ; ReturnArray := ["IP", "TimeZone", "Region", "City", "ZipCode", "Country"]
{
  ; -------------------------------------------
  File_IpLocatorBat := A_AppData "\PopUpMenu_PUM\emailtemp\IpLocator.bat"
  File_IpLocatorLnk := A_AppData "\PopUpMenu_PUM\emailtemp\IpLocator.lnk"
  File_TimeZone := Folder_EmailTemp "\TimeZone.txt"
  File_Region   := Folder_EmailTemp "\Region.txt"
  File_City     := Folder_EmailTemp "\City.txt"
  File_ZipCode  := Folder_EmailTemp "\ZipCode.txt"
  File_Country  := Folder_EmailTemp "\Country.txt"
  ; -------------------------------------------
  FileDelete, %File_IpLocatorBat%
  FileDelete, %File_IpLocatorLnk%
  FileDelete, %File_TimeZone%
  FileDelete, %File_Region%
  FileDelete, %File_City%
  FileDelete, %File_ZipCode%
  FileDelete, %File_Country%
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ThisIP := GetIP("http://www.netikus.net/show_ip.html")
  ; -------------------------------------------
  if (ThisIP == "NoIP")
	{
		; -------------------------------------------
    FileDelete, %File_IpLocatorBat%
    FileDelete, %File_IpLocatorLnk%
    FileDelete, %File_TimeZone%
    FileDelete, %File_Region%
    FileDelete, %File_City%
    FileDelete, %File_ZipCode%
    FileDelete, %File_Country%
    ; -------------------------------------------
		ReturnArray := ["IP Unknown", "TimeZone Unknown", "Region Unknown", "City Unknown", "ZipCode Unknown", "Country Unknown"]
		; -------------------------------------------
	}
	else
  {
    ; -------------------------------------------
    Line_1 := "curl ipinfo.io/" ThisIP "/timezone > " File_TimeZone "`n"
    Line_2 := "curl ipinfo.io/" ThisIP "/region > " File_Region "`n"
    Line_3 := "curl ipinfo.io/" ThisIP "/city > " File_City "`n"
    Line_4 := "curl ipinfo.io/" ThisIP "/postal > " File_ZipCode "`n"
    Line_5 := "curl ipinfo.io/" ThisIP "/country > " File_Country "`n"
  	; -------------------------------------------
    FileEncoding, UTF-8
  	FileAppend, %Line_1%, %File_IpLocatorBat%
  	FileAppend, %Line_2%, %File_IpLocatorBat%
  	FileAppend, %Line_3%, %File_IpLocatorBat%
  	FileAppend, %Line_4%, %File_IpLocatorBat%
  	FileAppend, %Line_5%, %File_IpLocatorBat%
  	; -------------------------------------------
    FileCreateShortcut, %File_IpLocatorBat%, %File_IpLocatorLnk%
    ; -------------------------------------------
    RunWait %File_IpLocatorLnk% , , Hide
  	; -------------------------------------------
  	FileDelete, %File_IpLocatorBat%
    FileDelete, %File_IpLocatorLnk%
  	; -------------------------------------------
    FileEncoding, UTF-8
		FileReadLine, ThisTimeZone, %File_TimeZone%, 1
		FileReadLine, ThisRegion, %File_Region%, 1
		FileReadLine, ThisCity, %File_City%, 1
		FileReadLine, ThisZipCode, %File_ZipCode%, 1
		FileReadLine, ThisCountry, %File_Country%, 1
		; -------------------------------------------
    FileDelete, %File_IpLocatorBat%
    FileDelete, %File_IpLocatorLnk%
    FileDelete, %File_TimeZone%
    FileDelete, %File_Region%
    FileDelete, %File_City%
    FileDelete, %File_ZipCode%
    FileDelete, %File_Country%
    ; -------------------------------------------
		ReturnArray := [ThisIP, ThisTimeZone, ThisRegion, ThisCity, ThisZipCode, ThisCountry]
		; -------------------------------------------
  }
	; -------------------------------------------
	;
	; -------------------------------------------
	return ReturnArray
	; -------------------------------------------
}
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

