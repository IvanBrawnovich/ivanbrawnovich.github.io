﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
  ; -------------------------------------------
  FontColor := "199524"
  FontColor := "a30404"
  FontColor := "000000"
  FontColor := "921297"
  FontColor := "040e47"
  ; -------------------------------------------
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Splash_Script("Off", 0) ; (Start Load of) (SysTray.exe)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
DataArray := Sys_DataArray()
; -------------------------------------------
(ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" . A_ComputerName . "\root\cimv2").ExecQuery("Select * From Win32_BaseBoard")._NewEnum)[objMBInfo]
global BoardID := objMBInfo["SerialNumber"] ; (333_2)(B)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Set Priority for AutoHotkey
; -------------------------------------------
Process, Priority, InternalAHK.exe, High
Process, Priority, AutoHotkey.exe, High
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Check if Context Menu Enabled
; -------------------------------------------
File_ContextMenu := A_AppData "\PopUpMenu_PUM\system\ContextMenu.txt"
; -------------------------------------------
if FileExist(File_ContextMenu)
{
  ; -------------------------------------------
  FileReadLine, Use_ContextMenu, %File_ContextMenu%, 1
  ; -------------------------------------------
  if (Use_ContextMenu == "")
  {
    ; -------------------------------------------
    FileDelete, %File_ContextMenu%
    Sleep, 250
    ; -------------------------------------------
    Use_ContextMenu := 1 ; NOT Context By Default
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %Use_ContextMenu%, %File_ContextMenu%
    Sleep, 250
    ; -------------------------------------------
  } ; [End] if (Use_ContextMenu == "")
} ; [End] if FileExist(File_ContextMenu)
; -------------------------------------------
else ; (File_ContextMenu) NOT Exist
{
  ; -------------------------------------------
  Use_ContextMenu := 1 ; NOT Context By Default
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileAppend, %Use_ContextMenu%, %File_ContextMenu%
  Sleep, 250
  ; -------------------------------------------
} ; [End] else ; (File_ContextMenu) NOT Exist
; -------------------------------------------
;
; -------------------------------------------
if (Use_ContextMenu == 2) ; (2) Context Menu Enabled
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SetWinEventHook(0x6, 0x6, 0, RegisterCallback("HookProc", "F"), 0, 0, 0)  ; EVENT_SYSTEM_MENUPOPUPSTART := 0x6
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] if (Use_ContextMenu == 2)
; -------------------------------------------
; Check if Context Menu Enabled
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Same Internet Browser pum or Each Different Internet Browser pum
; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
; [UseCommonBrowser = 2][Each Browser Different pum]
; -------------------------------------------
File_InternetBrowserPum := A_Appdata "\PopUpMenu_PUM\system\InternetBrowserPum.txt"
; -------------------------------------------
if !FileExist(File_InternetBrowserPum) ; File NOT Exist
{
  ; -------------------------------------------
  ; 0 = All Browsers Same Pum
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
  ; -------------------------------------------
  UseCommonBrowser := 1
  DataArray.290.2 := UseCommonBrowser
  ; -------------------------------------------
}
else
{
  ; -------------------------------------------
  FileReadLine, UseCommonBrowser, %File_InternetBrowserPum%, 1
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    ; -------------------------------------------
    FileDelete, %File_InternetBrowserPum%
    Sleep, 250
    FileEncoding, UTF-8
    FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
    ; -------------------------------------------
    UseCommonBrowser := 1
    ; -------------------------------------------
  }
  ; -------------------------------------------
  DataArray.290.2 := UseCommonBrowser
  ; -------------------------------------------
}
; -------------------------------------------
; Same Internet Browser pum or Each Different Internet Browser pum
; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
; [UseCommonBrowser = 2][Each Browser Different pum]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (CatPawAutoStart) 1 = OFF, 2 = ON
; -------------------------------------------
ScriptPath := "C:\Program Files\PopUpMenu_PUM\CatPaw.ahk"
if (Script_Running(ScriptPath) > 0) ; (running)
{
  Script_Close(ScriptPath)
}
; -------------------------------------------
File_CatPaw := A_Appdata "\PopUpMenu_PUM\system\CatPaw.txt"
; -------------------------------------------
if !FileExist(File_CatPaw) ; File NOT Exist
{
  ; -------------------------------------------
  ; 1 = Off
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileAppend, 1, %File_CatPaw%
  Sleep, 250
  CatPawAutoStart := 1
  ; -------------------------------------------
} ; [End] if !FileExist(File_CatPaw) ; File NOT Exist
else ; File Exist
{
  ; -------------------------------------------
  FileReadLine, CatPawAutoStart, %File_CatPaw%, 1
  ; -------------------------------------------
  if (CatPawAutoStart != 1 && CatPawAutoStart != 2) ; Something Wrong with File
  {
    ; -------------------------------------------
    ; Auto Start CatPaw Off
    FileDelete, %File_CatPaw%
    Sleep, 250
    ; -------------------------------------------
    ; 1 = Off
    FileEncoding, UTF-8
    FileAppend, 1, %File_CatPaw%
    Sleep, 250
    CatPawAutoStart := 1
    ; -------------------------------------------
  } ; [End] Something Wrong with File
  ; -------------------------------------------
  if (CatPawAutoStart == 2)
  {
    Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
  }
  ; -------------------------------------------
} ; [End] else ; File Exist
; -------------------------------------------
DataArray.169.2 := CatPawAutoStart ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
DataArray.169.4 := CatPawAutoStart ; (169_4)(Obj_CatPawPreviousAutoStart_Sel [1,2])
; -------------------------------------------
; (CatPawAutoStart) 1 = OFF, 2 = ON
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (CatPawTime) 1, 2, 3, 4, 5
; -------------------------------------------
File_CatPawTime := A_Appdata "\PopUpMenu_PUM\system\CatPawTime.txt"
; -------------------------------------------
if !FileExist(File_CatPawTime) ; File NOT Exist
{
  ; -------------------------------------------
  ; 1 = 1 Minute
  FileEncoding, UTF-8
  FileAppend, 1, %File_CatPawTime%
  Sleep, 250
  CatPawTime := 1 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
  ; -------------------------------------------
} ; [End] if !FileExist(File_CatPawTime) ; File NOT Exist
else ; File Exist
{
  ; -------------------------------------------
  FileReadLine, CatPawTime, %File_CatPawTime%, 1
  ; -------------------------------------------
  if (CatPawTime != 1 && CatPawTime != 2 && CatPawTime != 3 && CatPawTime != 4 && CatPawTime != 5) ; Something Wrong whit File
  {
    ; -------------------------------------------
    FileDelete, %File_CatPawTime%
    Sleep, 250
    ; -------------------------------------------
    ; 1 = Off
    FileEncoding, UTF-8
    FileAppend, 1, %File_CatPawTime%
    Sleep, 250
    CatPawTime := 1 ; (169_2)(Obj_CatPawAutoStart_Sel [0,1,2,3])
    ; -------------------------------------------
  } ; [End] Something Wrong whit File
  ; -------------------------------------------
} ; [End] else ; File Exist
; -------------------------------------------
DataArray.170.2 := CatPawTime ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
DataArray.170.4 := CatPawTime ; (170_4)(Obj_CatPawPreviousDropDown_Time [1,2,3,4,5])
; -------------------------------------------
; (CatPawTime) 1, 2, 3, 4, 5
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
gui_Shortcut(DataArray) ; > DataArray **********************************************
{
	; -------------------------------------------
	if !WinExist("HotKey_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Hotkey Select Gui DOES NOT Exist
	{
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Run, C:\Program Files\PopUpMenu_PUM\Script_SplashClose.ahk
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
    Run, %ScriptPath%
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; Close Support Processes (if they are running)
      ; -------------------------------------------
      SupportProcess := "magick.exe"
      Process, Exist, %SupportProcess%
      if (ErrorLevel != 0)
      {
        Process, Close, %SupportProcess%
      }
      ; -------------------------------------------
      SupportProcess := "PopUpMenu_MailSend.exe"
      Process, Exist, %SupportProcess%
      if (ErrorLevel != 0)
      {
        Process, Close, %SupportProcess%
      }
      ; -------------------------------------------
      SupportProcess := "PopUpMenu_ResourceHacker.exe"
      Process, Exist, %SupportProcess%
      if (ErrorLevel != 0)
      {
        Process, Close, %SupportProcess%
      }
      ; -------------------------------------------
    } ; Close Support Processes (if they are running)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Pre_102 := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    global LockKeys := 1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] global Var(s)
    PreventFunctionError := 1
    { ; [SET] global Var(s)
      ; -------------------------------------------
      global g_001 ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
      global g_002 ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
      global g_003 ; (003_1)(Obj_KeyOfl_3RAppIco)
      global g_004 ; (004_1)(Obj_ok)
      global g_005 ; (005_1)(ORG_ScriptType)
      global g_006 ; (006_1)(Obj_ShortcutToDefaultPum)
      global g_007 ; (007_1)(Obj_KeyOfl_RFolderImage)
      global g_008 ; (008_1)(Obj_Key_Alt)
      global g_009 ; (009_1)(Obj_Key_AltDown)
      global g_010 ; (010_1)(Obj_Key_AltLeft)
      global g_011 ; (011_1)(Obj_Key_AltRight)
      global g_012 ; (012_1)(Obj_Key_AltUp)
      global g_013 ; (013_1)(Obj_Key_CapsLock)
      global g_014 ; (014_1)(Obj_Key_CtrlDown)
      global g_015 ; (015_1)(Obj_Key_CtrlLeft)
      global g_016 ; (016_1)(Obj_Key_CtrlRight)
      global g_017 ; (017_1)(Obj_Key_CtrlUp)
      global g_018 ; (018_1)(Obj_Key_Enter)
      global g_019 ; (019_1)(Obj_Key_EnterX2)
      global g_020 ; (020_1)(Obj_Key_Esc)
      global g_021 ; (021_1)(Obj_Key_EscX2)
      global g_022 ; (022_1)(Obj_Key_F1)
      global g_023 ; (023_1)(Obj_Key_F2)
      global g_024 ; (024_1)(Obj_Key_F3)
      global g_025 ; (025_1)(Obj_Key_F4)
      global g_026 ; (026_1)(Obj_Key_F5)
      global g_027 ; (027_1)(Obj_Key_F6)
      global g_028 ; (028_1)(Obj_Key_F7)
      global g_029 ; (029_1)(Obj_Key_F8)
      global g_030 ; (030_1)(Obj_Key_F9)
      global g_031 ; (031_1)(Obj_Key_F10)
      global g_032 ; (032_1)(Obj_Key_F11)
      global g_033 ; (033_1)(Obj_Key_F12)
      global g_034 ; (034_1)(Obj_Key_Numpad0)
      global g_035 ; (035_1)(Obj_Key_Numpad1)
      global g_036 ; (036_1)(Obj_Key_Numpad2)
      global g_037 ; (037_1)(Obj_Key_Numpad3)
      global g_038 ; (038_1)(Obj_Key_Numpad4)
      global g_039 ; (039_1)(Obj_Key_Numpad5)
      global g_040 ; (040_1)(Obj_Key_Numpad6)
      global g_041 ; (041_1)(Obj_Key_Numpad7)
      global g_042 ; (042_1)(Obj_Key_Numpad8)
      global g_043 ; (043_1)(Obj_Key_Numpad9)
      global g_044 ; (044_1)(Obj_Key_NumpadAdd)
      global g_045 ; (045_1)(Obj_Key_NumpadDiv)
      global g_046 ; (046_1)(Obj_Key_NumpadDot)
      global g_047 ; (047_1)(Obj_Key_NumpadEnter)
      global g_048 ; (048_1)(Obj_Key_NumpadMult)
      global g_049 ; (049_1)(Obj_Key_NumpadSub)
      global g_050 ; (050_1)(Obj_Key_Shift)
      global g_051 ; (051_1)(Obj_Key_ShiftDown)
      global g_052 ; (052_1)(Obj_Key_ShiftLeft)
      global g_053 ; (053_1)(Obj_Key_ShiftRight)
      global g_054 ; (054_1)(Obj_Key_ShiftUp)
      global g_055 ; (055_1)(Obj_Key_Tab)
      global g_056 ; (056_1)(Obj_Key_TabX2)
      global g_057 ; (057_1)(Obj_Key_Win_Sel)
      global g_058 ; (058_1)(Obj_Key_WinDown)
      global g_059 ; (059_1)(Obj_Key_WinLeft)
      global g_060 ; (060_1)(Obj_Key_WinRight)
      global g_061 ; (061_1)(Obj_Key_WinUp)
      global g_062 ; (062_1)(Obj_Cancel)
      global g_063 ; (063_1)(Obj_SelectIconImage)
      global g_064 ; (064_1)(Obj_HotKey_LangArray)
      global g_065 ; (065_1)(Obj_ImageText_StatusBar)
      global g_066 ; (066_1)(Obj_Key_ImageText_TextInput)
      global g_067 ; (067_1)(Obj_Key_ImageText_NumericKeypad)
      global g_068 ; (068_1)(Obj_RwhUrl_OpenWith)
      global g_069 ; (069_1)(Obj_RwhUrl_OpenWithReset)
      global g_070 ; (070_1)(Obj_Cpl_WinControl)
      global g_071 ; (071_1)(Obj_URL)
      global g_072 ; (072_1)(Obj_Key_AppOnly)
      global g_073 ; (073_1)(Obj_Run_AsAdmin)
      global g_074 ; (074_1)(Obj_Key_Ctrl)
      global g_075 ; (075_1)(Obj_Key_Delete)
      global g_076 ; (076_1)(Obj_Key_End)
      global g_077 ; (077_1)(Obj_Key_Home)
      global g_078 ; (078_1)(Obj_Key_Insert)
      global g_079 ; (079_1)(Obj_Key_PgDn)
      global g_080 ; (080_1)(Obj_Key_PgUp)
      global g_081 ; (081_1)(Obj_RunRwh_File)
      global g_082 ; (082_1)(Obj_Ofl_Folder)
      global g_083 ; (083_1)(Obj_Tom_Pum)
      global g_084 ; (084_1)(Obj_Tom_FileUrlFolder)
      global g_085 ; (085_1)(Obj_Key_Keyboard)
      global g_086 ; (086_1)(Obj_Tom_MenuControlKey)
      global g_087 ; (087_1)(Obj_Mnu_Menu)
      global g_088 ; (088_1)(Obj_Mnu_AppMenu1)
      global g_089 ; (089_1)(Obj_Mnu_AppMenu2)
      global g_090 ; (090_1)(Obj_Mnu_AppMenu3)
      global g_091 ; (091_1)(Obj_Mnu_AppMenu4)
      global g_092 ; (092_1)(Obj_Mnu_AppMenu5)
      global g_093 ; (093_1)(Obj_Mnu_AppMenu6)
      global g_094 ; (094_1)(Obj_Mnu_AppMenu7)
      global g_095 ; (095_1)(Obj_Mnu_AppMenu8)
      global g_096 ; (096_1)(Obj_Mnu_AppMenu9)
      global g_097 ; (097_1)(Obj_Mnu_AppMenu10)
      global g_098 ; (098_1)(Obj_Mnu_AppMenu11)
      global g_099 ; (099_1)(Obj_PopUpMenuWebLink)
      global g_100 ; (100_1)(Obj_DisplayText_Top1)
      global g_101 ; (101_1)(Obj_LangFlag)
      global g_102 ; (102_1)(Obj_DisplayedIcon)
      global g_103 ; (103_1)(Obj_RwhUrl_OpeningAppImage)
      global g_104 ; (104_1)(Obj_DisplayText_Bottom1)
      global g_105 ; (105_1)(Obj_DisplayText_Top2)
      global g_106 ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
      global g_107 ; (107_1)(Obj_DisplayText_Bottom2)
      global g_108 ; (108_1)(Obj_Url_SameNewTab)
      global g_109 ; (109_1)(Obj_CatPaw)
      global g_110 ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
      global g_111 ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
      global g_112 ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
      global g_113 ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
      global g_114 ; (114_1)(Obj_DisplayText_Title1)
      global g_115 ; (115_1)(Obj_DisplayText_Title2)
      global g_116 ; (116_1)(Obj_CplMnu_List100)
      global g_117 ; (117_1)(Obj_CplMnu_ListRight60)
      global g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
      global g_119 ; (119_1)(Mkb_KeyStroke)
      global g_120 ; (120_1)(Obj_CplMnu_ListCenter30)
      global g_121 ; (121_1)(Obj_CplMnu_ListRight30)
      global g_122 ; (122_1)(Obj_EditFeild_StatusBar)
      global g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
      global g_124 ; (124_1)(Obj_DropDownListLang)
      global g_125 ; (125_1)(Obj_Cpl_Menu1)
      global g_126 ; (126_1)(Obj_Cpl_Menu2)
      global g_127 ; (127_1)(Obj_Cpl_Menu3)
      global g_128 ; (128_1)(Obj_Cpl_Menu4)
      global g_129 ; (129_1)(Obj_Cpl_Menu5)
      global g_130 ; (130_1)(Obj_Cpl_Menu6)
      global g_131 ; (131_1)(Obj_DisplayText_UrlAddress)
      global g_132 ; (132_1)(Empty)
      global g_133 ; (133_1)(Obj_DeleteShortcut)
      global g_134 ; (134_1)(Obj_ImageSelect1)
      global g_135 ; (135_1)(Obj_ImageSelect2)
      global g_136 ; (136_1)(Obj_ImageSelect3)
      global g_137 ; (137_1)(Obj_MsgImg480x270)
      global g_138 ; (138_1)(Obj_Cpl_Menu7)
      global g_139 ; (139_1)(Obj_Cpl_Menu8)
      global g_140 ; (140_1)(Obj_Mnu_AddonExtra)
      global g_141 ; (141_1)(Obj_DisplayText_Title3)
      global g_142 ; (142_1)(Obj_HotKeyLangFlag)
      global g_143 ; (143_1)(Obj_SelFlag_de)
      global g_144 ; (144_1)(Obj_SelFlag_en)
      global g_145 ; (145_1)(Obj_SelFlag_es)
      global g_146 ; (146_1)(Obj_SelFlag_fr)
      global g_147 ; (147_1)(Obj_SelFlag_it)
      global g_148 ; (148_1)(Obj_SelFlag_pl)
      global g_149 ; (149_1)(Obj_SelFlag_pt)
      global g_150 ; (150_1)(Obj_SelFlag_ru)
      global g_151 ; (151_1)(Obj_SelFlag_sv)
      global g_152 ; (152_1)(Obj_SelFlag_tr)
      global g_153 ; (153_1)(Empty)
      global g_154 ; (154_1)(Obj_Pum_BgImage)
      global g_155 ; (155_1)(Obj_Pum_BgText)
      global g_156 ; (156_1)(Obj_Pum_BgDim)
      global g_157 ; (157_1)(Obj_Pum_Setting)
      global g_158 ; (158_1)(Empty)
      global g_159 ; (159_1)(Obj_Pum_Contact)
      global g_160 ; (160_1)(Obj_Pum_App))
      global g_161 ; (161_1)(Obj_Pum_Del)
      global g_162 ; (162_1)(Empty)
      global g_163 ; (163_1)(Empty)
      global g_164 ; (164_1)(Obj_Pum_BgTxtImg)
      global g_165 ; (165_1)(Obj_Pum_BgImageSelect)
      global g_166 ; (166_1)(Obj_Pum_BgColor)
      global g_167 ; (167_1)(Obj_Pum_BgFitImage)
      global g_168 ; (168_1)(Empty)
      global g_169 ; (169_1)(Obj_CatPawAutoStart)
      global g_170 ; (170_1)(Obj_CatPawDropDown)
      global g_171 ; (171_1)(Empty)
      global g_172 ; (172_1)(Obj_Pum_MobileText)
      global g_173 ; (173_1)(Obj_Pum_MobileTxtColor)
      global g_174 ; (174_1)(Obj_Pum_MobileBgColor)
      global g_175 ; (175_1)(Empty)
      global g_176 ; (176_1)(Empty)
      global g_177 ; (177_1)(Obj_Pum_BgTrans)
      global g_178 ; (178_1)(Obj_Pum_BgOpacityUp)
      global g_179 ; (179_1)(Obj_Pum_BgOpacityDown)
      global g_180 ; (180_1)(Obj_Pum_DisplayText_Opacity)
      global g_181 ; (181_1)(Obj_Pum_Opacity)
      global g_182 ; (182_1)(Obj_Pum_BgRotateLeft)
      global g_183 ; (183_1)(Obj_Pum_BgRotateRight)
      global g_184 ; (184_1)(Obj_Pum_ImageText_EmailAddress)
      global g_185 ; (185_1)(Obj_Pum_ImageText_ContactName)
      global g_186 ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
      global g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
      global g_188 ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      global g_189 ; (189_1)(Obj_Pum_EditFeild_ContactName)
      global g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      global g_191 ; (191_1)(Obj_Pum_ColorA1)
      global g_192 ; (192_1)(Obj_Pum_ColorA2)
      global g_193 ; (193_1)(Obj_Pum_ColorA3)
      global g_194 ; (194_1)(Obj_Pum_ColorA4)
      global g_195 ; (195_1)(Obj_Pum_ColorA5)
      global g_196 ; (196_1)(Obj_Pum_ColorA6)
      global g_197 ; (197_1)(Obj_Pum_ColorB1)
      global g_198 ; (198_1)(Obj_Pum_ColorB2)
      global g_199 ; (199_1)(Obj_Pum_ColorB3)
      global g_200 ; (200_1)(Obj_Pum_ColorB4)
      global g_201 ; (201_1)(Obj_Pum_ColorB5)
      global g_202 ; (202_1)(Obj_Pum_ColorB6)
      global g_203 ; (203_1)(Obj_Pum_ColorC1)
      global g_204 ; (204_1)(Obj_Pum_ColorC2)
      global g_205 ; (205_1)(Obj_Pum_ColorC3)
      global g_206 ; (206_1)(Obj_Pum_ColorC4)
      global g_207 ; (207_1)(Obj_Pum_ColorC5)
      global g_208 ; (208_1)(Obj_Pum_ColorC6)
      global g_209 ; (209_1)(Obj_Pum_ColorD1)
      global g_210 ; (210_1)(Obj_Pum_ColorD2)
      global g_211 ; (211_1)(Obj_Pum_ColorD3)
      global g_212 ; (212_1)(Obj_Pum_ColorD4)
      global g_213 ; (213_1)(Obj_Pum_ColorD5)
      global g_214 ; (214_1)(Obj_Pum_ColorD6)
      global g_215 ; (215_1)(Obj_Pum_ColorE1)
      global g_216 ; (216_1)(Obj_Pum_ColorE2)
      global g_217 ; (217_1)(Obj_Pum_ColorE3)
      global g_218 ; (218_1)(Obj_Pum_ColorE4)
      global g_219 ; (219_1)(Obj_Pum_ColorE5)
      global g_220 ; (220_1)(Obj_Pum_ColorE6)
      global g_221 ; (221_1)(Obj_Pum_ColorF1)
      global g_222 ; (222_1)(Obj_Pum_ColorF2)
      global g_223 ; (223_1)(Obj_Pum_ColorF3)
      global g_224 ; (224_1)(Obj_Pum_ColorF4)
      global g_225 ; (225_1)(Obj_Pum_ColorF5)
      global g_226 ; (226_1)(Obj_Pum_ColorF6)
      global g_227 ; (227_1)(Obj_Pum_ColorG1)
      global g_228 ; (228_1)(Obj_Pum_ColorG2)
      global g_229 ; (229_1)(Obj_Pum_ColorG3)
      global g_230 ; (230_1)(Obj_Pum_ColorG4)
      global g_231 ; (231_1)(Obj_Pum_ColorG5)
      global g_232 ; (232_1)(Obj_Pum_ColorG6)
      global g_233 ; (233_1)(Obj_Pum_ColorH1)
      global g_234 ; (234_1)(Obj_Pum_ColorH2)
      global g_235 ; (235_1)(Obj_Pum_ColorH3)
      global g_236 ; (236_1)(Obj_Pum_ColorH4)
      global g_237 ; (237_1)(Obj_Pum_ColorH5)
      global g_238 ; (238_1)(Obj_Pum_ColorH6)
      global g_239 ; (239_1)(Empty)
      global g_240 ; (240_1)(Empty)
      global g_241 ; (241_1)(Obj_Pum_CropLeft)
      global g_242 ; (242_1)(Obj_Pum_CropRight)
      global g_243 ; (243_1)(Obj_Pum_CropUp)
      global g_244 ; (244_1)(Obj_Pum_CropDown)
      global g_245 ; (245_1)(Obj_Pum_CropCenter)
      global g_246 ; (246_1)(Obj_Pum_ZoomIn)
      global g_247 ; (247_1)(Obj_Pum_ZoomOut)
      global g_248 ; (248_1)(Obj_Ofl_1LAppIco)
      global g_249 ; (249_1)(Obj_Ofl_2LAppIco)
      global g_250 ; (250_1)(Obj_Ofl_3LAppIco)
      global g_251 ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
      global g_252 ; (252_1)(Obj_Ofl_LFolderImage)
      global g_253 ; (253_1)(Empty)
      global g_254 ; (254_1)(Obj_MsgImg300x300)
      global g_255 ; (255_1)(Empty)
      global g_256 ; (256_1)(Empty)
      global g_257 ; (257_1)(Empty)
      global g_258 ; (258_1)(Empty)
      global g_259 ; (259_1)(Empty)
      global g_260 ; (260_1)(Obj_Pum_IconSize)
      global g_261 ; (261_1)(Obj_Pum_IconUp)
      global g_262 ; (262_1)(Obj_Pum_IconDown)
      global g_263 ; (263_1)(Obj_Pum_ImageText_IconSize)
      global g_264 ; (264_1)(Empty)
      global g_265 ; (265_1)(Empty)
      global g_266 ; (266_1)(Obj_Pum_PumRow)
      global g_267 ; (267_1)(Obj_Pum_PumRowUp)
      global g_268 ; (268_1)(Obj_Pum_PumRowDown)
      global g_269 ; (269_1)(Obj_Pum_DisplayText_Vertical)
      global g_270 ; (270_1)(Empty)
      global g_271 ; (271_1)(Empty)
      global g_272 ; (272_1)(Obj_Pum_PumColumn)
      global g_273 ; (273_1)(Obj_Pum_PumColumnUp)
      global g_274 ; (274_1)(Obj_Pum_PumColumnDown)
      global g_275 ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      global g_276 ; (276_1)(Empty)
      global g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
      global g_278 ; (278_1)(Empty)
      global g_279 ; (279_1)(Empty)
      global g_280 ; (280_1)(Empty)
      global g_281 ; (281_1)(Empty)
      global g_282 ; (282_1)(Empty)
      global g_283 ; (283_1)(Empty)
      global g_284 ; (284_1)(Empty)
      global g_285 ; (285_1)(Empty)
      global g_286 ; (286_1)(Empty)
      global g_287 ; (287_1)(Empty)
      global g_288 ; (288_1)(Empty)
      global g_289 ; (289_1)(Empty)
      global g_290 ; (290_1)(Empty)
      global g_291 ; (291_1)(Empty)
      global g_292 ; (292_1)(Empty)
      global g_293 ; (293_1)(Empty)
      global g_294 ; (294_1)(Empty)
      global g_295 ; (295_1)(Empty)
      global g_296 ; (296_1)(Empty)
      global g_297 ; (297_1)(Empty)
      global g_298 ; (298_1)(Empty)
      global g_299 ; (299_1)(End GUI Object)
      ; -------------------------------------------
    } ; [End] [SET] global Var(s)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] global Var(s)
    ;
    PreventFunctionError := 1
    { ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Stop Animate
      ;
      ; -------------------------------------------
      global ShowAnimationChange := 0
      ; -------------------------------------------
      global s_187 := 0 ; Hide
      global n_187 := 1
      SetTimer, l_187, Off ; (187_1)(Obj_Pum_SendEmailAnimate)
      ; -------------------------------------------
      global s_520 := 0 ; Hide
      global n_520 := 1
      SetTimer, l_520, Off ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
      ; -------------------------------------------
      global s_521 := 0 ; Hide
      global n_521 := 1
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      ; -------------------------------------------
      global s_522 := 0 ; Hide
      global n_522 := 1
      SetTimer, l_522, Off ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
      ; -------------------------------------------
      global s_523 := 0 ; Hide
      global n_523 := 1
      SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
      ; -------------------------------------------
      global s_524 := 0 ; Hide
      global n_524 := 1
      SetTimer, l_524, Off ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
      ; -------------------------------------------
      global s_541 := 0 ; Hide
      global n_541 := 1
      SetTimer, l_541, Off ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
      ; -------------------------------------------
      global s_542 := 0 ; Hide
      global n_542 := 1
      SetTimer, l_542, Off ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
      ; -------------------------------------------
      global s_543 := 0 ; Hide
      global n_543 := 1
      SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
      ; -------------------------------------------
      global s_544 := 0 ; Hide
      global n_544 := 1
      SetTimer, l_544, Off ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
      ; -------------------------------------------
      global s_545_L := 0 ; Hide
      global n_545_L := 1
      SetTimer, l_545_L, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
      ; -------------------------------------------
      global s_545_R := 0 ; Hide
      global n_545_R := 1
      SetTimer, l_545_R, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
      ; -------------------------------------------
      global s_546 := 0 ; Hide
      global n_546 := 1
      SetTimer, l_546, Off ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
      ; -------------------------------------------
      ;
    } ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop Animate
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [STARTUP] Vars
    PreventFunctionError := 1
    { ; [STARTUP] Vars
      ; -------------------------------------------
      if (DataArray.169.2 != 1 &&  DataArray.169.2 != 2) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (CatPawAutoStart) 1 = OFF, 2 = ON
        ; -------------------------------------------
        File_CatPaw     := A_Appdata "\PopUpMenu_PUM\system\CatPaw.txt"
        ; -------------------------------------------
        if !FileExist(File_CatPaw) ; File NOT Exist
        {
          ; -------------------------------------------
           ; 1 = Off
          FileEncoding, UTF-8
          FileAppend, 1, %File_CatPaw%
          Sleep, 250
          CatPawAutoStart := 1
          ; -------------------------------------------
        } ; [End] if !FileExist(File_CatPaw) ; File NOT Exist
        else ; File Exist
        {
          ; -------------------------------------------
          FileReadLine, CatPawAutoStart, %File_CatPaw%, 1
          ; -------------------------------------------
          if (CatPawAutoStart != 1 && CatPawAutoStart != 2) ; Something Wrong with File
          {
            ; -------------------------------------------
            ; Auto Start CatPaw Off
            FileDelete, %File_CatPaw%
            Sleep, 250
           ; ------------------------------------------- 
            ; 1 = Off
            FileEncoding, UTF-8
            FileAppend, 1, %File_CatPaw%
            Sleep, 250
            CatPawAutoStart := 1
            ; -------------------------------------------
          } ; [End] Something Wrong with File
          ; -------------------------------------------
        } ; [End] else ; File Exist
        ; -------------------------------------------
        ; (CatPawAutoStart) 1 = OFF, 2 = ON
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        DataArray.169.2 := CatPawAutoStart ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (DataArray.170.2 != 1 && DataArray.170.2 != 2 && DataArray.170.2 != 3 && DataArray.170.2 != 4 && DataArray.170.2 != 5) ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (CatPawTime) 1, 2, 3, 4, 5
        ; -------------------------------------------
        File_CatPawTime := A_Appdata "\PopUpMenu_PUM\system\CatPawTime.txt"
        ; -------------------------------------------
        if !FileExist(File_CatPawTime) ; File NOT Exist
        {
          ; -------------------------------------------
          ; 1 = 1 Minute
          FileEncoding, UTF-8
          FileAppend, 1, %File_CatPawTime%
          Sleep, 250
          CatPawTime := 1 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
          ; -------------------------------------------
        } ; [End] if !FileExist(File_CatPawTime) ; File NOT Exist
        else ; File Exist
        {
          ; -------------------------------------------
          FileReadLine, CatPawTime, %File_CatPawTime%, 1
          ; -------------------------------------------
          if (CatPawTime != 1 && CatPawTime != 2 && CatPawTime != 3 && CatPawTime != 4 && CatPawTime != 5) ; Something Wrong whit File
          {
            ; -------------------------------------------
            FileDelete, %File_CatPawTime%
            Sleep, 250
            ; -------------------------------------------
            ; 1 = Off
            FileEncoding, UTF-8
            FileAppend, 1, %File_CatPawTime%
            Sleep, 250
            CatPawTime := 1 ; (169_2)(Obj_CatPawAutoStart_Sel [0,1,2,3])
            ; -------------------------------------------
          } ; [End] Something Wrong whit File
          ; -------------------------------------------
        } ; [End] else ; File Exist
        ; -------------------------------------------
        DataArray.170.2 := CatPawTime ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
        ; -------------------------------------------
        ; (CatPawTime) 1, 2, 3, 4, 5
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      }
      ; -------------------------------------------
      GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
      ; -------------------------------------------
      if (DataArray.370.1 == 0) ; (370_1)(XmlShortcutLineNum [XML Line Number])
      {
        ; -------------------------------------------
        DataArray.5.1 := "xxx" ; (005_1)(ORG_ScriptType)
        DataArray.366.5 := "xxx" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        DataArray.133.2 := 0 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
        DataArray.133.3 := "" ; (133_3)(Obj_DeleteShortcut_Img [Image Path])
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        DataArray.5.1 := DataArray.366.5 ; (005_1)(ORG_ScriptType)/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        DataArray := Shortcut_Info(DataArray)
        DataArray.133.2 := 1 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
        DataArray.133.3 := "" ; (133_3)(Obj_DeleteShortcut_Img [Image Path])
      }
      ; -------------------------------------------
      DataArray.5.1 := DataArray.366.5 ; (005_1)(ORG_ScriptType)/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
    } ; [End] [STARTUP] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [STARTUP] Vars
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] Defaults
    PreventFunctionError := 1
    { ; [SET] Defaults
      ; -------------------------------------------
      if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (DataArray.72.2 == "") ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
        {
          DataArray.72.2 := 1 ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
        } ; [End] (Obj_KeyMnu_AppOnly_Sel [0,1,2]) == ""
      } ; [End] (ScriptType [key,mnu])
      ; -------------------------------------------
    } ; [End] [SET] Defaults
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] Defaults
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ GUI Define by Monitor Size @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    PreventFunctionError := 1
    { ; GUI Define by Monitor Size
      ; -------------------------------------------
      Gui, PopUpMenu:+AlwaysOnTop
      ; -------------------------------------------
      if (A_ScreenHeight > 601)
      {
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Messages] / [Image 1-4]
          Gui, PopUpMenu:Font, c000000 s14 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x10  y194 w130 h100    vg_134                    gl_134, ; (134_1)(Obj_ImageSelect1)
          Gui, PopUpMenu:Add, Picture,                     x185 y194 w130 h100    vg_135                    gl_135, ; (135_1)(Obj_ImageSelect2)
          Gui, PopUpMenu:Add, Picture,                     x360 y194 w130 h100    vg_136                    gl_136, ; (136_1)(Obj_ImageSelect3)
          Gui, PopUpMenu:Add, Picture,                     x10  y295 w480 h270    vg_137                    gl_137, ; (137_1)(Obj_MsgImg480x270)
        } ; [End] [Messages] / [Image 1-4]
        ; ------------------------------------------
        PreventFunctionError := 1
        { ; [Displayed Text] / [Top 1][Top 2][Bottom 1][Bottom 2][Icon Warning Text][List Text][Opening Application Path][Title 1-3]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c199524 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y126 w480         vg_100, ; (100_1)(Obj_DisplayText_Top1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y147 w480         vg_105, ; (105_1)(Obj_DisplayText_Top2)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y521 w480         vg_104, ; (104_1)(Obj_DisplayText_Bottom1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y548 w480         vg_107, ; (107_1)(Obj_DisplayText_Bottom2)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                x10  y271 w158           vg_110, ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
          Gui, PopUpMenu:Add, Text, -Wrap                x171 y271 w158           vg_111, ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
          Gui, PopUpMenu:Add, Text, -Wrap                x332 y271 w158           vg_112, ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y271 w480         vg_113, ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s14 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, Center                 x110 y55  w275         vg_114, ; (114_1)(Obj_DisplayText_Title1)
          Gui, PopUpMenu:Add, Text, Center                 x110 y79  w275         vg_115, ; (115_1)(Obj_DisplayText_Title2)
          Gui, PopUpMenu:Add, Text, Center                 x147 y102 w200         vg_141, ; (141_1)(Obj_DisplayText_Title3)
          ; -------------------------------------------
        } ; [End] [Displayed Text] / [Top 1][Top 2][Bottom 1][Bottom 2][Icon Warning Text][List Text][Opening Application Path][Title 1-3]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Common] / [Delete Shortcut][Web Site Image Link][Cancel][Ok Button]
          Gui, PopUpMenu:Add, Picture,                     x390 y55  w100 h25     vg_133                   gl_133, ; (133_1)(Obj_DeleteShortcut)
          Gui, PopUpMenu:Add, Picture,                     x10  y670 w480 h20     vg_099                   gl_099, C:\Program Files\PopUpMenu_PUM\image\gui\WebAddress.png ; (099_1)(Obj_PopUpMenuWebLink)
          Gui, PopUpMenu:Add, Picture,                     x48  y622 w100 h35     vg_062                   gl_062, ; (062_1)(Obj_Cancel)
          Gui, PopUpMenu:Add, Picture,                     x353 y622 w100 h35     vg_004                   gl_004, ; (004_1)(Obj_ok)
        } ; [End] [Common] / [Delete Shortcut][Web Site Image Link][Cancel][Ok Button]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Top Menu] [BTS_FileFolder][Menu Control Key][pum]
          Gui, PopUpMenu:Add, Picture,                     x9   y10  w159 h35     vg_084                   gl_084, ; (084_1)(Obj_Tom_FileUrlFolder)
          Gui, PopUpMenu:Add, Picture,                     x170 y10  w159 h35     vg_086                   gl_086, ; (086_1)(Obj_Tom_MenuControlKey)
          Gui, PopUpMenu:Add, Picture,                     x331 y10  w159 h35     vg_083                   gl_083, ; (083_1)(Obj_Tom_Pum)
        } ; [End] [Top Menu] [BTS_FileFolder][Menu Control Key][pum]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Language] / [Language Flag][Choose Language Drop Down List]
          Gui, PopUpMenu:Add, Picture,                     x10  y55  w94  h50     vg_101 gl_101, ; (101_1)(Obj_LangFlag)
        } ; [End] [Language] / [Language Flag][Choose Language Drop Down List]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Icon] / [Icon Rotate][Main Display Icon][Icon Image 4][First App Icon][Second App Icon][Third App Icon][Select Icon Image][[Text] Number of Icons][Reset Icon Image]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x210 y574 w80  h80     vg_102                   gl_063, ; (063_1)(Obj_SelectIconImage)/(102_1)(Obj_DisplayedIcon)
          Gui, PopUpMenu:Add, Picture,                     x18  y574 w160 h35     vg_063                   gl_063, ; (063_1)(Obj_SelectIconImage)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x321 y574 w40  h40     vg_007                   gl_106, ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)/(007_1)(Obj_KeyOfl_RFolderImage)
          Gui, PopUpMenu:Add, Text, BackgroundTrans Center x321 y587 w40      r1  vg_106                   gl_106, ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
          ;
          Gui, PopUpMenu:Add, Picture,                     x364 y574 w40  h40     vg_001                   gl_001, ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
          Gui, PopUpMenu:Add, Picture,                     x407 y574 w40  h40     vg_002                   gl_002, ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
          Gui, PopUpMenu:Add, Picture,                     x450 y574 w40  h40     vg_003                   gl_003, ; (003_1)(Obj_KeyOfl_3RAppIco)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y574 w40  h40     vg_248                   gl_248, ; (248_1)(Obj_Ofl_1LAppIco)
          Gui, PopUpMenu:Add, Picture,                     x53  y574 w40  h40     vg_249                   gl_249, ; (249_1)(Obj_Ofl_2LAppIco)
          Gui, PopUpMenu:Add, Picture,                     x96  y574 w40  h40     vg_250                   gl_250, ; (250_1)(Obj_Ofl_3LAppIco)
          ;
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x139 y574 w40  h40     vg_252                   gl_251, ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)/(252_1)(Obj_Ofl_LFolderImage)
          Gui, PopUpMenu:Add, Text, BackgroundTrans Center x139 y587 w40      r1  vg_251                   gl_251, ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
          ; -------------------------------------------          
        } ; [End] [Icon] / [Icon Rotate][Main Display Icon][Icon Image 4][First App Icon][Second App Icon][Third App Icon][Select Icon Image][[Text] Number of Icons][Reset Icon Image]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Status Bar] Description
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Edit,                        x205 y204 w285 h25     vg_122,                   ; (122_1)(Obj_EditFeild_StatusBar)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y204 w185 h25     vg_065,                   ; (065_1)(Obj_ImageText_StatusBar)
          ; -------------------------------------------
        } ; [End] [Status Bar] Description
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [xxx]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x100 y204 w300 h70        vg_006 gl_006, ; (006_1)(Obj_ShortcutToDefaultPum)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x233 y124 w167 h70        vg_109 gl_109, ; (109_1)(Obj_CatPaw)
          Gui, PopUpMenu:Add, Picture,                     x100 y124 w120 h30        vg_169 gl_169, ; (169_1)(Obj_CatPawAutoStart)
          Gui, PopUpMenu:Add, DropDownList,                x100 y166 w120            vg_170 gl_170, ; (170_1)(Obj_CatPawDropDown)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [mnu][cpl][key] / (Select) / [Menu][Control][Keyboard]
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w130 h25     vg_087                   gl_087, ; (087_1)(Obj_Mnu_Menu)
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25     vg_070                   gl_070, ; (070_1)(Obj_Cpl_WinControl)
          Gui, PopUpMenu:Add, Picture,                     x360 y169 w130 h25     vg_085                   gl_085, ; (085_1)(Obj_Key_Keyboard)
        } ; [End] [mnu][cpl][key] / (Select) / [Menu][Control][Keyboard]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [cpl] / [Windows Control Menu 1-8]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y239 w58  h25     vg_125                   gl_125, ; (125_1)(Obj_Cpl_Menu1)
          Gui, PopUpMenu:Add, Picture,                     x70  y239 w58  h25     vg_126                   gl_126, ; (126_1)(Obj_Cpl_Menu2)
          Gui, PopUpMenu:Add, Picture,                     x130 y239 w58  h25     vg_127                   gl_127, ; (127_1)(Obj_Cpl_Menu3)
          Gui, PopUpMenu:Add, Picture,                     x190 y239 w58  h25     vg_128                   gl_128, ; (128_1)(Obj_Cpl_Menu4)
          Gui, PopUpMenu:Add, Picture,                     x250 y239 w58  h25     vg_129                   gl_129, ; (129_1)(Obj_Cpl_Menu5)
          Gui, PopUpMenu:Add, Picture,                     x310 y239 w58  h25     vg_130                   gl_130, ; (130_1)(Obj_Cpl_Menu6)
          Gui, PopUpMenu:Add, Picture,                     x370 y239 w58  h25     vg_138                   gl_138, ; (138_1)(Obj_Cpl_Menu7)
          Gui, PopUpMenu:Add, Picture,                     x430 y239 w58  h25     vg_139                   gl_139, ; (139_1)(Obj_Cpl_Menu8)
          ; -------------------------------------------
        } ; [End] [cpl] / [Windows Control Menu 1-8]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [key]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Edit,                        x205 y239 w285 h25     vg_123                   gl_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y239 w185 h25     vg_066, ; (066_1)(Obj_Key_ImageText_TextInput)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_072                   gl_072, ; (072_1)(Obj_Key_AppOnly)
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Down/Up/Left/Right] / [Windows Key][Shift][Ctrl][Alt]
            Gui, PopUpMenu:Add, Picture,                   x254 y274 w23  h23     vg_058                   gl_058, ; (058_1)(Obj_Key_WinDown)
            Gui, PopUpMenu:Add, Picture,                   x279 y274 w23  h23     vg_061                   gl_061, ; (061_1)(Obj_Key_WinUp)
            Gui, PopUpMenu:Add, Picture,                   x314 y274 w23  h23     vg_051                   gl_051, ; (051_1)(Obj_Key_ShiftDown)
            Gui, PopUpMenu:Add, Picture,                   x339 y274 w23  h23     vg_054                   gl_054, ; (054_1)(Obj_Key_ShiftUp)
            Gui, PopUpMenu:Add, Picture,                   x374 y274 w23  h23     vg_014                   gl_014, ; (014_1)(Obj_Key_CtrlDown)
            Gui, PopUpMenu:Add, Picture,                   x399 y274 w23  h23     vg_017                   gl_017, ; (017_1)(Obj_Key_CtrlUp)
            Gui, PopUpMenu:Add, Picture,                   x434 y274 w23  h23     vg_009                   gl_009, ; (009_1)(Obj_Key_AltDown)
            Gui, PopUpMenu:Add, Picture,                   x459 y274 w23  h23     vg_012                   gl_012, ; (012_1)(Obj_Key_AltUp)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x254 y326 w23  h23     vg_059                   gl_059, ; (059_1)(Obj_Key_WinLeft)
            Gui, PopUpMenu:Add, Picture,                   x279 y326 w23  h23     vg_060                   gl_060, ; (060_1)(Obj_Key_WinRight)
            Gui, PopUpMenu:Add, Picture,                   x314 y326 w23  h23     vg_052                   gl_052, ; (052_1)(Obj_Key_ShiftLeft)
            Gui, PopUpMenu:Add, Picture,                   x339 y326 w23  h23     vg_053                   gl_053, ; (053_1)(Obj_Key_ShiftRight)
            Gui, PopUpMenu:Add, Picture,                   x374 y326 w23  h23     vg_015                   gl_015, ; (015_1)(Obj_Key_CtrlLeft)
            Gui, PopUpMenu:Add, Picture,                   x399 y326 w23  h23     vg_016                   gl_016, ; (016_1)(Obj_Key_CtrlRight)
            Gui, PopUpMenu:Add, Picture,                   x434 y326 w23  h23     vg_010                   gl_010, ; (010_1)(Obj_Key_AltLeft)
            Gui, PopUpMenu:Add, Picture,                   x459 y326 w23  h23     vg_011                   gl_011, ; (011_1)(Obj_Key_AltRight)
          } ; [End] [Down/Up/Left/Right] / [Windows Key][Shift][Ctrl][Alt]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Esc][Enter][Tab][Caps Lock][Windows Key][Shift][Ctrl][Alt]
            Gui, PopUpMenu:Add, Picture,                   x10  y299 w56  h25     vg_020                   gl_020, ; (020_1)(Obj_Key_Esc)
            Gui, PopUpMenu:Add, Picture,                   x70  y299 w56  h25     vg_018                   gl_018, ; (018_1)(Obj_Key_Enter)
            Gui, PopUpMenu:Add, Picture,                   x130 y299 w56  h25     vg_055                   gl_055, ; (055_1)(Obj_Key_Tab)
            Gui, PopUpMenu:Add, Picture,                   x190 y299 w56  h25     vg_013                   gl_013, ; (013_1)(Obj_Key_CapsLock)
            Gui, PopUpMenu:Add, Picture,                   x250 y299 w56  h25     vg_057                   gl_057, ; (057_1)(Obj_Key_Win_Sel)
            Gui, PopUpMenu:Add, Picture,                   x310 y299 w56  h25     vg_050                   gl_050, ; (050_1)(Obj_Key_Shift)
            Gui, PopUpMenu:Add, Picture,                   x370 y299 w56  h25     vg_074                   gl_074, ; (074_1)(Obj_Key_Ctrl)
            Gui, PopUpMenu:Add, Picture,                   x430 y299 w56  h25     vg_008                   gl_008, ; (008_1)(Obj_Key_Alt)
          } ; [End] [Esc][Enter][Tab][Caps Lock][Windows Key][Shift][Ctrl][Alt]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Esc][Enter][Tab] X2
            Gui, PopUpMenu:Add, Picture,                   x10  y326 w56  h23     vg_021                   gl_021, ; (021_1)(Obj_Key_EscX2)
            Gui, PopUpMenu:Add, Picture,                   x70  y326 w56  h23     vg_019                   gl_019, ; (019_1)(Obj_Key_EnterX2)
            Gui, PopUpMenu:Add, Picture,                   x130 y326 w56  h23     vg_056                   gl_056, ; (056_1)(Obj_Key_TabX2)
          } ; [End] [Esc][Enter][Tab] X2
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Home][End][Insert][Delete][Page Up][Page Down]
            Gui, PopUpMenu:Add, Picture,                   x10  y359 w75  h25     vg_077                   gl_077, ; (077_1)(Obj_Key_Home)
            Gui, PopUpMenu:Add, Picture,                   x91  y359 w75  h25     vg_076                   gl_076, ; (076_1)(Obj_Key_End)
            Gui, PopUpMenu:Add, Picture,                   x172 y359 w75  h25     vg_078                   gl_078, ; (078_1)(Obj_Key_Insert)
            Gui, PopUpMenu:Add, Picture,                   x253 y359 w75  h25     vg_075                   gl_075, ; (075_1)(Obj_Key_Delete)
            Gui, PopUpMenu:Add, Picture,                   x334 y359 w75  h25     vg_080                   gl_080, ; (080_1)(Obj_Key_PgUp)
            Gui, PopUpMenu:Add, Picture,                   x415 y359 w75  h25     vg_079                   gl_079, ; (079_1)(Obj_Key_PgDn)
          } ; [End] [Home][End][Insert][Delete][Page Up][Page Down]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [F 1-12]
            Gui, PopUpMenu:Add, Picture,                   x12  y394 w36  h25     vg_022                   gl_022, ; (022_1)(Obj_Key_F1)
            Gui, PopUpMenu:Add, Picture,                   x52  y394 w36  h25     vg_023                   gl_023, ; (023_1)(Obj_Key_F2)
            Gui, PopUpMenu:Add, Picture,                   x92  y394 w36  h25     vg_024                   gl_024, ; (024_1)(Obj_Key_F3)
            Gui, PopUpMenu:Add, Picture,                   x132 y394 w36  h25     vg_025                   gl_025, ; (025_1)(Obj_Key_F4)
            Gui, PopUpMenu:Add, Picture,                   x172 y394 w36  h25     vg_026                   gl_026, ; (026_1)(Obj_Key_F5)
            Gui, PopUpMenu:Add, Picture,                   x212 y394 w36  h25     vg_027                   gl_027, ; (027_1)(Obj_Key_F6)
            Gui, PopUpMenu:Add, Picture,                   x252 y394 w36  h25     vg_028                   gl_028, ; (028_1)(Obj_Key_F7)
            Gui, PopUpMenu:Add, Picture,                   x292 y394 w36  h25     vg_029                   gl_029, ; (029_1)(Obj_Key_F8)
            Gui, PopUpMenu:Add, Picture,                   x332 y394 w36  h25     vg_030                   gl_030, ; (030_1)(Obj_Key_F9)
            Gui, PopUpMenu:Add, Picture,                   x372 y394 w36  h25     vg_031                   gl_031, ; (031_1)(Obj_Key_F10)
            Gui, PopUpMenu:Add, Picture,                   x412 y394 w36  h25     vg_032                   gl_032, ; (032_1)(Obj_Key_F11)
            Gui, PopUpMenu:Add, Picture,                   x452 y394 w36  h25     vg_033                   gl_033, ; (033_1)(Obj_Key_F12)
          } ; [End] [F 1-12]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Numpad] / [0-9][Divide][Multiply][Add][Subtract][Dot][Enter]
            Gui, PopUpMenu:Add, Picture,                   x158 y429 w185 h25     vg_067, ; (067_1)(Obj_Key_ImageText_NumericKeypad)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x12  y464 w44  h25     vg_034                   gl_034, ; (034_1)(Obj_Key_Numpad0)
            Gui, PopUpMenu:Add, Picture,                   x60  y464 w44  h25     vg_035                   gl_035, ; (035_1)(Obj_Key_Numpad1)
            Gui, PopUpMenu:Add, Picture,                   x108 y464 w44  h25     vg_036                   gl_036, ; (036_1)(Obj_Key_Numpad2)
            Gui, PopUpMenu:Add, Picture,                   x156 y464 w44  h25     vg_037                   gl_037, ; (037_1)(Obj_Key_Numpad3)
            Gui, PopUpMenu:Add, Picture,                   x204 y464 w44  h25     vg_038                   gl_038, ; (038_1)(Obj_Key_Numpad4)
            Gui, PopUpMenu:Add, Picture,                   x252 y464 w44  h25     vg_039                   gl_039, ; (039_1)(Obj_Key_Numpad5)
            Gui, PopUpMenu:Add, Picture,                   x300 y464 w44  h25     vg_040                   gl_040, ; (040_1)(Obj_Key_Numpad6)
            Gui, PopUpMenu:Add, Picture,                   x348 y464 w44  h25     vg_041                   gl_041, ; (041_1)(Obj_Key_Numpad7)
            Gui, PopUpMenu:Add, Picture,                   x396 y464 w44  h25     vg_042                   gl_042, ; (042_1)(Obj_Key_Numpad8)
            Gui, PopUpMenu:Add, Picture,                   x444 y464 w44  h25     vg_043                   gl_043, ; (043_1)(Obj_Key_Numpad9)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x10  y499 w75  h25     vg_045                   gl_045, ; (045_1)(Obj_Key_NumpadDiv)
            Gui, PopUpMenu:Add, Picture,                   x91  y499 w75  h25     vg_048                   gl_048, ; (048_1)(Obj_Key_NumpadMult)
            Gui, PopUpMenu:Add, Picture,                   x172 y499 w75  h25     vg_044                   gl_044, ; (044_1)(Obj_Key_NumpadAdd)
            Gui, PopUpMenu:Add, Picture,                   x253 y499 w75  h25     vg_049                   gl_049, ; (049_1)(Obj_Key_NumpadSub)
            Gui, PopUpMenu:Add, Picture,                   x334 y499 w75  h25     vg_046                   gl_046, ; (046_1)(Obj_Key_NumpadDot)
            Gui, PopUpMenu:Add, Picture,                   x415 y499 w75  h25     vg_047                   gl_047, ; (047_1)(Obj_Key_NumpadEnter)
          } ; [End] [Numpad] / [0-9][Divide][Multiply][Add][Subtract][Dot][Enter]
          ; -------------------------------------------
        } ; [End] [key]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [mnu] / [Addon Extra]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_140                   gl_140, ; (140_1)(Obj_Mnu_AddonExtra)
          ; -------------------------------------------
        } ; [End] [mnu] / [Addon Extra]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [cpl][mnu] / [List] / [Full Across][List Left 1/3][Center 1/3][List Right 1/3][List Right 2/3]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x10  y296 w480 r11       vg_116                   gl_116, ; (116_1)(Obj_CplMnu_List100)
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x10  y296 w158 r15       vg_118                   gl_118, ; (118_1)(Obj_CplMnu_ListLeft30)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s10 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x171 y296 w320 r13       vg_117                   gl_117, ; (117_1)(Obj_CplMnu_ListRight60)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x171 y296 w158 r15       vg_120                   gl_120, ; (120_1)(Obj_CplMnu_ListCenter30)
          Gui, PopUpMenu:Add, ListBox,                   x332 y296 w158 r15       vg_121                   gl_121, ; (121_1)(Obj_CplMnu_ListRight30)
          ; -------------------------------------------
        } ; [End] [cpl][mnu] / [List] / [Full Across][List Left 1/3][Center 1/3][List Right 1/3][List Right 2/3]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [run][rwh][url][ofl] / (Select) / (Select File)(Select URL)(Select Folder)
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w130 h25     vg_081                   gl_081, ; (081_1)(Obj_RunRwh_File)
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25     vg_071                   gl_071, ; (071_1)(Obj_URL)
          Gui, PopUpMenu:Add, Picture,                     x360 y169 w130 h25     vg_082                   gl_082, ; (082_1)(Obj_Ofl_Folder)
        } ; [End] [run][rwh][url][ofl] / (Select) / (Select File)(Select URL)(Select Folder)
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [rwh][url] / [url][Get URL Data] / [run][As Admin] / [rwh][url][Select Open With Application] / [rwh][url][Open With App Reset]
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_073 gl_073, ; (073_1)(Obj_Run_AsAdmin)
          Gui, PopUpMenu:Add, Picture,                     x10  y237 w30 h30      vg_103,        ; (103_1)(Obj_RwhUrl_OpeningAppImage)
          Gui, PopUpMenu:Add, Picture,                     x50  y239 w280 h25     vg_068 gl_068, ; (068_1)(Obj_RwhUrl_OpenWith)
          Gui, PopUpMenu:Add, Picture,                     x340 y239 w150 h25     vg_069 gl_069, ; (069_1)(Obj_RwhUrl_OpenWithReset)
        } ; [End] [rwh][url] / [url][Get URL Data] / [run][As Admin] / [rwh][url][Select Open With Application] / [rwh][url][Open With App Reset]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [url]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s10 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y135 w480         vg_131, ; (131_1)(Obj_DisplayText_UrlAddress)
          Gui, PopUpMenu:Add, Picture,                     x390 y87  w100 h41     vg_108 gl_108,  ; (108_1)(Obj_Url_SameNewTab)
          ; -------------------------------------------
        } ; [End] [url]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [pum]
          ; -------------------------------------------
          ;~ Gui, PopUpMenu:Add, Picture,                     x390 y67  w100 h35       vg_162 gl_162, ; (162)(Obj_Pum_Backup)
          ;~ Gui, PopUpMenu:Add, Picture,                     x390 y110 w100 h35       vg_163 gl_163, ; (163)(Obj_Pum_Restore)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x160 y90  w180 h35       vg_290 gl_290, ; (209)(Obj_BrowserPum)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x190 y295 w300 h300      vg_254         ; (254_1)(Obj_MsgImg300x300)
          ; -------------------------------------------
          ; [pum]
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w130 h25       vg_157 gl_157, ; (157_1)(Obj_Pum_Setting)
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25       vg_160 gl_160, ; (160_1)(Obj_Pum_App))
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25       vg_161 gl_161, ; (161_1)(Obj_Pum_Del)
          Gui, PopUpMenu:Add, Picture,                     x360 y169 w130 h25       vg_159 gl_159, ; (159_1)(Obj_Pum_Contact)
          ; -------------------------------------------
          ; [pum] > [pumSetting]
          Gui, PopUpMenu:Add, Picture,                     x10  y210 w158 h75      vg_154 gl_154, ; (154_1)(Obj_Pum_BgImage)
          Gui, PopUpMenu:Add, Picture,                     x171 y210 w158 h75      vg_155 gl_155, ; (155_1)(Obj_Pum_BgText)
          Gui, PopUpMenu:Add, Picture,                     x332 y210 w158 h75      vg_156 gl_156, ; (156_1)(Obj_Pum_BgDim)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumBgImage]
          Gui, PopUpMenu:Add, Picture,                     x38  y303 w100 h25       vg_165 gl_165, ; (165_1)(Obj_Pum_BgImageSelect)
          Gui, PopUpMenu:Add, Picture,                     x38  y396 w100 h25       vg_167 gl_167, ; (167_1)(Obj_Pum_BgFitImage)
          Gui, PopUpMenu:Add, Picture,                     x38  y333 w45  h45       vg_182 gl_182, ; (182_1)(Obj_Pum_BgRotateLeft)
          Gui, PopUpMenu:Add, Picture,                     x93  y333 w45  h45       vg_183 gl_183, ; (183_1)(Obj_Pum_BgRotateRight)
          Gui, PopUpMenu:Add, Picture,                     X24  y507 w45  h45       vg_241 gl_241, ; (241_1)(Obj_Pum_CropLeft)
          Gui, PopUpMenu:Add, Picture,                     X112 y507 w45  h45       vg_242 gl_242, ; (242_1)(Obj_Pum_CropRight)
          Gui, PopUpMenu:Add, Picture,                     X68  y463 w45  h45       vg_243 gl_243, ; (243_1)(Obj_Pum_CropUp)
          Gui, PopUpMenu:Add, Picture,                     X68  y551 w45  h45       vg_244 gl_244, ; (244_1)(Obj_Pum_CropDown)
          Gui, PopUpMenu:Add, Picture,                     X68  y507 w45  h45       vg_245 gl_245, ; (245_1)(Obj_Pum_CropCenter)
          Gui, PopUpMenu:Add, Picture,                     x112 y440 w45  h45       vg_246 gl_246, ; (246_1)(Obj_Pum_ZoomIn)
          Gui, PopUpMenu:Add, Picture,                     x24  y440 w45  h45       vg_247 gl_247, ; (247_1)(Obj_Pum_ZoomOut)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumBgText]
          Gui, PopUpMenu:Font, c000000 s16 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x38  y337 w100 h25       vg_164 gl_164, ; (164_1)(Obj_Pum_BgTxtImg)
          Gui, PopUpMenu:Add, Picture,                     x38  y374 w100 h25       vg_166 gl_166, ; (166_1)(Obj_Pum_BgColor)
          Gui, PopUpMenu:Add, Picture,                     x38  y411 w100 h25       vg_172 gl_172, ; (172_1)(Obj_Pum_MobileText)
          Gui, PopUpMenu:Add, Picture,                     x38  y448 w100 h50       vg_173 gl_173, ; (173_1)(Obj_Pum_MobileTxtColor)
          Gui, PopUpMenu:Add, Picture,                     x38  y509 w100 h50       vg_174 gl_174, ; (174_1)(Obj_Pum_MobileBgColor)
          Gui, PopUpMenu:Add, Picture,                     x14  y465 w150 h25       vg_177       , ; (177_1)(Obj_Pum_BgTrans)
          Gui, PopUpMenu:Add, Picture,                     x26  y485 w55  h60       vg_178 gl_178, ; (178_1)(Obj_Pum_BgOpacityUp)
          Gui, PopUpMenu:Add, Picture,                     x26  y537 w55  h60       vg_179 gl_179, ; (179_1)(Obj_Pum_BgOpacityDown)
          Gui, PopUpMenu:Add, Text, Center                 x28  y531 w50            vg_180       , ; (180_1)(Obj_Pum_DisplayText_Opacity)
          Gui, PopUpMenu:Add, Picture,                     x93  y504 w70  h80       vg_181       , ; (181_1)(Obj_Pum_Opacity)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumDimension]
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x18  y295 w64  h64       vg_260,        ; (260_1)(Obj_Pum_IconSize)
          Gui, PopUpMenu:Add, Picture,                     x139 y324 w33  h33       vg_261 gl_261, ; (261_1)(Obj_Pum_IconUp)
          Gui, PopUpMenu:Add, Picture,                     x100 y324 w33  h33       vg_262 gl_262, ; (262_1)(Obj_Pum_IconDown)
          Gui, PopUpMenu:Add, Picture,                     x86  y295 w100 h25       vg_263       , ; (263_1)(Obj_Pum_ImageText_IconSize)
          Gui, PopUpMenu:Add, Picture,                     x37  y481 w31  h20       vg_266       , ; (266_1)(Obj_Pum_PumRow)
          Gui, PopUpMenu:Add, Picture,                     x35  y404 w33  h33       vg_267 gl_267, ; (267_1)(Obj_Pum_PumRowUp)
          Gui, PopUpMenu:Add, Picture,                     x35  y443 w33  h33       vg_268 gl_268, ; (268_1)(Obj_Pum_PumRowDown)
          Gui, PopUpMenu:Add, Picture,                     x1   y375 w100 h25       vg_269       , ; (269_1)(Obj_Pum_DisplayText_Vertical)
          Gui, PopUpMenu:Add, Picture,                     x119 y481 w31  h20       vg_272       , ; (272_1)(Obj_Pum_PumColumn)
          Gui, PopUpMenu:Add, Picture,                     x138 y443 w33  h33       vg_273 gl_273, ; (273_1)(Obj_Pum_PumColumnUp)
          Gui, PopUpMenu:Add, Picture,                     x98  y443 w33  h33       vg_274 gl_274, ; (274_1)(Obj_Pum_PumColumnDown)
          Gui, PopUpMenu:Add, Picture,                     x85  y414 w100 h25       vg_275       , ; (275_1)(Obj_Pum_DisplayText_Horizontal)
          ;
          Gui, PopUpMenu:Add, Picture,                     x29  y527 w131 h44       vg_277       , ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
          ; -------------------------------------------
          ; [pum] > [pumContact]
          Gui, PopUpMenu:Add, Picture,                     x10  y219 w160 h25       vg_184       , ; (184_1)(Obj_Pum_ImageText_EmailAddress)
          Gui, PopUpMenu:Add, Edit,   limit50              x176 y220 w315 h25       vg_188 gl_188, ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
          Gui, PopUpMenu:Add, Picture,                     x10  y264 w160 h25       vg_185       , ; (185_1)(Obj_Pum_ImageText_ContactName)
          Gui, PopUpMenu:Add, Edit,   limit50              x176 y264 w315 h25       vg_189 gl_189, ; (189_1)(Obj_Pum_EditFeild_ContactName)
          Gui, PopUpMenu:Add, Picture,                     x115 y309 w270 h25       vg_186       , ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
          Gui, PopUpMenu:Add, Picture,                     x10  y405 w138 h192      vg_187       , ; (187_1)(Obj_Pum_SendEmailAnimate)
          Gui, PopUpMenu:Add, Edit,   limit1000  -VScroll  x158 y354 w332 h243      vg_190 gl_190, ; (190_1)(Obj_Pum_EditFeild_EmailBody)
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column A]
            Gui, PopUpMenu:Add, Picture,                     x196 y307 w30  h35     vg_191 gl_191, ; (191_1)(Obj_Pum_ColorA1)
            Gui, PopUpMenu:Add, Picture,                     x196 y354 w30  h35     vg_192 gl_192, ; (192_1)(Obj_Pum_ColorA2)
            Gui, PopUpMenu:Add, Picture,                     x196 y401 w30  h35     vg_193 gl_193, ; (193_1)(Obj_Pum_ColorA3)
            Gui, PopUpMenu:Add, Picture,                     x196 y448 w30  h35     vg_194 gl_194, ; (194_1)(Obj_Pum_ColorA4)
            Gui, PopUpMenu:Add, Picture,                     x196 y495 w30  h35     vg_195 gl_195, ; (195_1)(Obj_Pum_ColorA5)
            Gui, PopUpMenu:Add, Picture,                     x196 y542 w30  h35     vg_196 gl_196, ; (196_1)(Obj_Pum_ColorA6)
          } ; [End] [Column A]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column B]
            Gui, PopUpMenu:Add, Picture,                     x232 y307 w30  h35     vg_197 gl_197, ; (197_1)(Obj_Pum_ColorB1)
            Gui, PopUpMenu:Add, Picture,                     x232 y354 w30  h35     vg_198 gl_198, ; (198_1)(Obj_Pum_ColorB2)
            Gui, PopUpMenu:Add, Picture,                     x232 y401 w30  h35     vg_199 gl_199, ; (199_1)(Obj_Pum_ColorB3)
            Gui, PopUpMenu:Add, Picture,                     x232 y448 w30  h35     vg_200 gl_200, ; (200_1)(Obj_Pum_ColorB4)
            Gui, PopUpMenu:Add, Picture,                     x232 y495 w30  h35     vg_201 gl_201, ; (201_1)(Obj_Pum_ColorB5)
            Gui, PopUpMenu:Add, Picture,                     x232 y542 w30  h35     vg_202 gl_202, ; (202_1)(Obj_Pum_ColorB6)
          } ; [End] [Column B]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column C]
            Gui, PopUpMenu:Add, Picture,                     x268 y307 w30  h35     vg_203 gl_203, ; (203_1)(Obj_Pum_ColorC1)
            Gui, PopUpMenu:Add, Picture,                     x268 y354 w30  h35     vg_204 gl_204, ; (204_1)(Obj_Pum_ColorC2)
            Gui, PopUpMenu:Add, Picture,                     x268 y401 w30  h35     vg_205 gl_205, ; (205_1)(Obj_Pum_ColorC3)
            Gui, PopUpMenu:Add, Picture,                     x268 y448 w30  h35     vg_206 gl_206, ; (206_1)(Obj_Pum_ColorC4)
            Gui, PopUpMenu:Add, Picture,                     x268 y495 w30  h35     vg_207 gl_207, ; (207_1)(Obj_Pum_ColorC5)
            Gui, PopUpMenu:Add, Picture,                     x268 y542 w30  h35     vg_208 gl_208, ; (208_1)(Obj_Pum_ColorC6)
          } ; [End] [Column C]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column D]
            Gui, PopUpMenu:Add, Picture,                     x304 y307 w30  h35     vg_209 gl_209, ; (209_1)(Obj_Pum_ColorD1)
            Gui, PopUpMenu:Add, Picture,                     x304 y354 w30  h35     vg_210 gl_210, ; (210_1)(Obj_Pum_ColorD2)
            Gui, PopUpMenu:Add, Picture,                     x304 y401 w30  h35     vg_211 gl_211, ; (211_1)(Obj_Pum_ColorD3)
            Gui, PopUpMenu:Add, Picture,                     x304 y448 w30  h35     vg_212 gl_212, ; (212_1)(Obj_Pum_ColorD4)
            Gui, PopUpMenu:Add, Picture,                     x304 y495 w30  h35     vg_213 gl_213, ; (213_1)(Obj_Pum_ColorD5)
            Gui, PopUpMenu:Add, Picture,                     x304 y542 w30  h35     vg_214 gl_214, ; (214_1)(Obj_Pum_ColorD6)
          } ; [End] [Column D]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column E]
            Gui, PopUpMenu:Add, Picture,                     x340 y307 w30  h35     vg_215 gl_215, ; (215_1)(Obj_Pum_ColorE1)
            Gui, PopUpMenu:Add, Picture,                     x340 y354 w30  h35     vg_216 gl_216, ; (216_1)(Obj_Pum_ColorE2)
            Gui, PopUpMenu:Add, Picture,                     x340 y401 w30  h35     vg_217 gl_217, ; (217_1)(Obj_Pum_ColorE3)
            Gui, PopUpMenu:Add, Picture,                     x340 y448 w30  h35     vg_218 gl_218, ; (218_1)(Obj_Pum_ColorE4)
            Gui, PopUpMenu:Add, Picture,                     x340 y495 w30  h35     vg_219 gl_219, ; (219_1)(Obj_Pum_ColorE5)
            Gui, PopUpMenu:Add, Picture,                     x340 y542 w30  h35     vg_220 gl_220, ; (220_1)(Obj_Pum_ColorE6)
          } ; [End] [Column E]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column F]
            Gui, PopUpMenu:Add, Picture,                     x376 y307 w30  h35     vg_221 gl_221, ; (221_1)(Obj_Pum_ColorF1)
            Gui, PopUpMenu:Add, Picture,                     x376 y354 w30  h35     vg_222 gl_222, ; (222_1)(Obj_Pum_ColorF2)
            Gui, PopUpMenu:Add, Picture,                     x376 y401 w30  h35     vg_223 gl_223, ; (223_1)(Obj_Pum_ColorF3)
            Gui, PopUpMenu:Add, Picture,                     x376 y448 w30  h35     vg_224 gl_224, ; (224_1)(Obj_Pum_ColorF4)
            Gui, PopUpMenu:Add, Picture,                     x376 y495 w30  h35     vg_225 gl_225, ; (225_1)(Obj_Pum_ColorF5)
            Gui, PopUpMenu:Add, Picture,                     x376 y542 w30  h35     vg_226 gl_226, ; (226_1)(Obj_Pum_ColorF6)
          } ; [End] [Column F]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column G]
            Gui, PopUpMenu:Add, Picture,                     x412 y307 w30  h35     vg_227 gl_227, ; (227_1)(Obj_Pum_ColorG1)
            Gui, PopUpMenu:Add, Picture,                     x412 y354 w30  h35     vg_228 gl_228, ; (228_1)(Obj_Pum_ColorG2)
            Gui, PopUpMenu:Add, Picture,                     x412 y401 w30  h35     vg_229 gl_229, ; (229_1)(Obj_Pum_ColorG3)
            Gui, PopUpMenu:Add, Picture,                     x412 y448 w30  h35     vg_230 gl_230, ; (230_1)(Obj_Pum_ColorG4)
            Gui, PopUpMenu:Add, Picture,                     x412 y495 w30  h35     vg_231 gl_231, ; (231_1)(Obj_Pum_ColorG5)
            Gui, PopUpMenu:Add, Picture,                     x412 y542 w30  h35     vg_232 gl_232, ; (232_1)(Obj_Pum_ColorG6)
          } ; [End] [Column G]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column H]
            Gui, PopUpMenu:Add, Picture,                     x448 y307 w30  h35     vg_233 gl_233, ; (233_1)(Obj_Pum_ColorH1)
            Gui, PopUpMenu:Add, Picture,                     x448 y354 w30  h35     vg_234 gl_234, ; (234_1)(Obj_Pum_ColorH2)
            Gui, PopUpMenu:Add, Picture,                     x448 y401 w30  h35     vg_235 gl_235, ; (235_1)(Obj_Pum_ColorH3)
            Gui, PopUpMenu:Add, Picture,                     x448 y448 w30  h35     vg_236 gl_236, ; (236_1)(Obj_Pum_ColorH4)
            Gui, PopUpMenu:Add, Picture,                     x448 y495 w30  h35     vg_237 gl_237, ; (237_1)(Obj_Pum_ColorH5)
            Gui, PopUpMenu:Add, Picture,                     x448 y542 w30  h35     vg_238 gl_238, ; (238_1)(Obj_Pum_ColorH6)
          } ; [End] [Column H]
          ; -------------------------------------------
        } ; [End] [pum]
        ; -------------------------------------------
      } ; End (A_ScreenHeight > 601)
      else ; Under 601  (< 600 add 200 to x Position of Objects)
      {
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Messages] / [Image 1-4]
          Gui, PopUpMenu:Font, c000000 s14 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x216 y186 w130 h100    vg_134                    gl_134, ; (134_1)(Obj_ImageSelect1)
          Gui, PopUpMenu:Add, Picture,                     x391 y186 w130 h100    vg_135                    gl_135, ; (135_1)(Obj_ImageSelect2)
          Gui, PopUpMenu:Add, Picture,                     x566 y186 w130 h100    vg_136                    gl_136, ; (136_1)(Obj_ImageSelect3)
          Gui, PopUpMenu:Add, Picture,                     x216 y287 w480 h270    vg_137                    gl_137, ; (137_1)(Obj_MsgImg480x270)
        } ; [End] [Messages] / [Image 1-4]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Displayed Text] / [Top 1][Top 2][Bottom 1][Bottom 2][Icon Warning Text][List Text][Opening Application Path][Title 1-3]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c199524 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y118 w480         vg_100, ; (100_1)(Obj_DisplayText_Top1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y139 w480         vg_105, ; (105_1)(Obj_DisplayText_Top2)
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y513 w480         vg_104, ; (104_1)(Obj_DisplayText_Bottom1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y540 w480         vg_107, ; (107_1)(Obj_DisplayText_Bottom2)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                x216 y263 w158           vg_110, ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
          Gui, PopUpMenu:Add, Text, -Wrap                x377 y263 w158           vg_111, ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
          Gui, PopUpMenu:Add, Text, -Wrap                x538 y263 w158           vg_112, ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y263 w480         vg_113, ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s14 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, Center                 x316 y47  w275         vg_114, ; (114_1)(Obj_DisplayText_Title1)
          Gui, PopUpMenu:Add, Text, Center                 x316 y71  w275         vg_115, ; (115_1)(Obj_DisplayText_Title2)
          Gui, PopUpMenu:Add, Text, Center                 x353 y94  w200         vg_141, ; (141_1)(Obj_DisplayText_Title3)
          ; -------------------------------------------
        } ; [End] [Displayed Text] / [Top 1][Top 2][Bottom 1][Bottom 2][Icon Warning Text][List Text][Opening Application Path][Title 1-3]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Common] / [Delete Shortcut][Web Site Image Link][Cancel][Ok Button]
          Gui, PopUpMenu:Add, Picture,                     x596 y47  w100 h25     vg_133                   gl_133, ; (133_1)(Obj_DeleteShortcut)
          Gui, PopUpMenu:Add, Picture,                     x1  y547 w201 h26     vg_099                   gl_099, C:\Program Files\PopUpMenu_PUM\image\gui\WebAddress_Under_600.png ; (099_1)(Obj_PopUpMenuWebLink)
          Gui, PopUpMenu:Add, Picture,                     x55  y377 w100 h35     vg_062                   gl_062, ; (062_1)(Obj_Cancel)
          Gui, PopUpMenu:Add, Picture,                     x55 y316 w100 h35     vg_004                   gl_004, ; (004_1)(Obj_ok)
        } ; [End] [Common] / [Delete Shortcut][Web Site Image Link][Cancel][Ok Button]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Top Menu] [BTS_FileFolder][Menu Control Key][pum]
          Gui, PopUpMenu:Add, Picture,                     x215 y2   w159 h35     vg_084                   gl_084, ; (084_1)(Obj_Tom_FileUrlFolder)
          Gui, PopUpMenu:Add, Picture,                     x376 y2   w159 h35     vg_086                   gl_086, ; (086_1)(Obj_Tom_MenuControlKey)
          Gui, PopUpMenu:Add, Picture,                     x537 y2   w159 h35     vg_083                   gl_083, ; (083_1)(Obj_Tom_Pum)
        } ; [End] [Top Menu] [BTS_FileFolder][Menu Control Key][pum]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Language] / [Language Flag][Choose Language Drop Down List]
          Gui, PopUpMenu:Add, Picture,                     x216 y47  w94  h50     vg_101 gl_101, ; (101_1)(Obj_LangFlag)
        } ; [End] [Language] / [Language Flag][Choose Language Drop Down List]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Icon] / [Icon Rotate][Main Display Icon][Icon Image 4][First App Icon][Second App Icon][Third App Icon][Select Icon Image][[Text] Number of Icons][Reset Icon Image]
          Gui, PopUpMenu:Add, Picture,                     x65  y37  w80  h80     vg_102                   gl_063, ; (063_1)(Obj_SelectIconImage)/(102_1)(Obj_DisplayedIcon)
          Gui, PopUpMenu:Add, Picture,                     x25  y205 w160 h35     vg_063                   gl_063, ; (063_1)(Obj_SelectIconImage)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x20  y142 w40  h40     vg_007                   gl_106, ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)/(007_1)(Obj_KeyOfl_RFolderImage)
          Gui, PopUpMenu:Add, Text, BackgroundTrans Center x20  y156 w40      r1  vg_106                   gl_106, ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
          ;
          Gui, PopUpMenu:Add, Picture,                     x63  y142 w40  h40     vg_001                   gl_001, ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
          Gui, PopUpMenu:Add, Picture,                     x106 y142 w40  h40     vg_002                   gl_002, ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
          Gui, PopUpMenu:Add, Picture,                     x149 y142 w40  h40     vg_003                   gl_003, ; (003_1)(Obj_KeyOfl_3RAppIco)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x149 y200 w40  h40     vg_248                   gl_248, ; (248_1)(Obj_Ofl_1LAppIco)
          Gui, PopUpMenu:Add, Picture,                     x63  y200 w40  h40     vg_249                   gl_249, ; (249_1)(Obj_Ofl_2LAppIco)
          Gui, PopUpMenu:Add, Picture,                     x106 y200 w40  h40     vg_250                   gl_250, ; (250_1)(Obj_Ofl_3LAppIco)
          ;
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x20  y200 w40  h40     vg_252                   gl_251, ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)/(252_1)(Obj_Ofl_LFolderImage)
          Gui, PopUpMenu:Add, Text, BackgroundTrans Center x20  y214 w40      r1  vg_251                   gl_251, ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
          ; -------------------------------------------          
        } ; [End] [Icon] / [Icon Rotate][Main Display Icon][Icon Image 4][First App Icon][Second App Icon][Third App Icon][Select Icon Image][[Text] Number of Icons][Reset Icon Image]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [Status Bar] Description
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Edit,                        x411 y196 w285 h25     vg_122,                   ; (122_1)(Obj_EditFeild_StatusBar)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x216 y196 w185 h25     vg_065, ; (065_1)(Obj_ImageText_StatusBar)
          ; -------------------------------------------
        } ; [End] [Status Bar] Description
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [xxx]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x437 y114 w167 h70        vg_109 gl_109, ; (109_1)(Obj_CatPaw)
          Gui, PopUpMenu:Add, Picture,                     x304 y201 w300 h70        vg_006 gl_006, ; (006_1)(Obj_ShortcutToDefaultPum)
          Gui, PopUpMenu:Add, Picture,                     x304 y114 w120 h30        vg_169 gl_169, ; (169_1)(Obj_CatPawAutoStart)
          Gui, PopUpMenu:Add, DropDownList,                x304 y156 w120            vg_170 gl_170, ; (170_1)(Obj_CatPawDropDown)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [mnu][cpl][key] / (Select) / [Menu][Control][Keyboard]
          Gui, PopUpMenu:Add, Picture,                     x216 y161 w130 h25     vg_087                   gl_087, ; (087_1)(Obj_Mnu_Menu)
          Gui, PopUpMenu:Add, Picture,                     x391 y161 w130 h25     vg_070                   gl_070, ; (070_1)(Obj_Cpl_WinControl)
          Gui, PopUpMenu:Add, Picture,                     x566 y161 w130 h25     vg_085                   gl_085, ; (085_1)(Obj_Key_Keyboard)
        } ; [End] [mnu][cpl][key] / (Select) / [Menu][Control][Keyboard]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [cpl] / [Windows Control Menu 1-8]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x216 y231 w58  h25     vg_125                   gl_125, ; (125_1)(Obj_Cpl_Menu1)
          Gui, PopUpMenu:Add, Picture,                     x276 y231 w58  h25     vg_126                   gl_126, ; (126_1)(Obj_Cpl_Menu2)
          Gui, PopUpMenu:Add, Picture,                     x336 y231 w58  h25     vg_127                   gl_127, ; (127_1)(Obj_Cpl_Menu3)
          Gui, PopUpMenu:Add, Picture,                     x396 y231 w58  h25     vg_128                   gl_128, ; (128_1)(Obj_Cpl_Menu4)
          Gui, PopUpMenu:Add, Picture,                     x456 y231 w58  h25     vg_129                   gl_129, ; (129_1)(Obj_Cpl_Menu5)
          Gui, PopUpMenu:Add, Picture,                     x516 y231 w58  h25     vg_130                   gl_130, ; (130_1)(Obj_Cpl_Menu6)
          Gui, PopUpMenu:Add, Picture,                     x576 y231 w58  h25     vg_138                   gl_138, ; (138_1)(Obj_Cpl_Menu7)
          Gui, PopUpMenu:Add, Picture,                     x636 y231 w58  h25     vg_139                   gl_139, ; (139_1)(Obj_Cpl_Menu8)
          ; -------------------------------------------
        } ; [End] [cpl] / [Windows Control Menu 1-8]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [key]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Edit,                        x411 y231 w285 h25     vg_123                   gl_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x216 y231 w185 h25     vg_066, ; (066_1)(Obj_Key_ImageText_TextInput)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x596 y83  w100 h25     vg_072                   gl_072, ; (072_1)(Obj_Key_AppOnly)
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Down/Up/Left/Right] / [Windows Key][Shift][Ctrl][Alt]
            Gui, PopUpMenu:Add, Picture,                   x460 y266 w23  h23     vg_058                   gl_058, ; (058_1)(Obj_Key_WinDown)
            Gui, PopUpMenu:Add, Picture,                   x485 y266 w23  h23     vg_061                   gl_061, ; (061_1)(Obj_Key_WinUp)
            Gui, PopUpMenu:Add, Picture,                   x520 y266 w23  h23     vg_051                   gl_051, ; (051_1)(Obj_Key_ShiftDown)
            Gui, PopUpMenu:Add, Picture,                   x545 y266 w23  h23     vg_054                   gl_054, ; (054_1)(Obj_Key_ShiftUp)
            Gui, PopUpMenu:Add, Picture,                   x580 y266 w23  h23     vg_014                   gl_014, ; (014_1)(Obj_Key_CtrlDown)
            Gui, PopUpMenu:Add, Picture,                   x605 y266 w23  h23     vg_017                   gl_017, ; (017_1)(Obj_Key_CtrlUp)
            Gui, PopUpMenu:Add, Picture,                   x640 y266 w23  h23     vg_009                   gl_009, ; (009_1)(Obj_Key_AltDown)
            Gui, PopUpMenu:Add, Picture,                   x665 y266 w23  h23     vg_012                   gl_012, ; (012_1)(Obj_Key_AltUp)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x460 y318 w23  h23     vg_059                   gl_059, ; (059_1)(Obj_Key_WinLeft)
            Gui, PopUpMenu:Add, Picture,                   x485 y318 w23  h23     vg_060                   gl_060, ; (060_1)(Obj_Key_WinRight)
            Gui, PopUpMenu:Add, Picture,                   x520 y318 w23  h23     vg_052                   gl_052, ; (052_1)(Obj_Key_ShiftLeft)
            Gui, PopUpMenu:Add, Picture,                   x545 y318 w23  h23     vg_053                   gl_053, ; (053_1)(Obj_Key_ShiftRight)
            Gui, PopUpMenu:Add, Picture,                   x580 y318 w23  h23     vg_015                   gl_015, ; (015_1)(Obj_Key_CtrlLeft)
            Gui, PopUpMenu:Add, Picture,                   x605 y318 w23  h23     vg_016                   gl_016, ; (016_1)(Obj_Key_CtrlRight)
            Gui, PopUpMenu:Add, Picture,                   x640 y318 w23  h23     vg_010                   gl_010, ; (010_1)(Obj_Key_AltLeft)
            Gui, PopUpMenu:Add, Picture,                   x665 y318 w23  h23     vg_011                   gl_011, ; (011_1)(Obj_Key_AltRight)
          } ; [End] [Down/Up/Left/Right] / [Windows Key][Shift][Ctrl][Alt]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Esc][Enter][Tab][Caps Lock][Windows Key][Shift][Ctrl][Alt]
            Gui, PopUpMenu:Add, Picture,                   x216 y291 w56  h25     vg_020                   gl_020, ; (020_1)(Obj_Key_Esc)
            Gui, PopUpMenu:Add, Picture,                   x276 y291 w56  h25     vg_018                   gl_018, ; (018_1)(Obj_Key_Enter)
            Gui, PopUpMenu:Add, Picture,                   x336 y291 w56  h25     vg_055                   gl_055, ; (055_1)(Obj_Key_Tab)
            Gui, PopUpMenu:Add, Picture,                   x396 y291 w56  h25     vg_013                   gl_013, ; (013_1)(Obj_Key_CapsLock)
            Gui, PopUpMenu:Add, Picture,                   x456 y291 w56  h25     vg_057                   gl_057, ; (057_1)(Obj_Key_Win_Sel)
            Gui, PopUpMenu:Add, Picture,                   x516 y291 w56  h25     vg_050                   gl_050, ; (050_1)(Obj_Key_Shift)
            Gui, PopUpMenu:Add, Picture,                   x576 y291 w56  h25     vg_074                   gl_074, ; (074_1)(Obj_Key_Ctrl)
            Gui, PopUpMenu:Add, Picture,                   x636 y291 w56  h25     vg_008                   gl_008, ; (008_1)(Obj_Key_Alt)
          } ; [End] [Esc][Enter][Tab][Caps Lock][Windows Key][Shift][Ctrl][Alt]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Esc][Enter][Tab] X2
            Gui, PopUpMenu:Add, Picture,                   x216 y318 w56  h23     vg_021                   gl_021, ; (021_1)(Obj_Key_EscX2)
            Gui, PopUpMenu:Add, Picture,                   x276 y318 w56  h23     vg_019                   gl_019, ; (019_1)(Obj_Key_EnterX2)
            Gui, PopUpMenu:Add, Picture,                   x336 y318 w56  h23     vg_056                   gl_056, ; (056_1)(Obj_Key_TabX2)
          } ; [End] [Esc][Enter][Tab] X2
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Home][End][Insert][Delete][Page Up][Page Down]
            Gui, PopUpMenu:Add, Picture,                   x216 y351 w75  h25     vg_077                   gl_077, ; (077_1)(Obj_Key_Home)
            Gui, PopUpMenu:Add, Picture,                   x297 y351 w75  h25     vg_076                   gl_076, ; (076_1)(Obj_Key_End)
            Gui, PopUpMenu:Add, Picture,                   x378 y351 w75  h25     vg_078                   gl_078, ; (078_1)(Obj_Key_Insert)
            Gui, PopUpMenu:Add, Picture,                   x459 y351 w75  h25     vg_075                   gl_075, ; (075_1)(Obj_Key_Delete)
            Gui, PopUpMenu:Add, Picture,                   x540 y351 w75  h25     vg_080                   gl_080, ; (080_1)(Obj_Key_PgUp)
            Gui, PopUpMenu:Add, Picture,                   x621 y351 w75  h25     vg_079                   gl_079, ; (079_1)(Obj_Key_PgDn)
          } ; [End] [Home][End][Insert][Delete][Page Up][Page Down]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [F 1-12]
            Gui, PopUpMenu:Add, Picture,                   x218 y386 w36  h25     vg_022                   gl_022, ; (022_1)(Obj_Key_F1)
            Gui, PopUpMenu:Add, Picture,                   x258 y386 w36  h25     vg_023                   gl_023, ; (023_1)(Obj_Key_F2)
            Gui, PopUpMenu:Add, Picture,                   x298 y386 w36  h25     vg_024                   gl_024, ; (024_1)(Obj_Key_F3)
            Gui, PopUpMenu:Add, Picture,                   x338 y386 w36  h25     vg_025                   gl_025, ; (025_1)(Obj_Key_F4)
            Gui, PopUpMenu:Add, Picture,                   x378 y386 w36  h25     vg_026                   gl_026, ; (026_1)(Obj_Key_F5)
            Gui, PopUpMenu:Add, Picture,                   x418 y386 w36  h25     vg_027                   gl_027, ; (027_1)(Obj_Key_F6)
            Gui, PopUpMenu:Add, Picture,                   x458 y386 w36  h25     vg_028                   gl_028, ; (028_1)(Obj_Key_F7)
            Gui, PopUpMenu:Add, Picture,                   x498 y386 w36  h25     vg_029                   gl_029, ; (029_1)(Obj_Key_F8)
            Gui, PopUpMenu:Add, Picture,                   x538 y386 w36  h25     vg_030                   gl_030, ; (030_1)(Obj_Key_F9)
            Gui, PopUpMenu:Add, Picture,                   x578 y386 w36  h25     vg_031                   gl_031, ; (031_1)(Obj_Key_F10)
            Gui, PopUpMenu:Add, Picture,                   x618 y386 w36  h25     vg_032                   gl_032, ; (032_1)(Obj_Key_F11)
            Gui, PopUpMenu:Add, Picture,                   x658 y386 w36  h25     vg_033                   gl_033, ; (033_1)(Obj_Key_F12)
          } ; [End] [F 1-12]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Numpad] / [0-9][Divide][Multiply][Add][Subtract][Dot][Enter]
            Gui, PopUpMenu:Add, Picture,                   x364 y421 w185 h25     vg_067, ; (067_1)(Obj_Key_ImageText_NumericKeypad)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x218 y456 w44  h25     vg_034                   gl_034, ; (034_1)(Obj_Key_Numpad0)
            Gui, PopUpMenu:Add, Picture,                   x266 y456 w44  h25     vg_035                   gl_035, ; (035_1)(Obj_Key_Numpad1)
            Gui, PopUpMenu:Add, Picture,                   x314 y456 w44  h25     vg_036                   gl_036, ; (036_1)(Obj_Key_Numpad2)
            Gui, PopUpMenu:Add, Picture,                   x362 y456 w44  h25     vg_037                   gl_037, ; (037_1)(Obj_Key_Numpad3)
            Gui, PopUpMenu:Add, Picture,                   x410 y456 w44  h25     vg_038                   gl_038, ; (038_1)(Obj_Key_Numpad4)
            Gui, PopUpMenu:Add, Picture,                   x458 y456 w44  h25     vg_039                   gl_039, ; (039_1)(Obj_Key_Numpad5)
            Gui, PopUpMenu:Add, Picture,                   x506 y456 w44  h25     vg_040                   gl_040, ; (040_1)(Obj_Key_Numpad6)
            Gui, PopUpMenu:Add, Picture,                   x554 y456 w44  h25     vg_041                   gl_041, ; (041_1)(Obj_Key_Numpad7)
            Gui, PopUpMenu:Add, Picture,                   x602 y456 w44  h25     vg_042                   gl_042, ; (042_1)(Obj_Key_Numpad8)
            Gui, PopUpMenu:Add, Picture,                   x650 y456 w44  h25     vg_043                   gl_043, ; (043_1)(Obj_Key_Numpad9)
            ; -------------------------------------------
            Gui, PopUpMenu:Add, Picture,                   x216 y491 w75  h25     vg_045                   gl_045, ; (045_1)(Obj_Key_NumpadDiv)
            Gui, PopUpMenu:Add, Picture,                   x297 y491 w75  h25     vg_048                   gl_048, ; (048_1)(Obj_Key_NumpadMult)
            Gui, PopUpMenu:Add, Picture,                   x378 y491 w75  h25     vg_044                   gl_044, ; (044_1)(Obj_Key_NumpadAdd)
            Gui, PopUpMenu:Add, Picture,                   x459 y491 w75  h25     vg_049                   gl_049, ; (049_1)(Obj_Key_NumpadSub)
            Gui, PopUpMenu:Add, Picture,                   x540 y491 w75  h25     vg_046                   gl_046, ; (046_1)(Obj_Key_NumpadDot)
            Gui, PopUpMenu:Add, Picture,                   x621 y491 w75  h25     vg_047                   gl_047, ; (047_1)(Obj_Key_NumpadEnter)
          } ; [End] [Numpad] / [0-9][Divide][Multiply][Add][Subtract][Dot][Enter]
          ; -------------------------------------------
        } ; [End] [key]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [mnu] / [Addon Extra]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x596 y83  w100 h25     vg_140                   gl_140, ; (140_1)(Obj_Mnu_AddonExtra)
          ; -------------------------------------------
        } ; [End] [mnu] / [Addon Extra]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [cpl][mnu] / [List] / [Full Across][List Left 1/3][Center 1/3][List Right 1/3][List Right 2/3]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x216 y288 w480 r11       vg_116                   gl_116, ; (116_1)(Obj_CplMnu_List100)
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x216 y288 w158 r15       vg_118                   gl_118, ; (118_1)(Obj_CplMnu_ListLeft30)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s10 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x377 y288 w320 r13       vg_117                   gl_117, ; (117_1)(Obj_CplMnu_ListRight60)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont%
          Gui, PopUpMenu:Add, ListBox,                   x377 y288 w158 r15       vg_120                   gl_120, ; (120_1)(Obj_CplMnu_ListCenter30)
          Gui, PopUpMenu:Add, ListBox,                   x538 y288 w158 r15       vg_121                   gl_121, ; (121_1)(Obj_CplMnu_ListRight30)
          ; -------------------------------------------
        } ; [End] [cpl][mnu] / [List] / [Full Across][List Left 1/3][Center 1/3][List Right 1/3][List Right 2/3]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [run][rwh][url][ofl] / (Select) / (Select File)(Select URL)(Select Folder)
          Gui, PopUpMenu:Add, Picture,                     x216 y161 w130 h25     vg_081                   gl_081, ; (081_1)(Obj_RunRwh_File)
          Gui, PopUpMenu:Add, Picture,                     x391 y161 w130 h25     vg_071                   gl_071, ; (071_1)(Obj_URL)
          Gui, PopUpMenu:Add, Picture,                     x566 y161 w130 h25     vg_082                   gl_082, ; (082_1)(Obj_Ofl_Folder)
        } ; [End] [run][rwh][url][ofl] / (Select) / (Select File)(Select URL)(Select Folder)
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [rwh][url] / [url][Get URL Data] / [run][As Admin] / [rwh][url][Select Open With Application] / [rwh][url][Open With App Reset]
          Gui, PopUpMenu:Add, Picture,                     x596 y83  w100 h25     vg_073 gl_073, ; (073_1)(Obj_Run_AsAdmin)
          Gui, PopUpMenu:Add, Picture,                     x216 y229 w30 h30      vg_103,        ; (103_1)(Obj_RwhUrl_OpeningAppImage)
          Gui, PopUpMenu:Add, Picture,                     x256 y231 w280 h25     vg_068 gl_068, ; (068_1)(Obj_RwhUrl_OpenWith)
          Gui, PopUpMenu:Add, Picture,                     x546 y231 w150 h25     vg_069 gl_069, ; (069_1)(Obj_RwhUrl_OpenWithReset)
        } ; [End] [rwh][url] / [url][Get URL Data] / [run][As Admin] / [rwh][url][Select Open With Application] / [rwh][url][Open With App Reset]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [url]
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Text, -Wrap                  x216 y127 w480 h24     vg_131          ; (131_1)(Obj_DisplayText_UrlAddress)
          Gui, PopUpMenu:Add, Picture,                     x596 y79  w100 h41     vg_108 gl_108,  ; (108_1)(Obj_Url_SameNewTab)
          ; -------------------------------------------
        } ; [End] [url]
        ; -------------------------------------------
        PreventFunctionError := 1
        { ; [pum]
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x396 y287 w300 h300      vg_254         ; (254_1)(Obj_MsgImg300x300)
          ; -------------------------------------------
          ; [pum]
          Gui, PopUpMenu:Add, Picture,                     x216 y161 w130 h25       vg_157 gl_157, ; (157_1)(Obj_Pum_Setting)
          Gui, PopUpMenu:Add, Picture,                     x391 y161 w130 h25       vg_160 gl_160, ; (160_1)(Obj_Pum_App))
          Gui, PopUpMenu:Add, Picture,                     x391 y161 w130 h25       vg_161 gl_161, ; (161_1)(Obj_Pum_Del)
          Gui, PopUpMenu:Add, Picture,                     x566 y161 w130 h25       vg_159 gl_159, ; (159_1)(Obj_Pum_Contact)
          ; -------------------------------------------
          ; [pum] > [pumSetting]
          Gui, PopUpMenu:Add, Picture,                     x216 y202 w158 h75      vg_154 gl_154, ; (154_1)(Obj_Pum_BgImage)
          Gui, PopUpMenu:Add, Picture,                     x377 y202 w158 h75      vg_155 gl_155, ; (155_1)(Obj_Pum_BgText)
          Gui, PopUpMenu:Add, Picture,                     x538 y202 w158 h75      vg_156 gl_156, ; (156_1)(Obj_Pum_BgDim)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumBgImage]
          Gui, PopUpMenu:Add, Picture,                     x244 y295 w100 h25       vg_165 gl_165, ; (165_1)(Obj_Pum_BgImageSelect)
          Gui, PopUpMenu:Add, Picture,                     x244 y388 w100 h25       vg_167 gl_167, ; (167_1)(Obj_Pum_BgFitImage)
          Gui, PopUpMenu:Add, Picture,                     x244 y325 w45  h45       vg_182 gl_182, ; (182_1)(Obj_Pum_BgRotateLeft)
          Gui, PopUpMenu:Add, Picture,                     x299 y325 w45  h45       vg_183 gl_183, ; (183_1)(Obj_Pum_BgRotateRight)
          Gui, PopUpMenu:Add, Picture,                     X230 y499 w45  h45       vg_241 gl_241, ; (241_1)(Obj_Pum_CropLeft)
          Gui, PopUpMenu:Add, Picture,                     X318 y499 w45  h45       vg_242 gl_242, ; (242_1)(Obj_Pum_CropRight)
          Gui, PopUpMenu:Add, Picture,                     X274 y455 w45  h45       vg_243 gl_243, ; (243_1)(Obj_Pum_CropUp)
          Gui, PopUpMenu:Add, Picture,                     X274 y543 w45  h45       vg_244 gl_244, ; (244_1)(Obj_Pum_CropDown)
          Gui, PopUpMenu:Add, Picture,                     X274 y499 w45  h45       vg_245 gl_245, ; (245_1)(Obj_Pum_CropCenter)
          Gui, PopUpMenu:Add, Picture,                     x318 y432 w45  h45       vg_246 gl_246, ; (246_1)(Obj_Pum_ZoomIn)
          Gui, PopUpMenu:Add, Picture,                     x230 y432 w45  h45       vg_247 gl_247, ; (247_1)(Obj_Pum_ZoomOut)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumBgText]
          Gui, PopUpMenu:Font, c000000 s16 w700, %GuiFont%
          ; (164_1)(Obj_Pum_BgTxtImg)
          Gui, PopUpMenu:Add, Picture,                     x238 y337 w100 h25       vg_164 gl_164, ; (164_1)(Obj_Pum_BgTxtImg)
          Gui, PopUpMenu:Add, Picture,                     x244 y366 w100 h25       vg_166 gl_166, ; (166_1)(Obj_Pum_BgColor)
          Gui, PopUpMenu:Add, Picture,                     x244 y403 w100 h25       vg_172 gl_172, ; (172_1)(Obj_Pum_MobileText)
          Gui, PopUpMenu:Add, Picture,                     x244 y440 w100 h50       vg_173 gl_173, ; (173_1)(Obj_Pum_MobileTxtColor)
          Gui, PopUpMenu:Add, Picture,                     x244 y501 w100 h50       vg_174 gl_174, ; (174_1)(Obj_Pum_MobileBgColor)
          Gui, PopUpMenu:Add, Picture,                     x220 y465 w150 h25       vg_177       , ; (177_1)(Obj_Pum_BgTrans)
          Gui, PopUpMenu:Add, Picture,                     x232 y497 w55  h28       vg_178 gl_178, ; (178_1)(Obj_Pum_BgOpacityUp)
          Gui, PopUpMenu:Add, Picture,                     x232 y549 w55  h28       vg_179 gl_179, ; (179_1)(Obj_Pum_BgOpacityDown)
          Gui, PopUpMenu:Add, Text, Center                 x234 y526 w50            vg_180       , ; (180_1)(Obj_Pum_DisplayText_Opacity)
          Gui, PopUpMenu:Add, Picture,                     x299 y496 w70  h80       vg_181       , ; (181_1)(Obj_Pum_Opacity)
          ; -------------------------------------------
          ; [pum] > [pumSetting] > [pumDimension]
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont%
          Gui, PopUpMenu:Add, Picture,                     x224 y287 w64  h64       vg_260,        ; (260_1)(Obj_Pum_IconSize)
          Gui, PopUpMenu:Add, Picture,                     x345 y316 w33  h33       vg_261 gl_261, ; (261_1)(Obj_Pum_IconUp)
          Gui, PopUpMenu:Add, Picture,                     x306 y316 w33  h33       vg_262 gl_262, ; (262_1)(Obj_Pum_IconDown)
          Gui, PopUpMenu:Add, Picture,                     x292 y287 w100 h25       vg_263       , ; (263_1)(Obj_Pum_ImageText_IconSize)
          Gui, PopUpMenu:Add, Picture,                     x243 y473 w31  h20       vg_266       , ; (266_1)(Obj_Pum_PumRow)
          Gui, PopUpMenu:Add, Picture,                     x241 y396 w33  h33       vg_267 gl_267, ; (267_1)(Obj_Pum_PumRowUp)
          Gui, PopUpMenu:Add, Picture,                     x241 y435 w33  h33       vg_268 gl_268, ; (268_1)(Obj_Pum_PumRowDown)
          Gui, PopUpMenu:Add, Picture,                     x207 y367 w100 h25       vg_269       , ; (269_1)(Obj_Pum_DisplayText_Vertical)
          Gui, PopUpMenu:Add, Picture,                     x325 y473 w31  h20       vg_272       , ; (272_1)(Obj_Pum_PumColumn)
          Gui, PopUpMenu:Add, Picture,                     x344 y435 w33  h33       vg_273 gl_273, ; (273_1)(Obj_Pum_PumColumnUp)
          Gui, PopUpMenu:Add, Picture,                     x304 y435 w33  h33       vg_274 gl_274, ; (274_1)(Obj_Pum_PumColumnDown)
          Gui, PopUpMenu:Add, Picture,                     x291 y406 w100 h25       vg_275       , ; (275_1)(Obj_Pum_DisplayText_Horizontal)
          ;
          Gui, PopUpMenu:Add, Picture,                     x232  y510 w131 h44       vg_277       , ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
          ; -------------------------------------------
          ; [pum] > [pumContact]
          Gui, PopUpMenu:Add, Picture,                     x216 y211 w160 h25       vg_184       , ; (184_1)(Obj_Pum_ImageText_EmailAddress)
          Gui, PopUpMenu:Add, Edit,   limit50              x382 y212 w315 h25       vg_188 gl_188, ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
          Gui, PopUpMenu:Add, Picture,                     x216 y256 w160 h25       vg_185       , ; (185_1)(Obj_Pum_ImageText_ContactName)
          Gui, PopUpMenu:Add, Edit,   limit50              x382 y256 w315 h25       vg_189 gl_189, ; (189_1)(Obj_Pum_EditFeild_ContactName)
          Gui, PopUpMenu:Add, Picture,                     x321 y301 w270 h25       vg_186       , ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
          Gui, PopUpMenu:Add, Picture,                     x216 y397 w138 h192      vg_187       , ; (187_1)(Obj_Pum_SendEmailAnimate)
          Gui, PopUpMenu:Add, Edit,   limit1000  -VScroll  x364 y346 w332 h243      vg_190 gl_190, ; (190_1)(Obj_Pum_EditFeild_EmailBody)
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column A]
            Gui, PopUpMenu:Add, Picture,                     x402 y299 w30  h35     vg_191 gl_191, ; (191_1)(Obj_Pum_ColorA1)
            Gui, PopUpMenu:Add, Picture,                     x402 y346 w30  h35     vg_192 gl_192, ; (192_1)(Obj_Pum_ColorA2)
            Gui, PopUpMenu:Add, Picture,                     x402 y393 w30  h35     vg_193 gl_193, ; (193_1)(Obj_Pum_ColorA3)
            Gui, PopUpMenu:Add, Picture,                     x402 y440 w30  h35     vg_194 gl_194, ; (194_1)(Obj_Pum_ColorA4)
            Gui, PopUpMenu:Add, Picture,                     x402 y487 w30  h35     vg_195 gl_195, ; (195_1)(Obj_Pum_ColorA5)
            Gui, PopUpMenu:Add, Picture,                     x402 y534 w30  h35     vg_196 gl_196, ; (196_1)(Obj_Pum_ColorA6)
          } ; [End] [Column A]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column B]
            Gui, PopUpMenu:Add, Picture,                     x438 y299 w30  h35     vg_197 gl_197, ; (197_1)(Obj_Pum_ColorB1)
            Gui, PopUpMenu:Add, Picture,                     x438 y346 w30  h35     vg_198 gl_198, ; (198_1)(Obj_Pum_ColorB2)
            Gui, PopUpMenu:Add, Picture,                     x438 y393 w30  h35     vg_199 gl_199, ; (199_1)(Obj_Pum_ColorB3)
            Gui, PopUpMenu:Add, Picture,                     x438 y440 w30  h35     vg_200 gl_200, ; (200_1)(Obj_Pum_ColorB4)
            Gui, PopUpMenu:Add, Picture,                     x438 y487 w30  h35     vg_201 gl_201, ; (201_1)(Obj_Pum_ColorB5)
            Gui, PopUpMenu:Add, Picture,                     x438 y534 w30  h35     vg_202 gl_202, ; (202_1)(Obj_Pum_ColorB6)
          } ; [End] [Column B]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column C]
            Gui, PopUpMenu:Add, Picture,                     x474 y299 w30  h35     vg_203 gl_203, ; (203_1)(Obj_Pum_ColorC1)
            Gui, PopUpMenu:Add, Picture,                     x474 y346 w30  h35     vg_204 gl_204, ; (204_1)(Obj_Pum_ColorC2)
            Gui, PopUpMenu:Add, Picture,                     x474 y393 w30  h35     vg_205 gl_205, ; (205_1)(Obj_Pum_ColorC3)
            Gui, PopUpMenu:Add, Picture,                     x474 y440 w30  h35     vg_206 gl_206, ; (206_1)(Obj_Pum_ColorC4)
            Gui, PopUpMenu:Add, Picture,                     x474 y487 w30  h35     vg_207 gl_207, ; (207_1)(Obj_Pum_ColorC5)
            Gui, PopUpMenu:Add, Picture,                     x474 y534 w30  h35     vg_208 gl_208, ; (208_1)(Obj_Pum_ColorC6)
          } ; [End] [Column C]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column D]
            Gui, PopUpMenu:Add, Picture,                     x510 y299 w30  h35     vg_209 gl_209, ; (209_1)(Obj_Pum_ColorD1)
            Gui, PopUpMenu:Add, Picture,                     x510 y346 w30  h35     vg_210 gl_210, ; (210_1)(Obj_Pum_ColorD2)
            Gui, PopUpMenu:Add, Picture,                     x510 y393 w30  h35     vg_211 gl_211, ; (211_1)(Obj_Pum_ColorD3)
            Gui, PopUpMenu:Add, Picture,                     x510 y440 w30  h35     vg_212 gl_212, ; (212_1)(Obj_Pum_ColorD4)
            Gui, PopUpMenu:Add, Picture,                     x510 y487 w30  h35     vg_213 gl_213, ; (213_1)(Obj_Pum_ColorD5)
            Gui, PopUpMenu:Add, Picture,                     x510 y534 w30  h35     vg_214 gl_214, ; (214_1)(Obj_Pum_ColorD6)
          } ; [End] [Column D]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column E]
            Gui, PopUpMenu:Add, Picture,                     x546 y299 w30  h35     vg_215 gl_215, ; (215_1)(Obj_Pum_ColorE1)
            Gui, PopUpMenu:Add, Picture,                     x546 y346 w30  h35     vg_216 gl_216, ; (216_1)(Obj_Pum_ColorE2)
            Gui, PopUpMenu:Add, Picture,                     x546 y393 w30  h35     vg_217 gl_217, ; (217_1)(Obj_Pum_ColorE3)
            Gui, PopUpMenu:Add, Picture,                     x546 y440 w30  h35     vg_218 gl_218, ; (218_1)(Obj_Pum_ColorE4)
            Gui, PopUpMenu:Add, Picture,                     x546 y487 w30  h35     vg_219 gl_219, ; (219_1)(Obj_Pum_ColorE5)
            Gui, PopUpMenu:Add, Picture,                     x546 y534 w30  h35     vg_220 gl_220, ; (220_1)(Obj_Pum_ColorE6)
          } ; [End] [Column E]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column F]
            Gui, PopUpMenu:Add, Picture,                     x582 y299 w30  h35     vg_221 gl_221, ; (221_1)(Obj_Pum_ColorF1)
            Gui, PopUpMenu:Add, Picture,                     x582 y346 w30  h35     vg_222 gl_222, ; (222_1)(Obj_Pum_ColorF2)
            Gui, PopUpMenu:Add, Picture,                     x582 y393 w30  h35     vg_223 gl_223, ; (223_1)(Obj_Pum_ColorF3)
            Gui, PopUpMenu:Add, Picture,                     x582 y440 w30  h35     vg_224 gl_224, ; (224_1)(Obj_Pum_ColorF4)
            Gui, PopUpMenu:Add, Picture,                     x582 y487 w30  h35     vg_225 gl_225, ; (225_1)(Obj_Pum_ColorF5)
            Gui, PopUpMenu:Add, Picture,                     x582 y534 w30  h35     vg_226 gl_226, ; (226_1)(Obj_Pum_ColorF6)
          } ; [End] [Column F]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column G]
            Gui, PopUpMenu:Add, Picture,                     x618 y299 w30  h35     vg_227 gl_227, ; (227_1)(Obj_Pum_ColorG1)
            Gui, PopUpMenu:Add, Picture,                     x618 y346 w30  h35     vg_228 gl_228, ; (228_1)(Obj_Pum_ColorG2)
            Gui, PopUpMenu:Add, Picture,                     x618 y393 w30  h35     vg_229 gl_229, ; (229_1)(Obj_Pum_ColorG3)
            Gui, PopUpMenu:Add, Picture,                     x618 y440 w30  h35     vg_230 gl_230, ; (230_1)(Obj_Pum_ColorG4)
            Gui, PopUpMenu:Add, Picture,                     x618 y487 w30  h35     vg_231 gl_231, ; (231_1)(Obj_Pum_ColorG5)
            Gui, PopUpMenu:Add, Picture,                     x618 y534 w30  h35     vg_232 gl_232, ; (232_1)(Obj_Pum_ColorG6)
          } ; [End] [Column G]
          ; -------------------------------------------
          PreventFunctionError := 1
          { ; [Column H]
            Gui, PopUpMenu:Add, Picture,                     x654 y299 w30  h35     vg_233 gl_233, ; (233_1)(Obj_Pum_ColorH1)
            Gui, PopUpMenu:Add, Picture,                     x654 y346 w30  h35     vg_234 gl_234, ; (234_1)(Obj_Pum_ColorH2)
            Gui, PopUpMenu:Add, Picture,                     x654 y393 w30  h35     vg_235 gl_235, ; (235_1)(Obj_Pum_ColorH3)
            Gui, PopUpMenu:Add, Picture,                     x654 y440 w30  h35     vg_236 gl_236, ; (236_1)(Obj_Pum_ColorH4)
            Gui, PopUpMenu:Add, Picture,                     x654 y487 w30  h35     vg_237 gl_237, ; (237_1)(Obj_Pum_ColorH5)
            Gui, PopUpMenu:Add, Picture,                     x654 y534 w30  h35     vg_238 gl_238, ; (238_1)(Obj_Pum_ColorH6)
          } ; [End] [Column H]
          ; -------------------------------------------
        } ; [End] [pum]
        ; -------------------------------------------
      } ; [End] Under 600
      ; -------------------------------------------
    } ; End GUI Define by Monitor Size ********************************
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ GUI Define by Monitor Size @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
    if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
    {
      WinSet, AlwaysOnTop, Off, ahk_exe %ThisPumProcessExe%
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := CplMnu_MenuArray(DataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> App Menu
    PreventFunctionError := 1
    { ; App Menu
      ; -------------------------------------------
      Mnu_MenuSize := MenuSize(DataArray) ; > MenuSize
      ; -------------------------------------------
      if (Mnu_MenuSize > 0)
      {
        if (A_ScreenHeight > 601)
        {
          PosX := 10
          PosY := 239
        }
        else
        {
          PosX := 216
          PosY := 231
        }
        ; -------------------------------------------
        Var_Num := 88
        ; -------------------------------------------
        Loop %Mnu_MenuSize%
        {
          ; -------------------------------------------
          if (StrLen(Var_Num) == 1)
          {
            Var_Num := "00" Var_Num
          } ; [End] if (StrLen(Var_Num) == 1)
          if (StrLen(Var_Num) == 2)
          {
            Var_Num := "0" Var_Num
          } ; [End] if (StrLen(Var_Num) == 2)
          ; -------------------------------------------
          if (Mnu_MenuSize == 2)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w238 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 240 ; 2 px - Width (Img Width 238) (2 * 240 = 480)
          } ; [End] if (Mnu_MenuSize == 2)
          else if (Mnu_MenuSize == 3)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w158 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 160 ; 2 px - Width (Img Width 158) (3 * 160 = 480)
          } ; [End] else if (Mnu_MenuSize == 3)
          else if (Mnu_MenuSize == 4)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w118 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 120 ; 2 px - Width (Img Width 118) (4 * 120 = 480)
          } ; [End] else if (Mnu_MenuSize == 4)
          else if (Mnu_MenuSize == 5)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w94 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 96 ; 2 px - Width (Img Width 94) (5 * 96 = 480)
          } ; [End] else if (Mnu_MenuSize == 5)
          else if (Mnu_MenuSize == 6)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w78 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 80 ; 2 px - Width (Img Width 78) (6 * 80 = 480)
          } ; [End] else if (Mnu_MenuSize == 6)
          else if (Mnu_MenuSize == 7)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w67 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 69 ; 2 px - Width (Img Width 67) (7 * 69 = 483)
          } ; [End] else if (Mnu_MenuSize == 7)
          else if (Mnu_MenuSize == 8)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w58 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 60 ; 2 px - Width (Img Width 58) (8 * 60 = 480)
          } ; [End] else if (Mnu_MenuSize == 8)
          else if (Mnu_MenuSize == 9)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w51 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 53 ; 2 px - Width (Img Width 51) (9 * 53 = 477)
          } ; [End] else if (Mnu_MenuSize == 9)
          else if (Mnu_MenuSize == 10)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w46 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 48 ; 2 px - Width (Img Width 46) (10 * 48 = 480)
          } ; [End] else if (Mnu_MenuSize == 10)
          else if (Mnu_MenuSize == 11)
          {
            ; Just Adds the GUI Object NOT its value/Image
            Gui, PopUpMenu:Add, Picture, x%PosX% y%PosY% w42 h25 vg_%Var_Num% gl_%Var_Num%
            PosX := PosX + 44 ; 2 px - Width (Img Width 42) (11 * 44 = 484)
          } ; [End] else if (Mnu_MenuSize == 11)
          ; -------------------------------------------
          Var_Num := Var_Num + 1
          ; -------------------------------------------
        } ; [End] Loop %Mnu_MenuSize%
        ; -------------------------------------------
      } ; [End] if (Mnu_MenuSize > 0)
      else
      {
        ; -------------------------------------------
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray.366.5 := "mnu_cpl_key" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; [End] App Menu
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> App Menu
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    PreventFunctionError := 1
    { ; Hide Vars
      ; -------------------------------------------
      Pre_122 := DataArray.122.3 ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
      ;
      ; ------------------------------------------- [HIDE] (Edit Fields)
      DataArray := Image_GuiControl("122", 0, 0, DataArray) ; (122_1)(Obj_EditFeild_StatusBar)
      DataArray := Image_GuiControl("123", 0, 0, DataArray) ; (123_1)(Obj_Key_EditFeild_TextInput)
      DataArray := Image_GuiControl("131", 0, 0, DataArray) ; (131_1)(Obj_DisplayText_UrlAddress)
      DataArray := Image_GuiControl("170", 0, 0, DataArray) ; (170_1)(Obj_CatPawDropDown)
      DataArray := Image_GuiControl("188", 0, 0, DataArray) ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      DataArray := Image_GuiControl("189", 0, 0, DataArray) ; (189_1)(Obj_Pum_EditFeild_ContactName)
      DataArray := Image_GuiControl("190", 0, 0, DataArray) ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; ------------------------------------------- [HIDE] (Edit Fields)
      ;
      ; ------------------------------------------- [HIDE] (List)
      DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
      DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
      DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
      DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
      DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
      ; ------------------------------------------- [HIDE] (List)
      ;
      ; -------------------------------------------
      DataArray.122.3 := Pre_122 ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    } ; [End] Hide Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> GUI Show
    Gui, PopUpMenu:Color, e7d8fe ; Purple
    Gui, PopUpMenu:-Caption
    ; -------------------------------------------
    if (A_ScreenHeight > 601)
    {
      Gui, PopUpMenu:Show, w500 h700, Shortcut_Pop_Up_Menu ; Shortcut_Pop_Up_Menu is Title
    }
    else
    {
      Gui, PopUpMenu:Show, w700 h590, Shortcut_Pop_Up_Menu ; Shortcut_Pop_Up_Menu is Title
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> GUI Show
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Hide Gui from Task Bar
    ; -------------------------------------------
    WinWait Shortcut_Pop_Up_Menu
    DetectHiddenWindows On
    WinHide
    WinSet, ExStyle, +0x80 ; 0x80 is WS_EX_TOOLWINDOW
    WinShow
    ; -------------------------------------------
    ; Hide Gui from Task Bar
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Current Process Info
    PreventFunctionError := 1
    { ; Current Process Info
      ; -------------------------------------------
      File_ActiveApp := A_AppData "\PopUpMenu_PUM\system\File_ActiveApp.txt"
      FileReadLine, Context_Clicked, %File_ActiveApp%, 9
      ; -------------------------------------------
      ; The Reason for this is because 
      ; Dataarray is not set with these values 
      ; if clicked from the Right Click Menu
      ; -------------------------------------------
      if (Context_Clicked == 1)
      {
        ; -------------------------------------------
        FileReadLine, AppProcessName, %File_ActiveApp%, 1
        FileReadLine, AppProcessExtName, %File_ActiveApp%, 2
        FileReadLine, AppProcessClass, %File_ActiveApp%, 3
        FileReadLine, AppProcessTitle, %File_ActiveApp%, 4
        FileReadLine, AppProcessPathNameExt, %File_ActiveApp%, 5
        FileReadLine, AppProcesssVersion, %File_ActiveApp%, 6
        FileReadLine, AppProcesssPID, %File_ActiveApp%, 7
        ; -------------------------------------------
        DataArray.367.1 := AppProcessName ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        DataArray.367.2 := AppProcessExtName ; (367_2)(AppProcessExtName [Name,Ext])
        DataArray.367.3 := AppProcessClass ; (367_3)(AppProcessClass)
        DataArray.367.4 := AppProcessTitle ; (367_4)(AppProcessTitle)
        DataArray.367.5 := AppProcessPathNameExt ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
        DataArray.367.6 := AppProcesssVersion ; (367_6)(AppProcesssVersion)
        DataArray.367.7 := AppProcesssPID ; (367_7)(AppProcesssPID)
        ; -------------------------------------------
      } ; [End] if (Context_Clicked == 1)
      ; -------------------------------------------
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Internet Browser Application Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          ; This just Creates the Images for Later use
          ; -------------------------------------------
          ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          ; -------------------------------------------
          FileDel135   := Img_Del135(ArrayIn)
          FileDel254   := Img_Del254(ArrayIn)
          FileError440 := Img_Error440(ArrayIn)
          FileError450 := Img_Error450(ArrayIn)
          FileError460 := Img_Error460(ArrayIn)
          FileError470 := Img_Error470(ArrayIn)
          FileMnu134   := Img_Mnu134(ArrayIn)
          FileMnu137   := Img_Mnu137(ArrayIn)
          FileNew135   := Img_New135(ArrayIn)
          FileNew254   := Img_New254(ArrayIn)
          FileOflIco   := Img_OflIco(ArrayIn)
          FileRunIco   := Img_RunIco(ArrayIn)
          FileRwhIco   := Img_RwhIco(ArrayIn)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      } ; [Internet Browser Application Active]
      ; -------------------------------------------
      else ; [Any Other Application (Non Internet Browser) Active]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [Any Other Application (Non Internet Browser) Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (!FileExist(FileRunPng) or !FileExist(FileRunIco) or !FileExist(FileRwhIco) or !FileExist(FileOflIco) or !FileExist(FileNew135) or !FileExist(FileDel135) or !FileExist(FileMnu134) or !FileExist(FileMnu137) or !FileExist(FileError440) or !FileExist(FileError450) or !FileExist(FileError460) or !FileExist(FileError470) or !FileExist(FileNew254) or !FileExist(FileDel254))
        {
          ; -------------------------------------------
          ; This just Creates the Images for Later use
          ; -------------------------------------------
          ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          ; -------------------------------------------
          FileDel135   := Img_Del135(ArrayIn)
          FileDel254   := Img_Del254(ArrayIn)
          FileError440 := Img_Error440(ArrayIn)
          FileError450 := Img_Error450(ArrayIn)
          FileError460 := Img_Error460(ArrayIn)
          FileError470 := Img_Error470(ArrayIn)
          FileMnu134   := Img_Mnu134(ArrayIn)
          FileMnu137   := Img_Mnu137(ArrayIn)
          FileNew135   := Img_New135(ArrayIn)
          FileNew254   := Img_New254(ArrayIn)
          FileOflIco   := Img_OflIco(ArrayIn)
          FileRunIco   := Img_RunIco(ArrayIn)
          FileRwhIco   := Img_RwhIco(ArrayIn)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; [End] Current Process Info
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Current Process Info
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Pum Background Image
    PreventFunctionError := 1
    { ; Pum Background Image
      ; -------------------------------------------
      DataArray.362.52 := 0 ; (362_52)(bg_Selected_Change)
      ; -------------------------------------------
      ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      ;
      ; ------------------------------------------- (bg_Display_Img)
      bg_Display_Img     := ThisPumProcessFolder "\image\bg_Display_Img.png"
      if FileExist(bg_Display_Img)
      {
        Temp_Display_Img := ThisPumProcessFolder "\image\Temp_Display_Img.png"
        FileCopy, %bg_Display_Img%, %Temp_Display_Img%, 1
        Sleep, 250
      } ; [End] if FileExist(bg_Display_Img)
      ; ------------------------------------------- (bg_Display_Img)
      ;
      ; ------------------------------------------- (bg_Display_Txt_Col)
      bg_Display_Txt_Col := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png"
      if FileExist(bg_Display_Txt_Col)
      {
        Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png"
        FileCopy, %bg_Display_Txt_Col%, %Temp_Display_Txt_Col%, 1
        Sleep, 250
      }
      ; ------------------------------------------- (bg_Display_Txt_Col)
      ;
      ; ------------------------------------------- (bg_Display_Txt_Img)
      bg_Display_Txt_Img := ThisPumProcessFolder "\image\bg_Display_Txt_Img.png"
      if FileExist(bg_Display_Txt_Img)
      {
        Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png"
        FileCopy, %bg_Display_Txt_Img%, %Temp_Display_Txt_Img%, 1
        Sleep, 250
      } ; [End] if FileExist(bg_Display_Txt_Col)
      ; ------------------------------------------- (bg_Display_Txt_Img)
      ;
      ; ------------------------------------------- (bg_Selected_Gui)
      bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png"
      if FileExist(bg_Selected_Gui)
      {
        Temp_Selected_Gui := ThisPumProcessFolder "\image\Temp_Selected_Gui.png"
        FileCopy, %bg_Selected_Gui%, %Temp_Selected_Gui%, 1
        Sleep, 250
      } ; [End] if FileExist(bg_Selected_Gui)
      ; ------------------------------------------- (bg_Selected_Gui)
      ;
      ; ------------------------------------------- (bg_Selected_Fit)
      bg_Selected_Fit := ThisPumProcessFolder "\image\bg_Selected_Fit.png"
      if FileExist(bg_Selected_Fit)
      {
        Temp_Selected_Fit := ThisPumProcessFolder "\image\Temp_Selected_Fit.png"
        FileCopy, %bg_Selected_Fit%, %Temp_Selected_Fit%, 1
        Sleep, 250
      } ; [End] if FileExist(bg_Selected_Fit)
      ; ------------------------------------------- (bg_Selected_Fit)
      ;
      ; ------------------------------------------- (bg_Selected_Img)
      bg_Selected_Img := ThisPumProcessFolder "\image\bg_Selected_Img.*"
      Loop, %bg_Selected_Img%
      {
        StringGetPos, PosA, A_LoopFileName, ., R
        StringRight, CurrentExt, A_LoopFileName, % StrLen(A_LoopFileName)-PosA-1
        break
      } ; [End] Loop, %bg_Selected_Img%
      bg_Selected_Img := ThisPumProcessFolder "\image\bg_Selected_Img." CurrentExt
      Temp_Selected_Img := ThisPumProcessFolder "\image\Temp_Selected_Img." CurrentExt
      FileCopy, %bg_Selected_Img%, %Temp_Selected_Img%, 1
      Sleep, 250
      DataArray.362.33 := Temp_Selected_Img ; (362_33)(Temp_Selected_Img [FilePath])
      ; ------------------------------------------- (bg_Selected_Img)
    } ; [End] Pum Background Image
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Pum Background Image
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    PreventFunctionError := 1
    { ; UserLanguage
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [SET] Obj_DropDownListLang_ListBox
      ; -------------------------------------------
      Lang_de := "Deutsch"
      Lang_en := "English"
      Lang_es := "Español"
      Lang_fr := "Français"
      Lang_it := "Italiano"
      Lang_pl := "Polskie"
      Lang_pt := "Português"
      Lang_ru := "Pусский"
      Lang_sv := "Svenska"
      Lang_tr := "Türk"
      DataArray.124.3 := "|" Lang_de "|" Lang_en "|" Lang_es "|" Lang_fr "|" Lang_it "|" Lang_pl "|" Lang_pt "|" Lang_ru "|" Lang_sv "|" Lang_tr ; (124_3)(Obj_DropDownListLang_ListBox [List Box])
      ; -------------------------------------------
      ; [SET] Obj_DropDownListLang_ListBox
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [SET] LangListArray
      ; -------------------------------------------
      DataArray.365.4 := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"] ; (365_4)(LangListArray [Language List] [Array])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] UserLanguage
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("084", "1a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
    DataArray := Image_GuiControl("086", 1, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
    DataArray := Image_GuiControl("083", "1a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray.102.3 := Pre_102 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    PreventFunctionError := 1
    { ; Enable Objects
      ; -------------------------------------------
      GuiControl, PopUpMenu:Enable, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
      GuiControl, PopUpMenu:Enable, g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
      GuiControl, PopUpMenu:Enable, g_116 ; (116_1)(Obj_CplMnu_List100)
      GuiControl, PopUpMenu:Enable, g_117 ; (117_1)(Obj_CplMnu_ListRight60)
      GuiControl, PopUpMenu:Enable, g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
      GuiControl, PopUpMenu:Enable, g_120 ; (120_1)(Obj_CplMnu_ListCenter30)
      GuiControl, PopUpMenu:Enable, g_121 ; (121_1)(Obj_CplMnu_ListRight30)
      ; -------------------------------------------
    } ; [End] Enable Objects
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    WinGet, Gui_Id, ID , Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
    WinSet, Top, , ahk_id %Gui_Id%
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_525.ahk"
    ScriptRunning := Script_Running(ScriptPath)
    if (ScriptRunning > 0)
    {
      Script_Close(ScriptPath)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    global LockKeys := 0
    ; -------------------------------------------
    return DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                                                            
	} ; if !WinExist("HotKey_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Hotkey Select Gui DOES NOT Exist
	; -------------------------------------------
} ; [End] gui_Shortcut(DataArray) ; > DataArray
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
SetWinEventHook(eventMin, eventMax, hmodWinEventProc, lpfnWinEventProc, idProcess, idThread, dwFlags)
{
  return DllCall("SetWinEventHook", UInt, eventMin, UInt, eventMax, Ptr, hmodWinEventProc, Ptr, lpfnWinEventProc, UInt, idProcess, UInt, idThread, UInt, dwFlags, Ptr)
} ; [End] SetWinEventHook(eventMin, eventMax, hmodWinEventProc, lpfnWinEventProc, idProcess, idThread, dwFlags)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HookProc(hWinEventHook, event, hwnd, idObject, idChild, dwEventThread, dwmsEventTime)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  WinGetClass, WindowClassActive, A
  StringLower, WindowClassActive, WindowClassActive
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  AddPopUpToMenu := 1
  if (InStr(WindowClassActive, "AutoHotkey") > 0)
  {
    AddPopUpToMenu := 0
  }
  if (WindowClassActive == "photoshop")
  {
    AddPopUpToMenu := 0
  }
  if (WindowClassActive == "")
  {
    AddPopUpToMenu := 0
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (AddPopUpToMenu == 1)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    static MN_GETHMENU := 0x1E1
    static DRV_DISABLE := 0x5
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    BlockInput, On
    BlockInput, MouseMove
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    SendMessage, MN_GETHMENU,,,, ahk_id %hwnd%
    hMenu := ErrorLevel
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (hMwnu == 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      BlockInput, Off
      BlockInput, MouseMoveOff
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      return
    } ; [End] if (hMwnu == 0)
    else ; (hMwnu DOES NOT == 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      WinGetClass, WindowClassID, ahk_id %hWnd%
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (WindowClassID == "#32768")
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        SendMessage, MN_GETHMENU,,,, ahk_id %hwnd%
        hMenu := ErrorLevel
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ItemArray := CheckMenuItem("🙂 PopUpMenu 🙂", hMenu, hWnd) ; > ItemInMenu [0,#]
        MenuIsContext := ItemArray.1
        ItemInMenu    := ItemArray.2
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (ItemInMenu == 0) ; Is Not in Menu, Add it
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          SendMessage, MN_GETHMENU,,,, ahk_id %hwnd%
          hMenu := ErrorLevel
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          DllCall("AppendMenu", Ptr, hMenu, "UInt", 0, Ptr, 0, "Str", "🙂 PopUpMenu 🙂")
          ; -------------------------------------------
        } ; [End] if (ItemInMenu == 0) ; Is Not in Menu, Add it
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] if (WindowClass == "#32768")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] else ; (hMwnu DOES NOT == 0)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (WindowClassActive != "photoshop")
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  BlockInput, MouseMoveOff
  BlockInput, Off
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] HookProc(hWinEventHook, event, hwnd, idObject, idChild, dwEventThread, dwmsEventTime)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CheckMenuItem(ThisItem, hMenu, hWnd) ; > ItemInMenu [0,#]
{
  ; -------------------------------------------
  ItemInMenu := 0
  MenuIsContext := 0
  ; -------------------------------------------
  ThisPos := 0
  ; -------------------------------------------
  Loop 260
  {
    ; -------------------------------------------
    ThisPos := ThisPos + 1
    ItemName := Menu_getMenuString(hMenu, ThisPos)
    ; -------------------------------------------
    if (ItemName == ThisItem)
    {
      ItemInMenu := ThisPos
    }
    ; -------------------------------------------
    if (StrLen(ItemName) > 0)
    {
      MenuIsContext := 1
    }
  }
  ; -------------------------------------------
  ReturnArray := [MenuIsContext, ItemInMenu]
  return ReturnArray
  ; -------------------------------------------
} ; [End] CheckMenuItem(ThisItem) ; > ItemInMenu [0,1]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Menu_getMenuString(hMenu, Position) ; > ReturnValue
{
  ; -------------------------------------------
  ;implemented specifically for getting the MenuItemName for a menu item
  static alreadyDone, ReturnValue
  ; -------------------------------------------
  ;260 is the largest size a menu item can be
  if (!alreadyDone)
  {
    alreadyDone := true
    VarSetCapacity(ReturnValue, 260)
  } ; [End] if (!alreadyDone)
  ; -------------------------------------------
  if Position is integer
  {
    ;convert from one-based to zero-based index
    Position--
    ByPosition := 0x400      ;MF_BYPOSITION
  } ; [End] if Position is integer
  else
  {
    return
  }
  ; -------------------------------------------
  ; "int", 261, 260 (max size) + 1 (for null terminator)
  DllCall("GetMenuString", "uInt", hMenu, "uInt", Position, "uInt", &ReturnValue, "int", 261, "uInt", ByPosition)
  ; -------------------------------------------
  return ReturnValue
  ; -------------------------------------------
} ; [End] Menu_getMenuString(hMenu, Position) ; > ReturnValue
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Tray Icon Menu / Launcher Hot Key
{ ; Tray Icon Menu / Launcher Hot Key
  ; -------------------------------------------
  if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "HotKey, Direkter Zugang"
    MenuText_Exit := "Schließen Sie PopUpMenu"
  }
  else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "HotKey, Direct Access"
    MenuText_Exit := "Close PopUpMenu"
  }
  else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Tecla Caliente, Acceso Directo"
    MenuText_Exit := "Cerrar PopUpMenu"
  }
  else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Clé Chaude, Accès Direct"
    MenuText_Exit := "Fermer PopUpMenu"
  }
  else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Chiave Calda, Accesso Diretto"
    MenuText_Exit := "Chiudi PopUpMenu"
  }
  else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Gorący Klucz, Dostęp Bezpośredni"
    MenuText_Exit := "Zamknij PopUpMenu"
  }
  else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Chave Quente, Acesso Direto"
    MenuText_Exit := "Feche PopUpMenu"
  }
  else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Горячая клавиша, Прямой Доступ"
    MenuText_Exit := "Закрыть PopUpMenu"
  }
  else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Heta Nyckeln, Direktåtkomst"
    MenuText_Exit := "Stäng PopUpMenu"
  }
  else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
  {
    MenuText_HotKey := "Sıcak Anahtar, Doğrudan Erişim"
    MenuText_Exit := "Kapat PopUpMenu"
  }
  ; -------------------------------------------
  Image_TrayExit   := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_TrayExit.png"
  Image_TrayHotkey := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_TrayHotkey.png"
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  Image_LogoPng := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_TrayHotkey.ico"
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  File_UserHotkey := A_AppData "\PopUpMenu_PUM\system\File_UserHotkey.txt"
  FileReadLine, UserHotkey, %File_UserHotkey%, 1
  if (UserHotkey != "")
  {
    ; -------------------------------------------
    Hotkey, %UserHotkey%, PumLaunch
    ; -------------------------------------------
  }
  ; -------------------------------------------
  Menu, Tray, NoStandard
  Menu, Tray, Add,     %MenuText_HotKey%, Label_SetHotkey
  Menu, Tray, Add,     %MenuText_Exit%, Label_Exit
  Menu, Tray, Icon,    %MenuText_HotKey%, %Image_TrayHotkey%
  Menu, Tray, Icon,    %MenuText_Exit%, %Image_TrayExit%
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; Tray Icon Tip, When Mouse Roll Over Tray Icon
  ; -------------------------------------------
  if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Rechte Mausklick | Bearbeiten Sie Hotkey oder beenden Sie PopUpMenu"
  }
  else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Right Mouse Click | Edit HotKey or Exit PopUpMenu"
  }
  else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Clic derecho del ratón | Editar tecla de acceso rápido o salir de PopUpMenu"
  }
  else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Clic droit de la souris | Modifier la cuite ou la sortie PopUpMenu"
  }
  else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Fai clic sul mouse destro | Modifica Hotkey o uscita PopUpMenu"
  }
  else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Kliknij prawym przyciskiem myszy | Edytuj klawisz skrótu lub wyjdź PopUpMenu"
  }
  else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Clique com o mouse direito | Edite Hotkey ou saída PopUpMenu"
  }
  else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Правый щелчок мыши | Редактировать Hotkey или Exit PopUpMenu"
  }
  else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Höger musklick | Redigera snabbtangent eller utgång PopUpMenu"
  }
  else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
  {
    TrayIconTip := "Sağ Fare Tıklaması | Kısayol Tuşunu Düzenle veya PopUpMenu'ten Çık"
  }
  ; Tray Icon Tip, When Mouse Roll Over Tray Icon
  ; -------------------------------------------
  Menu, Tray, Tip, %TrayIconTip%
  ; -------------------------------------------
  ;
  return
  ; -------------------------------------------
} ; [End] Tray Icon Menu / Launcher Hot Key
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Tray Icon Menu / Launcher Hot Key
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Hot Heys
~Esc::
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Splash_Script("Off", 0) ; User Preassed Esc
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk"
  if (Script_Running(ScriptPath) > 0) ; (running)
  {
    Script_Close(ScriptPath)
  }
  else ; Hotkey Gui NOT Running
  {
    ; -------------------------------------------
    SetTitleMatchMode, 1
    ; -------------------------------------------
    if WinExist("PUM -" . "ahk_class #32770") ; File or Folder Dialogbox
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_SelectFileFolder.ahk"
      if (Script_Running(ScriptPath) > 0) ; (running)
      {
        Script_Close(ScriptPath)
      }
      ; -------------------------------------------
    }
    else if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
    {
      ; -------------------------------------------
      Pum_Close(DataArray)
      ; -------------------------------------------
      Sleep, 100
      ; -------------------------------------------
    }
    else ; Close pum
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check pum Process Exist (PumExist := [0,1])
      ; -------------------------------------------
      PumExist := 0
      PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
      PumListArray := Array_FromFile(PumList)
      for Index, ThisPumProcessExe in PumListArray
      {
        ; -------------------------------------------
        Process, Exist, %ThisPumProcessExe%
        if (ErrorLevel != 0)
        {
          ; -------------------------------------------
          PreThisPumProcessExe := "XXXXXX"
          ; -------------------------------------------
          Process, Close, %ThisPumProcessExe%
          ; -------------------------------------------
          Pum_FileDelete(ThisPumProcessExe)
          ; -------------------------------------------
        } ; [End] if (ErrorLevel != 0)
        ; -------------------------------------------
      } ; [End] for Index, ThisPumProcessExe in PumListArray
      ; -------------------------------------------
      ; Check pum Process Exist (PumExist := [0,1])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] else ; Close pum
    ; -------------------------------------------
  } ; [End] else ; Hotkey Gui NOT Running
  ; -------------------------------------------
} ; [End] ~Esc::
return
~Lbutton::
{
  ; -------------------------------------------
  SetTimer, Load_Config_Pum, Off
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  global ShortcutMoveLock := 0
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  StartTime := A_TickCount
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ThisPumProcessExe := ""
  WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
  if (InStr(ThisPumProcessExe, "pum_") == 0) ; pum NOT Exist
  {
    ThisPumProcessExe := ""
  }
  else
  {
    ; -------------------------------------------
    ThisPumProcessName := ThisPumProcessExe
    ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
    ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
    ; -------------------------------------------
    ThisPumProcessPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\" ThisPumProcessExe
    ; -------------------------------------------
    ThisX := ""
    ThisY := ""
    ; -------------------------------------------
    ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
    ; -------------------------------------------
    if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Not Exist
    {
      WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
    }
    else if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Not Exist
    {
      WinSet, Top, , ahk_class AutoHotkeyGUI
      WinSet, AlwaysOnTop, Off, ahk_exe %ThisPumProcessExe%
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Not Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; if pum is Active Check Grid
    ; if Grid ((XmlShortcutLineNum == 0) then Pum_Close(DataArray)
    ; -------------------------------------------
    if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
    {
      ; -------------------------------------------
      LButtonTime := A_TickCount + 1000
      BlockInput, MouseMove
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ModDatePumProcessName := ThisPumProcessExe
      ModDatePumProcessName := StrReplace(ModDatePumProcessName, "pum_", "")
      ModDatePumProcessName := StrReplace(ModDatePumProcessName, ".exe", "")
      ModDatePumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\" ModDatePumProcessName "\settings"
      ModDatePumProcessXml := ModDatePumProcessSettingsFolder "\toolbox0.xml"
      ; -------------------------------------------
      FileGetTime, PreModDate, %ModDatePumProcessXml%, M
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; ExistingShortcut = 0 (Not Over Shortcut)
      ; ExistingShortcut = 1 (Over Shortcut)
      ; ExistingShortcut = 2 (Not in Pum)
      DataArray := Shortcut_Description(DataArray) ; > [ExistingShortcut, ShortcutDescription, ShortcutColumnX, ShortcutRowY]
      ; (153)(01)(Shortcut_Description_ExistingShortcut)_(153)(02)(ShortcutDescription)_(153)(03)(XmlShortcutPosX)_(153)(04)(XmlShortcutPosY)
      ExistingShortcut := DataArray.153.1
      Pre_XmlShortcutPosX := DataArray.153.3
      Pre_XmlShortcutPosY := DataArray.153.4
      ; -------------------------------------------
      while (GetKeyState("LButton", "P") == 1)
      {
        if (A_TickCount > LButtonTime)
        {
          ; -------------------------------------------
          BlockInput, MouseMoveOff
          ; -------------------------------------------
          ; Change System Cursor to MoveIcon.cur
          ; -------------------------------------------
          Cursor = C:\Program Files\PopUpMenu_PUM\image\ico\MoveIcon.cur
          CursorHandle := DllCall( "LoadCursorFromFile", Str,Cursor )
          Cursors = 32512,32513,32514,32515,32516,32640,32641,32642,32643,32644,32645,32646,32648,32649,32650,32651
          Loop, Parse, Cursors, `,
          {
        	  DllCall( "SetSystemCursor", Uint,CursorHandle, Int,A_Loopfield )
          }
          ; -------------------------------------------
        } ; [End] if (A_TickCount > LButtonTime)
      } ; [End] while (GetKeyState("LButton", "P") == 1)
      ; -------------------------------------------
      BlockInput, MouseMoveOff
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; Restore System Cursor
      ; -------------------------------------------
      SPI_SETCURSORS := 0x57
      DllCall( "SystemParametersInfo", UInt,SPI_SETCURSORS, UInt,0, UInt,0, UInt,0 )
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      EndTime := A_TickCount - StartTime
      ; -------------------------------------------
      if (EndTime < 500) ; Run Shortcut
      {
        ; -------------------------------------------
        DataArray := Shortcut_LButton(DataArray) ; > XmlShortcutLineNum
        XmlShortcutLineNum := DataArray.370.1 ; (370)(01)(XmlShortcutLineNum [XML Line Number])
        ; -------------------------------------------
      } ; [End] if (EndTime < 750)
      else if (ExistingShortcut == 1) ; Move Shortcut
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; ExistingShortcut = 0 (Not Over Shortcut)
        ; ExistingShortcut = 1 (Over Shortcut)
        ; ExistingShortcut = 2 (Not in Pum)
        ; -------------------------------------------
        DataArray := Shortcut_Description(DataArray) ; > [ExistingShortcut, ShortcutDescription, ShortcutColumnX, ShortcutRowY]
        ; (153)(01)(Shortcut_Description_ExistingShortcut)_(153)(02)(ShortcutDescription)_(153)(03)(XmlShortcutPosX)_(153)(04)(XmlShortcutPosY)
        XmlShortcutPosX := DataArray.153.3
        XmlShortcutPosY := DataArray.153.4
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        if (Pre_XmlShortcutPosX != XmlShortcutPosX or Pre_XmlShortcutPosY != XmlShortcutPosY) ; Shortcut Has Been Moved
        {
          ; -------------------------------------------
          global ShortcutMoveLock := 1
          ; -------------------------------------------
          ;
          Sleep, 500 ; Min Sleep Time
          ;
          ; -------------------------------------------
          Process, Close, %ThisPumProcessExe%
          Sleep, 250
          ; -------------------------------------------
          Process, Exist, %ThisPumProcessExe%
          while (ErrorLevel != 0)
          {
            Process, Close, %ThisPumProcessExe%
            Sleep, 250
            Process, Exist, %ThisPumProcessExe%
          }
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Current (ThisPumProcessArray)
          ; After [RUN] ThisPumProcessPath
          ; -------------------------------------------
          ThisPumProcessName := ThisPumProcessExe
          ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
          ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
          ThisPumProcessSettingsFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings"
          ThisPumProcessXml := ThisPumProcessSettingsFolder "\toolbox0.xml"
          ; -------------------------------------------
          ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
          DataArray.361.10 := ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
          ; -------------------------------------------
          ; Current (ThisPumProcessArray)
          ; After [RUN] ThisPumProcessPath
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          ; When the pum has too many shortcuts
          ; the normal toolbox move shortcut Does Not Work
          ; By using the XML File's Modified Date
          ; We can know if this Error has occured
          ; We must move the shortcut manualy using the function (Pum_MoveShortcut)
          ; -------------------------------------------
          FileGetTime, PostModDate, %ThisPumProcessXml%, M
          ; -------------------------------------------
          if (PreModDate == PostModDate) ; The XML File Was Not Modified (Shortcut Move Error) | pum has many shortcuts
          {
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; Move Shortcut
            ; -------------------------------------------
            Pum_MoveShortcut(ThisPumProcessXml, Pre_XmlShortcutPosX, Pre_XmlShortcutPosY, XmlShortcutPosX, XmlShortcutPosY) ; Pum_MoveShortcut(ThisPumXml, From_ShortcutPosX, From_ShortcutPosY, To_ShortcutPosX, To_ShortcutPosY) > Nothing
            ; -------------------------------------------
            ; Move Shortcut
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          }
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Current (ThisPumProcessArray)
          ; After [RUN] ThisPumProcessPath
          ; -------------------------------------------
          ThisPumProcessArray := FixXmlArray(ThisPumProcessArray, ThisPumProcessXml) ; > FixThisArray
          DataArray.361.10 := ThisPumProcessArray ; (361)(10)(ThisPumProcessArray)
          ; -------------------------------------------
          ; Current (ThisPumProcessArray)
          ; After [RUN] ThisPumProcessPath
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>          
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; ReRun pum
          ; -------------------------------------------
          Run, %ThisPumProcessPath%,,, ThisPumProcessPriority
          ; ------------------------------------------
          ; ReRun pum
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          Process, Priority, %ThisPumProcessPriority%, High
          WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; MakeIt = 1 Delete Old (GridCheck.txt) (if Exist) Creat New (GridCheck.txt)
          Pum_GridCheck(ThisPumProcessName, 1) ; AppName [Lowercase], MakeIt [0/1]
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          global ShortcutMoveLock := 0
          ; -------------------------------------------
        } ; [End] if (Pre_XmlShortcutPosX != XmlShortcutPosX or Pre_XmlShortcutPosY != XmlShortcutPosY) ; Shortcut Has Been Moved
        ; -------------------------------------------
      } ; [End] else if (ExistingShortcut == 1) ; Move Shortcut
      ; -------------------------------------------
    } ; [End] if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
    ; -------------------------------------------
    else ; pum NOT Active
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      WinGetClass, ThisWinClass, A
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      MouseGetPos, MouseScreenX, MouseScreenY, MouseWindowUID, MouseControlID
      WinGet,ControlHwnd, ID,ahk_id %MouseWindowUID%
      hWnd := ControlHwnd
      SendMessage, 0x01E1, , , , ahk_id %hWnd%
      hMenu := errorlevel
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      CoordMode, Mouse, Screen
      MouseGetPos, X, Y,
      POINT := X | Y << 32
      ClickedPos := DllCall("MenuItemFromPoint", Ptr, hWnd, Ptr, hMenu, Int64, POINT)
      ClickedItemNum := ClickedPos + 1
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (ClickedPos != -1)
      {
        ; -------------------------------------------
        ClickedMenuItem := Menu_getMenuString(hMenu, ClickedItemNum)
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (ClickedMenuItem == "🙂 PopUpMenu 🙂")
        {
          ; -------------------------------------------
          Run, C:\Program Files\PopUpMenu_PUM\Context.ahk
          ; -------------------------------------------
        } ; [End] if (ClickedMenuItem == "🙂 PopUpMenu 🙂")
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] else ; NOT -1
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] NOT Active PUM
    ; -------------------------------------------
  } ; [End] if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Not Active GUI
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  
  ;
  ; -------------------------------------------
  SetTimer, Load_Config_Pum, 100
  ; -------------------------------------------
} ; [End] ~Lbutton::
return
~Rbutton::
{
  ; -------------------------------------------
  SetTimer, Load_Config_Pum, Off
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if WinExist("ToolBox v2.85" . "ahk_class #32770")
  {
    WinClose
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (Not Active) GUI
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; if pum is Active Check Grid
    ; if Grid ((XmlShortcutLineNum == 0) then Pum_Close(DataArray)
    ; -------------------------------------------
    WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
    if (InStr(ThisPumProcessExe, "pum_") > 0) ; Pum Exist
    {
      ; -------------------------------------------
      ThisX := ""
      ThisY := ""
      ; -------------------------------------------
      ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
  		; -------------------------------------------
      DataArray := Shortcut_RButton(DataArray) ; > DataArray      
      ; -------------------------------------------
      XmlShortcutLineNum := DataArray.370.1 ; (370_1)(XmlShortcutLineNum [XML Line Number])
      ; -------------------------------------------
      if (XmlShortcutLineNum == "-1" or XmlShortcutLineNum == "") ; Mouse Not in Pum
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; -1 Means a Not in Pum
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        Pum_Close(DataArray) ; > Nothing
        ; -------------------------------------------
      } ; [End] if (XmlShortcutLineNum == "-1")
      else ; Mouse Click in PUM
      {
        ; -------------------------------------------
        DataArray := gui_Shortcut(DataArray) ; > DataArray
        ; -------------------------------------------
      } ; [End] else ; Mouse Click in PUM
      ; -------------------------------------------
    } ; [End] if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum is Active
    ; -------------------------------------------
    else ; pum NOT Active
    {
      ; -------------------------------------------
      KeyWait, RButton
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check is pum Exist
      ; Close pum
      ; -------------------------------------------
      Process, Exist, %ThisPumProcessExe%
      if (ErrorLevel != 0) ; pum Exist
      {
        ; -------------------------------------------
        PreThisPumProcessExe := "XXXXXX"
        ; -------------------------------------------
        Process, Close, %ThisPumProcessExe%
        ; -------------------------------------------
        Pum_FileDelete(ThisPumProcessExe)
        ; -------------------------------------------
      } ; [End] if (ErrorLevel != 0)
      ; -------------------------------------------
      ; Check is pum Exist
      ; Close pum
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] else ; pum NOT Active
    ; -------------------------------------------
  } ; [End] if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (Not Active) GUI
  ; -------------------------------------------
  else if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (Exist) PopUpMenu Gui
  {
    ; -------------------------------------------
    KeyWait, RButton
    ; -------------------------------------------
    SetTitleMatchMode, 1
    if WinExist("PUM -" . "ahk_class #32770") ; (Exist) File Folder Select Window
    {
      if !WinExist("ahk_class ViewControlClass") ; (NOT Exist) Select View PopUp
      {
        SetTitleMatchMode, 1
        if !WinActive("PUM -" . "ahk_class #32770") ; (NOT Active) File Folder Select Window
        {
          DoWhile := 1
          while (DoWhile == 1)
          {
            SetTitleMatchMode, 1
            if !WinActive("PUM -" . "ahk_class #32770") ; (NOT Active) File Folder Select Window
            {
              if !WinExist("ahk_class ViewControlClass") ; (NOT Exist) Select View PopUp
              {
                Sleep, 250
                SetTitleMatchMode, 1
                if WinExist("PUM -" . "ahk_class #32770") ; (Exist) File Folder Select Window
                {
                  WinActivate ; (File Select Window)
                } ; [End] (Exist) File Folder Select Window
              } ; [End] (NOT Exist) Select View PopUp
            } ; [End] (NOT Active) File Folder Select Window
            else if WinActive("PUM -" . "ahk_class #32770") ; (Is Active) File Folder Select Window
            {
              DoWhile := 0
            } ; [End] (Is Active) File Folder Select Window
          } ; [End] while (DoWhile == 1)
        } ; [End] (NOT Active) File Folder Select Window
      } ; [End] (NOT Exist) Select View PopUp
    } ; [End] (Exist) File Folder Select Window
    ; -------------------------------------------
  } ; [End] else if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Exist
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  SetTimer, Load_Config_Pum, 100
  ; -------------------------------------------
} ; [End] ~Rbutton::
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Hot Heys
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ; GUI Labels
PreventFunctionError := 1
{ ; GUI Labels
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  PumLaunch: ; Uses User Specified Pum Launch HotKey
  {
    ; -------------------------------------------
    SetTimer, Load_Config_Pum, Off
    ; -------------------------------------------
    MobileOnOff := ""
    ; -------------------------------------------
    if !WinExist("CatPaw" . "ahk_class AutoHotkeyGUI") ; CatPaw Gui NOT Exist
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ThisPumProcessExe := ""
      WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
      if (InStr(ThisPumProcessExe, "pum_") == 0) ; pum NOT Exist
      {
        ThisPumProcessExe := ""
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Exist
      {
        ; -------------------------------------------
        if WinExist("PUM -" . "ahk_class #32770") ; File or Folder Dialogbox Exist
        {
          WinClose
        } ; [End] File or Folder Dialogbox Exist
        else
        {
          ; -------------------------------------------
          Gui, PopUpMenu:Destroy
          ; -------------------------------------------
          Sleep, 10
          ; -------------------------------------------
          DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
          ; -------------------------------------------
          if (UserHotkey != "")
          {
            ; -------------------------------------------
            Hotkey, %UserHotkey%, PumLaunch
            ; -------------------------------------------
          }
          ; -------------------------------------------
        } ; [End] File or Folder Dialogbox DOES NOT Exist
        ; -------------------------------------------
        Sleep, 100
        ; -------------------------------------------
      } ; [End] PopUpMenu Gui Exist
      else if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui DOES NOT Exist
      {
        ; -------------------------------------------
        if (ThisPumProcessExe == "") ; pum Not Exist
        {
          ; -------------------------------------------
          PreThisPumProcessExe := "XXXXXX"
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (_02_Dec_2022_)(_21:20:13_)
          ; See (D:\(_Installed_)\(_PopUpMenu_)\((_Errors_)\Error_NoDataArray.png)
          ; -------------------------------------------
          DataArray_Len := DataArray.MaxIndex()
          if (DataArray_Len == "" or DataArray_Len < 10)
          {
            DataArray := Sys_DataArray()
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          DataArray := Pum_Run(DataArray) ; > DataArray
          ; -------------------------------------------
        } ; [End] if (ThisPumProcessExe == "") ; pum Not Exist
        else ; pum Exist
        {
          ; -------------------------------------------
          PreThisPumProcessExe := "XXXXXX"
          ; -------------------------------------------
          Process, Close, %ThisPumProcessExe%
          ; -------------------------------------------
          Pum_FileDelete(ThisPumProcessExe)
          ; -------------------------------------------
        } ; [End] else ; pum Exist
        ; -------------------------------------------
      } ; [End] PopUpMenu Gui DOES NOT Exist
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      SetTimer, Load_Config_Pum, 100
      ; -------------------------------------------
    } ; [End] if !WinExist("CatPaw" . "ahk_class AutoHotkeyGUI") ; CatPaw Gui NOT Exist
    ; -------------------------------------------
    SetTimer, Load_Config_Pum, 100
    ; -------------------------------------------
  } ; [End] PumLaunch:
  return  
  Label_SetHotkey:
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Close All pum Processes
    ; -------------------------------------------
    WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
    if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
    {
      ; -------------------------------------------
      PumExist := 0
      PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
      PumListArray := Array_FromFile(PumList)
      for Index, ThisPumProcessExe in PumListArray
      {
        Process, Exist, %ThisPumProcessExe%
        if (ErrorLevel != 0)
        {
          ; -------------------------------------------
          PreThisPumProcessExe := "XXXXXX"
          ; -------------------------------------------
          Process, Close, %ThisPumProcessExe%
          ; -------------------------------------------
          Pum_FileDelete(ThisPumProcessExe)
          ; -------------------------------------------
        }
      }
      Sleep, 100
    } ; if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
    ; -------------------------------------------
    ; Close All pum Processes
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !WinExist("HotKey_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Hotkey Select Gui DOES NOT Exist
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; if PopUpMenu Gui Exist, Close it
      ; -------------------------------------------
      if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Exist
      {
        ; -------------------------------------------
        Gui, PopUpMenu:Destroy
        ; -------------------------------------------
        DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
        ; -------------------------------------------
      } ; [End] if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; PopUpMenu Gui Exist
      ; -------------------------------------------
      ; if PopUpMenu Gui Exist, Close it
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; if Check pum Process Exist, Close it
      ; -------------------------------------------
      WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
      if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
      {
        ; -------------------------------------------
        PreThisPumProcessExe := "XXXXXX"
        ; -------------------------------------------
        Process, Close, %ThisPumProcessExe%
        ; -------------------------------------------
        Pum_FileDelete(ThisPumProcessExe)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      ; if Check pum Process Exist, Close it
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      Run, C:\Program Files\PopUpMenu_PUM\Hotkey_gui.ahk
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      BreakTime := A_Tickcount + 2000
      while (HotkeyGui_Id == "")
      {
        WinGet, HotkeyGui_Id, ID, HotKey_Pop_Up_Menu ahk_class AutoHotkeyGUI
        if (A_Tickcount > BreakTime)
        {
          break
        }
      }
      if (HotkeyGui_Id != "")
      {
        WinSet, AlwaysOnTop, On, ahk_id %HotkeyGui_Id%
      }
      ; -------------------------------------------
    } ; [End] if !WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Hotkey Select Gui DOES NOT Exist
    ; -------------------------------------------
  } ; [End] Label_SetHotkey:
  return
  Label_Exit:
  {
    ; -------------------------------------------
    SkipThisPart := 1
    if (SkipThisPart == 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Delete Plugin Temp Files
      ; -------------------------------------------
      Text_Pluginacadacad := A_Appdata "\PopUpMenu_PUM\system\Plugin_acad.txt"
      if FileExist(Text_Pluginacad)
      {
        FileDelete, %Text_Pluginacad%
        Sleep, 250
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; if (SkipThisPart == 0)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Hotkey_Ok := "C:\Program Files\PopUpMenu_PUM\HotKey_Ok.ahk"
    Script_Close(Hotkey_Ok)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    SetTitleMatchMode, 2
    ; -------------------------------------------
    WinSet, AlwaysOnTop, Off, ahk_class TfrmToolbox
    ; -------------------------------------------
    if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Check for File/Folder/Icon Select dialog exist (Close)
    {
      WinClose
      WinGet, Pum, ProcessName, ahk_class #32770
      if (Pum == "AutoHotkey.exe")
      {
        WinClose, ahk_class #32770
      }
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Close All pum Processes
    ; -------------------------------------------
    PumExist := 0
    PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
    PumListArray := Array_FromFile(PumList)
    for Index, ThisPumProcessExe in PumListArray
    {
      Process, Exist, %ThisPumProcessExe%
      if (ErrorLevel != 0)
      {
        ; -------------------------------------------
        PreThisPumProcessExe := "XXXXXX"
        ; -------------------------------------------
        Process, Close, %ThisPumProcessExe%
        ; -------------------------------------------
        Pum_FileDelete(ThisPumProcessExe)
        ; -------------------------------------------
      }
    }
    ; -------------------------------------------
    ; Close All pum Processes
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;  
    ; -------------------------------------------
    ThisProcess := "magick.exe"
    Process, Exist, %ThisProcess%
    if (ErrorLevel != 0)
    {
      Process, Close, %ThisProcess%
    }
    ; -------------------------------------------
    ThisProcess := "PopUpMenu_ResourceHacker.exe"
    Process, Exist, %ThisProcess%
    if (ErrorLevel != 0)
    {
      Process, Close, %ThisProcess%
    }
    ; -------------------------------------------
    ThisProcess := "PopUpMenu_MailSend.exe"
    Process, Exist, %ThisProcess%
    if (ErrorLevel != 0)
    {
      Process, Close, %ThisProcess%
    }
    ; -------------------------------------------
    ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
    if (Script_Running(ScriptPath) > 0) ; (running)
    {
      Script_Close(ScriptPath)
      MobileOnOff := ""
      MobileTxColor := ""
      MobileTxSize := ""
    }
    ; -------------------------------------------
		SplashNum := 499
		Loop 100
		{
			SplashNum := SplashNum + 1
		  ScriptPath := "C:\Program Files\PopUpMenu_PUM\Splash_" SplashNum ".ahk"
      if (Script_Running(ScriptPath) > 0) ; (running)
      {
        Script_Close(ScriptPath)
      }
		}
    ; -------------------------------------------
    Script_Close("CatPaw_Wait.ahk")
    Script_Close("Clipboard_Watch.ahk")
    Script_Close("Config_SelectFileFolder.ahk")
    Script_Close("Config_Pum.ahk")
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; (RefreshSystemTrayOnExit.ahk) Will Close (SysTray.exe)
    ; -------------------------------------------
    RefreshTrayScript := "C:\Program Files\PopUpMenu_PUM\RefreshSystemTrayOnExit.ahk"
    if FileExist(RefreshTrayScript)
    {
      Run, %RefreshTrayScript%
    }
    else
    {
      ; -------------------------------------------
      ScriptPath := "C:\Program Files\PopUpMenu_PUM\SysTray.exe"
      if (Script_Running(ScriptPath) > 0) ; (running)
      {
        Script_Close(ScriptPath)
      }    
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  } ; [End] Label_Exit:
  return
  Load_Config_Pum:
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; PC          "M80-5A010400185"
    ; Work Laptop "M937NBCV00E1FRMB"
    ; Box Laptop  "MB46NBCV00UP90MB"
    ; Anne Laptop
    ; A_UserName = anneb
    ; A_ComputerName = ANNEB
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Clipboard Watch Persistent Script
    ; Only Used for PowerPoint Addon
    ; -------------------------------------------
    SkipThisPart := 1
    if (SkipThisPart == 0)
    {
      ; -------------------------------------------
      ScriptPath := "C:\Program Files\PopUpMenu_PUM\Clipboard_Watch.ahk"
      ; -------------------------------------------
      if (Script_Running(ScriptPath) == 0) ; (Clipboard_Watch.ahk) (NOT Running)
      {
        Run %ScriptPath%
      }
      ; -------------------------------------------
    } ; if (SkipThisPart == 0)
    ; -------------------------------------------
    ; Clipboard Watch Persistent Script
    ; Only Used for PowerPoint Addon
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (_02_Dec_2022_)(_21:20:13_)
    ; See (D:\(_Installed_)\(_PopUpMenu_)\((_Errors_)\Error_NoDataArray.png)
    ; -------------------------------------------
    DataArray_Len := DataArray.MaxIndex()
    if (DataArray_Len == "" or DataArray_Len < 10)
    {
      DataArray := Sys_DataArray()
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Acad Plugin
    ; -------------------------------------------
    SkipThisPart := 1
    if (SkipThisPart == 0)
    {
      ; -------------------------------------------
      Folder_Pluginacad := "C:\Program Files\PopUpMenu_PUM\menu\mnu\acad"
      if FileExist(Folder_Pluginacad)
      {
        SetTitleMatchMode, 2 ; WinTitle anywhere inside it to be a match.
        if WinActive("Autodesk AutoCAD")
        {
          SetTitleMatchMode, 2 ; WinTitle anywhere inside it to be a match.
          if !WinActive("[Start]")
          {
            Text_Pluginacad := A_Appdata "\PopUpMenu_PUM\system\Plugin_acad.txt"
            if FileExist(Text_Pluginacad)
            {
              ; -------------------------------------------
              FileReadLine, LispLoaded, %Text_Pluginacad%, 1
              Sleep, 100
              if (LispLoaded == 0)
              {
                ; -------------------------------------------
                UserLang := "en"
                LispPath := "C:\Program Files\PopUpMenu_PUM\menu\mnu\acad\" UserLang "\lsp\popupmenulisp.lsp"
                LispPath := StrReplace(LispPath, "\", "\\")
                ; -------------------------------------------
                SendThis := "(load """ LispPath """)"
                ; -------------------------------------------
                Send, {Esc}
                Sleep, 100
                Send, {Esc}
                Sleep, 100
                Send, %SendThis%
                Send, {Enter}
                ; -------------------------------------------
                DataArray.280.1 := 1 ; (280_1)(Plugin_AcadLspLoaded [0,1])
                ; -------------------------------------------
              }
            } ; [End] if FileExist(Text_Pluginacad)
            else
            {
              ; -------------------------------------------
              Fileappend, 1, %Text_Pluginacad%
              Sleep, 250
              ; -------------------------------------------
              UserLang := DataArray.365.2
              LispPath := "C:\Program Files\PopUpMenu_PUM\menu\mnu\acad\" UserLang "\lsp\popupmenulisp.lsp"
              LispPath := StrReplace(LispPath, "\", "\\")
              ; -------------------------------------------
              SendThis := "(load """ LispPath """)"
              ; -------------------------------------------
              Send, {Esc}
              Sleep, 100
              Send, {Esc}
              Sleep, 100
              Send, %SendThis%
              Send, {Enter}
              ; -------------------------------------------
              DataArray.280.1 := 1 ; (280_1)(Plugin_AcadLspLoaded [0,1])
              ; -------------------------------------------
            }
          } ; [End] if !WinActive("[Start]")
        } ; [End] if WinActive("Autodesk AutoCAD")
      } ; [End] if FileExist(Folder_Pluginacad)
    } ; if (SkipThisPart == 0)
    ; -------------------------------------------
    ; Acad Plugin
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; ToolBox (ERROR FIX)
    ; -------------------------------------------
    SetTitleMatchMode 2
    ; -------------------------------------------
    if WinExist("ToolBox v2.85" . "ahk_class TMessageForm") ; ToolBox (ERROR)
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      Pum_Kill()
      ; -------------------------------------------
      ThisPumProcessName := ThisPumProcessExe
      ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
      ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
      ; -------------------------------------------
    } ; [End] ToolBox (ERROR)
    ; -------------------------------------------
    SetTitleMatchMode 2
    ; -------------------------------------------
    if WinExist("ToolBox v2.85" . "ahk_class #32770") ; ToolBox (ERROR)
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      Pum_Kill()
      ; -------------------------------------------
      ThisPumProcessName := DataArray.361.15 ; (361)(15)(ThisPumProcessName [NO pum_,Path,Ext])
      ; -------------------------------------------
      ThisPumProcessExe  := "pum_" ThisPumProcessName ".exe"
      ThisPumProcessPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\" ThisPumProcessExe
      ; -------------------------------------------
      PreThisPumProcessExe := "XXXXXX" ; Reset
      ; -------------------------------------------
      Process, Close, %ThisPumProcessExe%
      ; -------------------------------------------
      Pum_FileDelete(ThisPumProcessExe)
      ; -------------------------------------------
      Sleep, 10
      ; -------------------------------------------
      Process, Exist, %ThisPumProcessExe%
      while (ErrorLevel != 0)
      {
        Sleep, 10
        Process, Exist, %ThisPumProcessExe%
      } ; [End] while (ErrorLevel != 0)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; run ThisPumProcess
      ; -------------------------------------------
      Run,  %ThisPumProcessPath%,,, ThisPumProcessPriority
      ; -------------------------------------------
      Process, Priority, %ThisPumProcessPriority%, High
      WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
      ; -------------------------------------------    
      Sleep, 10
      ; -------------------------------------------
      ; run ThisPumProcess
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    } ; [End] ToolBox (ERROR)
    ; -------------------------------------------
    ; ToolBox (ERROR FIX)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    if (ShortcutMoveLock == "")
    {
      global ShortcutMoveLock := 0
    }
    ; -------------------------------------------  
    if (ShortcutMoveLock == 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Get Pum Process Name
      ; -------------------------------------------
      WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Run/Close (Config_Pum.ahk) (ToolTip_Message)
      ; -------------------------------------------
      if (InStr(ThisPumProcessExe, "pum_") == 0) ; (pum) (Does NOT Exist)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (NOT Exist > pum)
        ; (NOT Exist > Gui)
        ; (Config_Pum.ahk) if (Running) (Close)
        ; -------------------------------------------
				; (Config_Pum.ahk) keystroke definitions
        ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
        if (Script_Running(ScriptPath) > 0) ; (Config_Pum.ahk) if (Running) (Close)
        {
          ; -------------------------------------------
          Script_Close(ScriptPath) ; (Close) (Config_Pum.ahk)
          ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
          ; -------------------------------------------
        } ; (Config_Pum.ahk) if (Running) (Close)
        ; -------------------------------------------
        ; (NOT Exist > pum)
        ; (NOT Exist > Gui)
        ; (Config_Pum.ahk) if (Running) (Close)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] (pum) (Does NOT Exist)
      else if (InStr(ThisPumProcessExe, "pum_") > 0) ; (pum) (Exist)
      {
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				; [CHECK] Current (ThisPumProcessXml) (ThisPumProcessArray)
        ; -------------------------------------------
        ThisPumProcessName := ThisPumProcessExe
        ThisPumProcessName := StrReplace(CheckThisPumProcessName, "pum_", "")
        ThisPumProcessName := StrReplace(CheckThisPumProcessName, ".exe", "")
        ; -------------------------------------------        
        ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
				; -------------------------------------------
        ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
        DataArray.361.10 := ThisPumProcessArray
        ; -------------------------------------------
				; [CHECK] Current (ThisPumProcessXml) (ThisPumProcessArray)
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				;
        ; -------------------------------------------
        SetTitleMatchMode 2
        ; -------------------------------------------
        if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui)(Exist)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Disable the pum While (ShortcutGui)(Exist)
          ; -------------------------------------------
          WinGet, ThisPum_Id, ID , ahk_class TfrmToolbox
          WinSet, Disable,, ahk_id %ThisPum_Id%
          ; -------------------------------------------
          ; Disable the pum While (ShortcutGui)(Exist)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (Exist > Gui)
          ; (Exist > pum)
          ; (Config_Pum.ahk) if (Running) (Close)
          ; -------------------------------------------
					; (Config_Pum.ahk) keystroke definitions
          ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
          ; -------------------------------------------
          if (Script_Running(ScriptPath) > 0) ; (Config_Pum.ahk) if (Running) (Close)
          {
            ; -------------------------------------------
            Script_Close(ScriptPath)
            ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
            ; -------------------------------------------
          } ; (Config_Pum.ahk) if (Running) (Close)
          ; -------------------------------------------
          ; (Exist > Gui)
          ; (Exist > pum)
          ; (Config_Pum.ahk) if (Running) (Close)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        } ; [End] if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui)(Exist)
        else if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui) (NOT Exist)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					; (ShortcutGui)(NOT Exist)
          ; Get the pum ID
          ; Enable the pum
          ; -------------------------------------------
          WinGet, ThisPum_Id, ID , ahk_class TfrmToolbox
          WinSet, Enable,, ahk_id %ThisPum_Id%
          ; -------------------------------------------
          ; (ShortcutGui)(NOT Exist)
          ; Get the pum ID
          ; Enable the pum
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
					; -------------------------------------------
					Pum_Acitve := WinActive("ahk_class TfrmToolbox")
					; -------------------------------------------
					;
					; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					; (ShortcutGui) (NOT Exist)
					; (pum)(Exist)
					; (pum) check if (Active)
					; -------------------------------------------
					if (Pum_Acitve != "0x0") ; (pum) is (Active) | (Config_Pum.ahk) if (NOT Running) (Run Script)
					{
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ; (ShortcutGui) (NOT Exist)
            ; (pum)(Exist)
						; (pum)(Active)
            ; (Config_Pum.ahk) if (NOT Running) (Run Script)
            ; -------------------------------------------
						; (Config_Pum.ahk) keystroke definitions
            ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
            ; -------------------------------------------
            if (Script_Running(ScriptPath) == 0) ; (Config_Pum.ahk) if (NOT Running) (Run Script)
            {
              ; -------------------------------------------
							; (Config_Pum.ahk) keystroke definitions
              Run %ScriptPath%
              Sleep, 100
              ; -------------------------------------------
            } ; (Config_Pum.ahk) if (NOT Running) (Run Script)
            ; -------------------------------------------
					  ; (ShortcutGui) (NOT Exist)
            ; (pum)(Exist)
						; (pum)(Active)
            ; (Config_Pum.ahk) if (NOT Running) (Run Script)
					  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					} ; (pum) is (Active) | (Config_Pum.ahk) if (NOT Running) (Run Script)
					; -------------------------------------------
					; (ShortcutGui) (NOT Exist)
					; (pum)(Exist)
					; (pum) check if (Active)
					; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					;
					; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
					; (ShortcutGui) (NOT Exist)
					; (pum)(Exist)
					; (pum) check if (Active)
					; -------------------------------------------
          if (Pum_Acitve == "0x0") ; (pum) (NOT Active) | (Config_Pum.ahk) if (Running) (Close)
          {
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						; (pum) NOT (Active)
						; (Config_Pum.ahk) if (Running) (Close)
            ; -------------------------------------------
            Process, Close, ThisPumProcessExe ; (pum) (NOT Active)
            ; -------------------------------------------
						; (Config_Pum.ahk) keystroke definitions
            ScriptPath := "C:\Program Files\PopUpMenu_PUM\Config_Pum.ahk"
            ; -------------------------------------------
            if (Script_Running(ScriptPath) > 0) ; (Config_Pum.ahk) if (Running) (Close)
            {
              Script_Close(ScriptPath)
            } ; (Config_Pum.ahk) if (Running) (Close)
            ; -------------------------------------------
            MobileOnOff := "" ; Reset
            ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y) ; Blank Tooltip popup
            ; -------------------------------------------
						; (pum) NOT (Active)
						; (Config_Pum.ahk) if (Running) (Close)
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          } ; (pum) (NOT Active) | (Config_Pum.ahk) if (Running) (Close)
          ; -------------------------------------------
          else ; (pum) (Active)
          {
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						; (pum) NOT (Active)
						; (Config_Pum.ahk) if (Running) (Close)
						;
						; if (MobileOnOff == "")
						; [SET] Defaults (MobileTxColor), (MobileBgColor), (MobileTxSize)
						; -------------------------------------------
            if (MobileOnOff == "")
            {
              ; -------------------------------------------
              WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
              ; -------------------------------------------
              ThisPumProcessName := ThisPumProcessExe
              ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
              ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
              ; -------------------------------------------
              File_MobileText := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\ahk\mobiletext.txt"
              FileReadLine, MobileOnOff, %File_MobileText%, 1 ; (362_24)(Mobile Text [1 = On, 0 Off])
							; -------------------------------------------
              if (MobileOnOff == 1) ; 1 = On
              {
                ; -------------------------------------------
                FileReadLine, MobileTxColor, %File_MobileText%, 2 ; (362_25)(Mobile Text [Text Color (Hex)])
                FileReadLine, MobileBgColor, %File_MobileText%, 3 ; (362_26)(Mobile Text [Background Color (Hex)])
                FileReadLine, MobileTxSize, %File_MobileText%, 4 ; (362_23)(Mobile Text [Font Size, 10, 12, 14])
                ; -------------------------------------------
                if (MobileTxColor == "")
                {
                  MobileTxColor := "0x000000" ; Black
                }
                ; -------------------------------------------
                if (MobileBgColor == "")
                {
                  MobileBgColor := "0xffffff" ; White
                }
                ; -------------------------------------------
                if (MobileTxSize == "")
                {
                  MobileTxSize := "12"
                }
								; ------------------------------------------- Set Tooltip PopUp Color Defaults
              } ; [End] if (MobileOnOff == 1) ; 1 = On
              ; -------------------------------------------
            } ; [End] if (MobileOnOff == "")
            ; -------------------------------------------
						; (pum) NOT (Active)
						; (Config_Pum.ahk) if (Running) (Close)
						;
						; if (MobileOnOff == "")
						; [SET] Defaults (MobileTxColor), (MobileBgColor), (MobileTxSize)
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						;
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						; Get (ExistingShortcut), (ShortcutDescription), (GiidX), (XmlShortcutPosY)
						; from the Function (Shortcut_Description)
						; (if ExistingShortcut == 1) Display (ToolTip_Message)
						; -------------------------------------------
            if (MobileOnOff == 1) ; 1 = On, Display (ToolTip_Message)
            {
              ; -------------------------------------------
              DataArray := Shortcut_Description(DataArray) ; > [ExistingShortcut, ShortcutDescription, ShortcutColumnX, ShortcutRowY]
              ExistingShortcut    := DataArray.153.1 ; (153)(01)(Shortcut_Description_ExistingShortcut)
              ShortcutDescription := DataArray.153.2 ; (153)(02)(ShortcutDescription)
              XmlShortcutPosX     := DataArray.153.3 ; (153)(03)(XmlShortcutPosX)
              XmlShortcutPosY     := DataArray.153.4 ; (153)(04)(XmlShortcutPosY)
              ; -------------------------------------------
              ;
              ; -------------------------------------------
              if (ExistingShortcut == 1)
              {
                if (XmlShortcutPosX != ThisX or XmlShortcutPosY != ThisY)
                {
                  ThisX := XmlShortcutPosX
                  ThisY := XmlShortcutPosY
                  ToolTip_Message(ShortcutDescription, MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
                } ; [End] if (XmlShortcutPosX != ThisX or XmlShortcutPosY != ThisY)
              } ; [End] if (ExistingShortcut == 1)
              ; -------------------------------------------
              else ; (ExistingShortcut != 1) blank (ToolTip_Message)
              {
                ; ------------------------------------------- (ExistingShortcut != 1)
                ThisX := "" ; Reset
                ThisY := "" ; Reset
                ; ------------------------------------------- (ExistingShortcut != 1)
                ;
                ; -------------------------------------------
                ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
                ; -------------------------------------------
              } ; else ; (ExistingShortcut != 1) blank (ToolTip_Message)
              ; -------------------------------------------
            } ; if (MobileOnOff == 1) ; 1 = On, Display (ToolTip_Message)
            ; -------------------------------------------
            else ; (MobileOnOff != 1) blank (ToolTip_Message)
            {
              ; ------------------------------------------- if (MobileOnOff != 1) ; Off
              ThisX := "" ; Reset
              ThisY := "" ; Reset
              ; ------------------------------------------- if (MobileOnOff != 1) ; Off
              ;
              ; -------------------------------------------
              ToolTip_Message("", MobileTxColor, MobileBgColor, MobileTxSize, Warn_Icon, Which_Tip, ThisCoord, Pos_X, Pos_Y)
              ; -------------------------------------------
            } ; (MobileOnOff != 1) blank (ToolTip_Message)
            ; -------------------------------------------
  					; Get (ExistingShortcut), (ShortcutDescription), (GiidX), (XmlShortcutPosY)
						; from the Function (Shortcut_Description)
						; (if ExistingShortcut == 1) Display (ToolTip_Message)
						; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
						;
          } ; [End] (pum) (Is Active)
          ; -------------------------------------------
          ; (ShortcutGui) (NOT Exist)
					; (pum)(Exist)
					; (pum) check if (Active)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        } ; [End] else if !WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui) (NOT Exist)
        ; -------------------------------------------
      } ; [End] else if (InStr(ThisPumProcessExe, "pum_") > 0) ; (pum) (Exist)
      ; -------------------------------------------
      ; Run/Close (Config_Pum.ahk) (ToolTip_Message)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (CatPaw_Wait.ahk) AutoStart
      ; (169_2) == 2 (CatPaw AutoStart is Selected)
      ; -------------------------------------------
      ScriptPath := "C:\Program Files\PopUpMenu_PUM\CatPaw.ahk" ; (CatPaw.ahk Key Lock)
      ; -------------------------------------------
      if (Script_Running(ScriptPath) == 0) ; (CatPaw.ahk Key Lock)(NOT Running)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (FileSelectGui)(Exist)
        ; -------------------------------------------
        if WinExist("PUM -" . "ahk_class #32770") ; (if)(Exist)-(FileSelectGui)
        {
          ; -------------------------------------------(LanguageGui)
          ScriptPath := "C:\Program Files\PopUpMenu_PUM\Gui_Language.ahk"
          if (Script_Running(ScriptPath) > 0) ; (if)(Exist)-(LanguageGui)(Script_Close)
          {
            Script_Close(ScriptPath)
          }
          ; -------------------------------------------(LanguageGui)
        } ; [End] (if)(Exist)-(FileSelectGui)
        ; -------------------------------------------
        ; (FileSelectGui)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (LanguageGui)
        ; -------------------------------------------
        else if WinExist("Language_Gui" . "ahk_class AutoHotkeyGUI") ; (LanguageGui)(Exist)
        {
          ; -------------------------------------------(LanguageGui)(WinActivate)
          Window_Active := WinActive("Language_Gui" . "ahk_class AutoHotkeyGUI") ; (LanguageGui)
          ; -------------------------------------------(LanguageGui)(WinActivate)
          if (Window_Active == "0x0") ; (if)(NOT Active)-(LanguageGui)(WinActivate)
          {
            WinActivate, Language_Gui ahk_class AutoHotkeyGUI ; (LanguageGui)(WinActivate)
          } ; [End] (LanguageGui) (NOT Active)
          ; -------------------------------------------
          ;
          ; -------------------------------------------(LanguageGui)(Top)
          WinSet, Top, , Language_Gui ahk_class AutoHotkeyGUI ; (LanguageGui)(Top)
          ; -------------------------------------------(LanguageGui)(Top)
        } ; [End] (LanguageGui)(Exist)
        ; -------------------------------------------
        ; (LanguageGui)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (ShortcutGui)
        ; -------------------------------------------
        else if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui)(Exist)(Top)
        {
          ; -------------------------------------------(ShortcutGui)(WinActivate)
          Window_Active := WinActive("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; (ShortcutGui)
          ; -------------------------------------------
          if (Window_Active == "0x0") ; (if)(NOT Active)-(ShortcutGui)(WinActivate)
          {
            WinActivate, Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
          } ; [End] (ShortcutGui) (NOT Active)
          ; -------------------------------------------(ShortcutGui)(WinActivate)
          ;
          ; -------------------------------------------(ShortcutGui)(Top)
          WinSet, Top, , Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI ; (ShortcutGui)(Top)
          ; -------------------------------------------(ShortcutGui)
        } ; [End] (ShortcutGui)(Exist)
        ; -------------------------------------------
        ; (ShortcutGui)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (169_2) == 2 (is Selected) (Run) (CatPaw_Wait.ahk AutoStart)
        ; (169_2) != 2 (NOT Selected) (Close) (CatPaw_Wait.ahk AutoStart)
        ; -------------------------------------------
        if (DataArray.169.2 == 2) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (169_2) == 2 (is Selected) (Run) (CatPaw_Wait.ahk AutoStart)
          ; -------------------------------------------
          ScriptPath := "C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk" ; (CatPaw_Wait.ahk AutoStart)
          ; -------------------------------------------
          if (Script_Running(ScriptPath) == 0) ; (CatPaw_Wait.ahk AutoStart) (NOT Running)
          {
            Run, C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk
          } ; [End] (CatPaw_Wait.ahk AutoStart) (NOT Running)
          ; -------------------------------------------
          ; (169_2) == 2 (is Selected) (Run) (CatPaw_Wait.ahk AutoStart)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        } ; [End] (169_2 = 2)
        else ; (169_2) != 2 (NOT Selected) (CLOSE) (CatPaw_Wait.ahk AutoStart)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (169_2) != 2 (NOT Selected) (CLOSE) (CatPaw_Wait.ahk AutoStart)
          ; -------------------------------------------
          ScriptPath := "C:\Program Files\PopUpMenu_PUM\CatPaw_Wait.ahk" ; (CatPaw_Wait.ahk AutoStart)
          if (Script_Running(ScriptPath) > 0) ; (CatPaw_Wait.ahk) (Running)
          {
            ; -------------------------------------------
            Script_Close(ScriptPath) ; (Close) (CatPaw_Wait.ahk)
            ; -------------------------------------------
          } ; [End] (CatPaw_Wait.ahk) (Running)
          ; -------------------------------------------
          ; (169_2) != 2 (NOT Selected) (CLOSE) (CatPaw_Wait.ahk AutoStart)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        } ; [End] (169_2 != 2)
      } ; [End] (CatPaw.ahk Key Lock) (NOT Running)
      ; -------------------------------------------
      ; (CatPaw_Wait.ahk) AutoStart
      ; (169_2) == 2 (CatPaw AutoStart is Selected)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End]  if (ShortcutMoveLock == 0)
		; -------------------------------------------
  } ; [End] Load_Config_Pum: ; and CatPaw
  return
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  l_001: ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; [ScriptError = 15] (url)(No Selected URL)
        ; [ScriptError = 18] (url)(Source Not Found)
        ; [ScriptError = 19] (url)(No Internet Connection)
        ; -------------------------------------------
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1 or DataArray.366.5 == "url") ; (004_2)(Obj_ok_Sel [0,1,3])/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := f_102(DataArray.001.3, DataArray) ; (001_3)(Obj_KeyOflRunRwh_1RAppIco_Img [Image Path])/(102_1)(Obj_DisplayedIcon)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return
  l_002: ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; [ScriptError = 15] (url)(No Selected URL)
        ; [ScriptError = 18] (url)(Source Not Found)
        ; [ScriptError = 19] (url)(No Internet Connection)
        ; -------------------------------------------
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1 or DataArray.366.5 == "url") ; (004_2)(Obj_ok_Sel [0,1,3])/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := f_102(DataArray.002.3, DataArray) ; (002_3)(Obj_KeyOflRunRwh_2RAppIco_Img [Image Path])/(102_1)(Obj_DisplayedIcon)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return
  l_003: ; (003_1)(Obj_KeyOfl_3RAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_102(DataArray.003.3, DataArray) ; (003_3)(Obj_KeyOfl_3RAppIco_Img [Image Path])/(102_1)(Obj_DisplayedIcon)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return ; ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ OK
  l_004:  ; (004_1)(Obj_ok)
  {
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_004(DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      PreThisPumProcessExe := "ZZZZZZ"
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (005_1)(ORG_ScriptType)
  l_006:  ; (006_1)(Obj_ShortcutToDefaultPum)
  {
    ; -------------------------------------------
    if (DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      if (LockKeys == 0)
      {
        ; -------------------------------------------
        global LockKeys := 1
        ; -------------------------------------------
        DataArray := f_006(DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
        ; -------------------------------------------
        global LockKeys := 0
        ; -------------------------------------------
      } ; [End] if (LockKeys == 0)
      ; -------------------------------------------
    } ; [End] (ScriptType [xxx])
    ; -------------------------------------------
  }
  return
  l_008: ; (008_1)(Obj_Key_Alt)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_008(DataArray) ; (008_1)(Obj_Key_Alt)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_009: ; (009_1)(Obj_Key_AltDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_009(DataArray) ; (009_1)(Obj_Key_AltDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_010: ; (010_1)(Obj_Key_AltLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_010(DataArray) ; (010_1)(Obj_Key_AltLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_011: ; (011_1)(Obj_Key_AltRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_011(DataArray) ; (011_1)(Obj_Key_AltRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_012: ; (012_1)(Obj_Key_AltUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_012(DataArray) ; (012_1)(Obj_Key_AltUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_013: ; (013_1)(Obj_Key_CapsLock)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_013(DataArray) ; (013_1)(Obj_Key_CapsLock)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_014: ; (014_1)(Obj_Key_CtrlDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_014(DataArray) ; (014_1)(Obj_Key_CtrlDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_015: ; (015_1)(Obj_Key_CtrlLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_015(DataArray) ; (015_1)(Obj_Key_CtrlLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_016: ; (016_1)(Obj_Key_CtrlRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_016(DataArray) ; (016_1)(Obj_Key_CtrlRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_017: ; (017_1)(Obj_Key_CtrlUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_017(DataArray) ; (017_1)(Obj_Key_CtrlUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_018: ; (018_1)(Obj_Key_Enter)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_018(DataArray) ; (018_1)(Obj_Key_Enter)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_019: ; (019_1)(Obj_Key_EnterX2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_019(DataArray) ; (019_1)(Obj_Key_EnterX2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_020: ; (020_1)(Obj_Key_Esc)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_020(DataArray) ; (020_1)(Obj_Key_Esc)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_021: ; (021_1)(Obj_Key_EscX2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_021(DataArray) ; (021_1)(Obj_Key_EscX2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_022: ; (022_1)(Obj_Key_F1)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_022(DataArray) ; (022_1)(Obj_Key_F1)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_023: ; (023_1)(Obj_Key_F2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_023(DataArray) ; (023_1)(Obj_Key_F2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_024: ; (024_1)(Obj_Key_F3)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_024(DataArray) ; (024_1)(Obj_Key_F3)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_025: ; (025_1)(Obj_Key_F4)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_025(DataArray) ; (025_1)(Obj_Key_F4)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_026: ; (026_1)(Obj_Key_F5)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_026(DataArray) ; (026_1)(Obj_Key_F5)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_027: ; (027_1)(Obj_Key_F6)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_027(DataArray) ; (027_1)(Obj_Key_F6)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_028: ; (028_1)(Obj_Key_F7)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_028(DataArray) ; (028_1)(Obj_Key_F7)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_029: ; (029_1)(Obj_Key_F8)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_029(DataArray) ; (029_1)(Obj_Key_F8)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_030: ; (030_1)(Obj_Key_F9)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_030(DataArray) ; (030_1)(Obj_Key_F9)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_031: ; (031_1)(Obj_Key_F10)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_031(DataArray) ; (031_1)(Obj_Key_F10)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_032: ; (032_1)(Obj_Key_F11)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_032(DataArray) ; (032_1)(Obj_Key_F11)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_033: ; (033_1)(Obj_Key_F12)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_033(DataArray) ; (033_1)(Obj_Key_F12)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_034: ; (034_1)(Obj_Key_Numpad0)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_034(DataArray) ; (034_1)(Obj_Key_Numpad0)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_035: ; (035_1)(Obj_Key_Numpad1)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_035(DataArray) ; (035_1)(Obj_Key_Numpad1)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_036: ; (036_1)(Obj_Key_Numpad2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_036(DataArray) ; (036_1)(Obj_Key_Numpad2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_037: ; (037_1)(Obj_Key_Numpad3)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_037(DataArray) ; (037_1)(Obj_Key_Numpad3)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_038: ; (038_1)(Obj_Key_Numpad4)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_038(DataArray) ; (038_1)(Obj_Key_Numpad4)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_039: ; (039_1)(Obj_Key_Numpad5)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_039(DataArray) ; (039_1)(Obj_Key_Numpad5)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_040: ; (040_1)(Obj_Key_Numpad6)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_040(DataArray) ; (040_1)(Obj_Key_Numpad6)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_041: ; (041_1)(Obj_Key_Numpad7)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_041(DataArray) ; (041_1)(Obj_Key_Numpad7)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_042: ; (042_1)(Obj_Key_Numpad8)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_042(DataArray) ; (042_1)(Obj_Key_Numpad8)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_043: ; (043_1)(Obj_Key_Numpad9)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_043(DataArray) ; (043_1)(Obj_Key_Numpad9)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_044: ; (044_1)(Obj_Key_NumpadAdd)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_044(DataArray) ; (044_1)(Obj_Key_NumpadAdd)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_045: ; (045_1)(Obj_Key_NumpadDiv)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_045(DataArray) ; (045_1)(Obj_Key_NumpadDiv)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_046: ; (046_1)(Obj_Key_NumpadDot)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_046(DataArray) ; (046_1)(Obj_Key_NumpadDot)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_047: ; (047_1)(Obj_Key_NumpadEnter)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_047(DataArray) ; (047_1)(Obj_Key_NumpadEnter)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_048: ; (048_1)(Obj_Key_NumpadMult)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_048(DataArray) ; (048_1)(Obj_Key_NumpadMult)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_049: ; (049_1)(Obj_Key_NumpadSub)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_049(DataArray) ; (049_1)(Obj_Key_NumpadSub)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_050: ; (050_1)(Obj_Key_Shift)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_050(DataArray) ; (050_1)(Obj_Key_Shift)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_051: ; (051_1)(Obj_Key_ShiftDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_051(DataArray) ; (051_1)(Obj_Key_ShiftDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_052: ; (052_1)(Obj_Key_ShiftLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_052(DataArray) ; (052_1)(Obj_Key_ShiftLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_053: ; (053_1)(Obj_Key_ShiftRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_053(DataArray) ; (053_1)(Obj_Key_ShiftRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_054: ; (054_1)(Obj_Key_ShiftUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_054(DataArray) ; (054_1)(Obj_Key_ShiftUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_055: ; (055_1)(Obj_Key_Tab)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_055(DataArray) ; (055_1)(Obj_Key_Tab)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_056: ; (056_1)(Obj_Key_TabX2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_056(DataArray) ; (056_1)(Obj_Key_TabX2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_057: ; (057_1)(Obj_Key_Win_Sel)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_057(DataArray) ; (057_1)(Obj_Key_Win_Sel)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_058: ; (058_1)(Obj_Key_WinDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_058(DataArray) ; (058_1)(Obj_Key_WinDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_059: ; (059_1)(Obj_Key_WinLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_059(DataArray) ; (059_1)(Obj_Key_WinLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_060: ; (060_1)(Obj_Key_WinRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_060(DataArray) ; (060_1)(Obj_Key_WinRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_061: ; (061_1)(Obj_Key_WinUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_061(DataArray) ; (061_1)(Obj_Key_WinUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ CANCEL
  l_062: ; (062_1)(Obj_Cancel)
  {
    ; -------------------------------------------
    DataArray := f_062(DataArray) ; (062_1)(Obj_Cancel)
    ; -------------------------------------------
  }
  return
  l_063: ; (063_1)(Obj_SelectIconImage)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
      {
        ; -------------------------------------------
        if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("063", 2, 1, DataArray) ; (063_1)(Obj_SelectIconImage)
        }
        ; -------------------------------------------
        DataArray := f_063(DataArray) ; (063_1)(Obj_SelectIconImage)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (064)(Not Used)
  l_068: ; (068_1)(Obj_RwhUrl_OpenWith)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_068(DataArray) ; (068_1)(Obj_RwhUrl_OpenWith)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_069: ; (069_1)(Obj_RwhUrl_OpenWithReset)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_069(DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_070: ; (070_1)(Obj_Cpl_WinControl)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_070(DataArray) ; (070_1)(Obj_Cpl_WinControl)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_071: ; (071_1)(Obj_URL)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_071(DataArray) ; (071_1)(Obj_URL)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_072: ; (072_1)(Obj_Key_AppOnly)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_072(DataArray) ; (072_1)(Obj_Key_AppOnly)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_073: ; (073_1)(Obj_Run_AsAdmin)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_073(DataArray) ; (073_1)(Obj_Run_AsAdmin)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_074: ; (074_1)(Obj_Key_Ctrl)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_074(DataArray) ; (074_1)(Obj_Key_Ctrl)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_075: ; (075_1)(Obj_Key_Delete)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_075(DataArray) ; (075_1)(Obj_Key_Delete)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_076: ; (076_1)(Obj_Key_End)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_076(DataArray) ; (076_1)(Obj_Key_End)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_077: ; (077_1)(Obj_Key_Home)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_077(DataArray) ; (077_1)(Obj_Key_Home)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_078: ; (078_1)(Obj_Key_Insert)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_078(DataArray) ; (078_1)(Obj_Key_Insert)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_079: ; (079_1)(Obj_Key_PgDn)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_079(DataArray) ; (079_1)(Obj_Key_PgDn)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_080: ; (080_1)(Obj_Key_PgUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_080(DataArray) ; (080_1)(Obj_Key_PgUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_081: ; (081_1)(Obj_RunRwh_File)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_081(DataArray) ; (081_1)(Obj_RunRwh_File)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_082: ; (082_1)(Obj_Ofl_Folder)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_082(DataArray) ; (082_1)(Obj_Ofl_Folder)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_083: ; (083_1)(Obj_Tom_Pum)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_083(DataArray) ; (083_1)(Obj_Tom_Pum)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_084: ; (084_1)(Obj_Tom_FileUrlFolder)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_084(DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_085: ; (085_1)(Obj_Key_Keyboard)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_085(DataArray) ; (085_1)(Obj_Key_Keyboard)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_086: ; (086_1)(Obj_Tom_MenuControlKey)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_086(DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_087: ; (087_1)(Obj_Mnu_Menu)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_087(DataArray) ; (087_1)(Obj_Mnu_Menu)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_088: ; (088_1)(Obj_Mnu_AppMenu1)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_088(DataArray) ; (088_1)(Obj_Mnu_AppMenu1)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_089: ; (089_1)(Obj_Mnu_AppMenu2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_089(DataArray) ; (089_1)(Obj_Mnu_AppMenu2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_090: ; (090_1)(Obj_Mnu_AppMenu3)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_090(DataArray) ; (090_1)(Obj_Mnu_AppMenu3)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_091: ; (091_1)(Obj_Mnu_AppMenu4)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_091(DataArray) ; (091_1)(Obj_Mnu_AppMenu4)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_092: ; (092_1)(Obj_Mnu_AppMenu5)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_092(DataArray) ; (092_1)(Obj_Mnu_AppMenu5)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_093: ; (093_1)(Obj_Mnu_AppMenu6)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_093(DataArray) ; (093_1)(Obj_Mnu_AppMenu6)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_094: ; (094_1)(Obj_Mnu_AppMenu7)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_094(DataArray) ; (094_1)(Obj_Mnu_AppMenu7)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_095: ; (095_1)(Obj_Mnu_AppMenu8)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_095(DataArray) ; (095_1)(Obj_Mnu_AppMenu8)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_096: ; (096_1)(Obj_Mnu_AppMenu9)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_096(DataArray) ; (096_1)(Obj_Mnu_AppMenu9)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_097: ; (097_1)(Obj_Mnu_AppMenu10)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_097(DataArray) ; (097_1)(Obj_Mnu_AppMenu10)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_098: ; (098_1)(Obj_Mnu_AppMenu11)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_098(DataArray) ; (098_1)(Obj_Mnu_AppMenu11)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_099: ; (099_1)(Obj_PopUpMenuWebLink)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      f_099() ; (099_1)(Obj_PopUpMenuWebLink)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_106: ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_106(DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_108: ; (108_1)(Obj_Url_SameNewTab)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.307.9 == "") ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray.307.9 := 1 ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        }
        ; -------------------------------------------
        if (DataArray.307.9 == 1) ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray.307.9 := 2 ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        }
        else if (DataArray.307.9 == 2) ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray.307.9 := 1 ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("108", DataArray.307.9, 1, DataArray) ; (108_1)(Obj_Url_SameNewTab)/(307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        ; -------------------------------------------
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_109: ; (109_1)(Obj_CatPaw)
  {
    ; -------------------------------------------
    if (DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      if (LockKeys == 0)
      {
        ; -------------------------------------------
        global LockKeys := 1
        ; -------------------------------------------
        DataArray := f_109(DataArray) ; (109_1)(Obj_CatPaw)
        ; -------------------------------------------
        global LockKeys := 0
        ; -------------------------------------------
      } ; [End] if (LockKeys == 0)
      ; -------------------------------------------
    } ; [End] (ScriptType [xxx])
    ; -------------------------------------------
  }
  return
  l_101: ; (101_1)(Obj_LangFlag)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray.365.5 := DataArray.365.2 ; (365_5)(UserOldLang [Old User language])/(365_2)(UserLang [Current User language])
      ; -------------------------------------------
      DataArray := f_101(DataArray) ; (101_1)(Obj_LangFlag)
      ; -------------------------------------------
      { ; Tray Icon Menu
        ; -------------------------------------------
        { ; (365_5)(Old User language)
          ; -------------------------------------------
          if (DataArray.365.5 == "de") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "HotKey, Direkter Zugang"
            Old_MenuText_Exit := "Schließen Sie PopUpMenu"
          }
          else if (DataArray.365.5 == "en") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "HotKey, Direct Access"
            Old_MenuText_Exit := "Close PopUpMenu"
          }
          else if (DataArray.365.5 == "es") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Tecla Caliente, Acceso Directo"
            Old_MenuText_Exit := "Cerrar PopUpMenu"
          }
          else if (DataArray.365.5 == "fr") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Clé Chaude, Accès Direct"
            Old_MenuText_Exit := "Fermer PopUpMenu"
          }
          else if (DataArray.365.5 == "it") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Chiave Calda, Accesso Diretto"
            Old_MenuText_Exit := "Chiudi PopUpMenu"
          }
          else if (DataArray.365.5 == "pl") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Gorący Klucz, Dostęp Bezpośredni"
            Old_MenuText_Exit := "Zamknij PopUpMenu"
          }
          else if (DataArray.365.5 == "pt") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Chave Quente, Acesso Direto"
            Old_MenuText_Exit := "Feche PopUpMenu"
          }
          else if (DataArray.365.5 == "ru") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Горячая клавиша, Прямой Доступ"
            Old_MenuText_Exit := "Закрыть PopUpMenu"
          }
          else if (DataArray.365.5 == "sv") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Heta Nyckeln, Direktåtkomst"
            Old_MenuText_Exit := "Stäng PopUpMenu"
          }
          else if (DataArray.365.5 == "tr") ; (365_5)(UserOldLang [Old User language])
          {
            Old_MenuText_HotKey := "Sıcak Anahtar, Doğrudan Erişim"
            Old_MenuText_Exit := "Kapat PopUpMenu"
          }
          ; -------------------------------------------
        } ; (365_5)(Old User language)
        ; -------------------------------------------
        { ; (365_2)(Current User language)
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "HotKey, Direkter Zugang"
            MenuText_Exit := "Schließen Sie PopUpMenu"
          }
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "HotKey, Direct Access"
            MenuText_Exit := "Close PopUpMenu"
          }
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Tecla Caliente, Acceso Directo"
            MenuText_Exit := "Cerrar PopUpMenu"
          }
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Clé Chaude, Accès Direct"
            MenuText_Exit := "Fermer PopUpMenu"
          }
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Chiave Calda, Accesso Diretto"
            MenuText_Exit := "Chiudi PopUpMenu"
          }
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Gorący Klucz, Dostęp Bezpośredni"
            MenuText_Exit := "Zamknij PopUpMenu"
          }
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Chave Quente, Acesso Direto"
            MenuText_Exit := "Feche PopUpMenu"
          }
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Горячая клавиша, Прямой Доступ"
            MenuText_Exit := "Закрыть PopUpMenu"
          }
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Heta Nyckeln, Direktåtkomst"
            MenuText_Exit := "Stäng PopUpMenu"
          }
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            MenuText_HotKey := "Sıcak Anahtar, Doğrudan Erişim"
            MenuText_Exit := "Kapat PopUpMenu"
          }
          ; -------------------------------------------
        } ; (365_2)(Current User language)
        ; -------------------------------------------
        Image_TrayExit   := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_TrayExit.png"
        Image_TrayHotkey := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_TrayHotkey.png"
        Image_LogoPng    := "C:\Program Files\PopUpMenu_PUM\image\gui\Image_LogoPng.png"
        Menu, Tray, DeleteAll
        Sleep, 1
        Menu, Tray, NoStandard
        Menu, Tray, Add,     %MenuText_HotKey%, Label_SetHotkey
        Menu, Tray, Add,     %MenuText_Exit%, Label_Exit
        Menu, Tray, Icon,    %MenuText_HotKey%, %Image_TrayHotkey%
        Menu, Tray, Icon,    %MenuText_Exit%, %Image_TrayExit%
        Menu, Tray, Icon,    %Image_LogoPng%
        ; -------------------------------------------
      } ; [End] Tray Icon Menu
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; (101_1)(Obj_LangFlag)
  return  
  l_116: ; (116_1)(Obj_CplMnu_List100)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_116(DataArray) ; (116_1)(Obj_CplMnu_List100)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_117: ; (117_1)(Obj_CplMnu_ListRight60)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_117(DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_118: ; (118_1)(Obj_CplMnu_ListLeft30)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_118(DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (119) (Not Used)
  l_120: ; (120_1)(Obj_CplMnu_ListCenter30)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_120(DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_121: ; (121_1)(Obj_CplMnu_ListRight30)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_121(DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (122) (01)(GUI Object: <Edit Feild> Status Bar Description)
  l_123: ; (123_1)(Obj_Key_EditFeild_TextInput)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_123(DataArray) ; (123_1)(Obj_Key_EditFeild_TextInput)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_125: ; (125_1)(Obj_Cpl_Menu1)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_125(DataArray) ; (125_1)(Obj_Cpl_Menu1)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_126: ; (126_1)(Obj_Cpl_Menu2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_126(DataArray) ; (126_1)(Obj_Cpl_Menu2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_127: ; (127_1)(Obj_Cpl_Menu3)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_127(DataArray) ; (127_1)(Obj_Cpl_Menu3)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_128: ; (128_1)(Obj_Cpl_Menu4)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_128(DataArray) ; (128_1)(Obj_Cpl_Menu4)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_129: ; (129_1)(Obj_Cpl_Menu5)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_129(DataArray) ; (129_1)(Obj_Cpl_Menu5)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_130: ; (130_1)(Obj_Cpl_Menu6)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_130(DataArray) ; (130_1)(Obj_Cpl_Menu6)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (131)(132)(Empty)
  l_133: ; (133_1)(Obj_DeleteShortcut)
  {
    if (LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_133(DataArray) ; (133_1)(Obj_DeleteShortcut)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  }
  return
  l_134: ; (134_1)(Obj_ImageSelect1)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_134(DataArray) ; (134_1)(Obj_ImageSelect1)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_135: ; (135_1)(Obj_ImageSelect2)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_135(DataArray) ; (135_1)(Obj_ImageSelect2)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_136: ; (136_1)(Obj_ImageSelect3)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_136(DataArray) ; (136_1)(Obj_ImageSelect3)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_137: ; (137_1)(Obj_MsgImg480x270)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_137(DataArray) ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_138: ; (138_1)(Obj_Cpl_Menu7)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_138(DataArray) ; (138_1)(Obj_Cpl_Menu7)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_139: ; (139_1)(Obj_Cpl_Menu8)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_139(DataArray) ; (139_1)(Obj_Cpl_Menu8)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_140: ; (140_1)(Obj_Mnu_AddonExtra)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_140(DataArray) ; (140_1)(Obj_Mnu_AddonExtra)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_154: ; (154_1)(Obj_Pum_BgImage)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_154(DataArray) ; (154_1)(Obj_Pum_BgImage)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_155: ; (155_1)(Obj_Pum_BgText)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_155(DataArray) ; (155_1)(Obj_Pum_BgText)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_156: ; (156_1)(Obj_Pum_BgDim)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_156(DataArray) ; (156_1)(Obj_Pum_BgDim)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_157: ; (157_1)(Obj_Pum_Setting)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_157(DataArray) ; (157_1)(Obj_Pum_Setting)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (158)(Not Used)
  l_159: ; (159_1)(Obj_Pum_Contact)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_159(DataArray) ; (159_1)(Obj_Pum_Contact)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_160: ; (160_1)(Obj_Pum_App))
  {
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_160(DataArray) ; (160_1)(Obj_Pum_App))
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  } ; End (160)([pum] [pumApplication])
  return ; ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ PUM DELETE
  l_161: ; (161_1)(Obj_Pum_Del)
  {
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && LockKeys == 0)
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_161(DataArray) ; (161_1)(Obj_Pum_Del)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  } ; End (160)([pum] [pumApplication])
  return
  l_162: ; (162)(Obj_Pum_Backup)
  {
    if (DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_162(DataArray) ; (162)(Obj_Pum_Backup)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  } ; (162)(Obj_Pum_Backup)
  return
  l_163: ; (163)(Obj_Pum_Restore)
  {
    if (DataArray.162.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_163(DataArray) ; (163)(Obj_Pum_Restore)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
  } ; (163)(Obj_Pum_Restore)
  return  
  l_164: ; (164_1)(Obj_Pum_BgTxtImg)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_164(DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_165: ; (165_1)(Obj_Pum_BgImageSelect)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_165(DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_166: ; (166_1)(Obj_Pum_BgColor)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_166(DataArray) ; (166_1)(Obj_Pum_BgColor)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_167: ; (167_1)(Obj_Pum_BgFitImage)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_167(DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (168) (Not Used)
  l_169: ; (169_1)(Obj_CatPawAutoStart)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.169.2 == "1") ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
        ; -------------------------------------------
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; -------------------------------------------
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        DataArray := Image_GuiControl("169", 2, 1, DataArray) ; (169_1)(Obj_CatPawAutoStart)
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minute|2 Minuten|3 Minuten|4 Minuten|5 Minuten" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minute|2 Minutes|3 Minutes|4 Minutes|5 Minutes" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minuto|2 Minutos|3 Minutos|4 Minutos|5 Minutos" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minute|2 Minutes|3 Minutes|4 Minutes|5 Minutes" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minuto|2 Minuti|3 Minuti|4 Minuti|5 Minuti" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minuta|2 Minuty|3 Minuty|4 Minuty|5 Minuty" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minuto|2 Minutos|3 Minutos|4 Minutos|5 Minutos" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Минута|2 Минуты|3 Минуты|4 Минуты|5 Минуты" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Minut|2 Minuter|3 Minuter|4 Minuter|5 Minuter" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          CatPawListBox := "|1 Dakika|2 Dakika|3 Dakika|4 Dakika|5 Dakika" ; (170_3)(Obj_CatPawDropDown [List Box])
        }
        ; -------------------------------------------
        DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
        GuiControl, PopUpMenu:, g_170, %CatPawListBox% ; (170_1)(Obj_CatPawDropDown)
        ; -------------------------------------------
        CatPawTime := DataArray.170.2 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
        ; -------------------------------------------
        if (CatPawTime == "")
        {
          CatPawTime := 1
          DataArray.170.2 := CatPawTime ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
        }
        ; -------------------------------------------
        GuiControl, PopUpMenu:Choose, g_170, %CatPawTime% ; (170_1)(Obj_CatPawDropDown)
        GuiControl, PopUpMenu:Show, g_170 ; (170_1)(Obj_CatPawDropDown)
        ; -------------------------------------------
      } ; (169_2)(Obj_CatPawAutoStart_Sel [0,1,2,3])
      else if (DataArray.169.2 == "2") ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
        ; -------------------------------------------
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; -------------------------------------------
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        DataArray := Image_GuiControl("169", 1, 1, DataArray) ; (169_1)(Obj_CatPawAutoStart)
        DataArray := Image_GuiControl("170", 0, 0, DataArray) ; (170_1)(Obj_CatPawDropDown)
        ; -------------------------------------------
      } ; (169_2)(Obj_CatPawAutoStart_Sel [0,1,2,3])
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_170: ; (170_1)(Obj_CatPawDropDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
      ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
      ; -------------------------------------------
      GuiControlGet, CatPawTime, PopUpMenu:, g_170 ; (170_1)(Obj_CatPawDropDown)
      ; -------------------------------------------
      if (InStr(CatPawTime, "1") > 0)
      {
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        CatPawTime := 1
      }
      else if (InStr(CatPawTime, "2") > 0)
      {
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        CatPawTime := 2
      }
      else if (InStr(CatPawTime, "3") > 0)
      {
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        CatPawTime := 3
      }
      else if (InStr(CatPawTime, "4") > 0)
      {
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        CatPawTime := 4
      }
      else if (InStr(CatPawTime, "5") > 0)
      {
        DataArray.366.5 := "CatPaw" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        CatPawTime := 5
      }
      ; -------------------------------------------
      DataArray.170.2 := CatPawTime ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
      ; -------------------------------------------
     global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (171) (Not Used)
  l_172: ; (172_1)(Obj_Pum_MobileText)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_172(DataArray) ; (172_1)(Obj_Pum_MobileText)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_173: ; (173_1)(Obj_Pum_MobileTxtColor)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_173(DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_174: ; (174_1)(Obj_Pum_MobileBgColor)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_174(DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_178: ; (178_1)(Obj_Pum_BgOpacityUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_178(DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_179: ; (179_1)(Obj_Pum_BgOpacityDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_179(DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  PreventFunctionError := 1
  { ; Color Table
    ; -------------------------------------------
    l_191: ; (191_1)(Obj_Pum_ColorA1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_192: ; (192_1)(Obj_Pum_ColorA2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_193: ; (193_1)(Obj_Pum_ColorA3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_194: ; (194_1)(Obj_Pum_ColorA4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_195: ; (195_1)(Obj_Pum_ColorA5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_196: ; (196_1)(Obj_Pum_ColorA6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("A6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_197: ; (197_1)(Obj_Pum_ColorB1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_198: ; (198_1)(Obj_Pum_ColorB2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_199: ; (199_1)(Obj_Pum_ColorB3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_200: ; (200_1)(Obj_Pum_ColorB4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_201: ; (201_1)(Obj_Pum_ColorB5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_202: ; (202_1)(Obj_Pum_ColorB6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("B6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_203: ; (203_1)(Obj_Pum_ColorC1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_204: ; (204_1)(Obj_Pum_ColorC2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_205: ; (205_1)(Obj_Pum_ColorC3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_206: ; (206_1)(Obj_Pum_ColorC4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_207: ; (207_1)(Obj_Pum_ColorC5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_208: ; (208_1)(Obj_Pum_ColorC6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("C6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_209: ; (209_1)(Obj_Pum_ColorD1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_210: ; (210_1)(Obj_Pum_ColorD2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_211: ; (211_1)(Obj_Pum_ColorD3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_212: ; (212_1)(Obj_Pum_ColorD4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_213: ; (213_1)(Obj_Pum_ColorD5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_214: ; (214_1)(Obj_Pum_ColorD6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("D6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_215: ; (215_1)(Obj_Pum_ColorE1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_216: ; (216_1)(Obj_Pum_ColorE2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_217: ; (217_1)(Obj_Pum_ColorE3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_218: ; (218_1)(Obj_Pum_ColorE4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_219: ; (219_1)(Obj_Pum_ColorE5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_220: ; (220_1)(Obj_Pum_ColorE6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("E6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_221: ; (221_1)(Obj_Pum_ColorF1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_222: ; (222_1)(Obj_Pum_ColorF2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_223: ; (223_1)(Obj_Pum_ColorF3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_224: ; (224_1)(Obj_Pum_ColorF4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_225: ; (225_1)(Obj_Pum_ColorF5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_226: ; (226_1)(Obj_Pum_ColorF6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("F6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_227: ; (227_1)(Obj_Pum_ColorG1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_228: ; (228_1)(Obj_Pum_ColorG2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_229: ; (229_1)(Obj_Pum_ColorG3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_230: ; (230_1)(Obj_Pum_ColorG4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_231: ; (231_1)(Obj_Pum_ColorG5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_232: ; (232_1)(Obj_Pum_ColorG6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("G6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_233: ; (233_1)(Obj_Pum_ColorH1)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H1", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_234: ; (234_1)(Obj_Pum_ColorH2)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H2", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_235: ; (235_1)(Obj_Pum_ColorH3)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H3", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_236: ; (236_1)(Obj_Pum_ColorH4)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H4", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_237: ; (237_1)(Obj_Pum_ColorH5)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H5", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    l_238: ; (238_1)(Obj_Pum_ColorH6)
    {
      ; -------------------------------------------
      DataArray := pum_ColorSelect("H6", DataArray) ; > DataArray
      ; -------------------------------------------
    }
    return
    ; -------------------------------------------
  } ; End Color Table
  ; -------------------------------------------
  l_182: ; (182_1)(Obj_Pum_BgRotateLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_182(DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_183: ; (183_1)(Obj_Pum_BgRotateRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_183(DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_188: ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_188(DataArray) ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_189: ; (189_1)(Obj_Pum_EditFeild_ContactName)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_189(DataArray) ; (189_1)(Obj_Pum_EditFeild_ContactName)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_190: ; (190_1)(Obj_Pum_EditFeild_EmailBody)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_190(DataArray) ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_241: ; (241_1)(Obj_Pum_CropLeft)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_241(DataArray) ; (241_1)(Obj_Pum_CropLeft)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_242: ; (242_1)(Obj_Pum_CropRight)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_242(DataArray) ; (242_1)(Obj_Pum_CropRight)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_243: ; (243_1)(Obj_Pum_CropUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_243(DataArray) ; (243_1)(Obj_Pum_CropUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_244: ; (244_1)(Obj_Pum_CropDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_244(DataArray) ; (244_1)(Obj_Pum_CropDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_245: ; (245_1)(Obj_Pum_CropCenter)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_245(DataArray) ; (245_1)(Obj_Pum_CropCenter)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_246: ; (246_1)(Obj_Pum_ZoomIn)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_246(DataArray) ; (246_1)(Obj_Pum_ZoomIn)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_247: ; (247_1)(Obj_Pum_ZoomOut)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_247(DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_248: ; (248_1)(Obj_Ofl_1LAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_248(DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return
  l_249: ; (249_1)(Obj_Ofl_2LAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_249(DataArray) ; (249_1)(Obj_Ofl_2LAppIco)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return
  l_250: ; (250_1)(Obj_Ofl_3LAppIco)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_250(DataArray) ; (250_1)(Obj_Ofl_3LAppIco)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
    GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
  }
  return
  l_251: ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := f_251(DataArray) ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
          }
        }
      }
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_261: ; (261_1)(Obj_Pum_IconUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_261(DataArray) ; (261_1)(Obj_Pum_IconUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_262: ; (262_1)(Obj_Pum_IconDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_262(DataArray) ; (262_1)(Obj_Pum_IconDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (263)[pumDimension] <Display Text> Icon Size), (264)-(265)((Not Used), (266)([pumDimension] [Edit Feild] PumRow_Edit)
  l_267: ; (267_1)(Obj_Pum_PumRowUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_267(DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_268: ; (268_1)(Obj_Pum_PumRowDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_268(DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (269)[pumDimension] <Display Text> Vertical), (270)-(271)(Not Used) 272)([pumDimension] <Edit Feild> PumColumn_Edit)
  l_273: ; (273_1)(Obj_Pum_PumColumnUp)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_273(DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  l_274: ; (274_1)(Obj_Pum_PumColumnDown)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_274(DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (275)(GUI Object: [pumDimension] <Display Text> Horizontal)
  l_290: ; (290)(Obj_BrowserPum)
  {
    ; -------------------------------------------
    if (DataArray.162.2 != 2 && DataArray.163.2 != 2 && DataArray.133.2 != 2 && DataArray.161.2 != 2 && LockKeys == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(161_2)(Obj_Pum_Del_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      global LockKeys := 1
      ; -------------------------------------------
      DataArray := f_290(DataArray) ; (290)(Obj_BrowserPum)
      ; -------------------------------------------
      global LockKeys := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  GuiClose: ; (062_1)(GUI Object: Cancel)
  {
    ; -------------------------------------------
    DataArray := f_062(DataArray) ; (062_1)(Obj_Cancel)
    ; -------------------------------------------
  }
  return
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; End Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
PreventFunctionError := 1
{ ; [Gui] [INCLUDE]
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\XmlWrite.ahk
  #Include C:\Program Files\PopUpMenu_PUM\FixXmlArray.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\XmlValidate.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Pum_MoveShortcut.ahk
  #Include C:\Program Files\PopUpMenu_PUM\GetCurrentWallpaper.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\CloseProcess.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\MsgToFile.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Pum_Kill.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Script_Running.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Pum_GridCheck.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Pum_FileDelete.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\ToolTip_Message.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Shortcut_Description.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Img_OflIco.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Img_RunIco.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Img_RwhIco.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Img_Error440.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Img_Error450.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Img_Error460.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Img_Error470.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\_S1_C.ahk
  #Include C:\Program Files\PopUpMenu_PUM\_S2_H.ahk
  #Include C:\Program Files\PopUpMenu_PUM\_S3_S.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Array_ReplaceItem.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Array_ItemExist.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\CplMnu_MenuArray.ahk
  #Include C:\Program Files\PopUpMenu_PUM\MenuSize.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Image_GuiControl.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Pum_Close.ahk
  #Include C:\Program Files\PopUpMenu_PUM\pum_ColorSelect.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Pum_Run.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Sys_ResetDataArray.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Script_Close.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Shortcut_Info.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Shortcut_LButton.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Shortcut_RButton.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Splash_Script.ahk
  #Include C:\Program Files\PopUpMenu_PUM\Sys_DataArray.ahk
  ; -------------------------------------------
  #Include C:\Program Files\PopUpMenu_PUM\Url_GetUrl.ahk
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  #Include C:\Program Files\PopUpMenu_PUM\f_004.ahk ; (004_1)(Obj_ok)
  #Include C:\Program Files\PopUpMenu_PUM\f_006.ahk ; (006_1)(Obj_ShortcutToDefaultPum)
  #Include C:\Program Files\PopUpMenu_PUM\f_008.ahk ; (008_1)(Obj_Key_Alt)
  #Include C:\Program Files\PopUpMenu_PUM\f_009.ahk ; (009_1)(Obj_Key_AltDown)
  #Include C:\Program Files\PopUpMenu_PUM\f_010.ahk ; (010_1)(Obj_Key_AltLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_011.ahk ; (011_1)(Obj_Key_AltRight)
  #Include C:\Program Files\PopUpMenu_PUM\f_012.ahk ; (012_1)(Obj_Key_AltUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_013.ahk ; (013_1)(Obj_Key_CapsLock)
  #Include C:\Program Files\PopUpMenu_PUM\f_014.ahk ; (014_1)(Obj_Key_CtrlDown)
  #Include C:\Program Files\PopUpMenu_PUM\f_015.ahk ; (015_1)(Obj_Key_CtrlLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_016.ahk ; (016_1)(Obj_Key_CtrlRight)
  #Include C:\Program Files\PopUpMenu_PUM\f_017.ahk ; (017_1)(Obj_Key_CtrlUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_018.ahk ; (018_1)(Obj_Key_Enter)
  #Include C:\Program Files\PopUpMenu_PUM\f_019.ahk ; (019_1)(Obj_Key_EnterX2)
  #Include C:\Program Files\PopUpMenu_PUM\f_020.ahk ; (020_1)(Obj_Key_Esc)
  #Include C:\Program Files\PopUpMenu_PUM\f_021.ahk ; (021_1)(Obj_Key_EscX2)
  #Include C:\Program Files\PopUpMenu_PUM\f_022.ahk ; (022_1)(Obj_Key_F1)
  #Include C:\Program Files\PopUpMenu_PUM\f_023.ahk ; (023_1)(Obj_Key_F2)
  #Include C:\Program Files\PopUpMenu_PUM\f_024.ahk ; (024_1)(Obj_Key_F3)
  #Include C:\Program Files\PopUpMenu_PUM\f_025.ahk ; (025_1)(Obj_Key_F4)
  #Include C:\Program Files\PopUpMenu_PUM\f_026.ahk ; (026_1)(Obj_Key_F5)
  #Include C:\Program Files\PopUpMenu_PUM\f_027.ahk ; (027_1)(Obj_Key_F6)
  #Include C:\Program Files\PopUpMenu_PUM\f_028.ahk ; (028_1)(Obj_Key_F7)
  #Include C:\Program Files\PopUpMenu_PUM\f_029.ahk ; (029_1)(Obj_Key_F8)
  #Include C:\Program Files\PopUpMenu_PUM\f_030.ahk ; (030_1)(Obj_Key_F9)
  #Include C:\Program Files\PopUpMenu_PUM\f_031.ahk ; (031_1)(Obj_Key_F10)
  #Include C:\Program Files\PopUpMenu_PUM\f_032.ahk ; (032_1)(Obj_Key_F11)
  #Include C:\Program Files\PopUpMenu_PUM\f_033.ahk ; (033_1)(Obj_Key_F12)
  #Include C:\Program Files\PopUpMenu_PUM\f_034.ahk ; (034_1)(Obj_Key_Numpad0)
  #Include C:\Program Files\PopUpMenu_PUM\f_035.ahk ; (035_1)(Obj_Key_Numpad1)
  #Include C:\Program Files\PopUpMenu_PUM\f_036.ahk ; (036_1)(Obj_Key_Numpad2)
  #Include C:\Program Files\PopUpMenu_PUM\f_037.ahk ; (037_1)(Obj_Key_Numpad3)
  #Include C:\Program Files\PopUpMenu_PUM\f_038.ahk ; (038_1)(Obj_Key_Numpad4)
  #Include C:\Program Files\PopUpMenu_PUM\f_039.ahk ; (039_1)(Obj_Key_Numpad5)
  #Include C:\Program Files\PopUpMenu_PUM\f_040.ahk ; (040_1)(Obj_Key_Numpad6)
  #Include C:\Program Files\PopUpMenu_PUM\f_041.ahk ; (041_1)(Obj_Key_Numpad7)
  #Include C:\Program Files\PopUpMenu_PUM\f_042.ahk ; (042_1)(Obj_Key_Numpad8)
  #Include C:\Program Files\PopUpMenu_PUM\f_043.ahk ; (043_1)(Obj_Key_Numpad9)
  #Include C:\Program Files\PopUpMenu_PUM\f_044.ahk ; (044_1)(Obj_Key_NumpadAdd)
  #Include C:\Program Files\PopUpMenu_PUM\f_045.ahk ; (045_1)(Obj_Key_NumpadDiv)
  #Include C:\Program Files\PopUpMenu_PUM\f_046.ahk ; (046_1)(Obj_Key_NumpadDot)
  #Include C:\Program Files\PopUpMenu_PUM\f_047.ahk ; (047_1)(Obj_Key_NumpadEnter)
  #Include C:\Program Files\PopUpMenu_PUM\f_048.ahk ; (048_1)(Obj_Key_NumpadMult)
  #Include C:\Program Files\PopUpMenu_PUM\f_049.ahk ; (049_1)(Obj_Key_NumpadSub)
  #Include C:\Program Files\PopUpMenu_PUM\f_050.ahk ; (050_1)(Obj_Key_Shift)
  #Include C:\Program Files\PopUpMenu_PUM\f_051.ahk ; (051_1)(Obj_Key_ShiftDown)
  #Include C:\Program Files\PopUpMenu_PUM\f_052.ahk ; (052_1)(Obj_Key_ShiftLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_053.ahk ; (053_1)(Obj_Key_ShiftRight)
  #Include C:\Program Files\PopUpMenu_PUM\f_054.ahk ; (054_1)(Obj_Key_ShiftUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_055.ahk ; (055_1)(Obj_Key_Tab)
  #Include C:\Program Files\PopUpMenu_PUM\f_056.ahk ; (056_1)(Obj_Key_TabX2)
  #Include C:\Program Files\PopUpMenu_PUM\f_057.ahk ; (057_1)(Obj_Key_Win_Sel)
  #Include C:\Program Files\PopUpMenu_PUM\f_058.ahk ; (058_1)(Obj_Key_WinDown)
  #Include C:\Program Files\PopUpMenu_PUM\f_059.ahk ; (059_1)(Obj_Key_WinLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_060.ahk ; (060_1)(Obj_Key_WinRight)
  #Include C:\Program Files\PopUpMenu_PUM\f_061.ahk ; (061_1)(Obj_Key_WinUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_062.ahk ; (062_1)(Obj_Cancel)
  #Include C:\Program Files\PopUpMenu_PUM\f_063.ahk ; (063_1)(Obj_SelectIconImage)
  ; (064_1)(Empty)
  ; (065_1)(Obj_ImageText_StatusBar)
  ; (066_1)(Obj_Key_ImageText_TextInput)
  ; (067_1)(Obj_Key_ImageText_NumericKeypad)
  #Include C:\Program Files\PopUpMenu_PUM\f_068.ahk ; (068_1)(Obj_RwhUrl_OpenWith)
  #Include C:\Program Files\PopUpMenu_PUM\f_069.ahk ; (069_1)(Obj_RwhUrl_OpenWithReset)
  #Include C:\Program Files\PopUpMenu_PUM\f_070.ahk ; (070_1)(Obj_Cpl_WinControl)
  #Include C:\Program Files\PopUpMenu_PUM\f_071.ahk ; (071_1)(Obj_URL)
  #Include C:\Program Files\PopUpMenu_PUM\f_072.ahk ; (072_1)(Obj_Key_AppOnly)
  #Include C:\Program Files\PopUpMenu_PUM\f_073.ahk ; (073_1)(Obj_Run_AsAdmin)
  #Include C:\Program Files\PopUpMenu_PUM\f_074.ahk ; (074_1)(Obj_Key_Ctrl)
  #Include C:\Program Files\PopUpMenu_PUM\f_075.ahk ; (075_1)(Obj_Key_Delete)
  #Include C:\Program Files\PopUpMenu_PUM\f_076.ahk ; (076_1)(Obj_Key_End)
  #Include C:\Program Files\PopUpMenu_PUM\f_077.ahk ; (077_1)(Obj_Key_Home)
  #Include C:\Program Files\PopUpMenu_PUM\f_078.ahk ; (078_1)(Obj_Key_Insert)
  #Include C:\Program Files\PopUpMenu_PUM\f_079.ahk ; (079_1)(Obj_Key_PgDn)
  #Include C:\Program Files\PopUpMenu_PUM\f_080.ahk ; (080_1)(Obj_Key_PgUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_081.ahk ; (081_1)(Obj_RunRwh_File)
  #Include C:\Program Files\PopUpMenu_PUM\f_082.ahk ; (082_1)(Obj_Ofl_Folder)
  #Include C:\Program Files\PopUpMenu_PUM\f_083.ahk ; (083_1)(Obj_Tom_Pum)
  #Include C:\Program Files\PopUpMenu_PUM\f_084.ahk ; (084_1)(Obj_Tom_FileUrlFolder)
  #Include C:\Program Files\PopUpMenu_PUM\f_085.ahk ; (085_1)(Obj_Key_Keyboard)
  #Include C:\Program Files\PopUpMenu_PUM\f_086.ahk ; (086_1)(Obj_Tom_MenuControlKey)
  #Include C:\Program Files\PopUpMenu_PUM\f_087.ahk ; (087_1)(Obj_Mnu_Menu)
  #Include C:\Program Files\PopUpMenu_PUM\f_088.ahk ; (088_1)(Obj_Mnu_AppMenu1)
  #Include C:\Program Files\PopUpMenu_PUM\f_089.ahk ; (089_1)(Obj_Mnu_AppMenu2)
  #Include C:\Program Files\PopUpMenu_PUM\f_090.ahk ; (090_1)(Obj_Mnu_AppMenu3)
  #Include C:\Program Files\PopUpMenu_PUM\f_091.ahk ; (091_1)(Obj_Mnu_AppMenu4)
  #Include C:\Program Files\PopUpMenu_PUM\f_092.ahk ; (092_1)(Obj_Mnu_AppMenu5)
  #Include C:\Program Files\PopUpMenu_PUM\f_093.ahk ; (093_1)(Obj_Mnu_AppMenu6)
  #Include C:\Program Files\PopUpMenu_PUM\f_094.ahk ; (094_1)(Obj_Mnu_AppMenu7)
  #Include C:\Program Files\PopUpMenu_PUM\f_095.ahk ; (095_1)(Obj_Mnu_AppMenu8)
  #Include C:\Program Files\PopUpMenu_PUM\f_096.ahk ; (096_1)(Obj_Mnu_AppMenu9)
  #Include C:\Program Files\PopUpMenu_PUM\f_097.ahk ; (097_1)(Obj_Mnu_AppMenu10)
  #Include C:\Program Files\PopUpMenu_PUM\f_098.ahk ; (098_1)(Obj_Mnu_AppMenu11)
  #Include C:\Program Files\PopUpMenu_PUM\f_099.ahk ; (099_1)(Obj_PopUpMenuWebLink)
  ; (100_1)(Obj_DisplayText_Top1)
  #Include C:\Program Files\PopUpMenu_PUM\f_101.ahk ; (101_1)(Obj_LangFlag)
  #Include C:\Program Files\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
  ; (103_1)(Obj_RwhUrl_OpeningAppImage)
  ; (104_1)(Obj_DisplayText_Bottom1)
  ; (105_1)(Obj_DisplayText_Top2)
  #Include C:\Program Files\PopUpMenu_PUM\f_106.ahk ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
  ; (107_1)(Obj_DisplayText_Bottom2)
  ; (108_1)(Obj_Url_GetAddressInfo)
  #Include C:\Program Files\PopUpMenu_PUM\f_109.ahk ; (109_1)(Obj_CatPaw)
  ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
  ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
  ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
  ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
  ; (114_1)(Obj_DisplayText_Title1)
  ; (115_1)(Obj_DisplayText_Title2)
  #Include C:\Program Files\PopUpMenu_PUM\f_116.ahk ; (116_1)(Obj_CplMnu_List100)
  #Include C:\Program Files\PopUpMenu_PUM\f_117.ahk ; (117_1)(Obj_CplMnu_ListRight60)
  #Include C:\Program Files\PopUpMenu_PUM\f_118.ahk ; (118_1)(Obj_CplMnu_ListLeft30)
  ; (119_1)(Empty)
  #Include C:\Program Files\PopUpMenu_PUM\f_120.ahk ; (120_1)(Obj_CplMnu_ListCenter30)
  #Include C:\Program Files\PopUpMenu_PUM\f_121.ahk ; (121_1)(Obj_CplMnu_ListRight30)
  ; (122_1)(Obj_EditFeild_StatusBar)
  #Include C:\Program Files\PopUpMenu_PUM\f_123.ahk ; (123_1)(Obj_Key_EditFeild_TextInput)
  ; (124)(Changed to 101 No Dropdown)
  #Include C:\Program Files\PopUpMenu_PUM\f_125.ahk ; (125_1)(Obj_Cpl_Menu1)
  #Include C:\Program Files\PopUpMenu_PUM\f_126.ahk ; (126_1)(Obj_Cpl_Menu2)
  #Include C:\Program Files\PopUpMenu_PUM\f_127.ahk ; (127_1)(Obj_Cpl_Menu3)
  #Include C:\Program Files\PopUpMenu_PUM\f_128.ahk ; (128_1)(Obj_Cpl_Menu4)
  #Include C:\Program Files\PopUpMenu_PUM\f_129.ahk ; (129_1)(Obj_Cpl_Menu5)
  #Include C:\Program Files\PopUpMenu_PUM\f_130.ahk ; (130_1)(Obj_Cpl_Menu6)
  ; (131_1)(Obj_Url_DisplayText_URLAddress)
  ; (132_1)(Empty)
  #Include C:\Program Files\PopUpMenu_PUM\f_133.ahk ; (133_1)(Obj_DeleteShortcut)
  #Include C:\Program Files\PopUpMenu_PUM\f_134.ahk ; (134_1)(Obj_ImageSelect1)
  #Include C:\Program Files\PopUpMenu_PUM\f_135.ahk ; (135_1)(Obj_ImageSelect2)
  #Include C:\Program Files\PopUpMenu_PUM\f_136.ahk ; (136_1)(Obj_ImageSelect3)
  #Include C:\Program Files\PopUpMenu_PUM\f_137.ahk ; (137_1)(Obj_MsgImg480x270)
  #Include C:\Program Files\PopUpMenu_PUM\f_138.ahk ; (138_1)(Obj_Cpl_Menu7)
  #Include C:\Program Files\PopUpMenu_PUM\f_139.ahk ; (139_1)(Obj_Cpl_Menu8)
  #Include C:\Program Files\PopUpMenu_PUM\f_140.ahk ; (140_1)(Obj_Mnu_AddonExtra)
  ; (141_1)(Obj_DisplayText_Title3)
  ; (142_1)(Obj_HotKey_MouseLeft)
  ; (143_1)(Obj_HotKey_MouseRight)
  ; (144_1)(Obj_HotKey_MouseMiddle)
  ; (145_1)(Obj_HotKey_MouseWheelUp)
  ; (146_1)(Obj_HotKey_MouseWheelDown)
  ; (147_1)(Obj_HotKey_MouseX1)
  ; (148_1)(Obj_HotKey_MouseX2)
  ; (149_1)(Obj_HotKey_WinLeft)
  ; (150_1)(Obj_HotKey_WinRight)
  ; (151_1)(Obj_HotKey_Ctrl)
  ; (152_1)(Obj_HotKey_Alt)
  ; (153_1)(Obj_HotKey_Shift)
  #Include C:\Program Files\PopUpMenu_PUM\f_154.ahk ; (154_1)(Obj_Pum_BgImage)
  #Include C:\Program Files\PopUpMenu_PUM\f_155.ahk ; (155_1)(Obj_Pum_BgText)
  #Include C:\Program Files\PopUpMenu_PUM\f_156.ahk ; (156_1)(Obj_Pum_BgDim)
  #Include C:\Program Files\PopUpMenu_PUM\f_157.ahk ; (157_1)(Obj_Pum_Setting)
  ; (158_1)(Empty)
  #Include C:\Program Files\PopUpMenu_PUM\f_159.ahk ; (159_1)(Obj_Pum_Contact)
  #Include C:\Program Files\PopUpMenu_PUM\f_160.ahk ; (160_1)(Obj_Pum_App))
  #Include C:\Program Files\PopUpMenu_PUM\f_161.ahk ; (161_1)(Obj_Pum_Del)
  #Include C:\Program Files\PopUpMenu_PUM\f_162.ahk ; (162)(Obj_Pum_Backup)
  #Include C:\Program Files\PopUpMenu_PUM\f_163.ahk ; (163)(Obj_Pum_Restore)
  #Include C:\Program Files\PopUpMenu_PUM\f_164.ahk ; (164_1)(Obj_Pum_BgTxtImg)
  #Include C:\Program Files\PopUpMenu_PUM\f_165.ahk ; (165_1)(Obj_Pum_BgImageSelect)
  #Include C:\Program Files\PopUpMenu_PUM\f_166.ahk ; (166_1)(Obj_Pum_BgColor)
  #Include C:\Program Files\PopUpMenu_PUM\f_167.ahk ; (167_1)(Obj_Pum_BgFitImage)
  ; (168_1)(Empty)
  ; (169_1)(Empty)
  ; (170_1)(Empty)
  ; (171_1)(Empty)
  #Include C:\Program Files\PopUpMenu_PUM\f_172.ahk ; (172_1)(Obj_Pum_MobileText)
  #Include C:\Program Files\PopUpMenu_PUM\f_173.ahk ; (173_1)(Obj_Pum_MobileTxtColor)
  #Include C:\Program Files\PopUpMenu_PUM\f_174.ahk ; (174_1)(Obj_Pum_MobileBgColor)
  ; (175_1)(Empty)
  ; (176_1)(Empty)
  ; (177_1)(Obj_Pum_BgTrans)
  #Include C:\Program Files\PopUpMenu_PUM\f_178.ahk ; (178_1)(Obj_Pum_BgOpacityUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_179.ahk ; (179_1)(Obj_Pum_BgOpacityDown)
  ; (180_1)(Obj_Pum_DisplayText_Opacity)
  ; (181_1)(Obj_Pum_Opacity)
  #Include C:\Program Files\PopUpMenu_PUM\f_182.ahk ; (182_1)(Obj_Pum_BgRotateLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_183.ahk ; (183_1)(Obj_Pum_BgRotateRight)
  ; (184_1)(GUI Object: [pumContact] <Image> Email Address)
  ; (185_1)(GUI Object: [pumContact] <Image> Contact Name)
  ; (186_1)(GUI Object: [pumContact] <Image No Lang> PopUpMenu.system@gmail.com)
  ; (187_1)(Not Used)
  #Include C:\Program Files\PopUpMenu_PUM\f_188.ahk ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
  #Include C:\Program Files\PopUpMenu_PUM\f_189.ahk ; (189_1)(Obj_Pum_EditFeild_ContactName)
  #Include C:\Program Files\PopUpMenu_PUM\f_190.ahk ; (190_1)(Obj_Pum_EditFeild_EmailBody)
  ; (191_1)(GUI Object: [pumBgText] [A1] <Image No Lang> Color Table)
  ; (192_1)(GUI Object: [pumBgText] [A2] <Image No Lang> Color Table)
  ; (193_1)(GUI Object: [pumBgText] [A3] <Image No Lang> Color Table)
  ; (194_1)(GUI Object: [pumBgText] [A4] <Image No Lang> Color Table)
  ; (195_1)(GUI Object: [pumBgText] [A5] <Image No Lang> Color Table)
  ; (196_1)(GUI Object: [pumBgText] [A6] <Image No Lang> Color Table)
  ; (197_1)(GUI Object: [pumBgText] [B1] <Image No Lang> Color Table)
  ; (198_1)(GUI Object: [pumBgText] [B2] <Image No Lang> Color Table)
  ; (199_1)(GUI Object: [pumBgText] [B3] <Image No Lang> Color Table)
  ; (200_1)(GUI Object: [pumBgText] [B4] <Image No Lang> Color Table)
  ; (201_1)(GUI Object: [pumBgText] [B5] <Image No Lang> Color Table)
  ; (202_1)(GUI Object: [pumBgText] [B6] <Image No Lang> Color Table)
  ; (203_1)(GUI Object: [pumBgText] [C1] <Image No Lang> Color Table)
  ; (204_1)(GUI Object: [pumBgText] [C2] <Image No Lang> Color Table)
  ; (205_1)(GUI Object: [pumBgText] [C3] <Image No Lang> Color Table)
  ; (206_1)(GUI Object: [pumBgText] [C4] <Image No Lang> Color Table)
  ; (207_1)(GUI Object: [pumBgText] [C5] <Image No Lang> Color Table)
  ; (208_1)(GUI Object: [pumBgText] [C6] <Image No Lang> Color Table)
  ; (209_1)(GUI Object: [pumBgText] [D1] <Image No Lang> Color Table)
  ; (210_1)(GUI Object: [pumBgText] [D2] <Image No Lang> Color Table)
  ; (211_1)(GUI Object: [pumBgText] [D3] <Image No Lang> Color Table)
  ; (212_1)(GUI Object: [pumBgText] [D4] <Image No Lang> Color Table)
  ; (213_1)(GUI Object: [pumBgText] [D5] <Image No Lang> Color Table)
  ; (214_1)(GUI Object: [pumBgText] [D6] <Image No Lang> Color Table)
  ; (215_1)(GUI Object: [pumBgText] [E1] <Image No Lang> Color Table)
  ; (216_1)(GUI Object: [pumBgText] [E2] <Image No Lang> Color Table)
  ; (217_1)(GUI Object: [pumBgText] [E3] <Image No Lang> Color Table)
  ; (218_1)(GUI Object: [pumBgText] [E4] <Image No Lang> Color Table)
  ; (219_1)(GUI Object: [pumBgText] [E5] <Image No Lang> Color Table)
  ; (220_1)(GUI Object: [pumBgText] [E6] <Image No Lang> Color Table)
  ; (221_1)(GUI Object: [pumBgText] [F1] <Image No Lang> Color Table)
  ; (222_1)(GUI Object: [pumBgText] [F2] <Image No Lang> Color Table)
  ; (223_1)(GUI Object: [pumBgText] [F3] <Image No Lang> Color Table)
  ; (224_1)(GUI Object: [pumBgText] [F4] <Image No Lang> Color Table)
  ; (225_1)(GUI Object: [pumBgText] [F5] <Image No Lang> Color Table)
  ; (226_1)(GUI Object: [pumBgText] [F6] <Image No Lang> Color Table)
  ; (227_1)(GUI Object: [pumBgText] [G1] <Image No Lang> Color Table)
  ; (228_1)(GUI Object: [pumBgText] [G2] <Image No Lang> Color Table)
  ; (229_1)(GUI Object: [pumBgText] [G3] <Image No Lang> Color Table)
  ; (230_1)(GUI Object: [pumBgText] [G4] <Image No Lang> Color Table)
  ; (231_1)(GUI Object: [pumBgText] [G5] <Image No Lang> Color Table)
  ; (232_1)(GUI Object: [pumBgText] [G6] <Image No Lang> Color Table)
  ; (233_1)(GUI Object: [pumBgText] [H1] <Image No Lang> Color Table)
  ; (234_1)(GUI Object: [pumBgText] [H2] <Image No Lang> Color Table)
  ; (235_1)(GUI Object: [pumBgText] [H3] <Image No Lang> Color Table)
  ; (236_1)(GUI Object: [pumBgText] [H4] <Image No Lang> Color Table)
  ; (237_1)(GUI Object: [pumBgText] [H5] <Image No Lang> Color Table)
  ; (238_1)(GUI Object: [pumBgText] [H6] <Image No Lang> Color Table)
  ; (239_1)(Not Used)
  ; (240_1)(Not Used)
  #Include C:\Program Files\PopUpMenu_PUM\f_241.ahk ; (241_1)(Obj_Pum_CropLeft)
  #Include C:\Program Files\PopUpMenu_PUM\f_242.ahk ; (242_1)(Obj_Pum_CropRight)
  #Include C:\Program Files\PopUpMenu_PUM\f_243.ahk ; (243_1)(Obj_Pum_CropUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_244.ahk ; (244_1)(Obj_Pum_CropDown)
  #Include C:\Program Files\PopUpMenu_PUM\f_245.ahk ; (245_1)(Obj_Pum_CropCenter)
  #Include C:\Program Files\PopUpMenu_PUM\f_246.ahk ; (246_1)(Obj_Pum_ZoomIn)
  #Include C:\Program Files\PopUpMenu_PUM\f_247.ahk ; (247_1)(Obj_Pum_ZoomOut)
  #Include C:\Program Files\PopUpMenu_PUM\f_248.ahk ; (248_1)(Obj_Ofl_1LAppIco)
  #Include C:\Program Files\PopUpMenu_PUM\f_249.ahk ; (249_1)(Obj_Ofl_2LAppIco)
  #Include C:\Program Files\PopUpMenu_PUM\f_250.ahk ; (250_1)(Obj_Ofl_3LAppIco)
  #Include C:\Program Files\PopUpMenu_PUM\f_251.ahk ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
  ; (252_1)(Obj_Ofl_LFolderImage)
  ; (253_1)(Empty)
  ; (254_1)(Obj_MsgImg300x300)
  ; (255_1)(Empty)
  ; (256_1)(Empty)
  ; (257_1)(Empty)
  ; (258_1)(Empty)
  ; (259_1)(Empty)
  ; (260_1)(Obj_Pum_IconSize)
  #Include C:\Program Files\PopUpMenu_PUM\f_261.ahk ; (261_1)(Obj_Pum_IconUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_262.ahk ; (262_1)(Obj_Pum_IconDown)
  ; (263_1)(Obj_Pum_ImageText_IconSize)
  ; (264_1)(Empty)
  ; (265_1)(Empty)
  ; (266_1)(Obj_Pum_PumRow)
  #Include C:\Program Files\PopUpMenu_PUM\f_267.ahk ; (267_1)(Obj_Pum_PumRowUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_268.ahk ; (268_1)(Obj_Pum_PumRowDown)
  ; (269_1)(Obj_Pum_DisplayText_Vertical)
  ; (270_1)(Empty)
  ; (271_1)(Empty)
  ; (272_1)(Obj_Pum_PumColumn)
  #Include C:\Program Files\PopUpMenu_PUM\f_273.ahk ; (273_1)(Obj_Pum_PumColumnUp)
  #Include C:\Program Files\PopUpMenu_PUM\f_274.ahk ; (274_1)(Obj_Pum_PumColumnDown)
  ; (275_1)(Obj_Pum_DisplayText_Horizontal)
  ; (276_1)(Empty)
  ; (277_1)(Empty)
  ; (278_1)(Empty)
  ; (279_1)(Empty)
  ; (280_1)(Empty)
  ; (281_1)(Empty)
  ; (282_1)(Empty)
  ; (283_1)(Empty)
  ; (284_1)(Empty)
  ; (285_1)(Empty)
  ; (286_1)(Empty)
  ; (287_1)(Empty)
  ; (288_1)(Empty)
  ; (289_1)(Empty)
  #Include C:\Program Files\PopUpMenu_PUM\f_290.ahk ; (290)(Obj_BrowserPum)
  ; (291_1)(Empty)
  ; (292_1)(Empty)
  ; (293_1)(Empty)
  ; (294_1)(Empty)
  ; (295_1)(Empty)
  ; (296_1)(Empty)
  ; (297_1)(Empty)
  ; (298_1)(Empty)
  ; (299_1)(End GUI Object)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [Gui] [INCLUDE]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
