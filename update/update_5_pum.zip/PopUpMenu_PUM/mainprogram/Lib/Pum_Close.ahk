﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Pum_Close() ; > Nothing
{
  ; -------------------------------------------
  Disable_Persistent := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_Persistent.ahk"
  Disable_Gui        := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_Gui.ahk"
  Disable_KeyGui     := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_KeyGui.ahk"
  ; -------------------------------------------
  if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Keep Shortcut Gui Active
  {
    ; -------------------------------------------
    Gui, PopUpMenu:Destroy
    ; -------------------------------------------
    Script_Close(Disable_Persistent)
    Script_Close(Disable_Gui)
    Script_Close(Disable_KeyGui)
    Run, %Disable_KeyPum%
    ; -------------------------------------------
    WinSet, Enable ,, ahk_class TfrmToolbox
    WinSet, AlwaysOnTop, On, ahk_class TfrmToolbox
    ; -------------------------------------------
  }
  else if WinExist("ahk_class TfrmToolbox") ; Close Any PUM
  {
    ; -------------------------------------------
    WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    IfInString, PumProcess, pum_
    {
      Process, Close, %PumProcess%
    } ; End IfInString, PumProcess, pum_
    ; -------------------------------------------
    v_380_4  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Active_App.txt" ; (380_4)(Active Application [System Text File Path])
    FileDelete, %v_380_4%
    ; -------------------------------------------
  } ; End WinExist("ahk_class TfrmToolbox") 
} ; End Pum_Close`
