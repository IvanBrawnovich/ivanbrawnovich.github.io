﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
#NoTrayIcon
; -------------------------------------------
; This File Must be Ran AsAdmin
; -------------------------------------------
Disable_StayInWindow(This_Id, More_Left, More_Right, More_Up, More_Down)
{
  ; -------------------------------------------
  InWin_X := 0
  InWin_Y := 0
  ; -------------------------------------------
  WinActivate, ahk_id %This_Id%
  CoordMode, Mouse , Window
  MouseGetPos, Pos_X, Pos_Y
  WinGetPos, UpperLeft_X, UpperLeft_Y, Win_Width, Win_Height, ahk_id %This_Id%
  ; -------------------------------------------
  if (More_Up == "")
  {
    More_Up := 0
  }
  if (More_Down == "")
  {
    More_Down := 0
  }
  if (More_Left == "")
  {
    More_Left := 0
  }
  if (More_Right == "")
  {
    More_Right := 0
  }
  ; -------------------------------------------
  Min_X := More_Right
  Max_X := (Win_Width - More_Left)
  Min_Y := More_Down
  Max_Y := (Win_Height - More_Up)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Pos_X < Min_X)
  {
    New_X := Min_X
  }
  else if (Pos_X > Max_X)
  {
    New_X := Max_X
  }
  else
  {
    New_X := Pos_X
  }
  ; -------------------------------------------
  if (Pos_Y < Min_Y)
  {
    New_Y := Min_Y
  }
  else if (Pos_Y > Max_Y)
  {
    New_Y := Max_Y
  }
  else
  {
    New_Y := Pos_Y
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (New_X != Pos_X or New_Y != Pos_Y )
  {
    MouseMove, New_X, New_Y
  } ; End (Pos_X >= Min_X && Pos_X <= Max_X)
  ; -------------------------------------------
} ; End Disable_StayInWindow(This_Id, More_Left, More_Right, More_Up, More_Down)
; -------------------------------------------
Loop
{
  ; -------------------------------------------
  SetTitleMatchMode, 1
  ; -------------------------------------------
  if WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI")
  {
    SetTitleMatchMode, 1
    WinGet, Hotkey_Id, ID , HotKey PopUpMenu ahk_class AutoHotkeyGUI
    WinGetTitle, Hotkey_Title, ahk_id %Hotkey_Id%
    WinGetClass, Hotkey_Class, ahk_id %Hotkey_Id%\
    WinActivate, ahk_id %Hotkey_Id%
  }
  else
  {
    ; -------------------------------------------
    ThisScript := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Hotkey_gui.ahk"
    DetectHiddenWindows, On
    WinClose, %ThisScript% ahk_class AutoHotkey
    ; -------------------------------------------
    ThisScript := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_Hotkey.ahk"
    DetectHiddenWindows, On
    WinClose, %ThisScript% ahk_class AutoHotkey
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  }
  ; -------------------------------------------
  Disable_StayInWindow(Hotkey_Id, 10, 10, 10, 35)
  ; -------------------------------------------
}
