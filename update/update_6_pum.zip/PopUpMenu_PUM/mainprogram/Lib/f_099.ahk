﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_099() ; (099_1)(GUI Object: Web Site Image Link)
{
  ; -------------------------------------------
  v_385_3 := "https://popupmenu.github.io/" ; (385_3)(PopUpMenu Home Page [PopUpMenu URL Address])
  Run, %v_385_3% ; (385_3)(PopUpMenu Home Page [PopUpMenu URL Address])
  ; -------------------------------------------
  if (WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") or WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI"))
  {
    Pum_Close() ; > Nothing
  }
  ; -------------------------------------------
  if WinExist("ahk_class TfrmToolbox") ; Close Any PUM
  {
    Pum_Close() ; > Nothing
  } ; End WinExist("ahk_class TfrmToolbox") 
  ; -------------------------------------------
}
