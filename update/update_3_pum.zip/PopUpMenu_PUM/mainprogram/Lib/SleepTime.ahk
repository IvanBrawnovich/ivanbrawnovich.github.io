﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
SleepTime(ThisTime) ; ThisTime, This_Benchmark
{
  ; -------------------------------------------
  File_PCBenchmark := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\PC_Benchmark.txt"
  ; -------------------------------------------
  if FileExist(File_PCBenchmark)
  {
    FileReadLine, This_Benchmark, %File_PCBenchmark%, 1
  }
  else
  {
    RunWait, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Benchmark_Test.ahk
    FileReadLine, This_Benchmark, %File_PCBenchmark%, 1
  }
  ; -------------------------------------------
  if (ThisTime > 0)
  {
    SleepThisTime := This_Benchmark * ThisTime
    Sleep, %SleepThisTime%
  }
}
; -------------------------------------------
