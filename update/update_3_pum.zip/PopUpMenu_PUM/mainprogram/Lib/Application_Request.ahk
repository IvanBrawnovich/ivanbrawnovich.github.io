﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Application_Request(DataArray) ; > DataArray
{
  ; -------------------------------------------
  This_Benchmark := Benchmark()
  ; -------------------------------------------
  v_360_1 := DataArray.360.1 ; (360_1)(Product ID)
  RegRead, v_360_3, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName ; (360_3)(World Location: Continent)
  v_360_4 := DataArray.360.4 ; (360_4)(World Location: Country)
  v_360_5 := DataArray.360.5 ; (360_5)(World Location: Region)
  v_360_6 := DataArray.360.6 ; (360_6)(World Location: This City)
  v_360_7 := DataArray.360.7 ; (360_7)(Public IP)
  ;
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  v_365_3 := DataArray.365.3 ; (365_3)(Language List Number [Integer])
  ;
  v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  v_367_4 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
  v_367_5 := DataArray.367.5 ; (367_5)([Line 4] Active Process Title)
  v_367_6 := DataArray.367.6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
  v_367_7 := DataArray.367.7 ; (367_7)([Line 6] Active Process Version)
  ;
  v_380_2 := DataArray.380.2 ; (380_2)(Application Request [System Text File Path])
  ;
  ; -------------------------------------------
  if (v_367_2 != "Windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  {
    ; -------------------------------------------
    if (Connect_Check(flag=0x40) == 1)
    {
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (503_1)(Splash Info File: Getting App Data)
      ; (503_1)(Splash Info Script File: Getting App Data)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; [GET] Language_Name from (365_2)(Current User language)
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(Current User language)
        {
          Language_Name := "German"
        }
        else if (v_365_2 == "en") ; (365_2)(Current User language)
        {
          Language_Name := "English"
        }
        else if (v_365_2 == "es") ; (365_2)(Current User language)
        {
          Language_Name := "Spanish"
        }
        else if (v_365_2 == "fr") ; (365_2)(Current User language)
        {
          Language_Name := "French"
        }
        else if (v_365_2 == "it") ; (365_2)(Current User language)
        {
          Language_Name := "Italian"
        }
        else if (v_365_2 == "pl") ; (365_2)(Current User language)
        {
          Language_Name := "Polish"
        }
        else if (v_365_2 == "pt") ; (365_2)(Current User language)
        {
          Language_Name := "Portuguese"
        }
        else if (v_365_2 == "ru") ; (365_2)(Current User language)
        {
          Language_Name := "Russian"
        }
        else if (v_365_2 == "sv") ; (365_2)(Current User language)
        {
          Language_Name := "Swedish"
        }
        else if (v_365_2 == "tr") ; (365_2)(Current User language)
        {
          Language_Name := "Turkish"
        }
        ; -------------------------------------------
      } ; End [GET] Language_Name from (365_2)(Current User language)
      ; -------------------------------------------
      { ; Send E-Mail
        ; -------------------------------------------
        Email_Subject :=  "PUM-App " A_UserName " " v_360_1 ; (360_1)(Product ID)
        Email_Body := ""
        ; -------------------------------------------
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Language`n" ; (365_2)(Current User language)
        Email_Body := Email_Body Language_Name "`n" ; (365_2)(Current User language)
        Email_Body := Email_Body v_365_2 "`n`n" ; (365_2)(Current User language)
        ;
        Email_Body := Email_Body "Application Requested`n"
        Email_Body := Email_Body v_367_2 "`n`n" ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
        ;
        Email_Body := Email_Body "Application Version`n"
        Email_Body := Email_Body v_367_7 "`n`n" ; (367_7)([Line 6] Active Process Version)
        ;
        Email_Body := Email_Body "Application Path`n"
        Email_Body := Email_Body v_367_6 "`n`n" ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
        ;
        Email_Body := Email_Body "Application Class`n"
        Email_Body := Email_Body v_367_4 "`n`n" ; (367_4)([Line 3] Active Process Class)
        ;
        Email_Body := Email_Body "Application Title`n"
        Email_Body := Email_Body v_367_5 "`n" ; (367_5)([Line 4] Active Process Title)
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Product ID:`n"
        Email_Body := Email_Body v_360_1 "`n`n" ; (360_1)(Product ID)
        ;
        Email_Body := Email_Body "User Name:`n"
        Email_Body := Email_Body A_UserName "`n`n"
        ;
        Email_Body := Email_Body "Benchmark:`n"
        Email_Body := Email_Body This_Benchmark "`n`n" ; (363_7)(PC Benchmark [Integer])
        ;
        Email_Body := Email_Body "AutoHotKey Version:`n"
        Email_Body := Email_Body A_AhkVersion "`n`n"
        ;
        Email_Body := Email_Body "Windows Version:`n"
        Email_Body := Email_Body v_360_3 "`n`n" ; (360_3)(World Location: Continent)
        ;
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Continent:`n"
        Email_Body := Email_Body v_360_4 "`n`n" ; (360_4)(World Location: Country)
        ;
        Email_Body := Email_Body "Country:`n"
        Email_Body := Email_Body v_360_5 "`n`n" ; (360_5)(World Location: Region)
        ;
        Email_Body := Email_Body "Region:`n"
        Email_Body := Email_Body v_360_6 "`n`n" ; (360_6)(World Location: This City)
        ;
        Email_Body := Email_Body "City:`n"
        Email_Body := Email_Body v_360_7 "`n" ; (360_7)(Public IP)
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Public IP:`n"
        Email_Body := Email_Body v_360_8 "`n`n" ; (360_8)(Private IP)
        ;
        Email_Body := Email_Body "Private IP:`n"
        Email_Body := Email_Body v_360_9 "`n" ; 
        Email_Body := Email_Body "----------------------------------`n"
        ; -------------------------------------------
        Email_Sent := Send_Email(Email_Subject, Email_Body, AttachFile)
        ; -------------------------------------------
      } ; End Send E-Mail
      ; -------------------------------------------
      {
        ; -------------------------------------------
        if (Email_Sent == 1)
        {
          ; -------------------------------------------
          ; (380_2)(Application Request [System Text File Path])
          AppRequest := v_367_2 "_" v_365_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(365_2)(Current User language)
          FileAppend, %AppRequest%`n, %v_380_2%, UTF-8 ; (380_2)(Application Request [System Text File Path])
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; (508_1)(Splash Info File: Thank You Request Sent)
          ; (508_1)(Splash Info Script File: Thank You Request Sent)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; -------------------------------------------
        }
        else if (Email_Sent == 0)
        {
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; (425_1)(Splash Error File: Error Sending Request)
          ; (425_1)(Splash Error Image File: Error Sending Request)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; -------------------------------------------
        }
      }
    }
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (427_1)(Splash Error File: No Internet Connection)
      ; (427_1)(Splash Error Image File: No Internet Connection)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
    }
  }
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;~ Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
