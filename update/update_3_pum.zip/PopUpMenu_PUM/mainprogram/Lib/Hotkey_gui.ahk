﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
; -------------------------------------------
DataArray := DataArray_Set()
; -------------------------------------------
DoNothing := 1
; -------------------------------------------
{ ; [SET] global Var(s)
  ; -------------------------------------------
  global HotKey_Header
  ;
  global g_101 ; (101_1)(GUI Object: Language Flag)
  global g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
  ;
  global g_062 ; (062_1)(GUI Object: Cancel)
  global g_004 ; (004_1)(GUI Object: Ok Button)
  global TextExplain
  global TextKeystroke
  global HK_Header2
  global g_099 ; (099_1)(GUI Object: Web Site Image Link)
  ;
  global g_142 ; (142_1)(GUI Object: HotKey Select Mouse Left)
  global g_143 ; (143_1)(GUI Object: HotKey Select Mouse Right)
  global g_145 ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
  global g_146 ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
  global g_144 ; (144_1)(GUI Object: HotKey Select Mouse Middle)
  global g_147 ; (147_1)(GUI Object: HotKey Select Mouse X1)
  global g_148 ; (148_1)(GUI Object: HotKey Select Mouse X2)
  ;
  global g_149 ; (149_1)(GUI Object: HotKey Windows Key Left)
  global g_151 ; (151_1)(GUI Object: HotKey Ctrl Key)
  global g_153 ; (153_1)(GUI Object: HotKey Shift Key)
  global g_152 ; (152_1)(GUI Object: HotKey Alt Key)
  global g_150 ; (150_1)(GUI Object: HotKey Windows Key Right)
} ; End [SET] global Var(s)  
; -------------------------------------------
{ ; [Start Up]
  ; -------------------------------------------
  v_124_3 := DataArray.124.3 ; (124_3)(<Drop Down List> Language: List Box)
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  v_365_3 := DataArray.365.3 ; (365_3)(Language List Number [Integer])
  v_366_2 := DataArray.366.2 ; (366_2)(GuiFont Set in DataArray_Set)
  v_381_3 := DataArray.381.3 ; (381_3)(User HotKey Text File [User Text File Path])
  v_384_2 := DataArray.384.2 ; (384_2)(Empty)
  v_386_7 := DataArray.386.7 ; (386_7)(Default Script Type Icon [Folder Path])
  v_386_9 := DataArray.386.9 ; (386_9)(Language Flag Image [Folder Path])
  ; -------------------------------------------
} ; End [Start Up]
; -------------------------------------------
{ ; GUI Define (Objects)
  ; -------------------------------------------
  Gui, HotKeySelect:+AlwaysOnTop
  ; -------------------------------------------
  if (A_ScreenWidth > 600) ; (364_2)(Monitor Height [Integer])
  {
    ; -------------------------------------------
    Gui,+AlwaysOnTop
    ; -------------------------------------------
    Gui, HotKeySelect:Font, c921297 s14 w700, %v_366_2% ; (366_2)(GuiFont Set in DataArray_Set)
    Gui, HotKeySelect:Add, Text, Center                x10  y132 w480        vTextExplain,
    Gui, HotKeySelect:Add, Text, -Wrap                 x10  y180 w480        vTextKeystroke,
    ; -------------------------------------------
    Gui, HotKeySelect:Add, Picture,                    x37  y7  w40   h40,   %v_386_7%\PopUpMenu.png ; (386_7)(Default Script Type Icon [Folder Path])
    Gui, HotKeySelect:Add, Picture,                    x129 y16 w350  h97    vHotKey_Header,
    ; -------------------------------------------
    { ; (101)(Language Flag)/(124)(Choose Language Drop Down List)/(062_1)(GUI Object: Cancel)/(004_1)(GUI Object: Ok Button)
      ; -------------------------------------------
      Gui, HotKeySelect:Add, Picture,                  x10  y55  w94  h23     vg_101, ; (101_1)(GUI Object: Language Flag)
      Gui, HotKeySelect:Font, c000000 s10 w700, %v_366_2% ; (366_2)(GuiFont Set in DataArray_Set)
      Gui, HotKeySelect:Add, DropDownList,             x10  y81  w94         -Tabstop  vg_124             gl_HotKey_124,   ; (124_1)(GUI Object: <Drop Down List> Language)
      ; -------------------------------------------
      Gui, HotKeySelect:Add, Picture,                  x48  y622 w100 h35  vg_062                         gl_HotKey_Cancel, ; (062_1)(GUI Object: Cancel)
      Gui, HotKeySelect:Add, Picture,                  x353 y622 w100 h35  vg_004                         gl_HotKey_Ok, ; (004_1)(GUI Object: Ok Button)
      ; -------------------------------------------
      Gui, HotKeySelect:Add, Picture,                  x10  y670 w480 h20  vg_099                         gl_HotKey_099, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\img\imgkey\WebAddress.png ; (099_1)(GUI Object: Web Site Image Link)
      ; -------------------------------------------
    } ; End (101)(Language Flag)/(124)(Choose Language Drop Down List)
    ; -------------------------------------------
    { ; (Control Keys)
      ; -------------------------------------------
      Gui, HotKeySelect:Add, Picture,                  x13  y231 w70  h70  vg_149                         gl_149, ; (149_1)(GUI Object: HotKey Windows Key Left)
      Gui, HotKeySelect:Add, Picture,                  x97  y231 w70  h70  vg_151                         gl_151, ; (151_1)(GUI Object: HotKey Ctrl Key)
      Gui, HotKeySelect:Add, Picture,                  x180 y231 w140 h70  vg_153                         gl_153, ; (153_1)(GUI Object: HotKey Shift Key)
      Gui, HotKeySelect:Add, Picture,                  x334 y231 w70  h70  vg_152                         gl_152, ; (152_1)(GUI Object: HotKey Alt Key)
      Gui, HotKeySelect:Add, Picture,                  x417 y231 w70  h70  vg_150                         gl_150, ; (150_1)(GUI Object: HotKey Windows Key Right)
      ; -------------------------------------------
    } ; End (Control Keys)
    ; -------------------------------------------
    { ; Mouse
      ; -------------------------------------------
      Gui, HotKeySelect:Add, Picture,                  x167 y321 w165 h274,                               %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\img\imgkey\Mouse.png ; (363_5)(PC Installed Dir)
      Gui, HotKeySelect:Add, Picture,                  x176 y326 w50  h113 vg_142                         gl_142, ; (142_1)(GUI Object: HotKey Select Mouse Left)
      Gui, HotKeySelect:Add, Picture,                  x273 y326 w50  h113 vg_143                         gl_143, ; (143_1)(GUI Object: HotKey Select Mouse Right)
      Gui, HotKeySelect:Add, Picture,                  x235 y353 w29  h53  vg_144                         gl_144, ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      Gui, HotKeySelect:Add, Picture,                  x235 y325 w28  h28  vg_145                         gl_145, ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      Gui, HotKeySelect:Add, Picture,                  x235 y406 w28  h28  vg_146                         gl_146, ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      Gui, HotKeySelect:Add, Picture,                  x131 y472 w53  h28  vg_147                         gl_147, ; (147_1)(GUI Object: HotKey Select Mouse X1)
      Gui, HotKeySelect:Add, Picture,                  x126 y443 w53  h28  vg_148                         gl_148, ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
    } ; End Mouse
    ; -------------------------------------------
  } ; (364_2)(Monitor Height [Integer])
  ; -------------------------------------------
} ; END GUI Define (Objects)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{ ; [StartUp] GuiControl
  ; -------------------------------------------
  GuiControl, HotKeySelect:, HotKey_Header, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\img\msg\HK_Header2_%v_365_2%.png ; (365_2)(Current User language)
  ; -------------------------------------------
  { ; (101)(Language Flag)/(124)(Choose Language Drop Down List)
    GuiControl, HotKeySelect:, g_101, %v_386_9%\%v_365_2%.png ; (386_9)(Language Flag Image [Folder Path])/(365_2)(Current User language)/(101_1)(GUI Object: Language Flag)
    DetectHiddenWindows, On
    if WinExist(v_384_2 . "ahk_class AutoHotkey") ; (384_2)(Empty)
    {
      GuiControl, HotKeySelect:Hide, g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
    }
    else
    {
      GuiControl, HotKeySelect:, g_124, %v_124_3% ; (124_3)(<Drop Down List> Language: List Box)/(124_1)(GUI Object: <Drop Down List> Language)
      GuiControl, HotKeySelect:Choose, g_124, %v_365_3% ; (365_3)(Language List Number [Integer])/(124_1)(GUI Object: <Drop Down List> Language)
    }
    ; ------------------------------------------
  } ; End (101)(Language Flag)/(124)(Choose Language Drop Down List)
  ; -------------------------------------------
  ; Set These GUI Image to Nothing so the Images will be in Reloaded
  DataArray.4.3 := "Nothing" ; (004_3)(Ok Button: Image Path)
  DataArray.62.3 := "Nothing" ; (062_3)(Cancel: Image Path)
  ; -------------------------------------------
  Num := 142
  while (Num < 154)
  {
    DataArray[Num][3] := "Nothing"
    Num := Num + 1
  }
  ; -------------------------------------------
  { ; [GET] Current Hotkey
    ; -------------------------------------------
    if FileExist(v_381_3) ; (381_3)(User HotKey Text File [User Text File Path])
    {
      FileReadLine, v_369_2, %v_381_3%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    }
    ; -------------------------------------------
    { ; (Key Positions)
      ; -------------------------------------------
      if (v_369_2 != "") ; (369_2)(Current User Hotkey)
      {
        ; -------------------------------------------
        ; Update DataArray
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_142_Pos := InStr(v_369_2, "LButton") ; (142_1)(GUI Object: HotKey Select Mouse Left)/(369_2)(Current User Hotkey)
        v_143_Pos := InStr(v_369_2, "RButton") ; (143_1)(GUI Object: HotKey Select Mouse Right)/(369_2)(Current User Hotkey)
        v_144_Pos := InStr(v_369_2, "MButton") ; (144_1)(GUI Object: HotKey Select Mouse Middle)/(369_2)(Current User Hotkey)
        v_145_Pos := InStr(v_369_2, "WheelUp") ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)/(369_2)(Current User Hotkey)
        v_146_Pos := InStr(v_369_2, "WheelDown") ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)/(369_2)(Current User Hotkey)
        v_147_Pos := InStr(v_369_2, "XButton1") ; (147_1)(GUI Object: HotKey Select Mouse X1)/(369_2)(Current User Hotkey)
        v_148_Pos := InStr(v_369_2, "XButton2") ; (148_1)(GUI Object: HotKey Select Mouse X2)/(369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_149_Pos := InStr(v_369_2, "LWin") ; (149_1)(GUI Object: HotKey Windows Key Left)/(369_2)(Current User Hotkey)
        v_150_Pos := InStr(v_369_2, "RWin") ; (150_1)(GUI Object: HotKey Windows Key Right)/(369_2)(Current User Hotkey)
        Win_Pos := InStr(v_369_2, "#") ; (369_2)(Current User Hotkey)
        v_151_Pos := InStr(v_369_2, "^") ; (151_1)(GUI Object: HotKey Ctrl Key)/(369_2)(Current User Hotkey)
        ; -------------------------------------------
        if (v_151_Pos == 0) ; (151_1)(GUI Object: HotKey Ctrl Key)
        {
          v_151_Pos := InStr(v_369_2, "Ctrl") ; (151_1)(GUI Object: HotKey Ctrl Key)/(369_2)(Current User Hotkey)
        }
        ; -------------------------------------------
        v_152_Pos := InStr(v_369_2, "!") ; (152_1)(GUI Object: HotKey Alt Key)/(369_2)(Current User Hotkey)
        ; -------------------------------------------
        if (v_152_Pos == 0) ; (152_1)(GUI Object: HotKey Alt Key)
        {
          v_152_Pos := InStr(v_369_2, "Alt") ; (152_1)(GUI Object: HotKey Alt Key)/(369_2)(Current User Hotkey)
        }
        ; -------------------------------------------
        v_153_Pos := InStr(v_369_2, "+") ; (153_1)(GUI Object: HotKey Shift Key)/(369_2)(Current User Hotkey)
        ; -------------------------------------------
        if (v_153_Pos == 0) ; (153_1)(GUI Object: HotKey Shift Key)
        {
          v_153_Pos := InStr(v_369_2, "Shift") ; (153_1)(GUI Object: HotKey Shift Key)/(369_2)(Current User Hotkey)
        }
        ; -------------------------------------------
      } ; End [GET] (Key Positions) (Hot Key is SET)
      else ; [SET] (Key Positions to 0) (Hot Key is NOT Set)
      {
        v_142_Pos := 0 ; (142_1)(GUI Object: HotKey Select Mouse Left)
        v_143_Pos := 0 ; (143_1)(GUI Object: HotKey Select Mouse Right)
        v_144_Pos := 0 ; (144_1)(GUI Object: HotKey Select Mouse Middle)
        v_145_Pos := 0 ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
        v_146_Pos := 0 ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
        v_147_Pos := 0 ; (147_1)(GUI Object: HotKey Select Mouse X1)
        v_148_Pos := 0 ; (148_1)(GUI Object: HotKey Select Mouse X2)
        v_149_Pos := 0 ; (149_1)(GUI Object: HotKey Windows Key Left)
        v_150_Pos := 0 ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_151_Pos := 0 ; (151_1)(GUI Object: HotKey Ctrl Key)
        v_152_Pos := 0 ; (152_1)(GUI Object: HotKey Alt Key)
        v_153_Pos := 0 ; (153_1)(GUI Object: HotKey Shift Key)
        Win_Pos := 0
      } ; End [SET] (Key Positions to 0) (Hot Key is NOT Set)
      ; -------------------------------------------
    } ; End (Key Positions)
    ; -------------------------------------------
    { ; [SET] (Key Images) from (Key Positions)
      ; -------------------------------------------
      { ; (142_1)(GUI Object: HotKey Select Mouse Left)
        if (v_142_Pos == 0) ; (142_1)(GUI Object: HotKey Select Mouse Left)
        {
          DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
        }
      } ; (142_1)(GUI Object: HotKey Select Mouse Left)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (143_1)(GUI Object: HotKey Select Mouse Right)
        if (v_143_Pos == 0) ; (143_1)(GUI Object: HotKey Select Mouse Right)
        {
          DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
        }
      } ; (143_1)(GUI Object: HotKey Select Mouse Right)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (144_1)(GUI Object: HotKey Select Mouse Middle)
        if (v_144_Pos == 0) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
        {
          DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("144", 2, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
        }
      } ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
        if (v_145_Pos == 0) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
        {
          DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("145", 2, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
        }
      } ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
        if (v_146_Pos == 0) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
        {
          DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("146", 2, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
        }
      } ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (147_1)(GUI Object: HotKey Select Mouse X1)
        if (v_147_Pos == 0) ; (147_1)(GUI Object: HotKey Select Mouse X1)
        {
          DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("147", 2, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
        }
      } ; (147_1)(GUI Object: HotKey Select Mouse X1)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (148_1)(GUI Object: HotKey Select Mouse X2)
        if (v_148_Pos == 0) ; (148_1)(GUI Object: HotKey Select Mouse X2)
        {
          DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("148", 2, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
        }
      } ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (GUI Object: HotKey Windows)
        if (v_149_Pos == 0 && v_150_Pos == 0) ; (149_1)(GUI Object: HotKey Windows Key Left)/(150_1)(GUI Object: HotKey Windows Key Right)
        {
          ; -------------------------------------------
          if (Win_Pos == 0)
          {
            DataArray := GuiControlImage_HotKeySelect("149", 1, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
            DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          else
          {
            DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
            DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          if (v_149_Pos == 0) ; (149_1)(GUI Object: HotKey Windows Key Left)
          {
            DataArray := GuiControlImage_HotKeySelect("149", 1, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
          }
          else
          {
            DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
          }
          ; -------------------------------------------
          if (v_150_Pos == 0) ; (150_1)(GUI Object: HotKey Windows Key Right)
          {
            DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          else
          {
            DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          ; -------------------------------------------
        }
      } ; (GUI Object: HotKey Windows)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (151_1)(GUI Object: HotKey Ctrl Key)
        if (v_151_Pos == 0) ; (151_1)(GUI Object: HotKey Ctrl Key)
        {
          DataArray := GuiControlImage_HotKeySelect("151", 1, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
        }
      } ; (151_1)(GUI Object: HotKey Ctrl Key)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (152_1)(GUI Object: HotKey Alt Key)
        if (v_152_Pos == 0) ; (152_1)(GUI Object: HotKey Alt Key)
        {
          DataArray := GuiControlImage_HotKeySelect("152", 1, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
        }
      } ; (152_1)(GUI Object: HotKey Alt Key)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      { ; (153_1)(GUI Object: HotKey Shift Key)
        if (v_153_Pos == 0) ; (153_1)(GUI Object: HotKey Shift Key)
        {
          DataArray := GuiControlImage_HotKeySelect("153", 1, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
        }
        else
        {
          DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
        }
      } ; (153_1)(GUI Object: HotKey Shift Key)
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    } ; End [SET] (Key Images) from (Key Positions)
    ; -------------------------------------------
  } ; End [GET] Current Hotkey
  ; -------------------------------------------
  DataArray := HotKey_Validate(DataArray)
  ; -------------------------------------------
} ; End [StartUp] GuiControl
; -------------------------------------------
{ ; GUI Show
  ; -------------------------------------------
  if (Is_Script_Running(DataArray.384.2) == 1) ; (384_2)(Empty)
  {
    GuiControl, HotKeySelect:Hide, g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
  }
  ; -------------------------------------------
  GuiControl, HotKeySelect:Focus, g_004 ; (004_1)(GUI Object: Ok Button)
  Gui, HotKeySelect:Color , e7d8fe ; Purple
  Gui, HotKeySelect:Show, w500 h700, HotKey PopUpMenu, AlwaysOnTop Window 
} ; END GUI Show
; -------------------------------------------
Menu, Tray, Icon, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\img\Hotkey_gui.png
; -------------------------------------------
return
  
; -------------------------------------------  
{ ; Gui Labels
  ; -------------------------------------------
  l_HotKey_Ok: ; (004_1)(GUI Object: Ok Button)
  {
    ; -------------------------------------------
    DataArray := HotKey_Ok(DataArray)
    ; -------------------------------------------
  }
  return
  l_HotKey_Cancel: ; (062_1)(GUI Object: Cancel)
  {
    ; -------------------------------------------
    DataArray := HotKey_Cancel(DataArray) ; > DataArray
    ; -------------------------------------------
  }
  return
  l_HotKey_124: ; (124_1)(GUI Object: <Drop Down List> Language)
  {
    ; -------------------------------------------
    DataArray := f_124(DataArray) ; (124_1)(GUI Object: <Drop Down List> Language)
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  }
  return
  l_HotKey_099: ; (099_1)(GUI Object: Web Site Image Link)
  {
    ; -------------------------------------------
    DataArray := f_099(DataArray) ; (099_1)(GUI Object: Web Site Image Link)
    ; -------------------------------------------
  } ; (099)(Web Site Image Link)
  l_142: ; (142_1)(GUI Object: HotKey Select Mouse Left)
  {
    ; -------------------------------------------
    if (DataArray.142.2 == 1) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_142", DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_142", DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (142) (HotKey Select Mouse Left)
  return
  l_143: ; (143_1)(GUI Object: HotKey Select Mouse Right)
  {
    ; -------------------------------------------
    if (DataArray.143.2 == 1) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_143", DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_143", DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (143) (HotKey Select Mouse Right)
  return
  l_144: ; (144_1)(GUI Object: HotKey Select Mouse Middle)
  {
    ; -------------------------------------------
    if (DataArray.144.2 == 1) ; (144_2)(HotKey Select Mouse Mouse Middle: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_144", DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_144", DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (144) (HotKey Select Mouse Middle)
  return
  l_145: ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
  {
    ; -------------------------------------------
    if (DataArray.145.2 == 1) ; (145_2)(HotKey Select Mouse Wheel Up: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_145", DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_145", DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (145) (HotKey Select Mouse Wheel Up)
  return
  l_146: ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
  {
    ; -------------------------------------------
    if (DataArray.146.2 == 1) ; (146_2)(HotKey Select Mouse Wheel Down: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_146", DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_146", DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (146) (HotKey Select Mouse Wheel Down)
  return
  l_147: ; (147_1)(GUI Object: HotKey Select Mouse X1)
  {
    ; -------------------------------------------
    if (DataArray.147.2 == 1) ; (147_2)(HotKey Select Mouse X1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_147", DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_147", DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (147) (HotKey Select Mouse X1)
  return
  l_148: ; (148_1)(GUI Object: HotKey Select Mouse X2)
  {
    ; -------------------------------------------
    if (DataArray.148.2 == 1) ; (148_2)(HotKey Select Mouse X2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_148", DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_148", DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (148) (HotKey Select Mouse X2)
  return
  l_149: ; (149_1)(GUI Object: HotKey Windows Key Left)
  {
    ; -------------------------------------------
    if (DataArray.149.2 == 1) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_149", DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_149", DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (149) (HotKey Windows Key Left)
  return
  l_150: ; (150_1)(GUI Object: HotKey Windows Key Right)
  {
    ; -------------------------------------------
    if (DataArray.150.2 == 1) ; (150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_150", DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_150", DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (150) (HotKey Windows Key Right)
  return
  l_151: ; (151_1)(GUI Object: HotKey Ctrl Key)
  {
    ; -------------------------------------------
    if (DataArray.151.2 == 1) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_151", DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_151", DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (151) (HotKey Ctrl Key)
  return
  l_152: ; (152_1)(GUI Object: HotKey Alt Key)
  {
    ; -------------------------------------------
    if (DataArray.152.2 == 1) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_152", DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_152", DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (152) (HotKey Alt Key)
  return
  l_153: ; (153_1)(GUI Object: HotKey Shift Key)
  {
    ; -------------------------------------------
    if (DataArray.153.2 == 1) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray := HotKey_Select_Key("v_153", DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
    }
    else
    {
      DataArray := HotKey_UnSelect_Key("v_153", DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
    }
    ; -------------------------------------------
    DataArray := HotKey_Validate(DataArray)
    ; -------------------------------------------
  } ; (153) (HotKey Shift Key)
  return
  ; ------------------------------------------- 
} ; End Gui Labels
; -------------------------------------------
{ ; #Include Lib Folder
  ; -------------------------------------------
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S1_C.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S2_H.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S3_S.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Application_Request.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Add.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_From_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_From_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Exist.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Is_In_Mult.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Position.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Replace_Item.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Reverse.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Subtract.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_To_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_to_ListBox.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Connect_Check.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ResizeToBmp.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ChopToBmp.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ToIco.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\cpl_TextFile_to_Array.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\DataArray_Set.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Default_Application.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Default_Browser.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Download_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Existing_Shortcut.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_Get.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetAll.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetPath.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetSelected.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetWindow.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Extract_Icons_From_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Find_Windows_Public_Folder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_004.ahk ; (004_1)(GUI Object: Ok Button)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_005.ahk ; (005_1)(GUI Object: Icon Rotate Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_006.ahk ; (006_1)(GUI Object: Icon Rotate Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_008.ahk ; (008_1)(GUI Object: [key] Alt)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_009.ahk ; (009_1)(GUI Object: [key] Alt Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_010.ahk ; (010_1)(GUI Object: [key] Alt Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_011.ahk ; (011_1)(GUI Object: [key] Alt Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_012.ahk ; (012_1)(GUI Object: [key] Alt Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_013.ahk ; (013_1)(GUI Object: [key] Caps Lock)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_014.ahk ; (014_1)(GUI Object: [key] Ctrl Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_015.ahk ; (015_1)(GUI Object: [key] Ctrl Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_016.ahk ; (016_1)(GUI Object: [key] Ctrl Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_017.ahk ; (017_1)(GUI Object: [key] Ctrl Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_018.ahk ; (018_1)(GUI Object: [key] Enter)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_019.ahk ; (019_1)(GUI Object: [key] Enter X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_020.ahk ; (020_1)(GUI Object: [key] Esc)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_021.ahk ; (021_1)(GUI Object: [key] Esc X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_022.ahk ; (022_1)(GUI Object: [key] F1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_023.ahk ; (023_1)(GUI Object: [key] F2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_024.ahk ; (024_1)(GUI Object: [key] F3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_025.ahk ; (025_1)(GUI Object: [key] F4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_026.ahk ; (026_1)(GUI Object: [key] F5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_027.ahk ; (027_1)(GUI Object: [key] F6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_028.ahk ; (028_1)(GUI Object: [key] F7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_029.ahk ; (029_1)(GUI Object: [key] F8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_030.ahk ; (030_1)(GUI Object: [key] F9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_031.ahk ; (031_1)(GUI Object: [key] F10)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_032.ahk ; (032_1)(GUI Object: [key] F11)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_033.ahk ; (033_1)(GUI Object: [key] F12)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_034.ahk ; (034_1)(GUI Object: [key] Numpad 0)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_035.ahk ; (035_1)(GUI Object: [key] Numpad 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_036.ahk ; (036_1)(GUI Object: [key] Numpad 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_037.ahk ; (037_1)(GUI Object: [key] Numpad 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_038.ahk ; (038_1)(GUI Object: [key] Numpad 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_039.ahk ; (039_1)(GUI Object: [key] Numpad 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_040.ahk ; (040_1)(GUI Object: [key] Numpad 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_041.ahk ; (041_1)(GUI Object: [key] Numpad 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_042.ahk ; (042_1)(GUI Object: [key] Numpad 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_043.ahk ; (043_1)(GUI Object: [key] Numpad 9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_044.ahk ; (044_1)(GUI Object: [key] Numpad Add)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_045.ahk ; (045_1)(GUI Object: [key] Numpad Divide)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_046.ahk ; (046_1)(GUI Object: [key] Numpad Dot)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_047.ahk ; (047_1)(GUI Object: [key] Numpad Enter)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_048.ahk ; (048_1)(GUI Object: [key] Numpad Multiply)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_049.ahk ; (049_1)(GUI Object: [key] Numpad Subtract)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_050.ahk ; (050_1)(GUI Object: [key] Shift)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_051.ahk ; (051_1)(GUI Object: [key] Shift Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_052.ahk ; (052_1)(GUI Object: [key] Shift Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_053.ahk ; (053_1)(GUI Object: [key] Shift Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_054.ahk ; (054_1)(GUI Object: [key] Shift Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_055.ahk ; (055_1)(GUI Object: [key] Tab)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_056.ahk ; (056_1)(GUI Object: [key] Tab X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_057.ahk ; (057_1)(GUI Object: [key] Windows Key)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_058.ahk ; (058_1)(GUI Object: [key] Windows Key Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_059.ahk ; (059_1)(GUI Object: [key] Windows Key Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_060.ahk ; (060_1)(GUI Object: [key] Windows Key Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_061.ahk ; (061_1)(GUI Object: [key] Windows Key Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_062.ahk ; (062_1)(GUI Object: Cancel)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_063.ahk ; (063_1)(GUI Object: Select Icon Image)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_064.ahk ; (064_1)(GUI Object: Reset Icon Image)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_068.ahk ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_069.ahk ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_070.ahk ; (070_1)(GUI Object: [cpl] Select Control)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_071.ahk ; (071_1)(GUI Object: [url] Select URL)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_072.ahk ; (072_1)(GUI Object: [key] Application Only)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_073.ahk ; (073_1)(GUI Object: [run] As Admin)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_074.ahk ; (074_1)(GUI Object: [key] Ctrl)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_075.ahk ; (075_1)(GUI Object: [key] Delete)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_076.ahk ; (076_1)(GUI Object: [key] End)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_077.ahk ; (077_1)(GUI Object: [key] Home)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_078.ahk ; (078_1)(GUI Object: [key] Insert)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_079.ahk ; (079_1)(GUI Object: [key] Page Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_080.ahk ; (080_1)(GUI Object: [key] Page Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_081.ahk ; (081_1)(GUI Object: [run][rwh] Select File)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_082.ahk ; (082_1)(GUI Object: [ofl] Select Folder)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_083.ahk ; (083_1)(GUI Object: [ToM] Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_084.ahk ; (084_1)(GUI Object: [ToM] File Url Folder)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_085.ahk ; (085_1)(GUI Object: [key] Select Keyboard)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_086.ahk ; (086_1)(GUI Object: [ToM] Menu Control Key)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_087.ahk ; (087_1)(GUI Object: [mnu] Select Menu)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_088.ahk ; (088_1)(GUI Object: [mnu] App Context Menu 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_089.ahk ; (089_1)(GUI Object: [mnu] App Context Menu 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_090.ahk ; (090_1)(GUI Object: [mnu] App Context Menu 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_091.ahk ; (091_1)(GUI Object: [mnu] App Context Menu 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_092.ahk ; (092_1)(GUI Object: [mnu] App Context Menu 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_093.ahk ; (093_1)(GUI Object: [mnu] App Context Menu 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_094.ahk ; (094_1)(GUI Object: [mnu] App Context Menu 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_095.ahk ; (095_1)(GUI Object: [mnu] App Context Menu 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_096.ahk ; (096_1)(GUI Object: [mnu] App Context Menu 9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_097.ahk ; (097_1)(GUI Object: [mnu] App Context Menu 10)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_098.ahk ; (098_1)(GUI Object: [mnu] App Context Menu 11)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_099.ahk ; (099_1)(GUI Object: Web Site Image Link)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_102.ahk ; (102_1)(GUI Object: Main Display Icon)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_106.ahk ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_116.ahk ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_117.ahk ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_118.ahk ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_120.ahk ; (120_1)(GUI Object: [mnu] List Center 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_121.ahk ; (121_1)(GUI Object: [mnu] List Right 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_123.ahk ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_124.ahk ; (124_1)(GUI Object: <Drop Down List> Language)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_125.ahk ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_126.ahk ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_127.ahk ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_128.ahk ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_129.ahk ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_130.ahk ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_131.ahk ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_132.ahk ; (132_1)(GUI Object: [url] Select Get URL Data)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_133.ahk ; (133_1)(GUI Object: Delete Shortcut)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_134.ahk ; (134_1)(GUI Object: Message Image 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_135.ahk ; (135_1)(GUI Object: Message Image 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_136.ahk ; (136_1)(GUI Object: Message Image 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_137.ahk ; (137_1)(GUI Object: Message Image 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_138.ahk ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_139.ahk ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_140.ahk ; (140_1)(GUI Object: [mnu] Addon Extra)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_154.ahk ; (154_1)(GUI Object: [pum] Pum Select Background)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_155.ahk ; (155_1)(GUI Object: [pum] Pum Select Display Text)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_156.ahk ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_157.ahk ; (157_1)(GUI Object: [pum] Pum Select Settings)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_158.ahk ; (158_1)(GUI Object: [pum] Pum Shortcut)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_159.ahk ; (159_1)(GUI Object: [pum] Select Custom Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_160.ahk ; (160_1)(GUI Object: [pum] Select Application Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_161.ahk ; (161_1)(GUI Object: [pum] Delete Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_165.ahk ; (165_1)(GUI Object: [pum] Backgroung Image Select)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_166.ahk ; (166_1)(GUI Object: [pum] Backgroung Color Select)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_167.ahk ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_168.ahk ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Function_Flow.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Function_Msg.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Find_Windows_Public_Folder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GetActiveBrowserURL.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GetSelected_ListNumber.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GuiControlImage_PopUpMenu.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GuiControlImage_HotKeySelect.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Gui_Text_Width.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Cancel.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Check_Selected.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Hotkey_gui.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Ok.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Select_Key.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Text_Display_Language.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_UnSelect_Key.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Validate.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Is_Script_Running.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Display.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_KeyIsIn.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Numbers.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_SelectKey.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Shortcut.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Validate.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\mnu_TextAddon_to_MenuArray.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Mouse_IsIn_Window.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Product_ID.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Close.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Run.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Reset_Vars.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Script_Close.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Select_FileFolder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Send_Email.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Shortcut_Config.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Shortcut_Info.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\SleepTime.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Splash_Script.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\String_Reverse.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_Adjust_PopUpMenu.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_Adjust_HotKeySelect.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_In_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_to_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_String_To.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_PageIcon.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_PageIcon_Title.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_URL_Address.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_HtmlCode_to_Text.ahk
  ; -------------------------------------------
} ; End #Include Lib Folder
; -------------------------------------------
