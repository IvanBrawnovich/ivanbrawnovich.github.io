; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
File_PCBenchmark  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\PC_Benchmark.txt" ; (380_5)(PC Benchmark [System Text File Path])
; -------------------------------------------
if FileExist(File_PCBenchmark) ; (380_5)(PC Benchmark [System Text File Path])
{
  FileReadLine, This_Benchmark, %File_PCBenchmark%, 1 ; (363_7)(PC Benchmark [Integer])/(380_5)(PC Benchmark [System Text File Path])
}
; -------------------------------------------
File_Benchmark_Test := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\PC_Benchmark_Temp.txt" ; (380_5)(PC Benchmark [System Text File Path])
if FileExist(File_Benchmark_Test)
{
  FileDelete, %File_Benchmark_Test%
}
; -------------------------------------------
Start_Time := A_TickCount
End_Time := 1000 + Start_Time
PcSpeed := 0 ; (363_7)(PC Benchmark [Integer])
while (A_TickCount < End_Time)
{
  PcSpeed := PcSpeed + 1 ; (363_7)(PC Benchmark [Integer])
  FileAppend, %PcSpeed%`n, %File_Benchmark_Test% ; (363_7)(PC Benchmark [Integer])
}
; -------------------------------------------
if (PcSpeed >= 10000)
{
  This_Benchmark := 1
}
else if (PcSpeed >= 5120 && PcSpeed < 10000) ; 5120 * 2 = 10240
{
  This_Benchmark := 2
}
else if (PcSpeed >= 2560 && PcSpeed < 5120) ; 2560 * 2 = 5120
{
  This_Benchmark := 3
}
else if (PcSpeed >= 1280 && PcSpeed < 2560) ; 1280 * 2 = 2560
{
  This_Benchmark := 4
}
else if (PcSpeed >= 640 && PcSpeed < 1280) ; 640 * 2 = 1280
{
  This_Benchmark := 5
}
else if (PcSpeed >= 320 && PcSpeed < 640) ; 320 * 2 = 640
{
  This_Benchmark := 6
}
else if (PcSpeed >= 160 && PcSpeed < 320) ; 160 * 2 = 320
{
  This_Benchmark := 7
}
else if (PcSpeed >= 80 && PcSpeed < 160) ; 80 * 2 = 160
{
  This_Benchmark := 8
}
else if (PcSpeed >= 40 && PcSpeed < 80) ; 40 * 2 = 80
{
  This_Benchmark := 9
}
else if (PcSpeed < 40) ; 20 * 2 = 40
{
  This_Benchmark := 10
}
; -------------------------------------------
FileDelete, %File_Benchmark_Test%
; -------------------------------------------
FileAppend, %This_Benchmark%, %File_PCBenchmark%, UTF-8 ; (363_7)(PC Benchmark [Integer])/(380_5)(PC Benchmark [System Text File Path])
