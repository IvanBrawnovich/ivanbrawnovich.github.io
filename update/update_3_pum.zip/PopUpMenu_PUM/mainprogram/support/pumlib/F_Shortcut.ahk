﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
/*  
  ; -------------------------------------------
  This file (F_Shortcut.ahk) is Located in (A_AppDataCommon \PopUpMenu_PUM\addons\ "PROCESS_NAME" \ "v_365_2" \ahk\lib\) ; (365_2)(Current User language)
  (de German)(en English)(fr French)(it Italian)(pl Polish)(pt Portuguese)(ru Russian)(es Spanish)(sv Swedish)(tr Turkish)
  ; -------------------------------------------
  LNK File is Located in (A_AppDataCommon \PopUpMenu_PUM\addons\ "PROCESS_NAME" \lnk\)
  ; -------------------------------------------
*/ ; End Info
; -------------------------------------------
F_Shortcut(v_366_5, Line2, Line3, Line4, Line5, Line6) ; (366_5)(Script Type)
{
  ; -------------------------------------------
  PassOK := 1
  ; -------------------------------------------
  { ; Set Sleep Times
    ; -------------------------------------------
    ; SleepTime(XXX) ; ThisTime <SleepThisTime := Benchmark * ThisTime>
    Wait_OflNewWin     := 100
    WaitSendEsc        := 50
    WaitSendKey        := 100
    WaitSendText       := 100
    WaitWinActive      := 100
    WaitCreateShortcut := 50
    WaitSendPath       := 50
    WaitF3Search       := 100
    WaitMnuSendKey     := 100
    WaitMnuSendText    := 100
    ; -------------------------------------------
  } ; End Set Sleep Times
  ; -------------------------------------------
  SetTitleMatchMode, 2
  ; -------------------------------------------
  DetectHiddenWindows, On
  if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Close Shortcut Gui
  {
    ; -------------------------------------------
    while GetKeyState("LButton", "P") ; User is Physical Holding Down a Key
    {
      DoNothing := 1
    } ; End User is Physical Holding Down a Key
    ; -------------------------------------------
  } ; End WinActive("PopUpMenu - Shortcut Icon") ; Shortcut Gui
  else ; Does NOT Exist Gui File Select
  {
    ; -------------------------------------------
    while GetKeyState("LButton", "P") ; User is Physical Holding Down a Key
    {
      DoNothing := 1
    }
    ; -------------------------------------------
    ; Can Not use Block Input
    ; Active Pum was not ran as Admin
    ; Thus This Script is Not ran as Admin
    ; -------------------------------------------
    { ; [GET] Current Language
     ; -------------------------------------------
      v_381_2 := A_AppData "\PopUpMenu_PUM\system\Language.txt" ; (381_2)(User Language Text File [User Text File Path])
      if FileExist(v_381_2) ; (381_2)(User Language Text File [User Text File Path])
      {
        FileReadLine, v_365_2, %v_381_2%, 1 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
        if (v_365_2 == "") ; (365_2)(Current User language)
        {
          v_365_2 := "en" ; (365_2)(Current User language)
          FileAppend, %v_365_2%`n, %v_381_2% ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
        }
      } ; End (User Language Text File) [Exist]
      else ; (User Language Text File) [NOT Exist] (Make it)
      {
        v_365_2 := "en" ; (365_2)(Current User language)
        FileAppend, %v_365_2%`n, %v_381_2% ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      } ; End (User Language Text File) [NOT Exist] (Make it)
      ; -------------------------------------------
    } ; End [GET] Current Language
    ; -------------------------------------------
    { ; [CHECK] Shortcut Errors
      ; -------------------------------------------
      PassOK := 1
      ; -------------------------------------------
      v_380_4  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Active_App.txt" ; (380_4)(Active Application [System Text File Path])
      FileReadLine, v_367_4, %v_380_4%, 3 ; (367_4)([Line 3] Active Process Class)/(380_4)(Active Application [System Text File Path])
      ; -------------------------------------------
      if (v_366_5 == "cpl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (cpl)
        ; (365_2)(Current User language)
        ; (300_2)([cpl] Menu Number #_X_[X])
        ; (300_3)([cpl] Menu Number X_#_[X])
        ; (300_4)([cpl] Menu Number X_X_[#])
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; Script_Line_2 := "#_#_(#)"            (cpl) %(365_2)%_cpl_%(300_2)%_%(300_3)%_(%(300_4)%) "XXX_XXX_(XXX)"
        ; Script_Line_3 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_4 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_5 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_6 := ""                   (cpl) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; F_Shortcut("cpl", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        Check_Lnk := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\cpl\lnk\" Line2 ".lnk" ; (363_5)(PC Installed Dir)
        Check_Ahk := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\cpl\lnk\" Line2 ".ahk" ; (363_5)(PC Installed Dir)
        if FileExist(Check_Lnk)
        {
          cplLinkRun := Check_Lnk
        }
        else if FileExist(Check_Ahk)
        {
          cplLinkRun := Check_Ahk
        }
        ; -------------------------------------------
      } ; (366_5)(Script Type) (cpl)
      ; -------------------------------------------
      else if (v_366_5 == "key") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (key)
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; Script_Line_2 := 1/2                  (key) (072_2)
        ; Script_Line_3 := ["[Key]", "~X~"]     (key) (301_8)
        ; Script_Line_4 := "App Class"          (key) (301_5)
        ; Script_Line_5 := "App Process"        (key) (301_6)
        ; Script_Line_6 := ""                   (key) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; F_Shortcut("key", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_072_2 := Line2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        v_301_8 := Line3 ; (301_8)([key] KeyArray_Shortcut [Array])
        v_301_5 := Line4 ; (301_5)([key][mnu] [Line 4] Application Only Class)
        v_301_6 := Line5 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
        ; -------------------------------------------
        if (v_072_2 == 2) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        {
          ; -------------------------------------------
          StringLower, Check_v_301_5, v_301_5 ; (301_5)([key][mnu] [Line 4] Application Only Class)
          StringLower, Check_v_367_4, v_367_4 ; (367_4)([Line 3] Active Process Class)
          ; -------------------------------------------
          if !WinExist("ahk_class" . v_301_5) ; (301_5)([key][mnu] [Line 4] Application Only Class)
          {
            ; -------------------------------------------
            PassOK := 0
            ; -------------------------------------------
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            SplashImage, Off
            if (v_301_6 != "") ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
            {
              StringLower, v_301_6, v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
              Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\addons\" v_301_6 "\" v_365_2 "\msg\NotOpen_" v_365_2 ".png" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(365_2)(Current User language)
              if !FileExist(Splash_Image)
              {
                ; (408_1)(Splash Error File: Application Not Open)
                Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\408_" v_365_2 ".png" ; (365_2)(Current User language)
              }
            }
            else
            {
              ; (429_1)(Splash Error File: Application Not Found)
              Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\429_" v_365_2 ".png" ; (365_2)(Current User language)
            }
            SplashImage, %Splash_Image%, b
            Sleep, 1500
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          } ; (301_5)([key][mnu] [Line 4] Application Only Class)
          else if (Check_v_301_5 != Check_v_367_4) ; (301_5)([key][mnu] [Line 4] Application Only Class)/(367_4)([Line 3] Active Process Class)
          {
            WinActivate, ahk_class %v_301_5% ; (301_5)([key][mnu] [Line 4] Application Only Class)
          } ; (301_5)([key][mnu] [Line 4] Application Only Class)/(367_4)([Line 3] Active Process Class)
        } ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      } ; (366_5)(Script Type) (key)
      ; -------------------------------------------
      else if (v_366_5 == "mnu") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (mnu)
        ; (302_2)([mnu] Menu Number #_X_X_[X])
        ; (302_3)([mnu] Menu Number X_#_X_[X])
        ; (302_4)([mnu] Menu Number X_X_#_[X])
        ; (302_5)([mnu] Menu Number X_X_X_[#])
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; Script_Line_2 := 2                    (mnu) (072_2) (Always Selected = 2)
        ; Script_Line_3 := "#_#_#_(#)"          (mnu) %(302_2)%_%(302_3)%_%(302_4)%_(%(302_5)%) "XXX_XXX_XXX_(XXX)"
        ; Script_Line_4 := "App Class"          (mnu) (301_5)
        ; Script_Line_5 := "App Process"        (mnu) (301_6)
        ; Script_Line_6 := "Lang"               (mnu) (365_2)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; F_Shortcut("mnu", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_072_2 := Line2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        MenuNum := Line3 ; < Used CmdType := MenuCommand.1, if (CmdType == "LNK") 
        v_301_5 := Line4 ; (301_5)([key][mnu] [Line 4] Application Only Class)
        v_301_6 := Line5 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
        AddonLang       := Line6
        ; -------------------------------------------
        StringLower, v_301_6, v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
        mnu_RunThis := A_AppDataCommon "\PopUpMenu_PUM\addons\" v_301_6 "\" v_365_2 "\lnk\" MenuNum ".ahk" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(365_2)(Current User language)
        ; -------------------------------------------
        if (v_365_2 != AddonLang) ; (365_2)(Current User language)
        {            
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (428_1)(Splash Error File: [Lang] Not Installed)
          SplashImage, Off
          Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\428_" v_365_2 ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (428_1)(Splash Error File: [Lang] Not Installed)
        }
        else if (v_072_2 == 2) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        {
          ; -------------------------------------------
          StringLower, Check_v_301_5, v_301_5 ; (301_5)([key][mnu] [Line 4] Application Only Class)
          StringLower, Check_v_367_4, v_367_4 ; (367_4)([Line 3] Active Process Class)
          ; -------------------------------------------
          if !WinExist("ahk_class" . v_301_5) ; (301_5)([key][mnu] [Line 4] Application Only Class)
          {
            ; -------------------------------------------
            PassOK := 0
            ; -------------------------------------------
            StringLower, v_301_6, v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ "This Application" Not Open
            SplashImage, Off
            Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\addons\" v_301_6 "\" v_365_2 "\msg\NotOpen_" v_365_2 ".png" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(365_2)(Current User language)
            SplashImage, %Splash_Image%, b
            Sleep, 1500
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ "This Application" Not Open
          } ; (301_5)([key][mnu] [Line 4] Application Only Class)
          else if (Check_v_301_5 != Check_v_367_4) ; (301_5)([key][mnu] [Line 4] Application Only Class)/(367_4)([Line 3] Active Process Class)
          {
            WinActivate, ahk_class %v_301_5% ; (301_5)([key][mnu] [Line 4] Application Only Class)
          } ; (301_5)([key][mnu] [Line 4] Application Only Class)/(367_4)(Active Process Class)
        } ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      } ; (366_5)(Script Type) (mnu)
      ; -------------------------------------------
      else if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (ofl)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; Script_Line_2 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_3 := "D:\Pictures"        (ofl) (303_2)
        ; Script_Line_4 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_5 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_6 := ""                   (ofl) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; F_Shortcut("ofl", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_303_2 := Line3 ; (303_2)([ofl] Folder Path)
        ; -------------------------------------------
        if !FileExist(v_303_2) ; (303_2)([ofl] Folder Path)
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (406_1)(Splash Error File: Folder Not Found)
          SplashImage, Off
          Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\406_" v_365_2 ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (406_1)(Splash Error File: Folder Not Found)
        } ; End (303_2)([ofl] Folder Path) [Not Exist]
      } ; (366_5)(Script Type) (ofl)
      ; -------------------------------------------
      else if (v_366_5 == "run") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (run)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        ; Script_Line_3 := "E:\Application.exe" (run) (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        ; Script_Line_4 := ""                   (run) *** EMPTY ***
        ; Script_Line_5 := ""                   (run) *** EMPTY ***
        ; Script_Line_6 := ""                   (run) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; F_Shortcut("run", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_073_2 := Line2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        v_305_4 := Line3 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        ; -------------------------------------------
        if !FileExist(v_305_4) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (429_1)(Splash Error File: Application Not Found)
          SplashImage, Off
          Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\429_" v_365_2 ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (429_1)(Splash Error File: Application Not Found)
        } ; End (305_4)([File Name] [File Ext] [File Path]) [Not Exist]
      } ; (366_5)(Script Type) (run)
      ; -------------------------------------------
      else if (v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (rwh)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        ; Script_Line_3 := "E:\FilePath.EXT"    (rwh) (305_4)([File Name] [File Ext] [File Path])
        ; Script_Line_4 := "C:\Application.exe" (rwh) (305_5)(Selected Opening Application [Full File Path])
        ; Script_Line_5 := ""                   (rwh) *** EMPTY ***
        ; Script_Line_6 := ""                   (rwh) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; F_Shortcut("rwh", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_073_2 := Line2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        v_305_4 := Line3 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        v_305_5 := Line4 ; (305_5)([rwh] Selected Opening Application [Full File Path])
        ; -------------------------------------------
        if !FileExist(v_305_4) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (411_1)(Splash Error File: File Not Found)
          SplashImage, Off
          Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\411_" v_365_2 ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (411_1)(Splash Error File: File Not Found)
        } ; End (305_4)([File Name] [File Ext] [File Path]) [Not Exist]
        else if !FileExist(v_305_5) ; (305_5)([rwh] Selected Opening Application [Full File Path])
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (421_1)(Splash Error File: Application to Open File Not Found)
          SplashImage, Off
          Splash_Image := A_AppDataCommon "\PopUpMenu_PUM\splash\421_" v_365_2 ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (421_1)(Splash Error File: Application to Open File Not Found)
        } ; End (305_5)(Selected Opening Application [Full File Path]) [Not Exist]
        ; -------------------------------------------
      } ; (366_5)(Script Type) (rwh)
      ; -------------------------------------------
      else if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (url)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; Script_Line_2 := 0/1                  (url) (307_7)([url] Use Default Browser [0/1])
        ; Script_Line_3 := "https://Site.com/"  (url) (307_2)([url] Current URL)
        ; Script_Line_4 := "C:\Browser.exe"     (url) (307_5)([url] Opening Browser [Full File Path])
        ; Script_Line_5 := ""                   (url) *** EMPTY ***
        ; Script_Line_6 := ""                   (url) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; F_Shortcut("url", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_307_7 := Line2 ; (307_7)([url] Use Default Browser [0/1])
        v_307_2 := Line3 ; (307_2)([url] Current URL)
        v_307_5 := Line4 ; (307_5)([url] Selected Opening Browser [Full File Path])
        UrlTitle := Line5 ; (Not Tracked in DataArray)
      } ; (366_5)(Script Type) (url)
      ; -------------------------------------------
    } ; End [CHECK] Shortcut Errors
    ; ------------------------------------------
    if (PassOK == 1)
    {
      ; -------------------------------------------
      { ; Close any Active Pum and Active Disable Script
        ; -------------------------------------------
        DetectHiddenWindows, On
        WinClose, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Disable_PumActive.ahk ahk_class AutoHotkey ; (363_5)(PC Installed Dir)
        ; -------------------------------------------
        if WinExist("ahk_class TfrmToolbox") ; Close PUM to Run ShortCut
        {
          WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
          IfInString, PumProcess, pum_
          {
            Process, Close, %PumProcess%
          } ; End IfInString, PumProcess, pum_
        } ; End if WinExist("ahk_class TfrmToolbox")
        ; -------------------------------------------
      } ; End Close any Active Pum and Active Disable Script
      ; -------------------------------------------
      if (v_366_5 == "cpl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (cpl)
        ; (300_2)([cpl] Menu Number #_X_[X])
        ; (300_3)([cpl] Menu Number X_#_[X])
        ; (300_4)([cpl] Menu Number X_X_[#])
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; Script_Line_2 := "#_#_(#)"            (cpl) %(365_2)%_cpl_%(300_2)%_%(300_3)%_(%(300_4)%) "XXX_XXX_(XXX)"
        ; Script_Line_3 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_4 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_5 := ""                   (cpl) *** EMPTY ***
        ; Script_Line_6 := ""                   (cpl) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; F_Shortcut("cpl", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        Run, %cplLinkRun%
      } ; End (366_5)(Script Type) (cpl)
      ; -------------------------------------------
      else if (v_366_5 == "key") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (key)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; Script_Line_2 := 1/2                  (key) (072_2)
        ; Script_Line_3 := ["[Key]", "~X~"]     (key) (301_8)
        ; Script_Line_4 := "App Class"          (key) (301_5)
        ; Script_Line_5 := "App Process"        (key) (301_6)
        ; Script_Line_6 := ""                   (key) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; F_Shortcut("key", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        for Index, ThisItem in v_301_8 ; (301_8)([key] KeyArray_Shortcut [Array])
        {
          { ; [SET] KeyType (KEY -or- TEXT)
            CheckThis := SubStr(ThisItem, 1, 1)
            if (CheckThis == "[")
            {
              KeyType := "KEY"
            } ; End (CheckThis == "[")
            else if (CheckThis == "~")
            {
              KeyType := "TEXT"
            } ; End (CheckThis == "~")
            ThisKey := SubStr(ThisItem, 2, StrLen(ThisItem) - 2) 
            if (KeyType == "KEY")
            {
              SleepTime(SendKeyWait)
              Send, {%ThisKey%}
            } ; End (KeyType == "KEY")
            else if (KeyType == "TEXT")
            {
              SleepTime(WaitSendText)
              Send, %ThisKey%
            } ; End (KeyType == "TEXT")
          } ; End [SET] KeyType (KEY -or- TEXT)
        } ; (301_8)([key] KeyArray_Shortcut [Array])
      } ; (366_5)(Script Type) (key)
      ; ------------------------------------------
      else if (v_366_5 == "mnu") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (mnu)
        ; (302_2)([mnu] Menu Number #_X_X_[X])
        ; (302_3)([mnu] Menu Number X_#_X_[X])
        ; (302_4)([mnu] Menu Number X_X_#_[X])
        ; (302_5)([mnu] Menu Number X_X_X_[#])
        ; -------------------------------------------
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; Script_Line_2 := 2                    (mnu) (072_2) (Always Selected = 2)
        ; Script_Line_3 := "#_#_#_(#)"          (mnu) %(302_2)%_%(302_3)%_%(302_4)%_(%(302_5)%) "XXX_XXX_XXX_(XXX)"
        ; Script_Line_4 := "App Class"          (mnu) (301_5)
        ; Script_Line_5 := "App Process"        (mnu) (301_6)
        ; Script_Line_6 := "Lang"               (mnu) (365_2)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; F_Shortcut("mnu", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        Run, %mnu_RunThis%
        ; -------------------------------------------
      } ; (366_5)(Script Type) (mnu)
      ; -------------------------------------------
      else if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (ofl)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; Script_Line_2 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_3 := "D:\Pictures"        (ofl) (303_2)
        ; Script_Line_4 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_5 := ""                   (ofl) *** EMPTY ***
        ; Script_Line_6 := ""                   (ofl) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; F_Shortcut("ofl", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        v_303_2 := Line3 ; (303_2)([ofl] Folder Path)
        ; -------------------------------------------
        ifWinActive, ahk_class CabinetWClass ; Explorer is Active
        {
          OldClip := Clipboard
          Clipboard := ""
          WinActivate, ahk_class CabinetWClass
          WinWait, ahk_class CabinetWClass
          SleepTime(WaitWinActive)
          SendInput, {Ctrl down}
          SendInput, l
          SendInput, {Ctrl up}
          SendInput, {Home}
          SendInput, {Shift Down}{End}{Shift Up}
          SendInput, {Ctrl Down}c{Ctrl Up}
          ClipWait,,1
          ThisClip := Clipboard
          if (ThisClip != Folder)
          {
            Sleep, 100
            SleepTime(WaitSendPath)
            SendInput, %v_303_2% ; (303_2)([ofl] Folder Path)
            SendInput, {Enter}
          } ; End if (ThisClip != Folder)
          else ; (ThisClip == Folder)
          {
            Send, {Tab 3}
          } ; End (ThisClip == Folder)
          Clipboard := OldClip
        } ; End ifWinActive, ahk_class CabinetWClass
        ; -------------------------------------------
        else ifWinExist, ahk_class CabinetWClass  ; Explorer Exist
        {
          OldClip := Clipboard
          Clipboard := ""
          WinActivate, ahk_class CabinetWClass
          WinWait, ahk_class CabinetWClass
          SendInput, {Ctrl down}
          SendInput, l
          SendInput, {Ctrl up}
          SendInput, {Home}
          SendInput, {Shift Down}{End}{Shift Up}
          SendInput, {Ctrl Down}c{Ctrl Up}
          ClipWait,,1
          ThisClip := Clipboard
          if (ThisClip != Folder)
          {
            SleepTime(100)
            SendInput, %v_303_2% ; (303_2)([ofl] Folder Path)
            SendInput, {Enter}
          } ; End if (ThisClip != Folder)
          else ; (ThisClip == Folder)
          {
            Send, {Tab 3}
          } ; End (ThisClip == Folder)
          Clipboard := OldClip
        } ; End else ifWinExist, ahk_class CabinetWClass
        ; -------------------------------------------
        else ; Explorer is Not Active, Does Not Exist
        {
          Send, {LWin Down}e{LWin Up}
          SleepTime(100)
          WinWait, ahk_class CabinetWClass
          SendInput, {Ctrl down}
          SendInput, l
          SendInput, {Ctrl up}
          SendInput, {Home}
          SendInput, {Shift Down}{End}{Shift Up}
          Sleep, 100
          SleepTime(WaitSendPath)
          SendInput, %v_303_2% ; (303_2)([ofl] Folder Path)
          SendInput, {Enter}
        } ; End else
        ; -------------------------------------------
      } ; (366_5)(Script Type) (ofl)
      ; -------------------------------------------
      else if (v_366_5 == "run") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (run)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        ; Script_Line_3 := "E:\Application.exe" (run) (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        ; Script_Line_4 := ""                   (run) *** EMPTY ***
        ; Script_Line_5 := ""                   (run) *** EMPTY ***
        ; Script_Line_6 := ""                   (run) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; F_Shortcut("run", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        SetTitleMatchMode, 2
        if WinExist("ahk_exe" . v_305_4) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        {
          ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath,  v_305_4, , , , ThisApp ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
          WinGet, id, list,,, Program Manager
          lookfor_class=%ThisApp% ;replace with the class you need
          Loop, %id%
          {
            this_id := id%A_Index%
            WinGetClass, this_class, ahk_id %this_id%
            if (this_class = lookfor_class)
            {
              Winactivate,ahk_id%this_id%  
              WinGetTitle, this_title, ahk_id %this_id%
              Test_Class := this_class
              Test_Id := this_id
              Test_Title := this_title
            }
          }
          ; -------------------------------------------
          ifWinActive, ahk_exe %v_305_4% ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
          {
            DoNothing := 1
          }
          else
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              Run, *RunAs %v_305_4% ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
            } ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            else
            {
              Run, %v_305_4% ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
            } ; End else
          }
        }
        else
        {
          if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            Run, *RunAs %v_305_4% ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
          } ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          else
          {
            Run, %v_305_4% ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
          } ; End else
        }
      } ; (366_5)(Script Type) (run)
      ; -------------------------------------------
      else if (v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (rwh)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        ; Script_Line_3 := "E:\FilePath.EXT"    (rwh) (305_4)([File Name] [File Ext] [File Path])
        ; Script_Line_4 := "C:\Application.exe" (rwh) (305_5)(Selected Opening Application [Full File Path])
        ; Script_Line_5 := ""                   (rwh) *** EMPTY ***
        ; Script_Line_6 := ""                   (rwh) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; F_Shortcut("rwh", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, v_305_4, ThisTitle ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        SetTitleMatchMode, 2
        if WinExist(ThisTitle)
        {
          WinActivate, %ThisTitle%
        }
        else
        {
          ; -------------------------------------------
          v_305_5 := """" v_305_5 """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
          v_305_4 := """" v_305_4 """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
          ; -------------------------------------------
          if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            Run, *RunAs %v_305_5% %v_305_4% ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_4)([run] Selected File [File Name] [File Ext] [File Path])
          } ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          else
          {
            Run, %v_305_5% %v_305_4% ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_4)([run] Selected File [File Name] [File Ext] [File Path])
          } ; End else
        }
      } ; (366_5)(Script Type) (rwh)
      ; -------------------------------------------
      else if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; (url)
        ; -------------------------------------------
        ; #NoTrayIcon
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; Script_Line_2 := 0/1                  (url) (307_7)([url] Use Default Browser [0/1])
        ; Script_Line_3 := "https://Site.com/"  (url) (307_2)([url] Current URL)
        ; Script_Line_4 := "C:\Browser.exe"     (url) (307_5)([url] Opening Browser [Full File Path])
        ; Script_Line_5 := ""                   (url) *** EMPTY ***
        ; Script_Line_6 := ""                   (url) *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; F_Shortcut("url", Line2, Line3, Line4, Line5, Line6)
        ; ExitApp
        ; -------------------------------------------
        Run, %v_307_5% %v_307_2% ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_2)([url] Current URL)
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, v_307_5 , FileNameExt ; (307_5)([url] Selected Opening Browser [Full File Path])
        WinGetClass, This_Class, ahk_exe %FileNameExt%
        WinActivate, ahk_class %This_Class%
        ; -------------------------------------------
      } ; (366_5)(Script Type) (url)
      ; -------------------------------------------                        
    } ; End No Shortcut Error
  } ; End Does NOT Exist Gui File Select
} ; (366_5)(Script Type)
; -------------------------------------------
ExitApp
