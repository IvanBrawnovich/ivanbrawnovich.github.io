﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
ActivateExe_TxtFile := A_ScriptDir "\ActivateExe.txt"
if FileExist(ActivateExe_TxtFile)
{
  FileReadLINE, ThisExe, %ActivateExe_TxtFile%, 1
  if WinExist("ahk_exe " ThisExe)
  {
    SetTitleMatchMode, 2
    WinActivate, ahk_exe %ThisExe%
  }
  FileDelete, %ActivateExe_TxtFile%
}
