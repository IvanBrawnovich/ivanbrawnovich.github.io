﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
ActivateTitle_TxtFile := A_ScriptDir "\ActivateTitle.txt"
if FileExist(ActivateTitle_TxtFile)
{
  FileReadLINE, ThisTitle, %ActivateTitle_TxtFile%, 1
  if WinExist(ThisTitle)
  {
    SetTitleMatchMode, 2
    WinActivate, %ThisTitle%
  }
  FileDelete, %ActivateTitle_TxtFile%
}
