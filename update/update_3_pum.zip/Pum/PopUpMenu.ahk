﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Splash_Script("500", 0) ; Var_Number_Error
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; -------------------------------------------
Pc_TxtFile_UserHotKey := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
if FileExist(Pc_TxtFile_UserHotKey) ; (381_3)(User HotKey Text File [User Text File Path])
{
  ; -------------------------------------------
  Current_UserHotKey := "" ; (369_2)(Current User Hotkey)
  Pc_TxtFile_UserHotKey  := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
  FileReadLine, Current_UserHotKey, %Pc_TxtFile_UserHotKey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
  ; -------------------------------------------
  if (Current_UserHotKey == "") ; (369_2)(Current User Hotkey)
  {
    Splash_Script("Off", 0)
    Hotkey_gui(DataArray) ; DataArray
  } ; HasUserHotKey Has No Value
  else ; HasUserHotKey OK
  {
    HasUserHotKey := 1
  } ; End HasUserHotKey OK
} ; (381_3)(User HotKey Text File [User Text File Path])
else ; (381_3)(User HotKey Text File [User Text File Path])
{
  Splash_Script("Off", 0)
  Hotkey_gui(DataArray) ; DataArray
} ; (381_3)(User HotKey Text File [User Text File Path])
; -------------------------------------------
if (HasUserHotKey == 1)
{
  ; -------------------------------------------
  Run, *RunAs %A_ScriptDir%\Lib\HasAdminRights.ahk
  File_HasAdminRights := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\HasAdminRights.txt"
  End_Time := A_TickCount + 1000
  while !FileExist(File_HasAdminRights) && A_TickCount < End_Time
  {
  }
  if FileExist(File_HasAdminRights)
  {
    FileReadLine, HasAdminRights, %File_HasAdminRights%, 1
  }
  ; -------------------------------------------
  if (HasAdminRights == 1)
  {
    Run, *RunAs %A_ScriptDir%\Lib\StartUp_StandAlone.ahk
  }
  ; -------------------------------------------
  Run, %A_ScriptDir%\Lib\Copy_Pum_Lib.ahk
  ; -------------------------------------------
  HotKey_AppSpicific := A_ScriptDir "\Lib\HotKey_AppSpicific.ahk" ; (384_7)(HotKey_AppSpicific [Script File Path])/(363_5)(PC Installed Dir)
  if FileExist(HotKey_AppSpicific) ; (384_7)(HotKey_AppSpicific [Script File Path])
  {
    ; HotKeys (App Spicific)
    ; Stand Alone Script
    ; Hidden Window
    Run, %HotKey_AppSpicific% ; (384_7)(HotKey_AppSpicific [Script File Path])
  }
  ; -------------------------------------------
  ; Visable in Tray / Shortcut GUI
  ; Stand Alone Script
  Ahk_PUM := A_ScriptDir "\Lib\PUM.ahk" ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])/(363_5)(PC Installed Dir)
  Run, %Ahk_PUM%,,, Script_Ahk_PUM ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  Process, Priority, %Script_Ahk_PUM%, High ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  ; -------------------------------------------
  while (Is_Script_Running(Ahk_PUM) == 0)
  {
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
} ; End else if (HasUserHotKey == 1) ; User Hot Key is Set
; -------------------------------------------
