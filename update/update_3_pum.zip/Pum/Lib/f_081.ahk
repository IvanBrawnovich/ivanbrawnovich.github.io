﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select File
; -------------------------------------------
f_081(DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
{
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; -------------------------------------------
  { ; Quick Select
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("081", 2, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
    DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
    DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
    ; -------------------------------------------
  } ; End Quick Select
  ; -------------------------------------------
  Selected_File := Select_FileFolder(v_365_2, "FileAppFile") ; (365_2)(Current User language)
  ; -------------------------------------------
  if (Selected_File != "")
  {
    ; -------------------------------------------
    IfInString, Selected_File, %A_ScriptDir%
    {
      Selected_File := ""
    } ; End IfInString, ThisFile, %A_ScriptDir%
    else
    {
      ; -------------------------------------------
      SplitPath, Selected_File , , , Check_Selected_File_Ext
      ;
      if (Check_Selected_File_Ext == "lnk")
      {
        FileGetShortcut, %Selected_File%, Selected_File
      }
      ; -------------------------------------------
    }
  } ; End (Selected_File != "")
  ; -------------------------------------------
  if (Selected_File != "")
  {
    ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, Selected_File , , , Check_Selected_File_Ext
    ;
    if (Check_Selected_File_Ext == "lnk")
    {
      ; FileGetShortcut, LinkFile , OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
      FileGetShortcut, %Selected_File%, Selected_File ; (305_5)(Selected Opening Application [Full File Path])
    }
    ; -------------------------------------------
    v_305_4 := Selected_File ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    ; -------------------------------------------
    ; (Value) (Modify)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_305_4, v_305_3, v_305_9, v_305_10, v_305_2, ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])/(305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])/(305_10)([run] Selected File [File Ext] WithOut [.])/(305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
    ; -------------------------------------------
    v_305_9 := v_305_9 "\" ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
    StringLower, v_305_10, v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
    ; ------------------------------------------
    DataArray.305.2 := v_305_2 ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
    DataArray.305.3 := v_305_3 ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
    DataArray.305.4 := v_305_4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    DataArray.305.9 := v_305_9 ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
    DataArray.305.10 := v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
    ; -------------------------------------------
    if (v_305_10 == "url" or v_305_10 == "htm" or v_305_10 == "html") ; (305_10)([run] Selected File [File Ext] WithOut [.])
    {
      ; -------------------------------------------
      ThisTime := A_TickCount
      BreakTime := ThisTime + 1000
      LineNum := 0
      ; -------------------------------------------
      Loop ; Infinite Loop
      {
        ; -------------------------------------------
        ; Check Url Shortcut for Url Address
        ; -------------------------------------------
        ThisTime := A_TickCount
        if (BreakTime == ThisTime)
        {
          break
        }
        ; -------------------------------------------
        LineNum := LineNum + 1
        ; -------------------------------------------
        FileReadLine, Ck_URL, %v_305_4%, LineNum ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        ; -------------------------------------------
        ThisLen := StrLen(Ck_URL)
        if (ThisLen == 0 or !Ck_URL)
        {
          break
        } ; End (ThisLen == 0 or !Ck_URL)
        else
        {
          CK_Pos := InStr(Ck_URL, "URL=")
          if (CK_Pos > 0)
          {
            v_307_2 := StrReplace(Ck_URL, "URL=", "") ; (307_2)([url] Current URL)
            break
          } ; End (CK_Pos > 0)
        }
      } ; End Infinite Loop
      if (v_307_2 != "") ; (307_2)([url] Current URL)
      {
        DataArray.366.5 := "url" ; (366_5)(Script Type)
        GuiControl, PopUpMenu:, g_131, %v_307_2% ; (307_2)([url] Current URL)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
        DataArray.307.2 := v_307_2 ; (307_2)([url] Current URL)
        DataArray := url_Get_PageIcon_Title(DataArray)
      }
    } ; (305_10)([File Ext] WithOut [.])
    ; -------------------------------------------
    else if (v_305_10 != "url" && v_305_10 != "htm" && v_305_10 != "html") ; (305_10)([run] Selected File [File Ext] WithOut [.])
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Value) 
      ; (ScriptType) 
      if (v_305_10 == "exe") ; (305_10)([run] Selected File [File Ext] WithOut [.])
      {
        DataArray.366.5 := "run" ; (366_5)(Script Type)
        DataArray.73.2 := 1 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      } ; (305_10)([File Ext] WithOut [.])
      else if (v_305_10 != "exe") ; (305_10)([run] Selected File [File Ext] WithOut [.])
      {
        DataArray.366.5 := "rwh" ; (366_5)(Script Type)
        DataArray.73.2 := 1 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        DataArray.305.5 := "" ; (305_5)([rwh] Selected Opening Application [Full File Path])
        DataArray.305.6 := "" ; (305_6)([rwh] Default Application [Full File Path])
      } ; (305_10)([File Ext] WithOut [.])
      ; -------------------------------------------
      DataArray.122.3 := v_305_2 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      ; -------------------------------------------
    } ; (305_10)([File Ext] WithOut [.])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; End (Selected_File != "")
  ; -------------------------------------------
  else ; (Selected_File == "")
  {
    ; -------------------------------------------
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick UnSelect
      ; -------------------------------------------
      if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("081", 2, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      ; -------------------------------------------
      if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("071", 2, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      ; -------------------------------------------
      if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("082", 2, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      ; -------------------------------------------
    } ; End Quick UnSelect
  } ; End (Selected_File == "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
