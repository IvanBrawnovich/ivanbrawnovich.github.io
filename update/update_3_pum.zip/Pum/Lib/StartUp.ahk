﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_DownloadFile(ThisUrl, ThisFile) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
{
  ; -------------------------------------------
  URLDownloadToFile, %ThisUrl%, %ThisFile%
  ; -------------------------------------------
  if FileExist(ThisFile)
  {
    FileReadLine, LineOne, %ThisFile%, 1 ; Number of the Last Update that was ran
    if (InStr(LineOne, "DOCTYPE") > 0) ; (Line 1 Github 404 page) <!DOCTYPE html>
    {
      FileOK := 0
      FileDelete, %ThisFile%
    }
    else
    {
      FileOK := 1
    }
  } ; End FileExist(ThisFile)
  else
  {
    FileOK := 0
  } ; End !FileExist(ThisFile)
  ; -------------------------------------------
  return FileOK
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_CheckForUpdate(UpdateType) ; UpdateType = (pum / "Process Name"_"Lang" / icons) > ThisUpdate_Array
{
  ; -------------------------------------------
  StringLower, UpdateType, UpdateType
  ; -------------------------------------------
  ; UpdateType = pum / "Addon App Name"_"Lang" / icons
  ; -------------------------------------------
  Url_Folder_Link        := "https://popupmenu.github.io/update/link"
  Url_File_CurrentUpdate := "https://popupmenu.github.io/update/current_" UpdateType ".txt"
  ; -------------------------------------------
  Pc_File_CurrentUpdate := A_AppDataCommon "\PopUpMenu_PUM\update\current_" UpdateType ".txt"
  Pc_File_LastUpdate := A_AppDataCommon "\PopUpMenu_PUM\update\last_" UpdateType ".txt"
  ; -------------------------------------------
  Pc_Folder_Update              := A_AppDataCommon "\PopUpMenu_PUM\update"
  Pc_Folder_UpdateLink          := A_AppDataCommon "\PopUpMenu_PUM\update\link"
  Pc_Folder_UpdateDownloadedZip := A_AppDataCommon "\PopUpMenu_PUM\update\downloaded_zip"
  Pc_Folder_UpdateUnZipped      := A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip"
  ; -------------------------------------------
  { ; Check / Create Folders
    ; -------------------------------------------
    if !FileExist(Pc_Folder_Update) ; A_AppDataCommon "\PopUpMenu_PUM\update"
    {
      FileCreateDir, %Pc_Folder_Update%
    }
    if !FileExist(Pc_Folder_UpdateLink) ; A_AppDataCommon "\PopUpMenu_PUM\update\link"
    {
      FileCreateDir, %Pc_Folder_UpdateLink%
    }
    if !FileExist(Pc_Folder_UpdateDownloadedZip) ; A_AppDataCommon "\PopUpMenu_PUM\update\downloaded_zip"
    {
      FileCreateDir, %Pc_Folder_UpdateDownloadedZip%
    }
    if !FileExist(Pc_Folder_UpdateDownloadedZip) ; A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip"
    {
      FileCreateDir, %Pc_Folder_UpdateUnZipped%
    }
    ; -------------------------------------------
  } ; End Check / Create Folders
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; -------------------------------------------
  ; If Pc_TxtFile_LastUpdate Does Not exist
  ; Create one Starting at 0 
  ; -------------------------------------------
  if !FileExist(Pc_File_LastUpdate) ; A_AppDataCommon "\PopUpMenu_PUM\update\last_" UpdateType ".txt"
  {
    FileAppend, 0`n, %Pc_File_LastUpdate%, UTF-8
  } ; End !FileExist(Pc_TxtFile_LastUpdate)
  ; -------------------------------------------
  Downloaded_OK := StartUp_DownloadFile(Url_File_CurrentUpdate, Pc_File_CurrentUpdate) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  if (Downloaded_OK == 1) ; (Current Update File) [Downloaded OK] > [Read] (Last Update File)
  {
    ; -------------------------------------------
    FileReadLine, CurrentUpdate, %Pc_File_CurrentUpdate%, 1 ;
    FileReadLine, LastUpdate, %Pc_File_LastUpdate%, 1 ;
    ; -------------------------------------------
    if (CurrentUpdate > LastUpdate) ; Splash Image
    {
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (501_1)(Splash Info File: PopUpMenu Updating)
      StartUp_SplashScript("501", 0) ; (501_1)(Splash Info Script File: PopUpMenu Updating)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
    } ; (CurrentUpdate > LastUpdate) ; Splash Image
    ; -------------------------------------------
    while (CurrentUpdate > LastUpdate) ; while there is a Update
    {
      ; -------------------------------------------
      ThisUpdate := LastUpdate + 1
      ; -------------------------------------------
      Url_File_UpdateDownloadLink := Url_Folder_Link "/link_" ThisUpdate "_" UpdateType ".txt"
      Pc_File_UpdateDownloadLink := Pc_Folder_UpdateLink "\link.txt"
      ; -------------------------------------------
      Downloaded_OK := StartUp_DownloadFile(Url_File_UpdateDownloadLink, Pc_File_UpdateDownloadLink) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
      ; -------------------------------------------
      if (Downloaded_OK == 1) ; (Link File) [Downloaded OK] > [Read] (Downloaded Link File) / [Download] (Update Zip File)
      {
        ; -------------------------------------------
        FileReadLine, UpdateDownloadLink, %Pc_File_UpdateDownloadLink%, 1
        Pc_File_UpdateDownloadedZip := Pc_Folder_UpdateDownloadedZip "\update.zip"
        Downloaded_OK := StartUp_DownloadFile(UpdateDownloadLink, Pc_File_UpdateDownloadedZip) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
        if (Downloaded_OK == 1) ; (Update Zip File) [Downloaded OK] > [UnZip] (Update Zip File)
        {
          ; -------------------------------------------
          ; Pc_File_UpdateDownloadedZip := A_AppDataCommon "\PopUpMenu_PUM\update\downloaded_zip\update.zip"
          ; Pc_Folder_UpdateUnZipped    := A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip"
          StartUp_UnZip(Pc_File_UpdateDownloadedZip, Pc_Folder_UpdateUnZipped) ; ZipFile, UnZipDir
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Icons" Folder
          Pc_Folder_UnZipped_Icon := Pc_Folder_UpdateUnZipped "\Icons" ; A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip\Icons"
          if FileExist(Pc_Folder_UnZipped_Icon) ; Check if Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_Folder_UnZipped_Icon
            MoveHere := StartUp_WinPubFolder("Pictures", 0) ; Folder, Public [ 0/1] > FoundFolder
            ; -------------------------------------------
            if FileExist(MoveHere) ; Folder Exist
            {
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
            } ; End FileExist(MoveHere)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Icons" Folder
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Addon" Folder
          Pc_Folder_UnZipped_Addon := Pc_Folder_UpdateUnZipped "\Addon" ; A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip\Addon"
          if FileExist(Pc_Folder_UnZipped_Addon) ; Check if Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_Folder_UnZipped_Addon
            MoveHere := A_AppDataCommon
            ; -------------------------------------------
            if FileExist(MoveHere) ; Folder Exist
            {
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
            } ; End FileExist(MoveHere)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Addon" Folder
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Pum\PopUpMenu_PUM"
          Pc_Folder_UnZipped_PumAppDataCommon := Pc_Folder_UpdateUnZipped "\Pum\PopUpMenu_PUM" ; A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip\Pum\PopUpMenu_PUM"
          if FileExist(Pc_Folder_UnZipped_PumAppDataCommon) ; Check if Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_Folder_UnZipped_PumAppDataCommon
            MoveHere := A_AppDataCommon
            if FileExist(MoveHere) ; Folder Exist
            {
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
            } ; End FileExist(MoveHere_1)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Pum\PopUpMenu_PUM"
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Pum"
          Pc_Folder_UnZipped_Pum := Pc_Folder_UpdateUnZipped "\Pum" ; A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip\Pum"
          if FileExist(Pc_Folder_UnZipped_Pum) ; Check if Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_Folder_UnZipped_Pum
            MoveHere := StrReplace(A_ScriptDir, "\Lib", "")
            if FileExist(MoveHere) ; Folder Exist
            {
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
            } ; End FileExist(MoveHere_1)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped  "\Pum"
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          LastUpdate := LastUpdate + 1
          FileDelete, %Pc_File_LastUpdate%
          Sleep, 500
          FileAppend, %LastUpdate%, %Pc_File_LastUpdate%, UTF-8
          This_Update := [UpdateType, LastUpdate, ThisUpdate]
          ThisUpdate_Array := StartUp_ArrayAdd(ThisUpdate_Array, This_Update, "End") ; ThisArray, AddThis, ThisPos > ThisArray
          ; -------------------------------------------
          FileDelete, %Pc_File_UpdateDownloadLink% ; [Delete] (Link File)
          FileDelete, %Pc_File_UpdateDownloadedZip% ; [Delete] (Update Zip File)
          ; -------------------------------------------
        } ; End (Update Zip File) [Downloaded OK] > [UnZip] (Update Zip File)
        else ; (Update Zip File) [Downloaded FAILED] > [Delete] (Link File) / [Delete] (Update Zip File) / [Break] (while (CurrentUpdate > LastUpdate))
        {
          ; -------------------------------------------
          FileDelete, %Pc_File_UpdateDownloadLink% ; [Delete] (Link File)
          ; -------------------------------------------
          if FileExist(Pc_File_UpdateDownloadedZip)
          {
            FileDelete, %Pc_File_UpdateDownloadedZip% ; [Delete] (Update Zip File)
          }
          break
          ; -------------------------------------------
        } ; End (Update Zip File) [Downloaded FAILED] > [Delete] (Link File) / [Delete] (Update Zip File) / [Break] (while (CurrentUpdate > LastUpdate))
        ; -------------------------------------------
      } ; End  ; (Update Zip File) [Downloaded FAILED] > [Delete] (Link File) / [Delete] (Update Zip File) / [Break] (while (CurrentUpdate > LastUpdate))
      else ; (Link File) [Downloaded FAILED] > [Read] (Downloaded Link File) / [Break] (while (CurrentUpdate > LastUpdate))
      {
        ; -------------------------------------------
        if FileExist(Pc_File_UpdateDownloadLink)
        {
          FileDelete, %Pc_File_UpdateDownloadLink% ; [Delete] (Link File)
        }
        break
        ; -------------------------------------------
      } ; End  ; (Link File) [Downloaded FAILED] > [Read] (Downloaded Link File) / [Break] (while (CurrentUpdate > LastUpdate))
      ; -------------------------------------------
    } ; End While (CurrentUpdate > LastUpdate)
    ; -------------------------------------------
    FileDelete, %Pc_File_CurrentUpdate%
    ; -------------------------------------------
  } ; End  ; (Current Update File) [Downloaded OK] > [Read] (Last Update File)
  else ; (Current Update File) [Downloaded FAILED] > [Delete] (Current Update File)
  {
    ; -------------------------------------------
    if FileExist(Pc_File_CurrentUpdate)
    {
      FileDelete, %Pc_File_CurrentUpdate% ; [Delete] (Current Update File)
    }
    ; -------------------------------------------
  } ; End (Current Update File) [Downloaded FAILED] > [Delete] (Current Update File)
  ; -------------------------------------------
  return ThisUpdate_Array
  ; -------------------------------------------
} ; End StartUp_CheckForUpdate(UpdateType)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_Benchmark() ; > Integer_PcBenchmark
{
  ; -------------------------------------------
  TxtFile_PcBenchmark := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\PC_Benchmark.txt"
  TxtTestFile_PcBenchmark := A_AppDataCommon "\PopUpMenu_PUM\temp\Test_PC_Benchmark.txt"
  ; -------------------------------------------
  if FileExist(TxtFile_PcBenchmark)
  {
    FileDelete, %TxtFile_PcBenchmark%
  }
  if FileExist(TxtTestFile_PcBenchmark)
  {
    FileDelete, %TxtTestFile_PcBenchmark%
  }
  ;
  ; -------------------------------------------
  StartTime := A_TickCount
  ; -------------------------------------------
  ;
  ; ------------------------------------------- 
  Factor := 12.29 ; Average Return BenchMark is 1000 as of (11-Nov-2020)
  ; -------------------------------------------
  WriteNum := Factor * 4.4 
  ReadNum := Factor * 5.6 
  MathNum := Factor * 60000
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [START] Write
  WriteLine := "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890`n"
  Loop, %WriteNum%
  {
    FileAppend, %WriteLine%, %TxtTestFile_PcBenchmark%,
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [END] Write
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [START] READ
  Loop %ReadNum%
  {
    LineNum := 0
    Loop, %WriteNum%
    {
      LineNum := LineNum + 1
      FileReadLine, ThisLine, %TxtTestFile_PcBenchmark%, LineNum
    } ; End Loop, %WriteNum%
  } ; End Loop %ReadNum%
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [END] READ  
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [START] Math
  MathLow := 1
  MathHigh := 1000000
  ; -------------------------------------------
  MathCnt := MathLow
  Loop, %MathNum%
  {
    MathCnt := MathCnt * 2
  } ; End Loop, %MathNum%
  MathCnt := MathHigh
  Loop, %MathNum%
  {
    MathCnt := MathCnt / 0.5
  } ; End Loop, %MathNum%
  MathCnt := MathLow
  Loop, %MathNum%
  {
    MathCnt := MathCnt + 1
  } ; End Loop, %MathNum%
  MathCnt := MathHigh
  Loop, %MathNum%
  {
    MathCnt := MathCnt - 1
  } ; End Loop, %MathNum%
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [END] Math  
  ;
  EndTime := A_TickCount
  Integer_PcBenchmark := EndTime - StartTime
  ; -------------------------------------------
  FileDelete, %TxtTestFile_PcBenchmark%
  ; -------------------------------------------
  FileAppend, %Integer_PcBenchmark%, %TxtFile_PcBenchmark%, UTF-8
  ; -------------------------------------------
  return Integer_PcBenchmark
  ; -------------------------------------------
} ; End StartUp_Benchmark() ; > Integer_PcBenchmark
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_ProductID() ; > [Pc_ProductID, WindowsVersion, Location_Continent, Location_Country, Location_Region, Location_City, IP_Public, IP_Private]
{
  ; -------------------------------------------
  Pc_TxtFile_ProductId  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Product_ID.txt"
  ; -------------------------------------------
  if !FileExist(Pc_TxtFile_ProductId)
  {
    ; -------------------------------------------
    FormatTime, TimeRightNow , , yyyyMMddHHmmss
    TimeRightNow := TimeRightNow A_TickCount
    ; -------------------------------------------
    { ; Get IP
      ; -------------------------------------------
      Pc_TxtFile_GetIp  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Get_IP.txt"
      Url_HtmlFile_GetIp := "http://www.netikus.net/show_ip.html"
      URLDownloadToFile, %Url_HtmlFile_GetIp%, %Pc_TxtFile_GetIp%
      ; -------------------------------------------
      if (ErrorLevel == 1)
      {
        ; -------------------------------------------
        IP_Public := "NoIp"
        IP_Private := "NoIp"
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        FileReadLINE, IP_Public, %Pc_TxtFile_GetIp%, 1
        IP_Private := A_IPAddress1
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if FileExist(Pc_TxtFile_GetIp)
      {
        FileDelete, %Pc_TxtFile_GetIp%
      }
      ; -------------------------------------------
      if (IP_Public != "NoIp")
      {
        Url_IP_Search := "https://whatismyipaddress.com/ip/" . IP_Public
        whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", Url_IP_Search)
        whr.Send()
        sleep 100
        version := whr.ResponseText
        RegExMatch(version, "Continent(.*)Latitude", Location)
        Location1 := RegExReplace(Location1,"<.+?>")
        Location1 := StrReplace(Location1, A_Tab, "")
        Location1 := StrReplace(Location1, " Country: ", "|")
        Location1 := StrReplace(Location1, " State/Region: ", "|")
        Location1 := StrReplace(Location1, " City: ", "|")
        LocationArray  := StrSplit(Location1, "|", "")
        ; -------------------------------------------
        Location_Continent := LocationArray.1
        Location_Continent := StrReplace(Location_Continent, ": ", "")
        Location_Continent := StrReplace(Location_Continent, "`n", "")
        Location_Country := LocationArray.2
        Location_Country := StrReplace(Location_Country, "`n", "")
        Location_Region := LocationArray.3
        Location_Region := StrReplace(Location_Region, "`n", "")
        Location_City := LocationArray.4
        Location_City := StrReplace(Location_City, "`n", "")
        Pos_1 := InStr(Location_City, "Javascript")
        if (Pos_1 > 0)
        {
          Pos_1 := Pos_1 - 2
          Location_City := SubStr(Location_City, 1, Pos_1)
        }
        ; -------------------------------------------
      }
      else
      {
        Location_Continent := "NoIp"
        Location_Country := "NoIp"
        Location_Region := "NoIp"
        Location_City := "NoIp"
      }
      ; -------------------------------------------
    } ; End Get IP
    ; -------------------------------------------
    Pc_ProductID := "PUM_(" IP_Public ")_(" IP_Private ")_(" TimeRightNow ")"
    RegRead, WindowsVersion, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName
    Pc_InstalledDir := A_ScriptDir
    Pc_InstalledDir := StrReplace(Pc_InstalledDir, "\Lib", "")
    ; -------------------------------------------
    { ; Send E-Mail
      ; -------------------------------------------
      Email_Subject := "PUM-ID " Pc_ProductID
      Email_Body := ""
      ; -------------------------------------------
      Email_Body := Email_Body "`n`n"
      ; -------------------------------------------
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Product ID:`n"
      Email_Body := Email_Body Pc_ProductID "`n`n"
      ;
      Email_Body := Email_Body "User Name:`n"
      Email_Body := Email_Body A_UserName "`n`n"
      ;
      Email_Body := Email_Body "Benchmark:`n"
      Email_Body := Email_Body Integer_PcBenchmark "`n`n"
      ;
      Email_Body := Email_Body "AutoHotKey Version:`n"
      Email_Body := Email_Body A_AhkVersion "`n`n"
      ;
      Email_Body := Email_Body "Windows Version:`n"
      Email_Body := Email_Body WindowsVersion "`n"
      Email_Body := Email_Body A_OSVersion "`n`n"
      ;
      Email_Body := Email_Body "PC Installed Directory:`n"
      Email_Body := Email_Body Pc_InstalledDir "`n"
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Continent:`n"
      Email_Body := Email_Body Location_Continent "`n`n"
      ;
      Email_Body := Email_Body "Country:`n"
      Email_Body := Email_Body Location_Country "`n`n"
      ;
      Email_Body := Email_Body "Region:`n"
      Email_Body := Email_Body Location_Region "`n`n"
      ;
      Email_Body := Email_Body "City:`n"
      Email_Body := Email_Body Location_City "`n"
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Public IP:`n"
      Email_Body := Email_Body IP_Public "`n`n"
      ;
      Email_Body := Email_Body "Private IP:`n"
      Email_Body := Email_Body IP_Private "`n"
      Email_Body := Email_Body "----------------------------------`n"
      ; -------------------------------------------
      Email_Sent := StartUp_SendEmail(Email_Subject, Email_Body, AttachFile)
      ; -------------------------------------------
    } ; End Send E-Mail
    ; -------------------------------------------
    if (Email_Sent == 1)
    {
      ; -------------------------------------------
      FileAppend, %Pc_ProductID%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %WindowsVersion%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %Location_Continent%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %Location_Country%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %Location_Region%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %Location_City%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %IP_Public%`n, %Pc_TxtFile_ProductId%, UTF-8
      FileAppend, %IP_Private%`n, %Pc_TxtFile_ProductId%, UTF-8
      ; -------------------------------------------
    } ; End if (Email_Sent == 1)
    ; -------------------------------------------
  } ; End if !FileExist(Pc_TxtFile_ProductId)
  ; -------------------------------------------
  else ; Read Pc_TxtFile_ProductId
  {
    FileReadLine, Pc_ProductID,       %Pc_TxtFile_ProductId%, 1
    FileReadLine, WindowsVersion,     %Pc_TxtFile_ProductId%, 2
    FileReadLine, Location_Continent, %Pc_TxtFile_ProductId%, 3
    FileReadLine, Location_Country,   %Pc_TxtFile_ProductId%, 4
    FileReadLine, Location_Region,    %Pc_TxtFile_ProductId%, 5
    FileReadLine, Location_City,      %Pc_TxtFile_ProductId%, 6
    FileReadLine, IP_Public,          %Pc_TxtFile_ProductId%, 7
    FileReadLine, IP_Private,         %Pc_TxtFile_ProductId%, 8
  } ; End Read Pc_TxtFile_ProductId
  ; -------------------------------------------
  Array_Return := [Pc_ProductID, WindowsVersion, Location_Continent, Location_Country, Location_Region, Location_City, IP_Public, IP_Private]
  return Array_Return
  ; -------------------------------------------
} ; End StartUp_ProductID()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_SplashScript(ImgNum, Sleep_Time) ; ImgNum ("Off"/Number), Sleep_Time
{
  ; -------------------------------------------
  { ; [GET] User Language
    ; -------------------------------------------
    Lang_File := A_AppData "\PopUpMenu_PUM\system\Language.txt"
    if FileExist(Lang_File)
    {
      FileReadLINE, ThisLang, %Lang_File%, 1
      if (ThisLang == "")
      {
        FileDelete, %Lang_File%
        ThisLang := "en"
        FileAppend, %ThisLang%`n, %Lang_File%, UTF-8
      }
    }
    else
    {
      ThisLang := "en"
      FileAppend, %ThisLang%`n, %Lang_File%, UTF-8
    }
    ; -------------------------------------------
  } ; End [GET] User Language
  ; -------------------------------------------
  SplashPath := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk"
  ; -------------------------------------------
  if (ImgNum == "Off")
  {
    ; -------------------------------------------
    ; Closes Any Splash Image
    ; Does Not Need DataArray
    ; -------------------------------------------
    if (Sleep_Time > 0)
    {
      Sleep, %Sleep_Time%
    }
    ; -------------------------------------------
    SplashImage, Off
    ; -------------------------------------------
    Array_Lang := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
    Array_Img := ["500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512"]
    for Index_1, This_Img in Array_Img
    {
      for Index_2, This_Lang in Array_Lang
      {
        This_Script := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" This_Img "_" This_Lang ".ahk"
        DetectHiddenWindows, On
        WinClose, %This_Script% ahk_class AutoHotkey
      } ; End for Index_2, This_Lang in Array_Lang
    } ; End for Index_1, This_Img in Array_Img
    ; -------------------------------------------
  }
  else
  {
    ; -------------------------------------------
    ThisSplash := SplashPath "\" ImgNum "_" ThisLang ".ahk"
    ; -------------------------------------------
    if (SubStr(ImgNum, 1, 1) == "4")
    {
      SplashImage, %ThisSplash%, b
      if (Sleep_Time > 0)
      {
        Sleep, %Sleep_Time%
        SplashImage, Off
      }
    }
    else
    {
      ; -------------------------------------------
      Run, %ThisSplash%,,, ThisSplash
      Process, Priority, %ThisSplash%, High
      ; -------------------------------------------
      if (Sleep_Time > 0)
      {
        ; -------------------------------------------
        Sleep, %Sleep_Time%
        ; -------------------------------------------
        Array_Lang := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
        Array_Img := ["500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512"]
        for Index_1, This_Img in Array_Img
        {
          for Index_2, This_Lang in Array_Lang
          {
            This_Script := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" This_Img "_" This_Lang ".ahk"
            DetectHiddenWindows, On
            WinClose, %This_Script% ahk_class AutoHotkey
          } ; End for Index_2, This_Lang in Array_Lang
        } ; End for Index_1, This_Img in Array_Img
        ; -------------------------------------------
      }
    }
  }
} ; End StartUp_SplashScript(ImgNum, Sleep_Time) ; ImgNum ("Off"/Number), Sleep_Time
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_SendEmail(Email_Subject, Email_Body, AttachFile)
{
  ; -------------------------------------------
  pmsg := ComObjCreate("CDO.Message")
  ; -------------------------------------------
  pmsg.From := """PopUpMenu AutoHotKey"" <popupmenu_autohotkey@yahoo.com>"
  ;~ pmsg.From := """PopUpMenu AutoHotKey"" <popupmenu_autohotkesdSdADADSDy@yahoo.com>"
  pmsg.To   := "popupmenu@yahoo.com"
  ; -------------------------------------------
  pmsg.BCC  := ""
  pmsg.CC   := ""
  ; -------------------------------------------
  pmsg.Subject  := Email_Subject
  pmsg.TextBody := Email_Body
  sAttach       := AttachFile
  ; -------------------------------------------
  fields := Object()
  ; -------------------------------------------
  fields.smtpserver            := "smtp.mail.yahoo.com" ; specify your SMTP server
  fields.smtpserverport        := 465 ; 25
  fields.smtpusessl            := True ; True (otherwise it will Lock Up)
  fields.sendusing             := 2   ; cdoSendUsingPort
  fields.smtpauthenticate      := 1   ; cdoBasic
  ; -------------------------------------------
  fields.sendusername          := "popupmenu_autohotkey@yahoo.com"
  fields.sendpassword          := "wtre wgpy tmlo hhwn" ; popupmenu_autohotkey@yahoo.com
  ; -------------------------------------------
  fields.smtpconnectiontimeout := 60
  schema := "http://schemas.microsoft.com/cdo/configuration/"
  ; -------------------------------------------
  pfld := pmsg.Configuration.Fields
  
  ; -------------------------------------------
  for field,value in fields
  {
    pfld.Item(schema . field) := value
  }
  ; -------------------------------------------
  pfld.Update()
  ; -------------------------------------------
  Loop, Parse, AttachFile, |, %A_Space%%A_Tab%
  {
    pmsg.AddAttachment(A_LoopField)
  }
  ; -------------------------------------------
  pmsg.Send()
  ; -------------------------------------------
  if (ErrorLevel != 0)
  {
    Return_Value := 0
  }
  else
  {
    Return_Value := 1
  }
  ; -------------------------------------------
  return Return_Value
} ; End StartUp_SendEmail(Email_Subject, Email_Body, AttachFile)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StarUp_DownloadFile(ThisUrl, ThisFile) ; > File Downloaded OK
{
  ; -------------------------------------------
  URLDownloadToFile, %ThisUrl%, %ThisFile%
  ; -------------------------------------------
  if (ErrorLevel == 0)
  {
    ; -------------------------------------------
    if FileExist(ThisFile)
    {
      FileReadLine, LineOne, %ThisFile%, 1 ; Number of the Last Update that was ran
      if (InStr(LineOne, "DOCTYPE") > 0)
      {
        FileOK := 0
      }
      else if (InStr(LineOne, "html") > 0)
      {
        FileOK := 0
      }
      else
      {
        FileOK := 1
      }
    } ; End FileExist(ThisFile)
    else
    {
      FileOK := 0
    } ; End !FileExist(ThisFile)
  } ; End (ErrorLevel == 0)
  else
  {
    FileOK := 0
  } ; End (ErrorLevel != 0)
  ; -------------------------------------------
  if (FileOK == 0)
  {
    FileDelete, %ThisFile%
  }
  ; -------------------------------------------
  return FileOK
  ; -------------------------------------------
} ; End StarUp_DownloadFile(ThisUrl, ThisFile) ; > File Downloaded OK
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_UnZip(ZipFile, UnZipDir)
{
  ; -------------------------------------------
  /*
    ThisFunction(ZipDir, ZipFile)
    ZipDir = This is a Folder, This "Folder" will be Created in the zip, contianing all files in that Folder
    ZipFile = the File to be Ziped
    
    ThisFunction(ZipFile, UnZipDir)
    ZipFile = the File to be UnZiped
    UnZipDir = Should be one Folder Back,
      The Last Folder from Zip File F_Zip "ZipDir"
      will be created if does not exist
  */
  ; -------------------------------------------
  fso := ComObjCreate("Scripting.FileSystemObject")
  If Not fso.FolderExists(UnZipDir)
  {
    fso.CreateFolder(UnZipDir)
  }
  psh  := ComObjCreate("Shell.Application")
  psh.Namespace( UnZipDir ).CopyHere( psh.Namespace( ZipFile ).items, 4|16 )
  ; -------------------------------------------
} ; End StartUp_UnZip(ZipFile, UnZipDir)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_WindowsFolder(Folder, Public)
{
  DriveLetter := ["Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "M", "N", "L", "K", "J", "I", "H", "G", "F", "E", "D", "C", "B", "A"]
  UserName := A_UserName
  FoundFolder := ""
  SytemDrive := ""
  if !Public
  {
    Public := 0
  }
  ; -------------------------------------------
  { ; Find Windows Folder
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\Windows"
      if FileExist(CkFolder)
      {
        SytemDrive := ThisLetter ":\"
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
  } ; End Find Windows Folder
  ; -------------------------------------------
  { ; Get Windows Version
    objWMIService := ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" A_ComputerName "\root\cimv2")
    for objOperatingSystem in objWMIService.ExecQuery("Select * from Win32_OperatingSystem")
    {
      Caption := objOperatingSystem.Caption , OSArchitecture := objOperatingSystem.OSArchitecture, CSDVersion  := objOperatingSystem.CSDVersion, Version := objOperatingSystem.Version
    }
    IfInString, Caption, Windows XP
    {
      WinXP := 1
    }
    else
    {
      WinXP := 0
    }
  } ; End Get Windows Version
  ; -------------------------------------------
  if SytemDrive
  {
    if Folder
    {
      if (WinXP == 1)
      {
        if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        {
          CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents\My " Folder
        } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        else if (Folder == "Documents")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\Documents"
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents"
          } ; End (Public == 0)
        } ; End (Folder == "Documents")
        else if (Folder == "Start Menu" or Folder == "Desktop")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\" Folder
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\" Folder
          } ; End (Public == 0)
        } ; End (Folder == "Start Menu" or Folder == "Desktop")
      } ; End (WinXP == 1)
      else if (WinXP == 0)
      {
        if (Public == 1)
        {
          if (Folder == "Desktop" or Folder == "Documents")
          {
            CkFolder := SytemDrive "Users\Public\" Folder
          } ; End (Folder == "Desktop" or Folder == "Documents")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "ProgramData\Microsoft\Windows\" Folder
          } ; End (Folder == "Start Menu")
        } ; End (Public == 1)
        else if (Public == 0)
        {
          if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop")
          {
            CkFolder := SytemDrive "Users\" UserName "\" Folder
          } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "Users\" UserName "\AppData\Roaming\Microsoft\Windows\" Folder
          } ; End (Folder == "Start Menu")
        } ; End (Public == 0)
      } ; End (WinXP == 0)
      ; -------------------------------------------          
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
      } ; End FileExist(CkFolder)
    } ; End if Folder
  } ; End if SytemDrive
  ; -------------------------------------------
  if !FoundFolder
  {
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\" Folder
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
    ; -------------------------------------------
    if !FoundFolder
    {
      FoundFolder := SytemDrive
    } ; End if !FoundFolder
  } ; End if !FoundFolder
  ; -------------------------------------------
  return FoundFolder
} ; End StartUp_WindowsFolder(Folder, Public)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_WinPubFolder(Folder, Public) ; Folder, Public [ 0/1] > FoundFolder
{
  DriveLetter := ["Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "M", "N", "L", "K", "J", "I", "H", "G", "F", "E", "D", "C", "B", "A"]
  UserName := A_UserName
  FoundFolder := ""
  SytemDrive := ""
  if !Public
  {
    Public := 0
  }
  ; -------------------------------------------
  { ; Find Windows Folder
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\Windows"
      if FileExist(CkFolder)
      {
        SytemDrive := ThisLetter ":\"
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
  } ; End Find Windows Folder
  ; -------------------------------------------
  { ; Get Windows Version
    objWMIService := ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" A_ComputerName "\root\cimv2")
    for objOperatingSystem in objWMIService.ExecQuery("Select * from Win32_OperatingSystem")
    {
      Caption := objOperatingSystem.Caption , OSArchitecture := objOperatingSystem.OSArchitecture, CSDVersion  := objOperatingSystem.CSDVersion, Version := objOperatingSystem.Version
    }
    IfInString, Caption, Windows XP
    {
      WinXP := 1
    }
    else
    {
      WinXP := 0
    }
  } ; End Get Windows Version
  ; -------------------------------------------
  if SytemDrive
  {
    if Folder
    {
      if (WinXP == 1)
      {
        if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        {
          CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents\My " Folder
        } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos")
        else if (Folder == "Documents")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\Documents"
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\My Documents"
          } ; End (Public == 0)
        } ; End (Folder == "Documents")
        else if (Folder == "Start Menu" or Folder == "Desktop")
        {
          if (Public == 1)
          {
            CkFolder := SytemDrive "Documents and Settings\All Users\" Folder
          } ; End (Public == 1)
          else if (Public == 0)
          {
            CkFolder := SytemDrive "Documents and Settings\" UserName "\" Folder
          } ; End (Public == 0)
        } ; End (Folder == "Start Menu" or Folder == "Desktop")
      } ; End (WinXP == 1)
      else if (WinXP == 0)
      {
        if (Public == 1)
        {
          if (Folder == "Desktop" or Folder == "Documents")
          {
            CkFolder := SytemDrive "Users\Public\" Folder
          } ; End (Folder == "Desktop" or Folder == "Documents")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "ProgramData\Microsoft\Windows\" Folder
          } ; End (Folder == "Start Menu")
        } ; End (Public == 1)
        else if (Public == 0)
        {
          if (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop")
          {
            CkFolder := SytemDrive "Users\" UserName "\" Folder
          } ; End (Folder == "Music" or Folder == "Pictures" or Folder == "Videos" or Folder == "Documents" or Folder == "Desktop")
          else if (Folder == "Start Menu")
          {
            CkFolder := SytemDrive "Users\" UserName "\AppData\Roaming\Microsoft\Windows\" Folder
          } ; End (Folder == "Start Menu")
        } ; End (Public == 0)
      } ; End (WinXP == 0)
      ; -------------------------------------------          
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
      } ; End FileExist(CkFolder)
    } ; End if Folder
  } ; End if SytemDrive
  ; -------------------------------------------
  if !FoundFolder
  {
    for Index, ThisLetter in DriveLetter
    {
      CkFolder := ThisLetter ":\" Folder
      if FileExist(CkFolder)
      {
        Loop, %CkFolder%\*.*,1,1
        {
          if A_Index
          {
            FoundFolder := CkFolder
            break
          } ; End if A_Index
        } ; End Loop, %CkFolder%\*.*,1,1
        break
      } ; End FileExist(CkFolder)
    } ; End for Index, ThisLetter in DriveLetter
    ; -------------------------------------------
    if !FoundFolder
    {
      FoundFolder := SytemDrive
    } ; End if !FoundFolder
  } ; End if !FoundFolder
  ; -------------------------------------------
  return FoundFolder
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
StartUp_ArrayAdd(ThisArray, AddThis, ThisPos) ; ThisArray, AddThis, ThisPos > ThisArray
{
  ; -------------------------------------------
  if !ThisPos
  {
    ThisPos := "End"
  }
  ; -------------------------------------------
  if AddThis
  {
    CheckThis := ThisArray[1]
    if CheckThis
    {
      if (ThisPos == "End")
      {
        ThisArray.Push(AddThis) ; Adds (AddThis) to End
      }
      else
      {
        if (ThisPos == 0)
        {
          ThisPos := 1
        }
        ThisArray.InsertAt(ThisPos, AddThis) ; Adds (AddThis) at (ThisPos)
      }
    } ; End if CheckThis
    else
    {
      ThisArray := []
      ThisArray[1] := AddThis
    } ; End else
  } ; End if AddThis
  return ThisArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
StartUp()
{
  ; -------------------------------------------
  Pc_InstalledDir := A_ScriptDir
  Pc_InstalledDir := StrReplace(Pc_InstalledDir, "\Lib", "")
  ; -------------------------------------------
  ; Start Up Benchmark (Creates a New Benchmark with each PopUpMenu Load)
  Integer_PcBenchmark := StartUp_Benchmark() ; > Integer_PcBenchmark
  ; -------------------------------------------
  Working_Pums := ""
  ; -------------------------------------------
  Folder_PumsCommon := A_AppData "\PopUpMenu_PUM\pums"
  Loop Files, %Folder_PumsCommon%\*.exe, R
  {
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, A_LoopFileFullPath, , , , This_Pum
    if Working_Pums
    {
      ArrayLen := Working_Pums.MaxIndex()
      NumAdd := ArrayLen +1
      Working_Pums[NumAdd] := This_Pum
    }
    else
    {
      Working_Pums := []
      Working_Pums[1] := This_Pum
    }
  }
  ; -------------------------------------------
  for Index, This_Pum in Working_Pums ; Delete Extra Xml files
  {
    XmlDir := Folder_PumsCommon "\" This_Pum "\system"
    Num := 1
    Loop 9
    {
      ErrorXml :=  XmlDir "\toolbox" Num "*.xml"
      if FileExist(ErrorXml)
      {
        FileDelete, %ErrorXml%
      }
      Num := Num + 1
    }
  }  
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Connect_Check(flag=0x40) == 1) ; Check Internet Connection
  {
    ; -------------------------------------------
    Array_UpdateEmail := []
    ; -------------------------------------------
    ; (READ)(MAKE)(if Made Send Email) Product ID
    Array_ProductID := StartUp_ProductID() ; > [Pc_ProductID, WindowsVersion, Location_Continent, Location_Country, Location_Region, Location_City, IP_Public, IP_Private]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Array_ThisUpdate := StartUp_CheckForUpdate("pum") ; UpdateType = (pum / "Addon App Name"_"Lang" / icons) > Updated_Array
    ThisUpdateLen := Array_ThisUpdate.MaxIndex()
    if (ThisUpdateLen > 0)
    {
      Array_UpdateEmail := StartUp_ArrayAdd(Array_UpdateEmail, Array_ThisUpdate, "End") ; ThisArray, AddThis, ThisPos > ThisArray
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Array_ThisUpdate := StartUp_CheckForUpdate("icon") ; UpdateType = (pum / "Addon App Name"_"Lang" / icons) > Updated_Array
    ThisUpdateLen := Array_ThisUpdate.MaxIndex()
    if (ThisUpdateLen > 0)
    {
      Array_UpdateEmail := StartUp_ArrayAdd(Array_UpdateEmail, Array_ThisUpdate, "End") ; ThisArray, AddThis, ThisPos > ThisArray
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Pc_Folder_CommonAddon  := A_AppDataCommon "\PopUpMenu_PUM\addons"
    ; -------------------------------------------
    Loop Files, %Pc_Folder_CommonAddon%\addon_*.txt, R ; (addon_photoshop_en.txt) addon_ "AppName" _ "Language" .txt
    {
      ; -------------------------------------------
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, A_LoopFileFullPath, , , , Addon_Name
      ; -------------------------------------------
      Addon_Name := StrReplace(Addon_Name, "addon_", "") ; > "Process Name" "_" "Lang"
      ; -------------------------------------------
      ; Addon_Name = "Process Name"_"Lang"
      ; -------------------------------------------
      Array_ThisUpdate := StartUp_CheckForUpdate(Addon_Name) ; UpdateType = (pum / "Process Name"_"Lang" / icons) > Updated_Array
      ThisUpdateLen := Array_ThisUpdate.MaxIndex()
      if (ThisUpdateLen > 0)
      {
        Array_UpdateEmail := StartUp_ArrayAdd(Array_UpdateEmail, Array_ThisUpdate, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      }
      ; -------------------------------------------
    } ; End Loop Files, %Pc_Folder_CommonAddon%\addon_*.txt, R
    ; -------------------------------------------
    EmailArrayLen := Array_UpdateEmail.MaxIndex()
    if (EmailArrayLen > 0)
    {
      ; -------------------------------------------
      Pc_ProductID := Array_ProductID.1
      WindowsVersion := Array_ProductID.2
      Location_Continent := Array_ProductID.3
      Location_Country := Array_ProductID.4
      Location_Region := Array_ProductID.5
      Location_City := Array_ProductID.6
      IP_Public := Array_ProductID.7
      IP_Private := Array_ProductID.8
      ; -------------------------------------------
      Email_Subject := "PUM-Update " Pc_ProductID
      Email_Body := ""
      ; -------------------------------------------
      RegRead, WindowsVersion, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName
      ; -------------------------------------------
      for Index, This_Update in Array_UpdateEmail
      {
        ; This_Update = [UpdateType, LastUpdate, ThisUpdate]
        ProductName := This_Update.1
        Email_LastUpdate := This_Update.2
        Email_ThisUpdate := This_Update.3
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Product Name : " ProductName "`n"
        Email_Body := Email_Body "Old Version : " Email_LastUpdate "`n"
        Email_Body := Email_Body "New Version : " Email_ThisUpdate "`n"
      } ; End for Index, This_Update in Array_SendEmailUpdated
      ; -------------------------------------------
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Product ID:`n"
      Email_Body := Email_Body Pc_ProductID "`n`n"
      ;
      Email_Body := Email_Body "User Name:`n"
      Email_Body := Email_Body A_UserName "`n`n"
      ;
      Email_Body := Email_Body "Benchmark:`n"
      Email_Body := Email_Body Integer_PcBenchmark "`n`n"
      ;
      Email_Body := Email_Body "AutoHotKey Version:`n"
      Email_Body := Email_Body A_AhkVersion "`n`n"
      ;
      Email_Body := Email_Body "Windows Version:`n"
      Email_Body := Email_Body WindowsVersion "`n"
      Email_Body := Email_Body A_OSVersion "`n`n"
      ;
      Email_Body := Email_Body "PC Installed Directory:`n"
      Email_Body := Email_Body Pc_InstalledDir "`n"
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Continent:`n"
      Email_Body := Email_Body Location_Continent "`n`n"
      ;
      Email_Body := Email_Body "Country:`n"
      Email_Body := Email_Body Location_Country "`n`n"
      ;
      Email_Body := Email_Body "Region:`n"
      Email_Body := Email_Body Location_Region "`n`n"
      ;
      Email_Body := Email_Body "City:`n"
      Email_Body := Email_Body Location_City "`n"
      Email_Body := Email_Body "----------------------------------`n"
      Email_Body := Email_Body "Public IP:`n"
      Email_Body := Email_Body IP_Public "`n`n"
      ;
      Email_Body := Email_Body "Private IP:`n"
      Email_Body := Email_Body IP_Private "`n"
      Email_Body := Email_Body "----------------------------------`n"
      ; -------------------------------------------
      Email_Sent := StartUp_SendEmail(Email_Subject, Email_Body, AttachFile)
      ; -------------------------------------------
    } ; End if IsObject(Array_SendEmailUpdated)
    ; -------------------------------------------
  } ; End if (Connect_Check(flag=0x40) == 1)
  ; -------------------------------------------
} ; End StartUp()
