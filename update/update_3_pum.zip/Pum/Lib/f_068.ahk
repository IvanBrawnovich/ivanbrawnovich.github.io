﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Open With Application
; -------------------------------------------
f_068(DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_068", DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
    ; -------------------------------------------
    v_305_4 := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    v_305_6 := DataArray.305.6 ; (305_6)([rwh] Default Application [Full File Path])
    v_307_6 := DataArray.307.6 ; (307_6)([url] Default Browser [Full File Path])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  if (DataArray.366.5 == "rwh") ; (366_5)(Script Type)
  {
    Selected_File := Select_FileFolder(v_365_2, "FileAppOpenWith") ; (365_2)(Current User language)
  }
  else if (DataArray.366.5 == "url") ; (366_5)(Script Type)
  {
    Selected_File := Select_FileFolder(v_365_2, "FileUrlOpenWith") ; (365_2)(Current User language)
  }
  ; -------------------------------------------
  if (Selected_File != "")
  {
    ; -------------------------------------------
    IfInString, Selected_File, %A_ScriptDir%
    {
      Selected_File := ""
    } ; End IfInString, ThisFile, %A_ScriptDir%
    else
    {
      ; -------------------------------------------
      SplitPath, Selected_File , , , Check_SelectedFile_Ext
      ;
      if (Check_SelectedFile_Ext == "lnk")
      {
        FileGetShortcut, %Selected_File%, Selected_File
      }
      ; -------------------------------------------
    }
  } ; End (Selected_File != "")
  ; -------------------------------------------
  if (Selected_File != "")
  {
    ; -------------------------------------------
    ; (Value) (Modify)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, Selected_File, , , FileExt ; (305_5)(Selected Opening Application [Full File Path])
    StringLower, FileExt, FileExt
    ; -------------------------------------------
    if (FileExt == "lnk")
    {
      FileGetShortcut, %Selected_File%, Selected_File ; (305_5)(Selected Opening Application [Full File Path])
    }
    ; -------------------------------------------
    if (FileExt == "exe")
    {
      if (DataArray.366.5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        v_305_5 := Selected_File ; (305_5)([rwh] Selected Opening Application [Full File Path])
        DataArray.305.5 := v_305_5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
        ; -------------------------------------------
        if (v_305_5 == v_305_6) ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_6)([rwh] Default Application [Full File Path])
        {
          ; 1 = Is Use Default
          DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
        }
        else
        {
          ; 0 = DO NOT Use Default
          DataArray.305.8 := 0 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
        }
      }
      ; -------------------------------------------
      else if (DataArray.366.5 == "url") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        v_307_5 := Selected_File ; (307_5)([url] Selected Opening Browser [Full File Path])
        DataArray.307.5 := v_307_5 ; (307_5)([url] Selected Opening Browser [Full File Path])
        ; -------------------------------------------
        if (v_307_5 == v_307_6) ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_6)([url] Default Browser [Full File Path])
        {
          ; 1 = Is Use Default
          DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
        }
        else
        {
          ; 0 = DO NOT Use Default
          DataArray.307.7 := 0 ; (307_7)([url] Use Default Browser [0/1])
        }
      }
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
    }
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (430_1)(Splash Error File: Not a Application)
      ; (430_1)(Splash Error Image File: Not a Application)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
  } ; End if ThisFile
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
