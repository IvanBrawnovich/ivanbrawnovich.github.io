﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Allowed Transparency
; no  > jpeg jpg iff jps mpo pcx pxr pbm sct tga 
; yes > tif tiff gif png
; -------------------------------------------
Convert_ChopToBmp(DataArray)
{
  ; -------------------------------------------
  v_368_5  := DataArray.368.5 ; (368_5)(Selected Pum Background [Full Path])
  v_386_2  := DataArray.386.2 ; (386_2)(Temporary Icon [System Folder Path])
  v_368_6  := DataArray.368.6 ; (368_6)(Pum Background Image X_Width)
  v_368_7  := DataArray.368.7 ; (368_7)(Pum Background Image Y_Height)
  v_368_8  := DataArray.368.8 ; (368_8)(Pum Background Chop X_Width)
  v_368_9  := DataArray.368.9 ; (368_9)(Pum Background Chop Y_Height)
  v_368_10 := DataArray.368.10 ; (368_10)(Pum Background Offset X Left To Right)
  v_368_11 := DataArray.368.11 ; (368_11)(Pum Background Offset Y Top To Bottom)
  ;
  v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
  ; -------------------------------------------
  Any_BmpFile := v_386_2 "\*.bmp" ; (386_2)(Temporary Icon [System Folder Path])
  ; -------------------------------------------
  if FileExist(Any_BmpFile)
  {
    FileDelete, %Any_BmpFile%
  }
  ; -------------------------------------------
  if v_368_5 ; (368_5)(Selected Pum Background [Full Path])
  {
    ; -------------------------------------------
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_368_5, , , , ImgName ; (368_5)(Selected Pum Background [Full Path])
    ; -------------------------------------------
    NewImg := v_386_2 "\" ImgName ".bmp" ; (386_2)(Temporary Icon [System Folder Path])
    ; -------------------------------------------
    ; (383_2)([Image Convert] magick.exe [Support Program File Path])
    ; -------------------------------------------
    ; Will Chop Selected Image to  Width  &  Height, Offsetting     X    &    Y     = bmp Image
    ; Will Chop     (368_5)    to (368_8) & (368_9), Offsetting (368_10) & (368_11) =  (368_3)
    ; -------------------------------------------
    ; (368_5)(Selected Pum Background Any Image)
    ; (368_8)(Pum Background Chop X_Width)
    ; (368_9)(Pum Background Chop Y_Height)
    ; (368_10)(Pum Background Offset X Left To Right)
    ; (368_11)(Pum Background Offset Y Top To Bottom)
    ; _(368)(03)(Temporary Pum Background xxx.bmp)
    ;
    RunThis := v_383_2 " convert " OldImg " -crop " v_368_8 "x" v_368_9 "+" v_368_10 "+" v_368_11 " " v_368_3 ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(368_8)(Pum Background Chop X_Width)/(368_9)(Pum Background Chop Y_Height)/(368_10)(Pum Background Offset X Left To Right)/(368_11)(Pum Background Offset Y Top To Bottom)/(368_3)(Temporary Pum Background xxx.bmp)
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("506", 0) ; 
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("Off", 0)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ;
    DataArray.368.3 := v_368_3 ; (368_3)(Temporary Pum Background xxx.bmp)
    ; -------------------------------------------
  }
  return DataArray
  ; -------------------------------------------
}
