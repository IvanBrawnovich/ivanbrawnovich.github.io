﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
Install_Dir := A_ScriptDir
if (inStr(Install_Dir, "\Lib") > 0)
{
  Install_Dir := StrReplace(Install_Dir, "\Lib", "")
}
; -------------------------------------------
CopyThis := Install_Dir "\support\pumlib\*.*"
; -------------------------------------------
; Pum Path Pum Name Found with No .ext
Array_Pums := ""
ThisFolder := A_AppData "\PopUpMenu_PUM\pums"
; -------------------------------------------
Array_Pums := []
Loop Files, %ThisFolder%\*.exe, R
{
  ; Choose (Full Path) or (Name)
  ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, A_LoopFileFullPath, , , , ThisPum
  ThisPum := StrReplace(ThisPum, "pum_", "")
  Array_Pums.Push(ThisPum) ; Adds (AddThis) to End
} ; End Loop Files, %ThisFolder%\*.exe
; -------------------------------------------
for Index, ThisPum in Array_Pums
{
  ; -------------------------------------------
  LibFolder := ThisFolder "\" ThisPum "\ahk\Lib"
  ; -------------------------------------------
  if !FileExist(LibFolder)
  {
    FileCreateDir, %LibFolder%
  } ; End !FileExist(LibFolder)
  ; -------------------------------------------
  FileCopy, %CopyThis%, %LibFolder%, 1
} ; End for Index, ThisPum in Array_Pums
; -------------------------------------------
