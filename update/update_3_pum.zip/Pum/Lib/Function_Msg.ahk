﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Function_Msg(SleepTime, DataArray) ; (450)Function Array /  SleepTime, DataArray > Nothing
{
  ; -------------------------------------------
  FlowArray := DataArray.450 ; Var_Number_Error
  ThisArrayLen := FlowArray.MaxIndex()
  Msg := Msg "FlowArray Length = " ThisArrayLen "`n"
  for Index, This_Fun in FlowArray
  {
    Msg := Msg Index " = " This_Fun "`n"
  }
  ToolTip, %Msg%, 300, 0
  Msg := ""
  Sleep, %SleepTime%
  ; -------------------------------------------
}
return
