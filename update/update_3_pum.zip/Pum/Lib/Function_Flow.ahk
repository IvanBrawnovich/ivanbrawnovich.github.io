﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
/*
Add at Start
DataArray.450 := "" ; Var_Number_Error
Add at End
Function_Msg(SleepTime, DataArray) ; (450)Function Array /  SleepTime, DataArray > Nothing
*/
; -------------------------------------------
Function_Flow(This_Function, DataArray)
{
  ; -------------------------------------------
  FlowArray := DataArray.450 ; Var_Number_Error
  if !FlowArray
  {
    FlowArray := []
  }
  if (This_Function != "GuiControl_Image")
  {
    FlowArray.Push(This_Function)
  }
  DataArray.450 := FlowArray ; Var_Number_Error
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
return
