﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Allowed Transparency
; no  > jpeg jpg iff jps mpo pcx pxr pbm sct tga 
; yes > tif tiff gif png
; -------------------------------------------
Convert_ResizeToBmp(DataArray)
{
  ; -------------------------------------------
  v_368_5 := DataArray.368.5 ; (368_5)(Selected Pum Background [Full Path])
  v_386_2 := DataArray.386.2 ; (386_2)(Temporary Icon [System Folder Path])
  v_368_6 := DataArray.368.6 ; (368_6)(Pum Background Image X_Width)
  v_368_7 := DataArray.368.7 ; (368_7)(Pum Background Image Y_Height)
  ;
  v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
  ; -------------------------------------------
  Any_BmpFile := v_386_2 "\*.bmp" ; (386_2)(Temporary Icon [System Folder Path])
  ; -------------------------------------------
  if FileExist(Any_BmpFile)
  {
    FileDelete, %Any_BmpFile%
  }
  ; -------------------------------------------
  if v_368_5 ; (368_5)(Selected Pum Background [Full Path])
  {
    ; -------------------------------------------
    ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_368_5, , , , ImgName ; (368_5)(Selected Pum Background [Full Path])
    ; -------------------------------------------
    NewImg := v_386_2 "\" ImgName ".bmp" ; (386_2)(Temporary Icon [System Folder Path])
    ; -------------------------------------------
    ; (383_2)([Image Convert] magick.exe [Support Program File Path])
    ; (368_5)(Selected Pum Background Any Image)
    ; -------------------------------------------
    ; Will Resize Selected Image to  Width  &  Height = bmp Image
    ; Will Resize    (368_5)     to (368_5) & (368_6) = (368_3)
    ; -------------------------------------------
    ; (368_5)(Selected Pum Background Any Image)
    ; (368_6)(Pum Background Image Width)
    ; (368_7)(Pum Background Image Height)
    ;
    RunThis := v_383_2 " convert " v_368_5 " -resize " v_368_6 "x" v_368_7 "! " 368_3 ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(368_5)(Selected Pum Background [Full Path])/(368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("506", 0) ; 
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("Off", 0)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ;
    DataArray.368.3 := v_368_3 ; (368_3)(Temporary Pum Background xxx.bmp)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
