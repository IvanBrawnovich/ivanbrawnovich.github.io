﻿Check_For_Update(UpdateType) ; UpdateType = (pum / "Process Name"_"Lang" / icons) > ThisUpdate_Array
{
  ; -------------------------------------------
  ; UpdateType = pum / "Addon App Name"_"Lang" / icons
  ; -------------------------------------------
  Url_Folder_Link                  := "https://popupmenu.github.io/update/link"
  Pc_Folder_Update                 := A_AppDataCommon "\PopUpMenu_PUM\update"
  Pc_Folder_UpdateLink             := A_AppDataCommon "\PopUpMenu_PUM\update\link"
  Pc_Folder_UpdateDownloadedZip    := A_AppDataCommon "\PopUpMenu_PUM\update\downloaded_zip"
  Pc_Folder_UpdateUnZipped         := A_AppDataCommon "\PopUpMenu_PUM\update\unzipped_zip"
  ; -------------------------------------------
  Pc_Folder_UnZipped_Icon          := Pc_Folder_UpdateUnZipped "\Icons"
  Pc_Folder_UnZipped_AppDataCommon := Pc_Folder_UpdateUnZipped "\AppDataCommon"
  Pc_Folder_UnZipped_AppData       := Pc_Folder_UpdateUnZipped "\AppData"
  Pc_Folder_UnZipped_Installed     := Pc_Folder_UpdateUnZipped "\Installed"
  ; -------------------------------------------
  Url_File_CurrentUpdate := "https://popupmenu.github.io/update/CurrentUpdate_" UpdateType ".txt"
  Pc_File_CurrentUpdate := A_AppDataCommon "\PopUpMenu_PUM\update\CurrentUpdate" UpdateType ".txt"
  ; -------------------------------------------
  Pc_File_LastUpdate := A_AppDataCommon "\PopUpMenu_PUM\update\LastUpdate_" UpdateType ".txt"
  ; -------------------------------------------
  ; If Pc_TxtFile_LastUpdate Does Not exist
  ; Create one Starting at 0 
  ; -------------------------------------------
  if !FileExist(Pc_File_LastUpdate)
  {
    FileAppend, 0`n, %Pc_File_LastUpdate%, UTF-8
  } ; End !FileExist(Pc_TxtFile_LastUpdate)
  ; -------------------------------------------
  
  Downloaded_OK := Download_File(Url_File_CurrentUpdate, Pc_File_CurrentUpdate) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  if (Downloaded_OK == 1) ; Current Update Number
  {
    ; -------------------------------------------
    FileReadLine, CurrentUpdate, %Pc_File_CurrentUpdate%, 1 ;
    FileReadLine, LastUpdate, %Pc_File_LastUpdate%, 1 ;
    ; -------------------------------------------
    if (CurrentUpdate > LastUpdate) ; Splash Image
    {
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (501_1)(Splash Info File: PopUpMenu Updating)
      StartUp_SplashScript("501", 0) ; (501_1)(Splash Info Script File: PopUpMenu Updating)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
    } ; (CurrentUpdate > LastUpdate) ; Splash Image
    ; -------------------------------------------
    While (CurrentUpdate > LastUpdate) ; while there is a Update
    {
      ; -------------------------------------------
      ThisUpdate := LastUpdate + 1
      ; -------------------------------------------
      Url_File_UpdateDownloadLink := Url_Folder_Link "/Link_"  ThisUpdate "_" UpdateType ".txt"
      Pc_File_UpdateDownloadLink := Pc_Folder_UpdateLink "\Link_"  ThisUpdate "_" UpdateType ".txt"
      ; -------------------------------------------
      Downloaded_OK := Download_File(Url_File_UpdateDownloadLink, Pc_File_UpdateDownloadLink) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
      ; -------------------------------------------
      if (Downloaded_OK == 1) ; (Download Link File)
      {
        ; -------------------------------------------
        FileReadLine, UpdateDownloadLink, %Pc_File_UpdateDownloadLink%, 1
        Pc_File_UpdateDownloadedZip := Pc_Folder_UpdateDownloadedZip "\updateDownloadedZip.zip"
        Downloaded_OK := Download_File(UpdateDownloadLink, Pc_File_UpdateDownloadedZip) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
        if (Downloaded_OK == 1) ; (Update Zip File)
        {
          ; -------------------------------------------
          UnZipFile(Pc_File_UpdateDownloadedZip, Pc_Folder_UpdateUnZipped) ; ZipFile, UnZipDir
          ; -------------------------------------------
          if (FileExist(Pc_Folder_UnZipped_Icon) or FileExist(Pc_Folder_UnZipped_AppDataCommon) or FileExist(Pc_Folder_UnZipped_AppData) or FileExist(Pc_Folder_UnZipped_Installed))
          {
            if FileExist(Pc_Folder_UnZipped_Icon) ; Check if Folder Exist
            {
              ; -------------------------------------------
              MoveThis := Pc_Folder_UnZipped_Icon
              MoveHere := Find_Windows_Public_Folder("Pictures", 0) ; Folder, Public [ 0/1] > FoundFolder
              ; -------------------------------------------
              if FileExist(MoveHere) ; Folder Exist
              {
                FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              } ; End FileExist(MoveHere)
            } ; End Check if Folder Exist
            ; -------------------------------------------
            if FileExist(Pc_Folder_UnZipped_AppDataCommon) ; Check if Folder Exist
            {
              ; -------------------------------------------
              MoveThis := Pc_Folder_UnZipped_AppDataCommon
              MoveHere := A_AppDataCommon
              if FileExist(MoveHere) ; Folder Exist
              {
                FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              } ; End FileExist(MoveHere_1)
            } ; End Check if Folder Exist
            ; -------------------------------------------
            if FileExist(Pc_Folder_UnZipped_AppData) ; Check if Folder Exist
            {
              ; -------------------------------------------
              MoveThis := Pc_Folder_UnZipped_AppData
              MoveHere := A_AppData
              if FileExist(MoveHere) ; Folder Exist
              {
                FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              } ; End FileExist(MoveHere_1)
            } ; End Check if Folder Exist
            ; -------------------------------------------
            if FileExist(Pc_Folder_UnZipped_Installed) ; Check if Folder Exist
            {
              ; -------------------------------------------
              MoveThis := Pc_Folder_UnZipped_Installed
              MoveHere := StrReplace(A_ScriptDir, "\Lib", "")
              if FileExist(MoveHere) ; Folder Exist
              {
                FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              } ; End FileExist(MoveHere_1)
            } ; End Check if Folder Exist
            ; -------------------------------------------
            LastUpdate := LastUpdate + 1
            ; -------------------------------------------
            FileDelete, %Pc_File_LastUpdate%
            Sleep, 500
            FileAppend, %LastUpdate%, %Pc_File_LastUpdate%, UTF-8
            ; -------------------------------------------
            This_Update := [UpdateType, LastUpdate, ThisUpdate]
            ThisUpdate_Array := Array_Add(ThisUpdate_Array, This_Update, "End") ; ThisArray, AddThis, ThisPos > ThisArray
            ; -------------------------------------------
          } ; End 1 or More Folders Exist from Unzipped File
          ; -------------------------------------------
          FileRemoveDir, %Pc_Folder_UnZipped_Icon% , 1
          FileRemoveDir, %Pc_Folder_UnZipped_AppDataCommon% , 1
          FileRemoveDir, %Pc_Folder_UnZipped_AppData% , 1
          FileRemoveDir, %Pc_Folder_UnZipped_Installed% , 1
          FileDelete, %Pc_File_UpdateDownloadLink%
          FileDelete, %Pc_File_CurrentUpdate%
          FileDelete, %Pc_File_UpdateDownloadedZip%
          ; -------------------------------------------
        } ; End if (Downloaded_OK == 1) (Update Zip File)
        else ; Not Download (Update Zip File)
        {
          ; -------------------------------------------
          FileDelete, %Pc_File_UpdateDownloadLink%
          FileDelete, %Pc_File_UpdateDownloadedZip%
          FileDelete, %Pc_File_CurrentUpdate%
          break
          ; -------------------------------------------
        } ; End Not Download (Update Zip File)
        ; -------------------------------------------
      } ; End if (Downloaded_OK == 1) (Download Link File)
      else ; Not Download (Download Link File)
      {
        ; -------------------------------------------
        FileDelete, %Pc_File_UpdateDownloadLink%
        FileDelete, %Pc_File_CurrentUpdate%
        break
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End While (CurrentUpdate > LastUpdate)
  } ; End if (Downloaded_OK == 1) (Current Update Number)
  else  ; Not Download (Current Update Number)
  {
    ; -------------------------------------------
    FileDelete, %Pc_File_CurrentUpdate%
    ; -------------------------------------------
  } ; End  ; Not Download (Current Update Number)
  ; -------------------------------------------
  return ThisUpdate_Array
  ; -------------------------------------------
} ; End **** Function ****
