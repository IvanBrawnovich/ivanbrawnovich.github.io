; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
Factor_Size_X := 1537
if (A_ScreenWidth > Factor_Size_X)
{
  FactorX := A_ScreenWidth / Factor_Size_X
  FactorY := A_ScreenHeight / 1390
  Pos_X := 38 * FactorX
}
else
{
  FactorX := 1
  Pos_X := 60 * FactorX
}
Pos_Y := 110
; -------------------------------------------
; (504)(1)(Splash Info Script File: Getting URL Data)
; (pl)(Polish)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\504_pl.png"
; -------------------------------------------
WM_USER        := 0x00000400
PBM_SETMARQUEE := WM_USER + 10 ; 
PBM_SETSTATE   := WM_USER + 16
PBS_MARQUEE    := 0x00000008 ; 
; -------------------------------------------
Gui, SI504PL:Margin , 0, 0
Gui, SI504PL:Add, Picture,, %ThisSplash%
Gui, SI504PL:Color, 573694
Gui, SI504PL:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
; -------------------------------------------
; Process Bar
DllCall("uxtheme.dll\SetThemeAppProperties", "UInt", 0)
Gui, SI504PL:Add, Progress, x%Pos_X% y%Pos_Y% w150 h20 c66EE66 hwndMARQ3 +%PBS_MARQUEE%, 50
DllCall("User32.dll\SendMessage", "Ptr", MARQ3, "Int", PBM_SETMARQUEE, "Ptr", 1, "Ptr", 50)
DllCall("uxtheme.dll\SetThemeAppProperties", "UInt", 7)
; -------------------------------------------
Gui, SI504PL:+AlwaysOnTop
Gui, SI504PL:-Caption
Gui, SI504PL:Show, NoActivate
return