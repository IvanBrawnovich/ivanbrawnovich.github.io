﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Icon Image
; -------------------------------------------
f_063(DataArray) ; (063_1)(GUI Object: Select Icon Image)
{
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  ; -------------------------------------------
  if (v_366_5 == "ofl")
  {
    Selected_File := Select_FileFolder(v_365_2, "FileImageFolder") ; Select_Type ("Folder", "FileAppFile", "FileImage", "FileAppOpenWith", "FileUrlOpenWith") > Selected_File  
  }
  else
  {
    Selected_File := Select_FileFolder(v_365_2, "FileImage") ; Select_Type ("Folder", "FileAppFile", "FileImage", "FileAppOpenWith", "FileUrlOpenWith") > Selected_File  
  }
  ; -------------------------------------------
  if Selected_File
  {
    ; -------------------------------------------
    ; SplitPath, Selected_FilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, Selected_File , , , Check_SelectedFile_Ext
    ;
    if (Check_SelectedFile_Ext == "lnk")
    {
      ; FileGetShortcut, LinkFile , OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
      FileGetShortcut, %Selected_File%, Selected_File ; (305_5)(Selected Opening Application [Full File Path])
    }
    ; -------------------------------------------
    ; SplitPath, Selected_FilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, Selected_File , NameIco, , ThisExt
    StringLower, ThisExt, ThisExt
    ; -------------------------------------------
    if (ThisExt == "ico") ; Selected Selected_File is a Ico
    {
      ; -------------------------------------------
      ; Selected Selected_File is a Ico
      ; -------------------------------------------
      DataArray := f_102(Selected_File, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
    } ; End if (ThisExt == "ico")
    ; -------------------------------------------
    else if (NameIco != "PopUpMenu.png" && ThisExt == "svg" or ThisExt == "gif" or ThisExt == "bmp" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "webp" or ThisExt == "tiff" or ThisExt == "tif")
    {
      ; -------------------------------------------
      ; Selected Selected_File is a Image
      ; -------------------------------------------
      DataArray.102.3 := Selected_File ; (102_3)(Main Display Icon: Image Path)
      ; -------------------------------------------
      ; (368_3)(Convert Image To Icon) = 1 | Convert to ico
      ; (368_3)(Convert Image To Icon) = 0 | Convert to for Pum Background Image
      ; -------------------------------------------
      DataArray := Convert_ToIco(DataArray) ; this Function runs f _ 102
      ; -------------------------------------------
    } ; End else if (NameIco != "PopUpMenu.png" && ThisExt == "svg" or ThisExt == "gif" or ThisExt == "bmp" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "webp" or ThisExt == "tiff" or ThisExt == "tif")
    ; -------------------------------------------
    else if(ThisExt == "exe")
    {
      ; -------------------------------------------
      DataArray.307.2 := Selected_File ; (307_2)([url] Current URL)
      DataArray.102.3 := "" ; (102_3)(Main Display Icon: Image Path)
      DataArray := Extract_Icons_From_File(DataArray)
      ; -------------------------------------------
    } ; End (ThisExt == "exe")
    ; -------------------------------------------
  } ; End if Selected_File
  ; -------------------------------------------        
  return DataArray
  ; -------------------------------------------
}
