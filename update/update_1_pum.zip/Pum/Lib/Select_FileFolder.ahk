; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Select_FileFolder(Lang, Select_Type) ; Select_Type ("Folder", "FileAppFile", "FileImage", "FileAppOpenWith", "FileUrlOpenWith") > Selected_File
{
  ; -------------------------------------------
  WinGetClass, This_Class, A
  WinGet, This_Id , ID, ahk_class %This_Class%
  ; -------------------------------------------
  ; =============================================================================================
  ; LOCALISATION
  ; =============================================================================================
  ApplyBText  := "&1"
  CancelBText := "&0"
  ; [SETS]
  ; Prompt Options Filter StartFolder
  if (Select_Type == "Folder") ; "PUM - Select a Folder"
  {
    ; -------------------------------------------
    Options := "OS" ; "OS" = Single Folder
    Filter  := "" ; Not Used Here
    StartFolder := "c:\" 
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+00E4}{U+0068}{U+006C}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0065}{U+0069}{U+006E}{U+0065}{U+006E}{U+0020}{U+004F}{U+0072}{U+0064}{U+006E}{U+0065}{U+0072}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Select a Folder"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0063}{U+0069}{U+006F}{U+006E}{U+0061}{U+0072}{U+0020}{U+0075}{U+006E}{U+0061}{U+0020}{U+0063}{U+0061}{U+0072}{U+0070}{U+0065}{U+0074}{U+0061}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+00E9}{U+006C}{U+0065}{U+0063}{U+0074}{U+0069}{U+006F}{U+006E}{U+006E}{U+0065}{U+007A}{U+0020}{U+0075}{U+006E}{U+0020}{U+0064}{U+006F}{U+0073}{U+0073}{U+0069}{U+0065}{U+0072}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - Seleziona una cartella"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - Wybierz folder"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - Selecione uma pasta"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0412}{U+044B}{U+0431}{U+0435}{U+0440}{U+0438}{U+0442}{U+0435}{U+0020}{U+043F}{U+0430}{U+043F}{U+043A}{U+0443}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0056}{U+00E4}{U+006C}{U+006A}{U+0020}{U+0065}{U+006E}{U+0020}{U+006D}{U+0061}{U+0070}{U+0070}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0042}{U+0069}{U+0072}{U+0020}{U+004B}{U+006C}{U+0061}{U+0073}{U+00F6}{U+0072}{U+0020}{U+0053}{U+0065}{U+00E7}{U+0069}{U+006E}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "Folder") ; "PUM - Select a Folder"
  ; -------------------------------------------
  else if (Select_Type == "FileAppFile") ; "PUM - Select a Application or File" (Any File)
  {
    ; -------------------------------------------
    Options := "I" ; "I" = Files only
    Filter  := "*.*"  ; Any File
    StartFolder := A_ProgramsCommon ; Common Start Menu
    IfNotExist, %StartFolder%
    {
      StartFolder := A_Programs ; User Spicifc Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_ProgramFiles ; Installed Programs Directory
        IfNotExist, %StartFolder%
        {
          StartFolder := A_WinDir
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; End IfNotExist, %StartFolder%
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+00E4}{U+0068}{U+006C}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0065}{U+0069}{U+006E}{U+0065}{U+0020}{U+0041}{U+006E}{U+0077}{U+0065}{U+006E}{U+0064}{U+0075}{U+006E}{U+0067}{U+0020}{U+006F}{U+0064}{U+0065}{U+0072}{U+0020}{U+0044}{U+0061}{U+0074}{U+0065}{U+0069}{U+0020}{U+0061}{U+0075}{U+0073}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Select a Application or File"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006E}{U+0061}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0063}{U+0069}{U+00F3}{U+006E}{U+0020}{U+006F}{U+0020}{U+0061}{U+0072}{U+0063}{U+0068}{U+0069}{U+0076}{U+006F}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+00E9}{U+006C}{U+0065}{U+0063}{U+0074}{U+0069}{U+006F}{U+006E}{U+006E}{U+0065}{U+007A}{U+0020}{U+0075}{U+006E}{U+0065}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}{U+0020}{U+006F}{U+0075}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+0063}{U+0068}{U+0069}{U+0065}{U+0072}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+007A}{U+0069}{U+006F}{U+006E}{U+0061}{U+0020}{U+0075}{U+006E}{U+0027}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+007A}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+006F}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+006C}{U+0065}")
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+0079}{U+0062}{U+0069}{U+0065}{U+0072}{U+007A}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0063}{U+006A}{U+0119}{U+0020}{U+006C}{U+0075}{U+0062}{U+0020}{U+0070}{U+006C}{U+0069}{U+006B}")
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006D}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+0076}{U+006F}{U+0020}{U+006F}{U+0075}{U+0020}{U+0061}{U+0072}{U+0071}{U+0075}{U+0069}{U+0076}{U+006F}")
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0412}{U+044B}{U+0431}{U+0435}{U+0440}{U+0438}{U+0442}{U+0435}{U+0020}{U+043F}{U+0440}{U+0438}{U+043B}{U+043E}{U+0436}{U+0435}{U+043D}{U+0438}{U+0435}{U+0020}{U+0438}{U+043B}{U+0438}{U+0020}{U+0444}{U+0430}{U+0439}{U+043B}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0056}{U+00E4}{U+006C}{U+006A}{U+0020}{U+0065}{U+0074}{U+0074}{U+0020}{U+0070}{U+0072}{U+006F}{U+0067}{U+0072}{U+0061}{U+006D}{U+0020}{U+0065}{U+006C}{U+006C}{U+0065}{U+0072}{U+0020}{U+0065}{U+006E}{U+0020}{U+0066}{U+0069}{U+006C}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0042}{U+0069}{U+0072}{U+0020}{U+0055}{U+0079}{U+0067}{U+0075}{U+006C}{U+0061}{U+006D}{U+0061}{U+0020}{U+0076}{U+0065}{U+0079}{U+0061}{U+0020}{U+0044}{U+006F}{U+0073}{U+0079}{U+0061}{U+0020}{U+0053}{U+0065}{U+00E7}{U+0069}{U+006E}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "FileAppFile") ; "PUM - Select a Application or File"
  ; -------------------------------------------
  else if (Select_Type == "FileImageFolder") ; "PUM - Select a Image or a Application File"
  {
    ; -------------------------------------------
    Options := "I" ; "I" = Files only
    Filter  := "*.ico; *.svg; *.gif; *.bmp; *.jpeg; *.jpg; *.png; *.webp; *.tiff; *.tif; *.exe; *.lnk" ; Image File
    StartFolder := Find_Windows_Public_Folder("Pictures", 0)
    StartFolder := StartFolder "\(_PopUpMenu_)"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+00E4}{U+0068}{U+006C}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0065}{U+0069}{U+006E}{U+0020}{U+0042}{U+0069}{U+006C}{U+0064}{U+0020}{U+006F}{U+0064}{U+0065}{U+0072}{U+0020}{U+0065}{U+0069}{U+006E}{U+0065}{U+0020}{U+0041}{U+006E}{U+0077}{U+0065}{U+006E}{U+0064}{U+0075}{U+006E}{U+0067}{U+0073}{U+0064}{U+0061}{U+0074}{U+0065}{U+0069}{U+0020}{U+0061}{U+0075}{U+0073}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Select a Image or a Application File"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006E}{U+0061}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+006E}{U+0020}{U+006F}{U+0020}{U+0075}{U+006E}{U+0020}{U+0061}{U+0072}{U+0063}{U+0068}{U+0069}{U+0076}{U+006F}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0063}{U+0069}{U+00F3}{U+006E}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+00E9}{U+006C}{U+0065}{U+0063}{U+0074}{U+0069}{U+006F}{U+006E}{U+006E}{U+0065}{U+007A}{U+0020}{U+0075}{U+006E}{U+0065}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+0020}{U+006F}{U+0075}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+0063}{U+0068}{U+0069}{U+0065}{U+0072}{U+0020}{U+0064}{U+0027}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+007A}{U+0069}{U+006F}{U+006E}{U+0061}{U+0020}{U+0075}{U+006E}{U+0027}{U+0069}{U+006D}{U+006D}{U+0061}{U+0067}{U+0069}{U+006E}{U+0065}{U+0020}{U+006F}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+006C}{U+0065}{U+0020}{U+0064}{U+0065}{U+006C}{U+006C}{U+0027}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+007A}{U+0069}{U+006F}{U+006E}{U+0065}")
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+0079}{U+0062}{U+0069}{U+0065}{U+0072}{U+007A}{U+0020}{U+006F}{U+0062}{U+0072}{U+0061}{U+007A}{U+0020}{U+006C}{U+0075}{U+0062}{U+0020}{U+0070}{U+006C}{U+0069}{U+006B}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0063}{U+006A}{U+0069}")
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006D}{U+0061}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+006D}{U+0020}{U+006F}{U+0075}{U+0020}{U+0061}{U+0072}{U+0071}{U+0075}{U+0069}{U+0076}{U+006F}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+0076}{U+006F}")
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0412}{U+044B}{U+0431}{U+0435}{U+0440}{U+0438}{U+0442}{U+0435}{U+0020}{U+0438}{U+0437}{U+043E}{U+0431}{U+0440}{U+0430}{U+0436}{U+0435}{U+043D}{U+0438}{U+0435}{U+0020}{U+0438}{U+043B}{U+0438}{U+0020}{U+0444}{U+0430}{U+0439}{U+043B}{U+0020}{U+043F}{U+0440}{U+0438}{U+043B}{U+043E}{U+0436}{U+0435}{U+043D}{U+0438}{U+044F}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0056}{U+00E4}{U+006C}{U+006A}{U+0020}{U+0065}{U+006E}{U+0020}{U+0062}{U+0069}{U+006C}{U+0064}{U+0020}{U+0065}{U+006C}{U+006C}{U+0065}{U+0072}{U+0020}{U+0065}{U+006E}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}{U+0073}{U+0066}{U+0069}{U+006C}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0042}{U+0069}{U+0072}{U+0020}{U+0047}{U+00F6}{U+0072}{U+00FC}{U+006E}{U+0074}{U+00FC}{U+0020}{U+0076}{U+0065}{U+0079}{U+0061}{U+0020}{U+0055}{U+0079}{U+0067}{U+0075}{U+006C}{U+0061}{U+006D}{U+0061}{U+0020}{U+0044}{U+006F}{U+0073}{U+0079}{U+0061}{U+0073}{U+0131}{U+0020}{U+0073}{U+0065}{U+00E7}{U+0069}{U+006E}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "FileImage") ; "PUM - Select a Image or a Application File"
  ; -------------------------------------------
  else if (Select_Type == "FileImage") ; "PUM - Select a Image or a Application File"
  {
    ; -------------------------------------------
    Options := "I" ; "I" = Files only
    Filter  := "*.ico; *.svg; *.gif; *.bmp; *.jpeg; *.jpg; *.png; *.webp; *.tiff; *.tif; *.exe; *.lnk" ; Image File
    StartFolder := Find_Windows_Public_Folder("Pictures", 0)
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+00E4}{U+0068}{U+006C}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0065}{U+0069}{U+006E}{U+0020}{U+0042}{U+0069}{U+006C}{U+0064}{U+0020}{U+006F}{U+0064}{U+0065}{U+0072}{U+0020}{U+0065}{U+0069}{U+006E}{U+0065}{U+0020}{U+0041}{U+006E}{U+0077}{U+0065}{U+006E}{U+0064}{U+0075}{U+006E}{U+0067}{U+0073}{U+0064}{U+0061}{U+0074}{U+0065}{U+0069}{U+0020}{U+0061}{U+0075}{U+0073}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Select a Image or a Application File"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006E}{U+0061}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+006E}{U+0020}{U+006F}{U+0020}{U+0075}{U+006E}{U+0020}{U+0061}{U+0072}{U+0063}{U+0068}{U+0069}{U+0076}{U+006F}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0063}{U+0069}{U+00F3}{U+006E}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+00E9}{U+006C}{U+0065}{U+0063}{U+0074}{U+0069}{U+006F}{U+006E}{U+006E}{U+0065}{U+007A}{U+0020}{U+0075}{U+006E}{U+0065}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+0020}{U+006F}{U+0075}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+0063}{U+0068}{U+0069}{U+0065}{U+0072}{U+0020}{U+0064}{U+0027}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+007A}{U+0069}{U+006F}{U+006E}{U+0061}{U+0020}{U+0075}{U+006E}{U+0027}{U+0069}{U+006D}{U+006D}{U+0061}{U+0067}{U+0069}{U+006E}{U+0065}{U+0020}{U+006F}{U+0020}{U+0075}{U+006E}{U+0020}{U+0066}{U+0069}{U+006C}{U+0065}{U+0020}{U+0064}{U+0065}{U+006C}{U+006C}{U+0027}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+007A}{U+0069}{U+006F}{U+006E}{U+0065}")
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0057}{U+0079}{U+0062}{U+0069}{U+0065}{U+0072}{U+007A}{U+0020}{U+006F}{U+0062}{U+0072}{U+0061}{U+007A}{U+0020}{U+006C}{U+0075}{U+0062}{U+0020}{U+0070}{U+006C}{U+0069}{U+006B}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0063}{U+006A}{U+0069}")
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0053}{U+0065}{U+006C}{U+0065}{U+0063}{U+0069}{U+006F}{U+006E}{U+0065}{U+0020}{U+0075}{U+006D}{U+0061}{U+0020}{U+0069}{U+006D}{U+0061}{U+0067}{U+0065}{U+006D}{U+0020}{U+006F}{U+0075}{U+0020}{U+0061}{U+0072}{U+0071}{U+0075}{U+0069}{U+0076}{U+006F}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+0076}{U+006F}")
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0412}{U+044B}{U+0431}{U+0435}{U+0440}{U+0438}{U+0442}{U+0435}{U+0020}{U+0438}{U+0437}{U+043E}{U+0431}{U+0440}{U+0430}{U+0436}{U+0435}{U+043D}{U+0438}{U+0435}{U+0020}{U+0438}{U+043B}{U+0438}{U+0020}{U+0444}{U+0430}{U+0439}{U+043B}{U+0020}{U+043F}{U+0440}{U+0438}{U+043B}{U+043E}{U+0436}{U+0435}{U+043D}{U+0438}{U+044F}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0056}{U+00E4}{U+006C}{U+006A}{U+0020}{U+0065}{U+006E}{U+0020}{U+0062}{U+0069}{U+006C}{U+0064}{U+0020}{U+0065}{U+006C}{U+006C}{U+0065}{U+0072}{U+0020}{U+0065}{U+006E}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}{U+0073}{U+0066}{U+0069}{U+006C}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0042}{U+0069}{U+0072}{U+0020}{U+0047}{U+00F6}{U+0072}{U+00FC}{U+006E}{U+0074}{U+00FC}{U+0020}{U+0076}{U+0065}{U+0079}{U+0061}{U+0020}{U+0055}{U+0079}{U+0067}{U+0075}{U+006C}{U+0061}{U+006D}{U+0061}{U+0020}{U+0044}{U+006F}{U+0073}{U+0079}{U+0061}{U+0073}{U+0131}{U+0020}{U+0073}{U+0065}{U+00E7}{U+0069}{U+006E}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "FileImage") ; "PUM - Select a Image or a Application File"
  ; -------------------------------------------
  else if (Select_Type == "FileAppOpenWith") ; "PUM - Open file with this Application"
  {
    ; -------------------------------------------
    Options := "I" ; "I" = Files only
    Filter  := "*.exe; *.lnk" ; Image File
    StartFolder := A_ProgramsCommon ; Common Start Menu
    IfNotExist, %StartFolder%
    {
      StartFolder := A_Programs ; User Spicifc Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_ProgramFiles ; Installed Programs Directory
        IfNotExist, %StartFolder%
        {
          StartFolder := A_WinDir
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; End IfNotExist, %StartFolder%
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      Prompt := "PUM - " Unicode_To_String("{U+00D6}{U+0066}{U+0066}{U+006E}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0064}{U+0069}{U+0065}{U+0020}{U+0044}{U+0061}{U+0074}{U+0065}{U+0069}{U+0020}{U+006D}{U+0069}{U+0074}{U+0020}{U+0064}{U+0069}{U+0065}{U+0073}{U+0065}{U+0072}{U+0020}{U+0041}{U+006E}{U+0077}{U+0065}{U+006E}{U+0064}{U+0075}{U+006E}{U+0067}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Open file with this Application"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0062}{U+0072}{U+0069}{U+0072}{U+0020}{U+0061}{U+0072}{U+0063}{U+0068}{U+0069}{U+0076}{U+006F}{U+0020}{U+0063}{U+006F}{U+006E}{U+0020}{U+0065}{U+0073}{U+0074}{U+0061}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0063}{U+0069}{U+00F3}{U+006E}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+004F}{U+0075}{U+0076}{U+0072}{U+0069}{U+0072}{U+0020}{U+006C}{U+0065}{U+0020}{U+0066}{U+0069}{U+0063}{U+0068}{U+0069}{U+0065}{U+0072}{U+0020}{U+0061}{U+0076}{U+0065}{U+0063}{U+0020}{U+0063}{U+0065}{U+0074}{U+0074}{U+0065}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0070}{U+0072}{U+0069}{U+0020}{U+0066}{U+0069}{U+006C}{U+0065}{U+0020}{U+0063}{U+006F}{U+006E}{U+0020}{U+0071}{U+0075}{U+0065}{U+0073}{U+0074}{U+0061}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+007A}{U+0069}{U+006F}{U+006E}{U+0065}")
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+004F}{U+0074}{U+0077}{U+00F3}{U+0072}{U+007A}{U+0020}{U+0070}{U+006C}{U+0069}{U+006B}{U+0020}{U+007A}{U+0061}{U+0020}{U+0070}{U+006F}{U+006D}{U+006F}{U+0063}{U+0105}{U+0020}{U+0074}{U+0065}{U+006A}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0063}{U+006A}{U+0069}")
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0062}{U+0072}{U+0069}{U+0072}{U+0020}{U+0061}{U+0072}{U+0071}{U+0075}{U+0069}{U+0076}{U+006F}{U+0020}{U+0063}{U+006F}{U+006D}{U+0020}{U+0065}{U+0073}{U+0074}{U+0065}{U+0020}{U+0061}{U+0070}{U+006C}{U+0069}{U+0063}{U+0061}{U+0074}{U+0069}{U+0076}{U+006F}")
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+041E}{U+0442}{U+043A}{U+0440}{U+044B}{U+0442}{U+044C}{U+0020}{U+0444}{U+0430}{U+0439}{U+043B}{U+0020}{U+0441}{U+0020}{U+043F}{U+043E}{U+043C}{U+043E}{U+0449}{U+044C}{U+044E}{U+0020}{U+044D}{U+0442}{U+043E}{U+0433}{U+043E}{U+0020}{U+043F}{U+0440}{U+0438}{U+043B}{U+043E}{U+0436}{U+0435}{U+043D}{U+0438}{U+044F}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+00D6}{U+0070}{U+0070}{U+006E}{U+0061}{U+0020}{U+0066}{U+0069}{U+006C}{U+0065}{U+006E}{U+0020}{U+006D}{U+0065}{U+0064}{U+0020}{U+0064}{U+0065}{U+006E}{U+0020}{U+0068}{U+00E4}{U+0072}{U+0020}{U+0061}{U+0070}{U+0070}{U+006C}{U+0069}{U+006B}{U+0061}{U+0074}{U+0069}{U+006F}{U+006E}{U+0065}{U+006E}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0044}{U+006F}{U+0073}{U+0079}{U+0061}{U+0079}{U+0131}{U+0020}{U+0062}{U+0075}{U+0020}{U+0055}{U+0079}{U+0067}{U+0075}{U+006C}{U+0061}{U+006D}{U+0061}{U+0020}{U+0069}{U+006C}{U+0065}{U+0020}{U+0061}{U+00E7}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "FileAppOpenWith") ; "PUM - Open file with this Application"
  ; -------------------------------------------
  else if (Select_Type == "FileUrlOpenWith") ; "PUM - Open URL with this Internet Browser"
  {
    ; -------------------------------------------
    Options := "I" ; "I" = Files only
    Filter  := "Iexplore.exe; msedge.exe; Brave.exe; chrome.exe; firefox.exe; iridium.exe; Kingpin Private Browser.exe; Maxthon.exe; launcher.exe; slimbrowser.exe; slimjet.exe; UCBrowser.exe; vivaldi.exe; browser.exe; *.lnk" ; Internet Browsers
    StartFolder := A_ProgramsCommon ; Common Start Menu
    IfNotExist, %StartFolder%
    {
      StartFolder := A_Programs ; User Spicifc Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_ProgramFiles ; Installed Programs Directory
        IfNotExist, %StartFolder%
        {
          StartFolder := A_WinDir
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; End IfNotExist, %StartFolder%
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      Prompt := "PUM - " Unicode_To_String("{U+00D6}{U+0066}{U+0066}{U+006E}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0064}{U+0069}{U+0065}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+006D}{U+0069}{U+0074}{U+0020}{U+0064}{U+0069}{U+0065}{U+0073}{U+0065}{U+006D}{U+0020}{U+0049}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}{U+0062}{U+0072}{U+006F}{U+0077}{U+0073}{U+0065}{U+0072}")
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      Prompt := "PUM - Open URL with this Internet Browser"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0062}{U+0072}{U+0069}{U+0072}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+0063}{U+006F}{U+006E}{U+0020}{U+0065}{U+0073}{U+0074}{U+0065}{U+0020}{U+006E}{U+0061}{U+0076}{U+0065}{U+0067}{U+0061}{U+0064}{U+006F}{U+0072}{U+0020}{U+0064}{U+0065}{U+0020}{U+0049}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}")
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      Prompt := "PUM - " Unicode_To_String("{U+004F}{U+0075}{U+0076}{U+0072}{U+0065}{U+007A}{U+0020}{U+006C}{U+0027}{U+0055}{U+0052}{U+004C}{U+0020}{U+0061}{U+0076}{U+0065}{U+0063}{U+0020}{U+0063}{U+0065}{U+0020}{U+006E}{U+0061}{U+0076}{U+0069}{U+0067}{U+0061}{U+0074}{U+0065}{U+0075}{U+0072}{U+0020}{U+0049}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}")
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0070}{U+0072}{U+0069}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+0063}{U+006F}{U+006E}{U+0020}{U+0071}{U+0075}{U+0065}{U+0073}{U+0074}{U+006F}{U+0020}{U+0062}{U+0072}{U+006F}{U+0077}{U+0073}{U+0065}{U+0072}{U+0020}{U+0049}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}")
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+004F}{U+0074}{U+0077}{U+00F3}{U+0072}{U+007A}{U+0020}{U+0061}{U+0064}{U+0072}{U+0065}{U+0073}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+007A}{U+0061}{U+0020}{U+0070}{U+006F}{U+006D}{U+006F}{U+0063}{U+0105}{U+0020}{U+0074}{U+0065}{U+006A}{U+0020}{U+0070}{U+0072}{U+007A}{U+0065}{U+0067}{U+006C}{U+0105}{U+0064}{U+0061}{U+0072}{U+006B}{U+0069}{U+0020}{U+0069}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}{U+006F}{U+0077}{U+0065}{U+006A}")
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0041}{U+0062}{U+0072}{U+0069}{U+0072}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+0063}{U+006F}{U+006D}{U+0020}{U+0065}{U+0073}{U+0074}{U+0065}{U+0020}{U+006E}{U+0061}{U+0076}{U+0065}{U+0067}{U+0061}{U+0064}{U+006F}{U+0072}{U+0020}{U+0064}{U+0065}{U+0020}{U+0049}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}")
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      Prompt := "PUM - " Unicode_To_String("{U+041E}{U+0442}{U+043A}{U+0440}{U+044B}{U+0442}{U+044C}{U+0020}{U+0055}{U+0052}{U+004C}{U+002D}{U+0430}{U+0434}{U+0440}{U+0435}{U+0441}{U+0020}{U+0432}{U+0020}{U+044D}{U+0442}{U+043E}{U+043C}{U+0020}{U+0438}{U+043D}{U+0442}{U+0435}{U+0440}{U+043D}{U+0435}{U+0442}{U+002D}{U+0431}{U+0440}{U+0430}{U+0443}{U+0437}{U+0435}{U+0440}{U+0435}")
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+00D6}{U+0070}{U+0070}{U+006E}{U+0061}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+006D}{U+0065}{U+0064}{U+0020}{U+0064}{U+0065}{U+006E}{U+0020}{U+0068}{U+00E4}{U+0072}{U+0020}{U+0077}{U+0065}{U+0062}{U+0062}{U+006C}{U+00E4}{U+0073}{U+0061}{U+0072}{U+0065}{U+006E}")
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      Prompt := "PUM - " Unicode_To_String("{U+0042}{U+0075}{U+0020}{U+0130}{U+006E}{U+0074}{U+0065}{U+0072}{U+006E}{U+0065}{U+0074}{U+0020}{U+0054}{U+0061}{U+0072}{U+0061}{U+0079}{U+0131}{U+0063}{U+0131}{U+0073}{U+0131}{U+0020}{U+0069}{U+006C}{U+0065}{U+0020}{U+0055}{U+0052}{U+004C}{U+0020}{U+0041}{U+00E7}{U+0131}{U+006E}")
    } ; End (tr Turkish)
  } ; End (Select_Type == "FileAppOpenWith") ; "PUM - Open file with this Application"
  ; -------------------------------------------
  ; ------------------------------------------- Options
  Static DefPromptAM := "Select your file(s) or folder(s)"  ; Options = (Empty) (Any Type/EXT Multiple  Files or Folders) 
  Static DefPromptAS := "Select your file or folder"        ; Options = S  (Only One File or Folder)
  Static DefPromptIM := "Select your files"                 ; Options = I  (Multiple Files)
  Static DefPromptOM := "Select your folders"               ; Options = O  (Multiple Folders)
  Static DefPromptIS := "Select a file"                     ; Options = IS (Only One File)
  Static DefPromptOS := "Select a folder"                   ; Options = OS (Only One Folder)
  ; -------------------------------------------
  ; (if WarnMsgB is set to 1 below)
  ; -------------------------------------------
  ; Text displayed in a warning MsgBox
  Static Warning     := "No file selected!"
  ; Notification in the title bar (extending the prompt text) if option O or a filter is set 
  Static DisplFilter := "Display filter"
  ; Local language word for 'folders' (option O)
  Static FoldersLocL := "Folders"
  ; =============================================================================================
  
  
  ; =============================================================================================
  ; INDIVIDUAL SETTINGS
  ; =============================================================================================
  ; Button arrangement: 1 = (Cancel - Apply), 0 = (Apply - Cancel)
  Static CancelApply := 1
  ; Option = I & No File is selected
  ; (1 = show MsgBox) (0 = only sound)
  Static WarnMsgB    := 0
  ; =============================================================================================
  
  
  ; =============================================================================================
  ; WINDOWS-VERSION ISSUES
  ; =============================================================================================
  Static WinVer := DllCall("GetVersion") & 0xff
  if (WinVer < 6) ; Win XP
  {
    List := "SysListView321", AltProb := 1, ButA := 2, ButB := 3
  }
  ; -------------------------------------------
  if (WinVer >= 6) ;  Win 10
  {
    ; **** Changed This 
    List := "DirectUIHWND2", AltProb := 0, ButA := 1, ButB := 2  
    ;~ List := "DirectUIHWND2", AltProb := 1, ButA := 1, ButB := 2  
  }
  ; =============================================================================================
  
  
  ; =============================================================================================
  ; PROCESSING THE PARAMETERS
  ; =============================================================================================
  if !(Options)
  {
    Case := "All",   Prmpt := DefPromptAM
  }
  if (Options = "S")
  {
    Case := "S",     Prmpt := DefPromptAS
  }
  if InStr(Options, "I")
  {
    if InStr(Options, "S")
    {
      Case := "IS", Prmpt := DefPromptIS
    }
    else
    {
      Case := "I",  Prmpt := DefPromptIM
    }
  }
  ; -------------------------------------------  
  if InStr(Options, "O")
  {
    if InStr(Options, "S")
    {
      Case := "OS", Prmpt := DefPromptOS
    }
    else
    {
      Case := "O",  Prmpt := DefPromptOM
    }
  }
  ; -------------------------------------------  
  if !(Prompt)
  {
    Prompt := Prmpt
  }
  ; -------------------------------------------
  if !(StartFolder)
  {
    StartFolder := "c:\"
  }
  ; -------------------------------------------
  if InStr(Options, "O")
  {
    Filter := "Directories"
  }
  ; -------------------------------------------
  if (Filter = "Directories")
  {
    Filt := FoldersLocL
  }
  else
  {
    Filt := Filter
  }
  ; -------------------------------------------
  if (Filter)
  {
    Prompt := Prompt
  }
  ; -------------------------------------------
  if (Apply)
  {
    ApplyBText := Apply
  }
  if (Cancel)
  {
    CancelBText := Cancel
  }
  ; =============================================================================================
  
  
  ; =============================================================================================
  ; EXTRACTING THE SHORTCUT LETTERS
  ; =============================================================================================
  if (PosA := InStr(ApplyBText, "&"))
  {
    LetA := SubStr(ApplyBText, PosA + 1, 1)
  }
  ; -------------------------------------------
  if (PosC := InStr(CancelBText, "&"))
  {
    LetC := SubStr(CancelBText, PosC + 1, 1)
  }
  ; =============================================================================================
  
  ; =============================================================================================
  ; MAIN PART OF THE FUNCTION
  ; =============================================================================================
  ; Adapting the dialog windows after it is opened
  SetTimer, SI_WaitAndAdapt, 20
  ; -------------------------------------------
  
  ; Opening the dialog window, waiting for the user input
  if InStr(Options, "S")
  {
    FileSelectFile, NotUsed,  , %StartFolder%, %Prompt%, %Filter%
  }
  else
  {
    FileSelectFile, NotUsed, M, %StartFolder%, %Prompt%, %Filter%
  }
  ; -------------------------------------------
  WinWaitClose, %Prompt%
  ; -------------------------------------------
  ; =============================================================================================
  ; Tidying up, returning Selected_Items
  ; =============================================================================================
  Hotkey, !%LetA%,  Off, UseErrorLevel
  Hotkey, !%LetC%,  Off, UseErrorLevel
  Hotkey, Enter,    Off, UseErrorLevel
  Gui ButA: Destroy
  Gui ButB: Destroy
  ; -------------------------------------------
  WinActivate, ahk_id %This_Id%
  ; -------------------------------------------
  return Selected_Items
  ; =============================================================================================
  
  ; =============================================================================================
  ; ADAPTING THE DIALOG WINDOW
  ; =============================================================================================
  ; Timer
  SI_WaitAndAdapt:
  {
    ; Wait for the dialog window
    if !(IdDialog := WinExist(Prompt))
    {
      return
    }
    ; -------------------------------------------
	  ; and go on!
    SetTimer, , Off
    ; -------------------------------------------
	; Getting the coordinates/size of the
	; dialog window (relative to screen)
    WinGetPos, , , WinW, WinH, %Prompt%
    ; -------------------------------------------
	; and of its controls (relative to window)
    ControlGetPos, , ListY, , ListH, %List%
    ControlGet, IdButA, Hwnd, , Button%ButA%
    ControlGet, IdButB, Hwnd, , Button%ButB%
    WinGetPos, ButAX, ButAY, ButAW, ButAH, ahk_id %IdButA%
    WinGetPos, ButBX, ButBY, ButBW, ButBH, ahk_id %IdButB%
	; Calculating the coordinates of the
    AreaX1 := 35, AreaX2 := WinW - 35
	; adaptation area (inside window)
    AreaY1 := ListY + ListH, AreaY2 := WinH
	; Hiding all controls present
    WinGet, ControlList, ControlList, %Prompt%
    Loop, Parse, ControlList, `n
    {
      ControlGetPos, x, y, , , %A_LoopField%, %Prompt%
      if ((x > AreaX1) && (x < AreaX2) && (y > AreaY1) && (y < AreaY2) && (SubStr(A_LoopField, 1, 7) != "Button" . ButA) && (SubStr(A_LoopField, 1, 7) != "Button" . ButB))
      {
        Control, Hide, , %A_LoopField%, %Prompt%
      }
    }
    ; -------------------------------------------
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\img\imgkey"
    }
    else
    {
      Script_Dir := StrReplace(Script_Dir, "\Lib", "\img\imgkey")
    }
    ; -------------------------------------------
	  ; Disabling the shortcut letters of the
    ControlGetText, TextA, , ahk_id %IdButA%
	  ; two buttons to be used for the
    ControlGetText, TextB, , ahk_id %IdButB%
	  ; Apply and Cancel buttons
    TextA := RegExReplace(TextA, "&")
    TextB := RegExReplace(TextB, "&")
    ControlSetText, , %TextA%, ahk_id %IdButA%
    ControlSetText, , %TextB%, ahk_id %IdButB%
    ; -------------------------------------------
	  ; Setting the border of the
    Brdr := 2
	  ; Apply and Cancel buttons
    BtnAW := ButAW - 2*Brdr, BtnAH := ButAH - 2*Brdr
    BtnBW := ButBW - 2*Brdr, BtnBH := ButBH - 2*Brdr
    ; -------------------------------------------
	  ; Assigning the Apply and
    if (CancelApply) ; Cancel buttons to
    {
      LabA := "SI_Cancel"
      LabB := "SI_Apply"
      BolA := "normal"
      BolB := "bold"
      TxtA := CancelBText
      TxtB := ApplyBText
    }
    else
    {
      LabA := "SI_Apply"
      LabB := "SI_Cancel"
      BolA := "bold"
      BolB := "normal"
      TxtA := ApplyBText
      TxtB := CancelBText
     }
    ; -------------------------------------------
    Gui ButA: +ToolWindow -Caption -DPIScale ; Creating a child gui
    Gui ButA: +Parent%IdButA% ; of the ButtonA
    Gui ButA: Font, %BolA%
    
    
    
    Gui ButA: Add, Picture, x2 y2 w%BtnAW% h%BtnAH% g%LabA%, %Script_Dir%\Select_FileFolder_Cancel.png
    ;~ Gui ButA: Add, Button, x2 y2 w%BtnAW% h%BtnAH% g%LabA%, %TxtA%
    
    
    ;~ Gui ButA: Add, Button, x2 y2 w%BtnAW% h%BtnAH% g%LabA%, %TxtA%
    Gui ButA: Show, x0 y0 w%ButAW% h%ButAH%
    Gui ButB: +ToolWindow -Caption -DPIScale ; Creating a child gui
    Gui ButB: +Parent%IdButB% ; of the ButtonB
    Gui ButB: Font, %BolB%
    ; -------------------------------------------
    
    
    
    Gui ButB: Add, Picture, x2 y2 w%BtnBW% h%BtnBH% g%LabB%, %Script_Dir%\Select_FileFolder_Ok.png
    ;~ Gui ButB: Add, Button, x2 y2 w%BtnBW% h%BtnBH% g%LabB%, %TxtB%
    
    
    Gui ButB: Show, x0 y0 w%ButBW% h%ButBH% ; End Cancel.png
    ; -------------------------------------------
    WinActivate, %Prompt%
    Selected_Items := 
    ; -------------------------------------------
    Hotkey, IfWinActive, %Prompt% ; Defining shortcut-letter hotkeys which
    ; -------------------------------------------
    if (LetA) ; are active in the dialog window
    {
      Hotkey, !%LetA%, SI_Apply,  On UseErrorLevel
    }
    ; -------------------------------------------
    if (LetC)
    {
      Hotkey, !%LetC%, SI_Cancel, On UseErrorLevel
    }
    ; -------------------------------------------
    Hotkey, Enter,     SI_Enter, On UseErrorLevel
  }
  return
  ; =============================================================================================
  
  
  ; =============================================================================================
  ; BUTTON AND HOTKEY ACTIONS
  ; =============================================================================================
  SI_Apply: ; Button and hotkey
  {
    ; -------------------------------------------
    WinActivate, %Prompt%
	  ; -------------------------------------------
    if (Selected_Items == "") ; Nothing Selected (or Folder is Selected)
    {
      ClipboardIs := ClipboardAll ; Getting the selected item(s)
      Clipboard := "" ; using Ctrl+c and Clipboard
      WinWaitActive, %Prompt%
      ControlFocus, %List%
      SendInput, ^c
      ClipWait, 0.5
      Selected_Items := Clipboard
      ; -------------------------------------------
      if (Selected_Items == "") ; Nothing Selected (Clipboard is Empty)
      {
        ; -------------------------------------------
        if (Select_Type == "Folder")
        {
          ; -------------------------------------------
          Clipboard := ""
          Send, {Ctrl Down}l{Ctrl Up}
          Sleep, 100
          Send, {Ctrl Down}c{Ctrl Up}
          ClipWait, 0.5
          ThisPath := Clipboard
          Send, {Tab 3}
          ; -------------------------------------------
          Check_Drive := SubStr(ThisPath, 1, 3)
          StringLower, Check_Drive, Check_Drive
          if (Check_Drive != "a:\" && Check_Drive != "b:\" && Check_Drive != "c:\" && Check_Drive != "d:\" && Check_Drive != "e:\" && Check_Drive != "f:\" && Check_Drive != "g:\" && Check_Drive != "h:\" && Check_Drive != "i:\" && Check_Drive != "j:\" && Check_Drive != "k:\" && Check_Drive != "l:\" && Check_Drive != "m:\" && Check_Drive != "n:\" && Check_Drive != "o:\" && Check_Drive != "p:\" && Check_Drive != "q:\" && Check_Drive != "r:\" && Check_Drive != "s:\" && Check_Drive != "t:\" && Check_Drive != "u:\" && Check_Drive != "v:\" && Check_Drive != "w:\" && Check_Drive != "x:\" && Check_Drive != "y:\" && Check_Drive != "z:\")
          {
            Splash_Script("407", 1100) ; ImgNum ("Off"/Number), Sleep_Time > Nothing
          }
          else
          {
            Selected_Items := ThisPath
          }
          ; -------------------------------------------
        } ; End (Select_Type == "Folder")
        ; -------------------------------------------
        else if (Select_Type == "FileAppFile")
        {
          Splash_Script("412", 1100) ; (412_1)(Splash Error Image File: A File is Not Selected)
         ; (412)(01)(Splash Error Image File: A File is Not Selected) 
        } ; End (Select_Type == "FileAppFile")
        ; -------------------------------------------
        else if (Select_Type == "FileImage")
        {
          Splash_Script("418", 1000) ; (418_1)(Splash Error Image File: No Image Selected)
          ; (418)(01)(Splash Error Image File: No Image Selected)
        } ; End (Select_Type == "FileImage")
        else if (Select_Type == "FileAppOpenWith")
        {
          Splash_Script("415", 1100) ; (415_1)(Splash Error Image File: No Executable File Selected)
          ; (415)(01)(Splash Error Image File: No Executable File Selected)
        } ; End (Select_Type == "FileAppOpenWith")
        ; -------------------------------------------
        else if (Select_Type == "FileUrlOpenWith")
        {
          Splash_Script("431", 1000) ; (431_1)(Splash Error Image File: Internet Browser Not Selected)
        }
        ; -------------------------------------------
      } ; End if (Selected_Items == "")
      else ; Something Is Selected
      {
        ; -------------------------------------------
        if (Select_Type == "FileAppFile")
        {
          ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, Selected_Items , , , Check_Selected_Ext
          ;
          if (Check_Selected_Ext == "") ; (The Selected is a Folder)
          {
            Selected_Items := ""
            Splash_Script("412", 1100) ; (412_1)(Splash Error Image File: A File is Not Selected)
          } ; End (Check_Selected_Ext == "")
        } ; End (Select_Type == "FileAppFile")
        ; -------------------------------------------
        if (Select_Type == "FileImage") ; "PUM - Select a Image or a Application File" (Any File)
        {
          ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, Selected_Items , , , Check_Selected_Ext
          ;
          if (Check_Selected_Ext == "") ; (The Selected is a Folder)
          {
            Selected_Items := ""
            Splash_Script("418", 1000) ; (418_1)(Splash Error Image File: No Image Selected)
          } ; End (Check_Selected_Ext == "")
          else if (Check_Selected_Ext == "lnk")
          {
            ; FileGetShortcut, LinkFile , OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
            FileGetShortcut, %Selected_Items%, Check_Selected ; (305_5)(Selected Opening Application [Full File Path])
            ;
            ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
            SplitPath, Check_Selected , , , Check_Selected_Ext
            ;
            if (Check_Selected_Ext == "") ; (The Selected LINK is to a Folder)
            {
              Selected_Items := ""
              Splash_Script("432", 1100) ; (432_1)(Splash Error Image File: The Selected is Not a Image)
            } ; End (Check_Selected_Ext == "")
            ;
            else if (Check_Selected_Ext != "ico" && Check_Selected_Ext != "svg" && Check_Selected_Ext != "gif" && Check_Selected_Ext != "bmp" && Check_Selected_Ext != "jpeg" && Check_Selected_Ext != "jpg" && Check_Selected_Ext != "png" && Check_Selected_Ext != "webp" && Check_Selected_Ext != "tiff" && Check_Selected_Ext != "tif" && Check_Selected_Ext != "exe")
            {
              Selected_Items := ""
              Splash_Script("432", 1100) ; (432_1)(Splash Error Image File: The Selected is Not a Image)
            }  ; End Is a Image
          } ; End (Check_Selected_Ext == "lnk")
        } ; End (Select_Type == "FileImage")
        ; -------------------------------------------
        else if (Select_Type == "FileAppOpenWith")
        {
          ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, Selected_Items , , , Check_Selected_Ext
          ;
          if (Check_Selected_Ext == "") ; (the Selected is a Folder)
          {
            Selected_Items := ""
            Splash_Script("433", 1100) ; (433_1)(Splash Error Image File: The Selected is Not a Application)
          } ; End (Check_Selected_Ext == "")
          ;
          else if (Check_Selected_Ext == "lnk")
          {
            ; FileGetShortcut, LinkFile , OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
            FileGetShortcut, %Selected_Items%, Check_Selected ; (305_5)(Selected Opening Application [Full File Path])
            ;
            ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
            SplitPath, Check_Selected , , , Check_Selected_Ext
            ;
            if (Check_Selected_Ext != "exe") ; (The Selected is NOT a exe)
            {
              Selected_Items := ""
              Splash_Script("433", 1100) ; (433_1)(Splash Error Image File: The Selected is Not a Application)
            } ; End (Check_Selected_Ext != "exe")
          } ; End (Check_Selected_Ext == "lnk")
        } ; End (Select_Type == "FileAppOpenWith")
        ; -------------------------------------------
        else if (Select_Type == "FileUrlOpenWith")
        {
          ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, Selected_Items , , , Check_Selected_Ext
          ;
          if (Check_Selected_Ext == "") ; (the Selected is a Folder)
          {
            Selected_Items := ""
            Splash_Script("434", 1100) ; (434_1)(Splash Error Image File: The Selected is Not a Internet Browser)
          } ; End (Check_Selected_Ext == "")
          ;
          if (Check_Selected_Ext == "lnk")
          {
            ; FileGetShortcut, LinkFile , OutTarget, OutDir, OutArgs, OutDescription, OutIcon, OutIconNum, OutRunState
            FileGetShortcut, %Selected_Items%, Check_Selected ; (305_5)(Selected Opening Application [Full File Path])
            ;
            ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
            SplitPath, Check_Selected , Check_Selected_FileNameExt
            ;
            if (Check_Selected_Ext == "") ; (The Selected LINK is to a Folder)
            {
              Selected_Items := ""
              Splash_Script("434", 1100) ; (434_1)(Splash Error Image File: The Selected is Not a Internet Browser)
            } ; End (Check_Selected_Ext == "")
            ;
            else if (Check_Selected_FileNameExt != "Iexplore.exe" && Check_Selected_FileNameExt != "msedge.exe" && Check_Selected_FileNameExt != "Brave.exe" && Check_Selected_FileNameExt != "chrome.exe" && Check_Selected_FileNameExt != "firefox.exe" && Check_Selected_FileNameExt != "iridium.exe" && Check_Selected_FileNameExt != "Kingpin Private Browser.exe" && Check_Selected_FileNameExt != "Maxthon.exe" && Check_Selected_FileNameExt != "launcher.exe" && Check_Selected_FileNameExt != "slimbrowser.exe" && Check_Selected_FileNameExt != "slimjet.exe" && Check_Selected_FileNameExt != "UCBrowser.exe" && Check_Selected_FileNameExt != "vivaldi.exe" && Check_Selected_FileNameExt != "browser.exe")
            {
              Selected_Items := ""
              Splash_Script("434", 1100) ; (434_1)(Splash Error Image File: The Selected is Not a Internet Browser)
            }
          }
        } ; End (Select_Type == "FileUrlOpenWith")
        ; -------------------------------------------
      } ; End Something Is Selected
      ; -------------------------------------------
      Clipboard := ClipboardIs
      ; -------------------------------------------
      
      if !(Selected_Items)
      {
        return
      }
    }
    else
    {
      ; -------------------------------------------
      if (Select_Type == "FileImage") ; "PUM - Select a Image or a Application File" (Any File)
      {
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, Selected_Items , , , Check_Selected_Ext
        ;
        if (Check_Selected_Ext == "") ; (The Selected is a Folder)
        {
          Selected_Items := ""
          Splash_Script("418", 1000) ; (418_1)(Splash Error Image File: No Image Selected)
        }
      } ; End (Select_Type == "FileImage")
      ; -------------------------------------------
      else if (Select_Type == "FileAppOpenWith")
      {
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, Selected_Items , , , Check_Selected_Ext
        if (Check_Selected_Ext == "")
        {
          Selected_Items := ""
          Splash_Script("415", 1100) ; (415_1)(Splash Error Image File: No Executable File Selected)
        }
      } ; End (Select_Type == "FileAppOpenWith")
      ; -------------------------------------------
      else if (Select_Type == "FileUrlOpenWith")
      {
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, Selected_Items , , , Check_Selected_Ext
        ;
        if (Check_Selected_Ext == "") ; (the Selected is a Folder)
        {
          Selected_Items := ""
          Splash_Script("431", 1100) ; (431_1)(Splash Error Image File: Internet Browser Not Selected)
        } ; End (Check_Selected_Ext == "")
      } ; End (Select_Type == "FileUrlOpenWith")
      ; -------------------------------------------
    }
    ; -------------------------------------------
    Selected_Items := RegExReplace(Selected_Items, "`r")
    ; -------------------------------------------
    if InStr(Case, "I") ; if files only:
    {
      FoldFound := 0, SelIt := ""
      Loop, Parse, Selected_Items, `n
      {
        if !(InStr(FileExist(A_LoopField), "D")) ; eliminating folders from SelectedItems
        {
          SelIt .= "`n" . A_LoopField
        }
        else
        {
          FoldFound := 1
        }
      } ; End Loop, Parse, Selected_Items, `n
      Selected_Items := SubStr(SelIt, 2)
      if (FoldFound)
      {
        if !(Selected_Items) ; and possibly MsgBox
        {
          if (WarnMsgB) ; if no file is selected 
          {
            MsgBox, , , %Warning%
          } ; End if (WarnMsgB) ; if no file is selected 
        } ; End if !(Selected_Items) ; and possibly MsgBox
      } ; End if (FoldFound)
    } ; End if InStr(Case, "I") ; if files only:
	  ; -------------------------------------------
    if (Selected_Items) ; Valid selection:
    {
      WinClose, %Prompt% ; triggering 'return Selected_Items'
    }
    ; -------------------------------------------
  } ; End SI_Apply: ; Button and hotkey
  return
  ; =============================================================================================
  
  
  ; =============================================================================================
  SI_Cancel:
  {
    WinActivate, %Prompt%
    Selected_Items := ""
    WinClose, %Prompt% ; Triggering 'return Selected_Items'
  } ; End SI_Cancel:
  return
  ; =============================================================================================
  SI_Enter:
  {
    ; -------------------------------------------
    WinActivate, %Prompt%
    ; -------------------------------------------
    ControlGetFocus, FocusedCtrl, %Prompt%
    if (FocusedCtrl != List) ; Outside List: normal action
    {
      SendInput {Enter}
    }
    else ; Inside List and 
    { 
      ClipboardIs := ClipboardAll
      Clipboard := ""
      SendInput, ^c
      ClipWait, 0.5
      Selected_Items := Clipboard
      Clipboard := ClipboardIs
      Selected_Items := RegExReplace(Selected_Items, "`r")
      ; -------------------------------------------
      if !(Selected_Items) ; nothing selected: do nothing
      {
        return
      }
	    ; -------------------------------------------
      if InStr(Selected_Items, "`n") ; multiple selection: Apply
      {
        GoSub SI_Apply
      }
      else
      {
        if InStr(FileExist(Selected_Items), "D") ; single selected folder: open folder
        {
          SendInput {Enter}
          SelItem := ""
        }
        else
        {
          WinClose, %Prompt% ; single selected file: Apply
        }
      }
    }
  } ; End SI_Enter:
  return
  ;=================================================================================================================;
} ; End SelectItems(Prompt := "", Options := "", StartFolder := "", Filter := "", Apply := "", Cancel := "")
