﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
_S3_S(DataArray)
{
  ; -------------------------------------------
  /*
  ; -------------------------------------------
  FontColor := "199524" ; (Green)
  FontColor := "a30404" ; (Red)
  FontColor := "000000" ; (Black)
  FontColor := "921297" ; (Purple)
  FontColor := "040e47" ; (Dark Blue) As Admin Color
  ; -------------------------------------------
  (cpl)(mnu) g_004 ; (004_1)(GUI Object: Ok Button)
  
  (ThisItem == "v_120_1") ; (120_1)(GUI Object: [mnu] List Center 1/3)
  
  [These Var are Skiped until End]
  [For (cpl)(mnu) ScriptType]
  g_005 ; (005_1)(GUI Object: Icon Rotate Left)
  g_006 ; (006_1)(GUI Object: Icon Rotate Right)
  g_063 ; (063_1)(GUI Object: Select Icon Image)
  g_064 ; (064_1)(GUI Object: Reset Icon Image)
  g_065 ; (065_1)(GUI Object: <Image Text> Status Bar Description)
  g_100 ; (100_1)(GUI Object: <Displayed Text> Top 1)
  g_102 ; (102_1)(GUI Object: Main Display Icon)
  g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
  g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
  
  [These Var are not Listed until End]
  [For (cpl)(mnu) ScriptType]
  g_104 ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
  g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
  g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
  g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
  g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
  g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
  g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
  g_112 ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
  g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
  g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
  ; -------------------------------------------
  */ ; Info
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [Start Up Vars]
    ; -------------------------------------------
    MissingIconNum := ""
    ; -------------------------------------------
    Script_Type_Only := 0
    ; -------------------------------------------
    v_073_2  := DataArray.73.2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    ;
    v_102_3 := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
    ;
    v_133_2  := DataArray.133.2 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
    ;
    v_301_2  := DataArray.301.2 ; (301_2)([key] KeyArray_Numbers [Array])
    v_301_6  := DataArray.301.6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
    v_301_7  := DataArray.301.7 ; (301_7)([key] KeyArray_Display [String] [by Lang])
    ;
    v_303_2  := DataArray.303.2 ; (303_2)([ofl] Folder Path)
    v_303_3  := DataArray.303.3 ; (303_3)([ofl] Folder Name [NO Folder Path])
    v_305_2  := DataArray.305.2 ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
    ;
    v_305_3  := DataArray.305.3 ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
    v_305_4  := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    v_305_5  := DataArray.305.5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
    v_305_6  := DataArray.305.6 ; (305_6)([rwh] Default Application [Full File Path])
    v_305_8  := DataArray.305.8 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
    v_305_9  := DataArray.305.9 ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
    v_305_10 := DataArray.305.10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
    ;
    v_307_5  := DataArray.307.5 ; (307_5)([url] Selected Opening Browser [Full File Path])
    v_307_6  := DataArray.307.6 ; (307_6)([url] Default Browser [Full File Path])
    v_307_7  := DataArray.307.7 ; (307_7)([url] Use Default Browser [0/1])
    ;
    v_363_5  := DataArray.363.5 ; (363_5)(PC Installed Dir)
    ;
    v_365_2  := DataArray.365.2 ; (365_2)(Current User language)
    ;
    v_366_2  := DataArray.366.2 ; (366_2)(GuiFont Set in DataArray_Set)
    v_366_5  := DataArray.366.5 ; (366_5)(Script Type)
    v_366_6  := DataArray.366.6 ; (366_6)(This Script Error [Integer])
    v_367_2  := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    StringLower, ActiveProcess, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    v_367_3  := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
    v_367_4  := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
    v_367_5  := DataArray.367.5 ; (367_5)([Line 4] Active Process Title)
    v_367_6  := DataArray.367.6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
    ;
    v_370_8  := DataArray.370.8 ; (370_8)(XML_SC_L2 Script [Full File Path])
    ;
    v_386_7  := DataArray.386.7 ; (386_7)(Default Script Type Icon [Folder Path])
    v_386_9  := DataArray.386.9 ; (386_9)(Language Flag Image [Folder Path])
    ; -------------------------------------------
  } ; End [Start Up Vars]
  ; -------------------------------------------
  { ; [Start Up Vars] (mnu)
    ; -------------------------------------------
    v_302_2 := DataArray.302.2 ; (302_2)([mnu] Menu Number #_X_X_[X])
    v_302_3 := DataArray.302.3 ; (302_3)([mnu] Menu Number X_#_X_[X])
    v_302_4 := DataArray.302.4 ; (302_4)([mnu] Menu Number X_X_#_[X])
    v_302_5 := DataArray.302.5 ; (302_5)([mnu] Menu Number X_X_X_[#])
    v_302_6 := DataArray.302.6 ; (302_6)([mnu] Menu Size [#])
    v_302_7 := DataArray.302.7 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
    ; -------------------------------------------
    if !v_302_6 ; (302_6)([mnu] Menu Size [#])
    {
      v_302_6 := 0 ; (302_6)([mnu] Menu Size [#])
      DataArray.302.6 := v_302_6 ; (302_6)([mnu] Menu Size [#])
    }
    if !v_302_2 ; (302_2)([mnu] Menu Number #_X_X_[X])
    {
      v_302_2 := 0 ; (302_2)([mnu] Menu Number #_X_X_[X])
      DataArray.302.2 := v_302_2 ; (302_2)([mnu] Menu Number #_X_X_[X])
    }
    if !v_302_3 ; (302_3)([mnu] Menu Number X_#_X_[X])
    {
      v_302_3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
      DataArray.302.3 := v_302_3 ; (302_3)([mnu] Menu Number X_#_X_[X])
    }
    if !v_302_4 ; (302_4)([mnu] Menu Number X_X_#_[X])
    {
      v_302_4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
      DataArray.302.4 := v_302_4 ; (302_4)([mnu] Menu Number X_X_#_[X])
    }
    if !v_302_5 ; (302_5)([mnu] Menu Number X_X_X_[#])
    {
      v_302_5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      DataArray.302.5 := v_302_5 ; (302_5)([mnu] Menu Number X_X_X_[#])
    }
    ; -------------------------------------------
  } ; End [Start Up Vars] (mnu)
  ; -------------------------------------------
  { ; [Start Up Vars] (cpl)
    ; -------------------------------------------  
    v_300_2 := DataArray.300.2 ; (300_2)([cpl] Menu Number #_X_[X])
    v_300_3 := DataArray.300.3 ; (300_3)([cpl] Menu Number X_#_[X])
    v_300_4 := DataArray.300.4 ; (300_4)([cpl] Menu Number X_X_[#])
    ; -------------------------------------------
    if !v_300_2 ; (300_2)([cpl] Menu Number #_X_[X])
    {
      v_300_2 := 0 ; (300_2)([cpl] Menu Number #_X_[X])
      DataArray.300.2 := v_300_2 ; (300_2)([cpl] Menu Number #_X_[X])
    }
    if !v_300_3 ; (300_3)([cpl] Menu Number X_#_[X])
    {
      v_300_3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
      DataArray.300.3 := v_300_3 ; (300_3)([cpl] Menu Number X_#_[X])
    }
    if !v_300_4 ; (300_4)([cpl] Menu Number X_X_[#])
    {
      v_300_4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
      DataArray.300.4 := v_300_4 ; (300_4)([cpl] Menu Number X_X_[#])
    }
    ; -------------------------------------------
  } ; End [Start Up Vars] (cpl)
  ; -------------------------------------------  
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; -------------------------------------------
  LimitedArray := DataArray.363.9 ; (363_9)(Limited DataArray)
  if (LimitedArray == "")
  {
    LimitedArray := DataArray
  }
  ; -------------------------------------------
  for Index, ThisItem in LimitedArray
  {
    ; -------------------------------------------
    ThisItem := ThisItem.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (ThisItem == "GuiVarEnd")
    {
      break
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_001_1") ; (001_1)(GUI Object: [run][rwh] First App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          Script_Type_Only := "run_rwh"
        }
      }
    } ; (001_1)(GUI Object: [run][rwh] First App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_002_1") ; (002_1)(GUI Object: [run][rwh] Second App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          Script_Type_Only := "run_rwh"
        }
      }
    } ; (002_1)(GUI Object: [run][rwh] Second App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_003_1") ; (003_1)(GUI Object: [run][rwh] Third App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          Script_Type_Only := "run_rwh"
        }
      }
    } ; (003_1)(GUI Object: [run][rwh] Third App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_004_1") ; (004_1)(GUI Object: Ok Button)
    {
      ; -------------------------------------------
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        DataArray := GuiControlImage_PopUpMenu("004", 1, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
      }
      else
      {
        if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        {
          DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
        }
      }
    } ; (004_1)(GUI Object: Ok Button)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_005_1") ; (005_1)(GUI Object: Icon Rotate Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; ------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_102_3 != v_386_7 "\PopUpMenu.png") ; (102_3)(Main Display Icon: Image Path)/(386_7)(Default Script Type Icon [Folder Path])
          {
            if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            {
              DataArray := GuiControlImage_PopUpMenu("005", 1, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
            }
          }
        }
      }
    } ; (005_1)(GUI Object: Icon Rotate Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_006_1") ; (006_1)(GUI Object: Icon Rotate Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_102_3 != v_386_7 "\PopUpMenu.png") ; (102_3)(Main Display Icon: Image Path)/(386_7)(Default Script Type Icon [Folder Path])
          {
            if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            {
              DataArray := GuiControlImage_PopUpMenu("006", 1, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
            }
          }
        }
      }
    } ; (006_1)(GUI Object: Icon Rotate Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_007_1") ; (007_1)(GUI Object: Icon Image 4)
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          Script_Type_Only := "run_rwh"
        }
      }
    } ; (007_1)(GUI Object: Icon Image 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_008_1") ; (008_1)(GUI Object: [key] Alt)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(008)") == 0 && Array_Item_Exist(v_301_2, "(010)") == 0 && Array_Item_Exist(v_301_2, "(011)") == 0) ; (008_1)(GUI Object: [key] Alt)/(010_1)(GUI Object: [key] Alt Left)/(011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("008", 1, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(009)") == Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("008", 3, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
            }
          }
        }
      }
    } ; (008_1)(GUI Object: [key] Alt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_009_1") ; (009_1)(GUI Object: [key] Alt Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(009)") == 0) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
          {
            ; (009_1)(GUI Object: [key] Alt Down)
            ; (012_1)(GUI Object: [key] Alt Up)
            DataArray := GuiControlImage_PopUpMenu("009", 1, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
            DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
          }
          else if (Array_Item_Exist(v_301_2, "(012)") == 0) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("009", 3, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
          }
          else  if (Array_Item_Exist(v_301_2, "(012)") == 1) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("009", 2, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
          }
        }
      }
    } ; (009_1)(GUI Object: [key] Alt Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_010_1") ; (010_1)(GUI Object: [key] Alt Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(009)") == Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("010", 2, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("010", 3, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
            }
          }
        }
      }
    } ; (010_1)(GUI Object: [key] Alt Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_011_1") ; (011_1)(GUI Object: [key] Alt Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(009)") == Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("011", 2, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("011", 3, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
            }
          }
        }
      }
    } ; (011_1)(GUI Object: [key] Alt Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_012_1") ; (012_1)(GUI Object: [key] Alt Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          ; -------------------------------------------
          if (Array_Item_Exist(v_301_2, "(012)") == 0) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(009)") == 0) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("012", 1, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("012", 2, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
          }
        }
      }
    } ; (012_1)(GUI Object: [key] Alt Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_013_1") ; (013_1)(GUI Object: [key] Caps Lock)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(013)") == 0) ; (013_1)(GUI Object: [key] Caps Lock)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("013", 1, 1, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("013", 2, 1, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
          }
        }
      }
    } ; (013_1)(GUI Object: [key] Caps Lock)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_014_1") ; (014_1)(GUI Object: [key] Ctrl Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(014)") == 0) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
          {
            ; (014_1)(GUI Object: [key] Ctrl Down)
            ; (017_1)(GUI Object: [key] Ctrl Up)
            DataArray := GuiControlImage_PopUpMenu("014", 1, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
            DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
          }
          else if (Array_Item_Exist(v_301_2, "(017)") == 0) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("014", 3, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
          }
          else  if (Array_Item_Exist(v_301_2, "(017)") == 1) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("014", 2, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
          }
        }
      }
    } ; (014_1)(GUI Object: [key] Ctrl Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_015_1") ; (015_1)(GUI Object: [key] Ctrl Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(014)") == Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("015", 2, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("015", 3, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_016_1") ; (016_1)(GUI Object: [key] Ctrl Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(014)") == Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("016", 2, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("016", 3, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
            }
          }
        }
      }
    } ; (016_1)(GUI Object: [key] Alt Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_017_1") ; (017_1)(GUI Object: [key] Ctrl Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          ; -------------------------------------------
          if (Array_Item_Exist(v_301_2, "(017)") == 0) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(014)") == 0) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("017", 1, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("017", 2, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
          }
        }
      }
    } ; (017_1)(GUI Object: [key] Ctrl Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_018_1") ; (018_1)(GUI Object: [key] Enter)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(018)") == 0) ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("018", 1, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("018", 2, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
          }
        }
      }
    } ; (018_1)(GUI Object: [key] Enter)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_019_1") ; (019_1)(GUI Object: [key] Enter X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          IsInArray := Array_Item_Exist(v_301_2, "(018)") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
          DataArray := GuiControlImage_PopUpMenu("019", IsInArray, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        }
      }
    } ; (019_1)(GUI Object: [key] Enter X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_020_1") ; (020_1)(GUI Object: [key] Esc)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(020)") == 0) ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("020", 1, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("020", 2, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
          }
        }
      }
    } ; (020_1)(GUI Object: [key] Esc)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_021_1") ; (021_1)(GUI Object: [key] Esc X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          IsInArray := Array_Item_Exist(v_301_2, "(020)") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
          DataArray := GuiControlImage_PopUpMenu("021", IsInArray, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        }
      }
    } ; (021_1)(GUI Object: [key] Esc X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_022_1") ; (022_1)(GUI Object: [key] F1)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(022)") == 0) ; (022_1)(GUI Object: [key] F1)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("022", 1, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("022", 2, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
          }
        }
      }
    } ; (022_1)(GUI Object: [key] F1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_023_1") ; (023_1)(GUI Object: [key] F2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(023)") == 0) ; (023_1)(GUI Object: [key] F2)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("023", 1, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("023", 2, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
          }
        }
      }
    } ; (023_1)(GUI Object: [key] F2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_024_1") ; (024_1)(GUI Object: [key] F3)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(024)") == 0) ; (024_1)(GUI Object: [key] F3)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("024", 1, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("024", 2, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
          }
        }
      }
    } ; (024_1)(GUI Object: [key] F3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_025_1") ; (025_1)(GUI Object: [key] F4)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(025)") == 0) ; (025_1)(GUI Object: [key] F4)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("025", 1, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("025", 2, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
          }
        }
      }
    } ; (025_1)(GUI Object: [key] F4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_026_1") ; (026_1)(GUI Object: [key] F5)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(026)") == 0) ; (026_1)(GUI Object: [key] F5)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("026", 1, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("026", 2, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
          }
        }
      }
    } ; (026_1)(GUI Object: [key] F5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_027_1") ; (027_1)(GUI Object: [key] F6)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(027)") == 0) ; (027_1)(GUI Object: [key] F6)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("027", 1, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("027", 2, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
          }
        }
      }
    } ; (027_1)(GUI Object: [key] F6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_028_1") ; (028_1)(GUI Object: [key] F7)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(028)") == 0) ; (028_1)(GUI Object: [key] F7)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("028", 1, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("028", 2, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
          }
        }
      }
    } ; (028_1)(GUI Object: [key] F7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_029_1") ; (029_1)(GUI Object: [key] F8)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(029)") == 0) ; (029_1)(GUI Object: [key] F8)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("029", 1, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("029", 2, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
          }
        }
      }
    } ; (029_1)(GUI Object: [key] F8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_030_1") ; (030_1)(GUI Object: [key] F9)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(030)") == 0) ; (030_1)(GUI Object: [key] F9)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("030", 1, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("030", 2, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
          }
        }
      }
    } ; (030_1)(GUI Object: [key] F9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_031_1") ; (031_1)(GUI Object: [key] F10)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(031)") == 0) ; (031_1)(GUI Object: [key] F10)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("031", 1, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("031", 2, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
          }
        }
      }
    } ; (031_1)(GUI Object: [key] F10)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_032_1") ; (032_1)(GUI Object: [key] F11)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(032)") == 0) ; (032_1)(GUI Object: [key] F11)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("032", 1, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("032", 2, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
          }
        }
      }
    } ; (032_1)(GUI Object: [key] F11)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_033_1") ; (033_1)(GUI Object: [key] F12)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(033)") == 0) ; (033_1)(GUI Object: [key] F12)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("033", 1, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("033", 2, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
          }
        }
      }
    } ; (033_1)(GUI Object: [key] F12)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_034_1") ; (034_1)(GUI Object: [key] Numpad 0)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(034)") == 0) ; (034_1)(GUI Object: [key] Numpad 0)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("034", 1, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("034", 2, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
          }
        }
      }
    } ; (034_1)(GUI Object: [key] Numpad 0)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_035_1") ; (035_1)(GUI Object: [key] Numpad 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(035)") == 0) ; (035_1)(GUI Object: [key] Numpad 1)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("035", 1, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("035", 2, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
          }
        }
      }
    } ; (035_1)(GUI Object: [key] Numpad 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_036_1") ; (036_1)(GUI Object: [key] Numpad 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(036)") == 0) ; (036_1)(GUI Object: [key] Numpad 2)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("036", 1, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("036", 2, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
          }
        }
      }
    } ; (036_1)(GUI Object: [key] Numpad 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_037_1") ; (037_1)(GUI Object: [key] Numpad 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(037)") == 0) ; (037_1)(GUI Object: [key] Numpad 3)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("037", 1, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("037", 2, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
          }
        }
      }
    } ; (037_1)(GUI Object: [key] Numpad 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_038_1") ; (038_1)(GUI Object: [key] Numpad 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(038)") == 0) ; (038_1)(GUI Object: [key] Numpad 4)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("038", 1, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("038", 2, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
          }
        }
      }
    } ; (038_1)(GUI Object: [key] Numpad 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_039_1") ; (039_1)(GUI Object: [key] Numpad 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(039)") == 0) ; (039_1)(GUI Object: [key] Numpad 5)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("039", 1, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("039", 2, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
          }
        }
      }
    } ; (039_1)(GUI Object: [key] Numpad 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_040_1") ; (040_1)(GUI Object: [key] Numpad 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(040)") == 0) ; (040_1)(GUI Object: [key] Numpad 6)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("040", 1, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("040", 2, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
          }
        }
      }
    } ; (040_1)(GUI Object: [key] Numpad 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_041_1") ; (041_1)(GUI Object: [key] Numpad 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(041)") == 0) ; (041_1)(GUI Object: [key] Numpad 7)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("041", 1, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("041", 2, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
          }
        }
      }
    } ; (041_1)(GUI Object: [key] Numpad 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_042_1") ; (042_1)(GUI Object: [key] Numpad 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(042)") == 0) ; (042_1)(GUI Object: [key] Numpad 8)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("042", 1, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("042", 2, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
          }
        }
      }
    } ; (042_1)(GUI Object: [key] Numpad 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_043_1") ; (043_1)(GUI Object: [key] Numpad 9)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(043)") == 0) ; (043_1)(GUI Object: [key] Numpad 9)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("043", 1, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("043", 2, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
          }
        }
      }
    } ; (043_1)(GUI Object: [key] Numpad 9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_044_1") ; (044_1)(GUI Object: [key] Numpad Add)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(044)") == 0) ; (044_1)(GUI Object: [key] Numpad Add)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("044", 1, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("044", 2, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
          }
        }
      }
    } ; (044_1)(GUI Object: [key] Numpad Add)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_045_1") ; (045_1)(GUI Object: [key] Numpad Divide)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(045)") == 0) ; (045_1)(GUI Object: [key] Numpad Divide)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("045", 1, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("045", 2, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
          }
        }
      }
    } ; (045_1)(GUI Object: [key] Numpad Divide)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_046_1") ; (046_1)(GUI Object: [key] Numpad Dot)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(046)") == 0) ; (046_1)(GUI Object: [key] Numpad Dot)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("046", 1, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("046", 2, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
          }
        }
      }
    } ; (046_1)(GUI Object: [key] Numpad Dot)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_047_1") ; (047_1)(GUI Object: [key] Numpad Enter)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(047)") == 0) ; (047_1)(GUI Object: [key] Numpad Enter)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("047", 1, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("047", 2, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
          }
        }
      }
    } ; (047_1)(GUI Object: [key] Numpad Enter)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_048_1") ; (048_1)(GUI Object: [key] Numpad Multiply)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(048)") == 0) ; (048_1)(GUI Object: [key] Numpad Multiply)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("048", 1, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("048", 2, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
          }
        }
      }
    } ; (048_1)(GUI Object: [key] Numpad Multiply)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_049_1") ; (049_1)(GUI Object: [key] Numpad Subtract)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(049)") == 0) ; (049_1)(GUI Object: [key] Numpad Subtract)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("049", 1, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("049", 2, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
          }
        }
      }
    } ; (049_1)(GUI Object: [key] Numpad Subtract)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_050_1") ; (050_1)(GUI Object: [key] Shift)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(050)") == 0 && Array_Item_Exist(v_301_2, "(052)") == 0 && Array_Item_Exist(v_301_2, "(053)") == 0) ; (050_1)(GUI Object: [key] Shift)/(052_1)(GUI Object: [key] Shift Left)/(053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("050", 1, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
          }
          else
          {
            ; (051_1)(GUI Object: [key] Shift Down)
            ; (054_1)(GUI Object: [key] Shift Up)
            if (Array_Item_Exist(v_301_2, "(051)") == Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("050", 3, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
            }
          }
        }
      }
    } ; (050_1)(GUI Object: [key] Shift)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_051_1") ; (051_1)(GUI Object: [key] Shift Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(051)") == 0) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
          {
            ; (051_1)(GUI Object: [key] Shift Down)
            ; (054_1)(GUI Object: [key] Shift Up)
            DataArray := GuiControlImage_PopUpMenu("051", 1, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
            DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
          }
          else if (Array_Item_Exist(v_301_2, "(054)") == 0) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("051", 3, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
          }
          else  if (Array_Item_Exist(v_301_2, "(054)") == 1) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("051", 2, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
          }
        }
      }
    } ; (051_1)(GUI Object: [key] Shift Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_052_1") ; (052_1)(GUI Object: [key] Shift Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(051)") == Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("052", 2, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("052", 3, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_053_1") ; (053_1)(GUI Object: [key] Shift Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(051)") == Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("053", 2, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("053", 3, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_054_1") ; (054_1)(GUI Object: [key] Shift Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          ; -------------------------------------------
          if (Array_Item_Exist(v_301_2, "(054)") == 0) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(051)") == 0) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("054", 1, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("054", 2, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
          }
        }
      }
    } ; (054_1)(GUI Object: [key] Shift Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_055_1") ; (055_1)(GUI Object: [key] Tab)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(055)") == 0) ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("055", 1, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("055", 2, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
          }
        }
      }
    } ; (055_1)(GUI Object: [key] Tab)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_056_1") ; (056_1)(GUI Object: [key] Tab X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          IsInArray := Array_Item_Exist(v_301_2, "(055)") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
          DataArray := GuiControlImage_PopUpMenu("056", IsInArray, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        }
      }
    } ; (056_1)(GUI Object: [key] Tab X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_057_1") ; (057_1)(GUI Object: [key] Windows Key)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(057)") == 0 && Array_Item_Exist(v_301_2, "(059)") == 0 && Array_Item_Exist(v_301_2, "(060)") == 0) ; (057_1)(GUI Object: [key] Windows Key)/(059_1)(GUI Object: [key] Windows Key Left)/(060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("057", 1, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(058)") == Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("057", 2, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("057", 3, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
            }
          }
        }
      }
    } ; (057_1)(GUI Object: [key] Windows Key)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_058_1") ; (058_1)(GUI Object: [key] Windows Key Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(058)") == 0) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
          {
            ; (058_1)(GUI Object: [key] Windows Key Down)
            ; (061_1)(GUI Object: [key] Windows Key Up)
            DataArray := GuiControlImage_PopUpMenu("058", 1, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
            DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
          }
          else if (Array_Item_Exist(v_301_2, "(061)") == 0) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("058", 3, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
          }
          else  if (Array_Item_Exist(v_301_2, "(061)") == 1) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("058", 2, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
          }
        }
      }
    } ; (058_1)(GUI Object: [key] Windows Key Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_059_1") ; (059_1)(GUI Object: [key] Windows Key Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(058)") == Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("059", 2, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("059", 3, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_060_1") ; (060_1)(GUI Object: [key] Windows Key Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(058)") == Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("060", 2, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
            }
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("060", 3, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_061_1") ; (061_1)(GUI Object: [key] Windows Key Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          ; -------------------------------------------
          if (Array_Item_Exist(v_301_2, "(061)") == 0) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            if (Array_Item_Exist(v_301_2, "(058)") == 0) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("061", 1, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("061", 2, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
          }
        }
      }
    } ; (061_1)(GUI Object: [key] Windows Key Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_062_1") ; (062_1)(GUI Object: Cancel)
    {
      DataArray := GuiControlImage_PopUpMenu("062", 1, 0, DataArray) ; (062_1)(GUI Object: Cancel)
    } ; (062_1)(GUI Object: Cancel)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_063_1") ; (063_1)(GUI Object: Select Icon Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
          {
            DataArray := GuiControlImage_PopUpMenu("063", 1, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
          }
        }
      }
    } ; (063_1)(GUI Object: Select Icon Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_064_1") ; (064_1)(GUI Object: Reset Icon Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "url") ; (366_5)(Script Type)
        {
          if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
          {
            DataArray := GuiControlImage_PopUpMenu("064", 1, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
          }
        }
      }
    } ; (064_1)(GUI Object: Reset Icon Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_065_1") ; (065_1)(GUI Object: <Image Text> Status Bar Description)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
        }
      }
    } ; (065_1)(GUI Object: <Image Text> Status Bar Description)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_066_1") ; (066_1)(GUI Object: <Image Text> Text Input)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("066", 1, 1, DataArray) ; (066_1)(GUI Object: <Image Text> Text Input)
        }
      }
    } ; (066_1)(GUI Object: <Image Text> Text Input)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_067_1") ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("067", 1, 1, DataArray) ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
        }
      }
    } ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_068_1") ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("068_rwh", 1, 1, DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
        }
        else if (v_366_5 == "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("068_url", 1, 1, DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
        }
      }
    } ; (068_1)(GUI Object: [rwh][url] Select Open With Application)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_069_1") ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "rwh" && v_305_8 == 1) ; (366_5)(Script Type)/(305_8)([rwh] Use Default Application to Open This File [0/1])
        {
          ; 1 = Is Use Default
          ; 0 = DO NOT Use Default
          DataArray := GuiControlImage_PopUpMenu("069", 1, 1, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        }
        else if (v_366_5 == "rwh" && v_305_8 == 0) ; (366_5)(Script Type)/(305_8)([rwh] Use Default Application to Open This File [0/1])
        {
          ; 1 = Is Use Default
          ; 0 = DO NOT Use Default
          DataArray := GuiControlImage_PopUpMenu("069", 2, 1, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        }
        else if (v_366_5 == "url" && v_307_7 == 1) ; (366_5)(Script Type)/(307_7)([url] Use Default Browser [0/1])
        {
          ; 1 = Is Use Default
          ; 0 = DO NOT Use Default
          DataArray := GuiControlImage_PopUpMenu("069", 1, 1, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        }
        else if (v_366_5 == "url" && v_307_7 == 0) ; (366_5)(Script Type)/(307_7)([url] Use Default Browser [0/1])
        {
          ; 1 = Is Use Default
          ; 0 = DO NOT Use Default
          DataArray := GuiControlImage_PopUpMenu("069", 2, 1, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        }
      }
    } ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_070_1") ; (070_1)(GUI Object: [cpl] Select Control)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 == "cpl") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("070", 2, 1, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
          }
          else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "key") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("070", 1, 1, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
          }
        }
      }
    } ; (070_1)(GUI Object: [cpl] Select Control)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_071_1") ; (071_1)(GUI Object: [url] Select URL)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url" or v_366_5 == "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 != "url") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
          } 
          else if (v_366_5 == "url") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("071", 2, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
          } 
        }
      }
    } ; (071_1)(GUI Object: [ruf] Select URL)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_072_1") ; (072_1)(GUI Object: [key] Application Only)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (DataArray.72.2 == "" or DataArray.72.2 == 0) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
          {
            DataArray.72.2 := 1 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
          }
          DataArray := GuiControlImage_PopUpMenu("072", DataArray.72.2, 1, DataArray) ; (072_1)(GUI Object: [key] Application Only)/(072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        }
      }
    } ; (072_1)(GUI Object: [key] Application Only)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_073_1") ; (073_1)(GUI Object: [run] As Admin)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          if (DataArray.73.2 == "" or DataArray.73.2 == 0 or DataArray.73.2 == 1) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            DataArray := GuiControlImage_PopUpMenu("073", 1, 1, DataArray) ; (073_1)(GUI Object: [run] As Admin)
          }
          else if (DataArray.73.2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            DataArray := GuiControlImage_PopUpMenu("073", 2, 1, DataArray) ; (073_1)(GUI Object: [run] As Admin)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("073", 0, 1, DataArray) ; (073_1)(GUI Object: [run] As Admin)
        }
      }
    } ; (073_1)(GUI Object: [run][rwh] As Admin)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_074_1") ; (074_1)(GUI Object: [key] Ctrl)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(074)") == 0 && Array_Item_Exist(v_301_2, "(015)") == 0 && Array_Item_Exist(v_301_2, "(016)") == 0) ; (074_1)(GUI Object: [key] Ctrl)/(015_1)(GUI Object: [key] Ctrl Left)/(016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("074", 1, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
          }
          else
          {
            if (Array_Item_Exist(v_301_2, "(014)") == Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
            {
              DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
            }
            else
            {
              DataArray := GuiControlImage_PopUpMenu("074", 3, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
            }
          }
        }
      }
    } ; (074_1)(GUI Object: [key] Ctrl)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_075_1") ; (075_1)(GUI Object: [key] Delete)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(075)") == 0) ; (075_1)(GUI Object: [key] Delete)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("075", 1, 1, DataArray) ; (075_1)(GUI Object: [key] Delete)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("075", 2, 1, DataArray) ; (075_1)(GUI Object: [key] Delete)
          }
        }
      }
    } ; (075_1)(GUI Object: [key] Delete)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_076_1") ; (076_1)(GUI Object: [key] End)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(076)") == 0) ; (076_1)(GUI Object: [key] End)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("076", 1, 1, DataArray) ; (076_1)(GUI Object: [key] End)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("076", 2, 1, DataArray) ; (076_1)(GUI Object: [key] End)
          }
        }
      }
    } ; (076_1)(GUI Object: [key] End)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_077_1") ; (077_1)(GUI Object: [key] Home)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(077)") == 0) ; (077_1)(GUI Object: [key] Home)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("077", 1, 1, DataArray) ; (077_1)(GUI Object: [key] Home)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("077", 2, 1, DataArray) ; (077_1)(GUI Object: [key] Home)
          }
        }
      }
    } ; (077_1)(GUI Object: [key] Home)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_078_1") ; (078_1)(GUI Object: [key] Insert)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(078)") == 0) ; (078_1)(GUI Object: [key] Insert)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("078", 1, 1, DataArray) ; (078_1)(GUI Object: [key] Insert)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("078", 2, 1, DataArray) ; (078_1)(GUI Object: [key] Insert)
          }
        }
      }
    } ; (078_1)(GUI Object: [key] Insert)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_079_1") ; (079_1)(GUI Object: [key] Page Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(079)") == 0) ; (079_1)(GUI Object: [key] Page Down)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("079", 1, 1, DataArray) ; (079_1)(GUI Object: [key] Page Down)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("079", 2, 1, DataArray) ; (079_1)(GUI Object: [key] Page Down)
          }
        }
      }
    } ; (079_1)(GUI Object: [key] Page Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_080_1") ; (080_1)(GUI Object: [key] Page Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (Array_Item_Exist(v_301_2, "(080)") == 0) ; (080_1)(GUI Object: [key] Page Up)/(301_2)([key] KeyArray_Numbers [Array])
          {
            DataArray := GuiControlImage_PopUpMenu("080", 1, 1, DataArray) ; (080_1)(GUI Object: [key] Page Up)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("080", 2, 1, DataArray) ; (080_1)(GUI Object: [key] Page Up)
          }
        }
      }
    } ; (080_1)(GUI Object: [key] Page Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_081_1") ; (081_1)(GUI Object: [run][rwh] Select File)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url" or v_366_5 == "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
          }
          else if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("081", 2, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
          }
        }
      }
    } ; (081_1)(GUI Object: [run][rwh] Select File)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_082_1") ; (082_1)(GUI Object: [ofl] Select Folder)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url" or v_366_5 == "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 != "ofl") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
          }
          else if (v_366_5 == "ofl") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("082", 2, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
          }
        }
      }
    } ; (082_1)(GUI Object: [ofl] Select Folder)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_083_1") ; (083_1)(GUI Object: [ToM] Pum)
    {
      ; -------------------------------------------
      if (v_366_5 == "pum") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("083", 2, 0, DataArray) ; (083_1)(GUI Object: [ToM] Pum)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("083", 1, 0, DataArray) ; (083_1)(GUI Object: [ToM] Pum)
      }
    } ; (083_1)(GUI Object: [ToM] Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_084_1") ; (084_1)(GUI Object: [ToM] File Url Folder)
    {
      if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("084", 2, 1, DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("084", 1, 1, DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
      }
    } ; (084_1)(GUI Object: [ToM] File Url Folder)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_085_1") ; (085_1)(GUI Object: [key] Select Keyboard)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 == "key") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("085", 2, 1, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
          }
          else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "cpl" or v_366_5 == "mnu") ; (366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("085", 1, 1, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
          }
        }
      }
    } ; (085_1)(GUI Object: [key] Select Keyboard)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_086_1") ; (086_1)(GUI Object: [ToM] Menu Control Key)
    {
      if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "key" or v_366_5 == "cpl") ; (366_5)(Script Type)/(366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("086", 2, 1, DataArray) ; (086_1)(GUI Object: [ToM] Menu Control Key)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("086", 1, 1, DataArray) ; (086_1)(GUI Object: [ToM] Menu Control Key)
      }
    } ; (086_1)(GUI Object: [ToM] Menu Control Key)
    ; >>>>>>>>>>>>>>>7>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_087_1") ; (087_1)(GUI Object: [mnu] Select Menu)
    {
      if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
      {
        ; -------------------------------------------
        ; [ScriptError == 3] (Invalid KeyStroke)
        ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
        ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
        ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
        ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
        ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
        ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
        {
          if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key") ; (366_5)(Script Type)/(366_5)(Script Type)
          {
            if (DataArray.302.7 == 1) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
            {
              if (v_366_5 == "mnu") ; (366_5)(Script Type)
              {
                DataArray := GuiControlImage_PopUpMenu("087", 2, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
              }
              else
              {
                DataArray := GuiControlImage_PopUpMenu("087", 1, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
              }
            }
            else ; (302_1)(ScriptType [mnu])_(302_2)([mnu] Menu Item #_X_X_[X])_(302_3)([mnu] Menu Item X_#_X_[X])_(302_4)([mnu] Menu Item X_X_#_[X])_(302_5)([mnu] Menu Item X_X_X_[#])_(302_6)([mnu] Menu Size [#])_(302_7)([mnu] Active Process Has a Addon Installed [1/0])
            {
              DataArray := GuiControlImage_PopUpMenu("087", 3, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
            }
          }
        }
      }
    } ; (087_1)(GUI Object: [mnu] Select Menu)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_088_1") ; (088_1)(GUI Object: [mnu] App Context Menu 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 1) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 1) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(088)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.88.2 := 2 ; (088_2)([mnu] App Context Menu 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(088)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.88.2 := 1 ; (088_2)([mnu] App Context Menu 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.88.3) ; (088_3)([mnu] App Context Menu 1: Image Path)
              {
                DataArray.88.3 := ThisImage ; (088_3)([mnu] App Context Menu 1: Image Path)
                GuiControl, PopUpMenu:, g_088, %ThisImage% ; (088_1)(GUI Object: [mnu] App Context Menu 1)
              }
              GuiControl, PopUpMenu:Show, g_088 ; (088_1)(GUI Object: [mnu] App Context Menu 1)
            }
          }
        }
      }
    } ; (088_1)(GUI Object: [mnu] App Context Menu 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_089_1") ; (089_1)(GUI Object: [mnu] App Context Menu 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 2) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 2) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(089)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.89.2 := 2 ; (089_2)([mnu] App Context Menu 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(089)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.89.2 := 1 ; (089_2)([mnu] App Context Menu 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.89.3) ; (089_3)([mnu] App Context Menu 2: Image Path)
              {
                DataArray.89.3 := ThisImage ; (089_3)([mnu] App Context Menu 2: Image Path)
                GuiControl, PopUpMenu:, g_089, %ThisImage% ; (089_1)(GUI Object: [mnu] App Context Menu 2)
              }
              GuiControl, PopUpMenu:Show, g_089 ; (089_1)(GUI Object: [mnu] App Context Menu 2)
            }
          }
        }
      }
    } ; (089_1)(GUI Object: [mnu] App Context Menu 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_090_1") ; (090_1)(GUI Object: [mnu] App Context Menu 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 3) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 3) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(090)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.90.2 := 2 ; (090_2)([mnu] App Context Menu 3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(090)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.90.2 := 1 ; (090_2)([mnu] App Context Menu 3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.90.3) ; (090_3)([mnu] App Context Menu 3: Image Path)
              {
                DataArray.90.3 := ThisImage ; (090_3)([mnu] App Context Menu 3: Image Path)
                GuiControl, PopUpMenu:, g_090, %ThisImage% ; (090_1)(GUI Object: [mnu] App Context Menu 3)
              }
              GuiControl, PopUpMenu:Show, g_090 ; (090_1)(GUI Object: [mnu] App Context Menu 3)
            }
          }
        }
      }
    } ; (090_1)(GUI Object: [mnu] App Context Menu 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_091_1") ; (091_1)(GUI Object: [mnu] App Context Menu 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 4) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 4) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(091)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.91.2 := 2 ; (091_2)([mnu] App Context Menu 4: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(091)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.91.2 := 1 ; (091_2)([mnu] App Context Menu 4: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.91.3) ; (091_3)([mnu] App Context Menu 4: Image Path)
              {
                DataArray.91.3 := ThisImage ; (091_3)([mnu] App Context Menu 4: Image Path)
                GuiControl, PopUpMenu:, g_091, %ThisImage% ; (091_1)(GUI Object: [mnu] App Context Menu 4)
              }
              GuiControl, PopUpMenu:Show, g_091 ; (091_1)(GUI Object: [mnu] App Context Menu 4)
            }
          }
        }
      }
    } ; (091_1)(GUI Object: [mnu] App Context Menu 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_092_1") ; (092_1)(GUI Object: [mnu] App Context Menu 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 5) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 5) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(092)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.92.2 := 2 ; (092_2)([mnu] App Context Menu 5: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(092)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.92.2 := 1 ; (092_2)([mnu] App Context Menu 5: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.92.3) ; (092_3)([mnu] App Context Menu 5: Image Path)
              {
                DataArray.92.3:= ThisImage ; (092_3)([mnu] App Context Menu 5: Image Path)
                GuiControl, PopUpMenu:, g_092, %ThisImage% ; (092_1)(GUI Object: [mnu] App Context Menu 5)
              }
              GuiControl, PopUpMenu:Show, g_092 ; (092_1)(GUI Object: [mnu] App Context Menu 5)
            }
          }
        }
      }
    } ; (092_1)(GUI Object: [mnu] App Context Menu 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_093_1") ; (093_1)(GUI Object: [mnu] App Context Menu 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 6) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 6) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(093)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.93.2 := 2 ; (093_2)([mnu] App Context Menu 6: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(093)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.93.2 := 1 ; (093_2)([mnu] App Context Menu 6: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.93.3) ; (093_3)([mnu] App Context Menu 6: Image Path)
              {
                DataArray.93.3 := ThisImage ; (093_3)([mnu] App Context Menu 6: Image Path)
                GuiControl, PopUpMenu:, g_093, %ThisImage% ; (093_1)(GUI Object: [mnu] App Context Menu 6)
              }
              GuiControl, PopUpMenu:Show, g_093 ; (093_1)(GUI Object: [mnu] App Context Menu 6)
            }
          }
        }
      }
    } ; (093_1)(GUI Object: [mnu] App Context Menu 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_094_1") ; (094_1)(GUI Object: [mnu] App Context Menu 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 7) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 7) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(094)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.94.2 := 2 ; (094_2)([mnu] App Context Menu 7: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(094)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.94.2 := 1 ; (094_2)([mnu] App Context Menu 7: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.94.3) ; (094_3)([mnu] App Context Menu 7: Image Path)
              {
                DataArray.94.3 := ThisImage ; (094_3)([mnu] App Context Menu 7: Image Path)
                GuiControl, PopUpMenu:, g_094, %ThisImage% ; (094_1)(GUI Object: [mnu] App Context Menu 7)
              }
              GuiControl, PopUpMenu:Show, g_094 ; (094_1)(GUI Object: [mnu] App Context Menu 7)
            }
          }
        }
      }
    } ; (094_1)(GUI Object: [mnu] App Context Menu 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_095_1") ; (095_1)(GUI Object: [mnu] App Context Menu 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 8) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 8) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(095)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.95.2 := 2 ; (095_2)([mnu] App Context Menu 8: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(095)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.95.2 := 1 ; (095_2)([mnu] App Context Menu 8: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.95.3) ; (095_3)([mnu] App Context Menu 8: Image Path)
              {
                DataArray.95.3 := ThisImage ; (095_3)([mnu] App Context Menu 8: Image Path)
                GuiControl, PopUpMenu:, g_095, %ThisImage% ; (095_1)(GUI Object: [mnu] App Context Menu 8)
              }
              GuiControl, PopUpMenu:Show, g_095 ; (095_1)(GUI Object: [mnu] App Context Menu 8)
            }
          }
        }
      }
    } ; (095_1)(GUI Object: [mnu] App Context Menu 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_096_1") ; (096_1)(GUI Object: [mnu] App Context Menu 9)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 9) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 9) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(096)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.96.2 := 2 ; (096_2)([mnu] App Context Menu 9: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(096)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.96.2 := 1 ; (096_2)([mnu] App Context Menu 9: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.96.3) ; (096_3)([mnu] App Context Menu 9: Image Path)
              {
                DataArray.96.3 := ThisImage ; (096_3)([mnu] App Context Menu 9: Image Path)
                GuiControl, PopUpMenu:, g_096, %ThisImage% ; (096_1)(GUI Object: [mnu] App Context Menu 9)
              }
              GuiControl, PopUpMenu:Show, g_096 ; (096_1)(GUI Object: [mnu] App Context Menu 9)
            }
          }
        }
      }
    } ; (096_1)(GUI Object: [mnu] App Context Menu 9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_097_1") ; (097_1)(GUI Object: [mnu] App Context Menu 10)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 10) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 10) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(097)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.97.2 := 2 ; (097_2)([mnu] App Context Menu 10: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(097)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.97.2 := 1 ; (097_2)([mnu] App Context Menu 10: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.97.3) ; (097_3)([mnu] App Context Menu 10: Image Path)
              {
                DataArray.97.3 := ThisImage ; (097_3)([mnu] App Context Menu 10: Image Path)
                GuiControl, PopUpMenu:, g_097, %ThisImage% ; (097_1)(GUI Object: [mnu] App Context Menu 10)
              }
              GuiControl, PopUpMenu:Show, g_097 ; (097_1)(GUI Object: [mnu] App Context Menu 10)
            }
          }
        }
      }
    } ; (097_1)(GUI Object: [mnu] App Context Menu 10)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_098_1") ; (098_1)(GUI Object: [mnu] App Context Menu 11)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 11) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              ; -------------------------------------------
              if (v_302_2 == 11) ; (302_2)([mnu] Menu Number #_X_X_[X])
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(098)_2_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.98.2 := 2 ; (098_2)([mnu] App Context Menu 11: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              else
              {
                ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(098)_1_" v_302_6 "_" v_365_2 ".png" ; (302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
                DataArray.98.2 := 1 ; (098_2)([mnu] App Context Menu 11: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              }
              ; -------------------------------------------
              if (ThisImage != DataArray.98.3) ; (098_3)([mnu] App Context Menu 11: Image Path)
              {
                DataArray.98.3 := ThisImage ; (098_3)([mnu] App Context Menu 11: Image Path)
                GuiControl, PopUpMenu:, g_098, %ThisImage% ; (098_1)(GUI Object: [mnu] App Context Menu 11)
              }
              GuiControl, PopUpMenu:Show, g_098 ; (098_1)(GUI Object: [mnu] App Context Menu 11)
            }
          }
        }
      }
    } ; (098_1)(GUI Object: [mnu] App Context Menu 11)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_100_1") ; (100_1)(GUI Object: <Displayed Text> Top 1)
    {
      ; -------------------------------------------
      ; [(366_6) ScriptError == 1] (Application Target [exe] File Not Found)
      ; -------------------------------------------
      if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; [(366_6) ScriptError == 1] (Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (v_366_6 == 1) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ( %Process% " Missing")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Vermisst" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Missing" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Faltante" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Disparu" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Disperso" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Zaginiony" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Desaparecido" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " потерявшийся" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Försvunnen" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_100_3 := v_305_3 " Kayıp" ; (100_3)(<Displayed Text> Top 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ( %Process% " Missing")
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ("Folder Path")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_100_3 := "Ordnerpfad" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_100_3 := "Folder Path" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_100_3 := "Ruta de carpeta" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_100_3 := "Chemin du dossier" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_100_3 := "Percorso cartella" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_100_3 := "Ścieżkę foldera" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_100_3 := "Caminho da pasta" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_100_3 := "Путь фолдера" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_100_3 := "Sökväg till mapp" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_100_3 := "Klasör Yolu" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ( %Process% " Missing")
          ; -------------------------------------------
        } ; End else
        ; -------------------------------------------
        v_100_3 := Unicode_In_String(v_100_3) ; (100_3)(<Displayed Text> Top 1: Value)
        DataArray.100.3 := v_100_3 ; (100_3)(<Displayed Text> Top 1: Value)
        ; -------------------------------------------
        ; [(366_6) ScriptError == 3] (key)(Invalid KeyStroke)
        ; [(366_6) ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (v_100_3 == "") ; (100_3)(<Displayed Text> Top 1: Value)
        {
          DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
        }
        else
        {
          ; -------------------------------------------
          if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "199524" ; (Green)
          }
          else
          {
            FontColor := "a30404" ; (Red)
          }
          FontSize := 12
          MaxWidth := 480
          Text_Adjust_PopUpMenu("g_100", v_100_3, v_366_2, FontSize, FontColor, MaxWidth) ; (100_3)(<Displayed Text> Top 1: Value)/(366_2)(GuiFont Set in DataArray_Set)/(100_1)(GUI Object: <Displayed Text> Top 1)
        } ; End else
      } ; End (366_5)(Script Type) (run)
      ; -------------------------------------------
      else if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; [(366_6) ScriptError == 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (v_366_6 == 6) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ( %Process% " Missing")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Vermisst" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Missing" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Faltante" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Disparu" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Disperso" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Zaginiony" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Desaparecido" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " потерявшийся" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Försvunnen" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_100_3 := v_303_3 " Kayıp" ; (100_3)(<Displayed Text> Top 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ( %Process% " Missing")
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ("Folder Path")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_100_3 := "Ordnerpfad" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_100_3 := "Folder Path" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_100_3 := "Ruta de carpeta" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_100_3 := "Chemin du dossier" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_100_3 := "Percorso cartella" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_100_3 := "Ścieżkę foldera" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_100_3 := "Caminho da pasta" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_100_3 := "Путь фолдера" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_100_3 := "Sökväg till mapp" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_100_3 := "Klasör Yolu" ; (100_3)(<Displayed Text> Top 1: Value)
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ( %Process% " Missing")
          ; -------------------------------------------
        } ; End else
        ; -------------------------------------------
        v_100_3 := Unicode_In_String(v_100_3) ; (100_3)(<Displayed Text> Top 1: Value)
        DataArray.100.3 := v_100_3 ; (100_3)(<Displayed Text> Top 1: Value)
        ; -------------------------------------------
        ; [(366_6) ScriptError == 3] (key)(Invalid KeyStroke)
        ; [(366_6) ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (v_100_3 == "") ; (100_3)(<Displayed Text> Top 1: Value)
        {
          DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
        }
        else
        {
          ; -------------------------------------------
          if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "199524" ; (Green)
          }
          else
          {
            FontColor := "a30404" ; (Red)
          }
          FontSize := 12
          MaxWidth := 480
          Text_Adjust_PopUpMenu("g_100", v_100_3, v_366_2, FontSize, FontColor, MaxWidth) ; (100_3)(<Displayed Text> Top 1: Value)/(366_2)(GuiFont Set in DataArray_Set)/(100_1)(GUI Object: <Displayed Text> Top 1)
        } ; End else
      } ; End (366_5)(Script Type) (ofl)
      ; -------------------------------------------
    } ; (100_1)(GUI Object: <Displayed Text> Top 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_102_1") ; (102_1)(GUI Object: Main Display Icon)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Application Target [exe] File Not Found)
      ; [ScriptError == 2] (rwh)(No Application to Open File)
      ; [ScriptError == 3] (key)(Invalid KeyStroke)
      ; [ScriptError == 6] (ofl)(Folder Not Found)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_102_3 == "") ; (102_3)(Main Display Icon: Image Path)
          {
            DataArray := f_064(DataArray) ; (064_1)(GUI Object: Reset Icon Image)
          }
          else
          {
            DataArray := f_102(v_102_3, DataArray) ; (102_3)(Main Display Icon: Image Path)/(102_1)(GUI Object: Main Display Icon)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      }
    } ; (102_1)(GUI Object: Main Display Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_103_1") ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)
        {
          if (v_366_5 == "rwh") ; (366_5)(Script Type)
          {
            if (DataArray.305.5 == "") ; (305_5)([rwh] Selected Opening Application [Full File Path])
            {
              DataArray.305.5 := DataArray.305.6 ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_6)([rwh] Default Application [Full File Path])
            }
            ThisImage := DataArray.305.5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
          }
          else if (v_366_5 == "url") ; (366_5)(Script Type)
          {
            if (DataArray.307.5 == "") ; (307_5)([url] Selected Opening Browser [Full File Path])
            {
              DataArray.307.5 := DataArray.307.6 ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_6)([url] Default Browser [Full File Path])
            }
            ThisImage := DataArray.307.5 ; (307_5)([url] Selected Opening Browser [Full File Path])
          }
          if !FileExist(ThisImage)
          {
            ThisImage := v_363_5 "\img\Error.png" ; (363_5)(PC Installed Dir)
          }
          if (ThisImage != DataArray.103.3) ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
          {
            DataArray.103.3 := ThisImage ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
            GuiControl, PopUpMenu:, g_103, %ThisImage% ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
            GuiControl, PopUpMenu:MoveDraw, g_103 , +w30 +h30 ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
          }
          GuiControl, PopUpMenu:Show, g_103 ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
        } 
      } 
    } ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_105_1") ; (105_1)(GUI Object: <Displayed Text> Top 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          if (v_366_5 == "key") ; (366_5)(Script Type)
          {
            v_105_3 := DataArray.301.7 ; (301_7)([key] KeyArray_Display [String] [by Lang])/(105_3)(<Displayed Text> Top 2: Value)
          }
          else if (v_366_5 == "ofl") ; (366_5)(Script Type)
          {
            v_105_3 := DataArray.303.2 ; (303_2)([ofl] Folder Path)/(105_3)(<Displayed Text> Top 2: Value)
          }
          else if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
          {
            v_105_3 := DataArray.305.9 ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])/(105_3)(<Displayed Text> Top 2: Value)
          }
          ; -------------------------------------------
          v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
          DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
          ; -------------------------------------------
          ; [(366_6) ScriptError == 3] (key)(Invalid KeyStroke)
          ; [(366_6) ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
          ; -------------------------------------------
          if (v_105_3 == "") ; (105_3)(<Displayed Text> Top 2: Value)
          {
            DataArray := GuiControlImage_PopUpMenu("105", 0, 0, DataArray) ; (105_1)(GUI Object: <Displayed Text> Top 2)
          }
          else
          {
            ; -------------------------------------------
            ; [(366_6) ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
            ; -------------------------------------------
            if (v_366_6 == 0 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
            {
              FontColor := "199524" ; (Green)
            }
            else
            {
              FontColor := "a30404" ; (Red)
            }
            FontSize := 12
            MaxWidth := 480
            Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
          }
        }
      }
    } ; (105_1)(GUI Object: <Displayed Text> Top 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_113_1") ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)
        {
          ; -------------------------------------------
          ; [ScriptError == 2] (No Application to Open File)
          ; -------------------------------------------
          if (v_366_6 == 2) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            { ; [SET] FontColor
              FontColor := "a30404" ; (Red)
            }
            ; -------------------------------------------
            { ; "No Application to open File"
              ; -------------------------------------------
              if (v_365_2 == "de") ; (365_2)(Current User language)
              {
                v_113_3 := "Keine Anwendung zum Öffnen der Datei" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "en") ; (365_2)(Current User language)
              {
                v_113_3 := "No Application to open File" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "es") ; (365_2)(Current User language)
              {
                v_113_3 := "No hay aplicación para abrir el archivo" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "fr") ; (365_2)(Current User language)
              {
                v_113_3 := "Aucune application pour ouvrir le fichier" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "it") ; (365_2)(Current User language)
              {
                v_113_3 := "Nessuna applicazione per aprire il file" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "pl") ; (365_2)(Current User language)
              {
                v_113_3 := "Brak aplikacji do otwierania pliku" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "pt") ; (365_2)(Current User language)
              {
                v_113_3 := "Sem aplicativo para abrir arquivo" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "ru") ; (365_2)(Current User language)
              {
                v_113_3 := "Нет приложения для открытия файла" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "sv") ; (365_2)(Current User language)
              {
                v_113_3 := "Inget program för att öppna filen" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
              else if (v_365_2 == "tr") ; (365_2)(Current User language)
              {
                v_113_3 := "Dosyayı Açmak Için Uygulama Yok" ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
              }
              ; -------------------------------------------
            } ; End "No Application to open File"
            ; -------------------------------------------
          }
          else ; (366_1)(Gui)_(366_2)(GuiFont Set in DataArray_Set)_(366_3)(First Run [1/0])_(366_4)([cpl][mnu] Selected List Item is a Divider)_(366_5)(Script Type)_(366_6)(This Script Error)
          {
            ; -------------------------------------------
            ; [ScriptError == 0] (No Error)
            ; -------------------------------------------
            { ; [SET] FontColor
              FontColor := "921297" ; (Purple)
            }
            ; -------------------------------------------
            if (v_366_5 == "rwh") ; (366_5)(Script Type)
            {
              ; 1 = Is Use Default
              ; 0 = DO NOT Use Default
              if (v_305_8 == 0) ; (305_8)([rwh] Use Default Application to Open This File [0/1])
              {
                v_113_3 := v_305_5 ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)/(305_5)([rwh] Selected Opening Application [Full File Path])
              }
              ; 1 = Is Use Default
              ; 0 = DO NOT Use Default
              else if (v_305_8 == 1) ; (305_8)([rwh] Use Default Application to Open This File [0/1])
              {
                v_113_3 := v_305_6 ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)/(305_6)([rwh] Default Application [Full File Path])
              }
            } ; End (366_5)(Script Type) (rwh)
            ; -------------------------------------------
            else if (v_366_5 == "url") ; (366_5)(Script Type)
            {
              ; 1 = Is Use Default
              ; 0 = DO NOT Use Default
              if (v_307_7 == 0) ; (307_7)([url] Use Default Browser [0/1])
              {
                v_113_3 := v_307_5 ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)/(307_5)([url] Selected Opening Browser [Full File Path])
              }
              ; 1 = Is Use Default
              ; 0 = DO NOT Use Default
              else if (v_307_7 == 1) ; (307_7)([url] Use Default Browser [0/1])
              {
                v_113_3 := v_307_6 ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)/(307_6)([url] Default Browser [Full File Path])
              }
            } ; End (366_5)(Script Type) (url)
            ; -------------------------------------------
          }
          DataArray.113.3 := v_113_3 ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)
          FontSize := 12
          MaxWidth := 480
          Text_Adjust_PopUpMenu("g_113", v_113_3, v_366_2, FontSize, FontColor, MaxWidth) ; (113_3)(<Displayed Text> Opening Application [Full File Path]: Value)/(366_2)(GuiFont Set in DataArray_Set)/(113_1)(GUI Object: <Displayed Text> Opening Application Path)
        }
      }
    } ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_114_1") ; (114_1)(GUI Object: <Displayed Text> Title 1)
    {
      if (v_133_2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        { ; [SET] FontColor
          FontColor := "ffffff" ; (White)
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Delete Shortcut")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_114_3 := "Verknüpfung Löschen" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_114_3 := "Delete Shortcut" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_114_3 := "Eliminar acceso directo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_114_3 := "Supprimer Le Raccourci" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_114_3 := "Elimina Collegamento" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_114_3 := "Usuń Skrót" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_114_3 := "Excluir atalho" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_114_3 := "Удалить Ярлык" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_114_3 := "Ta Bort Genväg" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_114_3 := "Kısayolu Sil" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
        } ; End (114_1)(Title 1)("Delete Shortcut")
        ; -------------------------------------------
      } ; End (133_2)(Delete Shortcut) = (2)
      ; -------------------------------------------
      else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "run_rwh_url_ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          FontColor := "921297" ; (Purple)
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Create New")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_114_3 := "Neue erstellen" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_114_3 := "Create New" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_114_3 := "Crear nuevo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_114_3 := "Créer de nouveaux" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_114_3 := "Crea nuovo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_114_3 := "Tworzenie nowego" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_114_3 := "Criar novo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_114_3 := "Создать новый" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_114_3 := "Skapa nya" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_114_3 := "Yeni Oluştur" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
        } ; End (114)(Title 1)("Create New")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("mnu_cpl_key") / ("run_rwh_url_ofl")
      ; -------------------------------------------
      else if (v_366_5 == "key") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
          {
            ; 1 = Any Application
            FontColor := "199524" ; (Green)
          }
          ; -------------------------------------------
          else
          {
            ; 2 = Application Only
            FontColor := "921297" ; (Purple)
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (367_2)(Active Process Name)
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Jede Anwendung" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Nur " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Any Application" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := v_367_2 " Only" ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Cualquier Aplicación" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Solo " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Toute Application" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := v_367_2 " Uniquement" ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Qualsiasi Applicazione" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Solo " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Kazda Aplikacja" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Tylko " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Qualquer Aplicação" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Apenas " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Любое приложение" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Только " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Alla Program" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Endast " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Herhangi bir Uygulama" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (072_1)(GUI Object: [key] Application Only)_(072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(072_3)([key] Application Only: Image Path)
            {
              v_114_3 := "Sadece " v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            }
          }
          ; -------------------------------------------
        } ; (367_2)(Active Process Name)
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("key")
      ; -------------------------------------------
      else if (v_366_5 == "mnu") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "921297" ; (Purple)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = (367_2)(Active Process Name)
          ; -------------------------------------------
          v_114_3 := v_367_2 ; (114_3)(<Displayed Text> Title 1: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
          ; -------------------------------------------
        }
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("mnu")
      ; -------------------------------------------
      else if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          ; [(366_6) ScriptError == 6] (ofl)(Folder Not Found)
          ; -------------------------------------------
          if (v_366_6 == 6) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "a30404" ; (Red)
          }
          else
          {
            FontColor := "199524" ; (Green)
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Open Drive") / ("Open Folder")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Laufwerk öffnen" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Offener Ordner" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Open Drive" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Open Folder" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Unidad Drive" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Abrir Carpeta" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Ouvrez le lecteur" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Dossier ouvert" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Apri l'unità" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Apri Cartella" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Otwórz dysk" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Otwórz v_303_3" ; (114_3)(<Displayed Text> Title 1: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Unidade acionar" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Pasta Aberta" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Открыть диск" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Открыть папку" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Öppna Drive" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Öppna Mapp" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
            {
              ; -------------------------------------------
              v_114_3 := "Açık Sürücü" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
            else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            {
              ; -------------------------------------------
              v_114_3 := "Klasörü Aç" ; (114_3)(<Displayed Text> Title 1: Value)
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
        } ; End (114)(Title 1) = ("Open Drive") / ("Open Folder")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("ofl")
      ; -------------------------------------------
      else if (v_366_5 == "run") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          ; [(366_6) ScriptError == 1] (Application Target [exe] File Not Found)
          ; -------------------------------------------
          if (v_366_6 == 1) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "a30404" ; (Red)
          }
          else if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            FontColor := "040e47" ; (Dark Blue) As Admin Color
          }
          else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
          {
            FontColor := "199524" ; (Green) Normal Color
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Run As Administrator") / ("Run")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Ausführen als Administrator" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Betreiben" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Run As Administrator" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Run" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Ejecutar como administrador" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Ejecutar" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Exécuter en tant qu'administrateur" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Fonctionner" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Esegui come Amministratore" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Funzionare" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Uruchom jako Administrator" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Uruchomić" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Executado como Administrador" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Executar" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Выполнить в качестве администратора" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Запустить" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Kör som Administratör" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Köra" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            if (v_073_2 == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              v_114_3 := "Yönetici Olarak Çalıştır" ; (114_3)(<Displayed Text> Title 1: Value)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              v_114_3 := "Çalıştırmak" ; (114_3)(<Displayed Text> Title 1: Value)
            }
          }
          ; -------------------------------------------
        } ; End (114)(Title 1) = ("Run As Administrator") / ("Run")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("run")
      ; -------------------------------------------
      else if (v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          ; [(366_6) ScriptError == 1] (Application Target [exe] File Not Found)
          ; -------------------------------------------
          ; [(366_6) ScriptError == 2] (rwh)(No Application to Open File)
          ; -------------------------------------------
          if (v_366_6 == 1 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "a30404" ; (Red)
            
          }
          else
          {
            FontColor := "199524" ; (Green) 
          }
          ; -------------------------------------------
        } ; End [SET] FontColor
        ; -------------------------------------------
        v_114_3 := v_305_3 ; (114_3)(<Displayed Text> Title 1: Value)/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("rwh")
      ; -------------------------------------------
      else if (v_366_5 == "cpl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "199524" ; (Green) 
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Windows")
          ; -------------------------------------------
          v_114_3 := "Windows" ; (114_3)(<Displayed Text> Title 1: Value)
          ; -------------------------------------------
        } ; End (114)(Title 1) = ("Windows")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("cpl")
      ; -------------------------------------------
      else if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "199524" ; (Green) 
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("URL")
          ; -------------------------------------------
          v_114_3 := "URL" ; (114_3)(<Displayed Text> Title 1: Value)
          ; -------------------------------------------
        } ; End (114)(Title 1) = ("URL")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("url")
      ; -------------------------------------------
      else if (v_366_5 == "xxx") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "921297" ; (Purple)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (114)(Title 1) = ("Create New")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_114_3 := "Neue erstellen" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_114_3 := "Create New" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_114_3 := "Crear nuevo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_114_3 := "Créer de nouveaux" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_114_3 := "Crea nuovo" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_114_3 := "Tworzenie nowego" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_114_3 := "Criar novos" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_114_3 := "Создать новый" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_114_3 := "Skapa nya" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_114_3 := "Yeni Oluştur" ; (114_3)(<Displayed Text> Title 1: Value)
          }
          ; -------------------------------------------
        } ; End (114)(Title 1) = ("Create New")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("xxx")
      ; -------------------------------------------
      FontSize := 14
      Text_Adjust_PopUpMenu("g_114", v_114_3, v_366_2, FontSize, FontColor, 158)  ; (114_3)(<Displayed Text> Title 1: Value)/(366_2)(GuiFont Set in DataArray_Set)/(114_1)(GUI Object: <Displayed Text> Title 1)
      ; -------------------------------------------
    } ; (114_1)(GUI Object: <Displayed Text> Title 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_115_1") ; (115_1)(GUI Object: <Displayed Text> Title 2)
    {
      if (v_133_2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "ffffff" ; (White)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Press Accept")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Drücken Akzeptieren" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Press Accept" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Pulsar Aceptar" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Pousser Accepter" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Spingere Accettare" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Naciśnij Zaakceptować" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Pressione Aceitar" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "Нажмите Принять" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Trycka Acceptera" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Kabul Et'e basın" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Press Accept")
        ; -------------------------------------------
      } ; End (133_2)(Delete Shortcut) = (2)
      ; -------------------------------------------
      else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "run_rwh_url_ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "921297" ; (Purple)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Shortcut")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Verknüpfung" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Shortcut" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Acceso directo" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Raccourci" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Collegamento" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Skrótu" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Atalho" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "ярлык" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Genväg" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Kısayol" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Shortcut")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("mnu_cpl_key") / ("run_rwh_url_ofl")
      ; -------------------------------------------
      else if (v_366_5 == "key") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          if (v_366_6 == 3) ; (366_6)(This Script Error [Integer])
          {
            FontColor := "a30404" ; (Red)
          }
          else
          {
            FontColor := "199524" ; (Green)
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Keystroke Entry")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Tastenanschlag Eintrag" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Keystroke Entry" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Entrada de pulsación de tecla" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Entrée de frappe" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Immissione della sequenza di tasti" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Wpisywanie Klawiszy" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Entrada de teclas" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "Ключевой удар Вступление" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Tangenttryckningar" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Tuş vuruşu Girişi" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Keystroke Entry")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("key")
      ; -------------------------------------------
      else if (v_366_5 == "mnu") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          FontColor := "921297" ; (Purple)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Context Menu")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Kontextmenü" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Context Menu" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Menú Contextual" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Menu Contexte" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Menu contestuale" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Menu kontekstowe" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Menu contextual" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "Контекстное меню" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Snabbmenyn" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Bağlam Menüsü" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Context Menu")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("mnu")
      ; -------------------------------------------
      else if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          ; -------------------------------------------
          if (StrLen(v_303_3) == 3) ; (303_3)([ofl] Folder Name [NO Folder Path])
          {
            FontColor := "199524" ; (Green)
          }
          else ; (303_1)(ScriptType [ofl])_(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
          {
            FontColor := "921297" ; (Purple)
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Drive letter") / (Folder Name)
          ; -------------------------------------------
          if (StrLen(v_303_2) == 3) ; (303_2)([ofl] Folder Path)
          {
            ; ------------------------------------------(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
            ; is a Drive letter
            StringUpper, v_303_2, v_303_2 ; (303_2)([ofl] Folder Path)
            v_115_3 := v_303_2 ; (115_3)(<Displayed Text> Title 2: Value)/(303_2)([ofl] Folder Path)
            ; -------------------------------------------
          } ; End is a Drive letter
          else ; Folder Name No Path
          {
            ; -------------------------------------------
            ; is a Folder
            ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
            Reversed_String_1 := String_Reverse(v_303_2) ; (303_2)([ofl] Folder Path)
            Backslash_Position := InStr(Reversed_String_1, "\")
            Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
            v_303_3 := String_Reverse(Reversed_String_2) ; (303_3)([ofl] Folder Name [NO Folder Path])
            DataArray.303.3 := v_303_3 ; (303_3)([ofl] Folder Name [NO Folder Path])
            v_115_3 := v_303_3 ; (115_3)(<Displayed Text> Title 2: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
            ; -------------------------------------------
          } ; End Folder Name No Path
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Drive letter") / (Folder Name)
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("ofl")
      ; -------------------------------------------
      else if (v_366_5 == "run") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        ; [ScriptError == 1] (Target File Not Found)
        ; -------------------------------------------
        if (v_366_6 == 1) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          { ; [SET] FontColor
            ; -------------------------------------------
            FontColor := "a30404" ; (Red)
            ; -------------------------------------------
          }
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ("Target File Not Found")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_115_3 := "Zieldatei nicht gefunden" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_115_3 := "Target File Not Found" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_115_3 := "Archivo de destino no encontrado" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_115_3 := "Fichier cible introuvable" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_115_3 := "File di destinazione non trovato" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_115_3 := "Nie znaleziono pliku docelowego" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_115_3 := "Arquivo de destino não encontrado" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_115_3 := "Целевой файл не найден" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_115_3 := "Målfil hittades inte" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_115_3 := "Hedef Dosya Bulunamadı" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ("Target File Not Found")
          ; -------------------------------------------            
        } ; End (366_6)(This Script Error) = 1
        ; -------------------------------------------
        else ; (366_6)(This Script Error) != 1
        {
          ; -------------------------------------------
          { ; [SET] FontColor
            ; -------------------------------------------
            if (v_073_2 == 1) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              FontColor := "199524" ; (Green)
            }
            else ; (073_1)(GUI Object: [run][rwh] As Admin)_(073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(073_3)([run][rwh] As Admin: Image Path)
            {
              FontColor := "921297" ; (Purple)
            }
            ; -------------------------------------------
          }
          ; -------------------------------------------
          { ; (115)(Title Text 2) = (File Name & Extension)
            ; -------------------------------------------
            ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
            SplitPath, v_305_4 , v_115_3 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])/(115_3)(<Displayed Text> Title 2: Value)
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = (File Name & Extension)
          ; -------------------------------------------
        } ; End (366_6)(This Script Error) != 1
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("run")
      ; -------------------------------------------
      else if (v_366_5 == "rwh") ; (366_5)(Script Type)
      {
         ; -------------------------------------------
         ; [ScriptError == 1] (Target File Not Found)
         ; -------------------------------------------
        if (v_366_6 == 1) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          { ; [SET] FontColor
            ; -------------------------------------------
            FontColor := "a30404" ; (Red)
            ; -------------------------------------------
          }
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ("Target File Not Found")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_115_3 := "Zieldatei nicht gefunden" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_115_3 := "Target File Not Found" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_115_3 := "Archivo de destino no encontrado" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_115_3 := "Fichier cible introuvable" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_115_3 := "File di destinazione non trovato" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_115_3 := "Nie znaleziono pliku docelowego" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_115_3 := "Arquivo de destino não encontrado" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_115_3 := "Целевой файл не найден" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_115_3 := "Målfil hittades inte" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_115_3 := "Hedef Dosya Bulunamadı" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ("Target File Not Found")
          ; -------------------------------------------            
        } ; End (366_6)(This Script Error) = 1
        ; -------------------------------------------
        ; [ScriptError == 2] (No Application to Open File)
        ; -------------------------------------------
        else if (v_366_6 == 2) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          { ; [SET] FontColor
            ; -------------------------------------------
            FontColor := "a30404" ; (Red)
            ; -------------------------------------------
          }
          ; -------------------------------------------
          { ; (115)(Title Text 2) = ("No Application to open File")
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_115_3 := "Keine Anwendung zum Öffnen der Datei" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_115_3 := "No Application to open File" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_115_3 := "No hay aplicación para abrir el archivo" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_115_3 := "Aucune application pour ouvrir le fichier" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_115_3 := "Nessuna applicazione per aprire il file" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_115_3 := "Brak aplikacji do otwierania pliku" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_115_3 := "Sem aplicativo para abrir arquivo" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_115_3 := "Нет приложения для открытия файла" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_115_3 := "Inget program för att öppna filen" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_115_3 := "Dosyayı Açmak Için Uygulama Yok" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
          } ; End (115)(Title Text 2) = ("No Application to open File")
          ; -------------------------------------------            
        } ; End (366_6)(This Script Error) = 2
        ; -------------------------------------------
        else ; (366_6)(This Script Error) != 1 or != 2
        {
          ; -------------------------------------------
          { ; [SET] FontColor
            ; -------------------------------------------
            FontColor := "921297" ; (Purple)
            ; -------------------------------------------
          }
          ; -------------------------------------------
          { ; (113_1)(GUI Object: <Displayed Text> Opening Application Path) "Open With"
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_115_3 := "Öffnen Mit" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_115_3 := "Open With" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_115_3 := "Abrir con" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_115_3 := "Ouvrir avec" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_115_3 := "Aperta con" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_115_3 := "Otwierać z" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_115_3 := "Abrir com" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_115_3 := "Открыть с" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_115_3 := "Öppna med" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_115_3 := "Bununla aç" ; (115_3)(<Displayed Text> Title 2: Value)
            }
            ; -------------------------------------------
          } ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
        ; -------------------------------------------
        } ; End (366_6)(This Script Error) != 1 or != 2
      } ; End (366_5)(Script Type) = ("rwh")
      ; -------------------------------------------
      else if (v_366_5 == "cpl") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          FontColor := "199524" ; (Green)
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Control")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Steuerung" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Control" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Control" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Contrôle" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Controllo" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Kontroli" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Controle" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "Управления" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Kontroll" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Denetim" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Control")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("cpl")
      ; -------------------------------------------
      else if (v_366_5 == "url" or v_366_5 == "xxx") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        { ; [SET] FontColor
          FontColor := "921297" ; (Purple)
        }
        ; -------------------------------------------
        { ; (115)(Title Text 2) = ("Shortcut")
          ; -------------------------------------------
          if (v_365_2 == "de") ; (365_2)(Current User language)
          {
            v_115_3 := "Verknüpfung" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "en") ; (365_2)(Current User language)
          {
            v_115_3 := "Shortcut" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "es") ; (365_2)(Current User language)
          {
            v_115_3 := "Acceso directo" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "fr") ; (365_2)(Current User language)
          {
            v_115_3 := "Raccourci" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "it") ; (365_2)(Current User language)
          {
            v_115_3 := "Scelta rapida" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pl") ; (365_2)(Current User language)
          {
            v_115_3 := "Skrótów" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "pt") ; (365_2)(Current User language)
          {
            v_115_3 := "Atalho" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "ru") ; (365_2)(Current User language)
          {
            v_115_3 := "ярлык" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "sv") ; (365_2)(Current User language)
          {
            v_115_3 := "Genväg" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
          else if (v_365_2 == "tr") ; (365_2)(Current User language)
          {
            v_115_3 := "Kısayol" ; (115_3)(<Displayed Text> Title 2: Value)
          }
          ; -------------------------------------------
        } ; End (115)(Title Text 2) = ("Shortcut")
        ; -------------------------------------------
      } ; End (366_5)(Script Type) = ("url") / ("xxx")
      ; -------------------------------------------
      FontSize := 14
      Text_Adjust_PopUpMenu("g_115", v_115_3, v_366_2, FontSize, FontColor, 158) ; (115_3)(<Displayed Text> Title 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(115_1)(GUI Object: <Displayed Text> Title 2)
      ; -------------------------------------------
    } ; (115_1)(GUI Object: <Displayed Text> Title 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_122_1") ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          ; -------------------------------------------
          v_122_3 := DataArray.122.3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
          ; -------------------------------------------
          if (v_122_3 != "")
          {
            GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
          }
          GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
          ; -------------------------------------------
        }
      }
    } ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_123_1") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "key") ; (366_5)(Script Type)
        {
          if (DataArray.451.1 != "123") ; (451_1)(Error Fix Skip This Var)
          {
            for Index, CheckThisKey in v_301_2 ; (301_2)([key] KeyArray_Numbers [Array])
            {
              if (SubStr(CheckThisKey, 1, 1) == "~")
              {
                v_123_3 := SubStr(CheckThisKey, 2, StrLen(CheckThisKey) - 2) ; (123_3)(<Edit Feild> [key] Text Input: Value)
                DataArray.123.3 := v_123_3 ; (123_3)(<Edit Feild> [key] Text Input: Value)
                GuiControl, PopUpMenu:, g_123, %v_123_3% ; (123_3)(<Edit Feild> [key] Text Input: Value)/(123_1)(GUI Object: <Edit Feild> [key] Text Input)
                break
              }
            }
          }
          GuiControl, PopUpMenu:Show, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        } ; End (366_5)(Script Type) (key)
      } ; End (366_6)(This Script Error [Integer])
    } ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_125_1") ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 1) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("125", 2, 0, DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("125", 1, 0, DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_126_1") ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 2) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("126", 2, 0, DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("126", 1, 0, DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_127_1") ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 3) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("127", 2, 0, DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("127", 1, 0, DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_128_1") ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 4) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("128", 2, 0, DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("128", 1, 0, DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_129_1") ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 5) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("129", 2, 0, DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("129", 1, 0, DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_130_1") ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 6) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("130", 2, 0, DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("130", 1, 0, DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_131_1") ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    {
      if (v_133_2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        if (v_366_5 == "url") ; (366_5)(Script Type)
        {
          if (v_366_6 != 19) ; (366_6)(This Script Error [Integer])
          {
            URL_Current := DataArray.307.2 ; (307_2)([url] Current URL)
            URL_Current := StrReplace(URL_Current, A_Space, "")
            if (InStr(URL_Current, "http://") == 0 && InStr(URL_Current, "https://") == 0 && InStr(URL_Current, "ftp://") == 0)
            {
              URL_Current := "http://" URL_Current 
            }
            v_131_3 := URL_Current ; (131_3)(<Edit Feild> [url] URL Address: Value)
            DataArray.131.3 := v_131_3 ; (131_3)(<Edit Feild> [url] URL Address: Value)
            GuiControl, PopUpMenu:, g_131, %v_131_3% ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
            GuiControl, PopUpMenu:Show, g_131 ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
          }
        }
      }
    } ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_132_1") ; (132_1)(GUI Object: [url] Select Get URL Data)
    {
      ; -------------------------------------------
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("132", 1, 1, DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
        }
      }
    } ; (132_1)(GUI Object: [url] Select Get URL Data)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_133_1") ; (133_1)(GUI Object: Delete Shortcut)
    {
      if (v_370_8 != "") ; (370_8)(XML_SC_L2 Script [Full File Path])
      {
        if (v_366_5 != "run_rwh_url_ofl" && v_366_5 != "mnu_cpl_key") ; (366_5)(Script Type)
        {
          if (DataArray.133.2 == 0) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
          {
            DataArray.133.2 := 1 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
          }
          DataArray.133.3 := "" ; (133_3)(Delete Shortcut: Image Path)
          v_133_2 := DataArray.133.2 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
          DataArray := GuiControlImage_PopUpMenu("133", v_133_2, 1, DataArray) ; (133_1)(GUI Object: Delete Shortcut)/(133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        }
        else
        {
          DataArray.133.2 := 0 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
          DataArray.133.3 := "" ; (133_3)(Delete Shortcut: Image Path)
        }
      }
      else
      {
        DataArray.133.2 := 0 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        DataArray.133.3 := "" ; (133_3)(Delete Shortcut: Image Path)
      }
    } ; (133_1)(GUI Object: Delete Shortcut)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_134_1") ; (134_1)(GUI Object: Message Image 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; -------------------------------------------
      if (v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 8 or v_366_6 == 12 or v_366_6 == 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
        ; -------------------------------------------
        if (v_366_6 == 8) ; (366_6)(This Script Error [Integer])
        {
          ThisImage := v_363_5 "\img\msg\MSGImg1_run.png" ; (363_5)(PC Installed Dir)
        }
        ; -------------------------------------------
        ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
        ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
        ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
        ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        else if (v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 12 or v_366_6 == 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
        {
          StringLower, msg_icons_Process, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
          msg_icon_v_303_3 := A_AppDataCommon "\PopUpMenu_PUM\msg_icons" ; (303_3)([ofl] Folder Name [NO Folder Path])
          msg_icon_File := msg_icon_v_303_3 "\" msg_icons_Process "_0.ico" ; (303_3)([ofl] Folder Name [NO Folder Path])
          if FileExist(msg_icon_File)
          {
            ThisImage := msg_icon_File
          }
          else ; Icon does exist (Create it)
          {
            PumIconExtract := v_363_5 "\support\PumIconExtract.exe" ; (363_5)(PC Installed Dir)
            RunThis := PumIconExtract " ""-res=" v_367_6 ",0" """ ""-icon=" msg_icon_File """ -formats=32,48,256 -pngc" ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
            RunWait, %RunThis%, , Hide
            if FileExist(msg_icon_File)
            {
              ThisImage := msg_icon_File
            }
            else
            {
              ThisImage := v_363_5 "\ico\exe.ico" ; (363_5)(PC Installed Dir)
            }
          }
        }
        if (ThisImage != DataArray.134.3) ; (134_3)(Message Image 1: Image Path)
        {
          DataArray.134.3 := ThisImage ; (134_3)(Message Image 1: Image Path)
          GuiControl, PopUpMenu:, g_134, %ThisImage% ; (134_1)(GUI Object: Message Image 1)
          ; -------------------------------------------
          ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
          ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
          ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
          ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
          ; -------------------------------------------
          if (v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 12 or v_366_6 == 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
          {
            GuiControl, PopUpMenu:Move, g_134, x40 y207 w70 h70 ; (134_1)(GUI Object: Message Image 1)
            winset redraw
          }
        }
        GuiControl, PopUpMenu:Show, g_134 ; (134_1)(GUI Object: Message Image 1)
      }
    } ; (134_1)(GUI Object: Message Image 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_135_1") ; (135_1)(GUI Object: Message Image 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 8 or v_366_6 == 12 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url" or v_366_5 == "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          ThisImage := v_363_5 "\img\msg\MSGImg2_url.png" ; (363_5)(PC Installed Dir)
        }
        else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          ThisImage := v_363_5 "\img\msg\MSGImg2_cpl.png" ; (363_5)(PC Installed Dir)
        }
        if (ThisImage != DataArray.135.3) ; (135_3)(Message Image 2: Image Path)
        {
          DataArray.135.3 := ThisImage ; (135_3)(Message Image 2: Image Path)
          GuiControl, PopUpMenu:, g_135, %ThisImage% ; (135_1)(GUI Object: Message Image 2)
        }
        GuiControl, PopUpMenu:Show, g_135 ; (135_1)(GUI Object: Message Image 2)
      }
    } ; (135_1)(GUI Object: Message Image 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_136_1") ; (136_1)(GUI Object: Message Image 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 8 or v_366_6 == 12 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "run_rwh_url_ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url" or v_366_5 == "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          ThisImage := v_363_5 "\img\msg\MSGImg3_ofl.png" ; (363_5)(PC Installed Dir)
        }
        else if (v_366_5 == "mnu_cpl_key" or v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          ThisImage := v_363_5 "\img\msg\MSGImg3_key.png" ; (363_5)(PC Installed Dir)
        }
        if (ThisImage != DataArray.136.3) ; (136_3)(Message Image 3: Image Path)
        {
          DataArray.136.3 := ThisImage ; (136_3)(Message Image 3: Image Path)
          GuiControl, PopUpMenu:, g_136, %ThisImage% ; (136_1)(GUI Object: Message Image 3)
        }
        GuiControl, PopUpMenu:Show, g_136 ; (136_1)(GUI Object: Message Image 3)
      }
    } ; (136_1)(GUI Object: Message Image 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_137_1") ; (137_1)(GUI Object: Message Image 4)
    {
      ; -------------------------------------------
      if (v_366_6 == 0 && v_366_5 == "url") ; (366_6)(This Script Error [Integer])/(366_5)(Script Type)
      {
        ThisImage := v_363_5 "\img\msg\MSGImg4_SE15_" v_365_2 ".png" ; (363_5)(PC Installed Dir)/(365_2)(Current User language)
      }
      else if (v_366_6 == 9) ; (366_6)(This Script Error [Integer])
      {
        ; MSGImg4_SE9_photoshop.png
        ThisImage := v_363_5 "\img\msg\MSGImg4_SE9_" ActiveProcess ".png" ; (363_5)(PC Installed Dir)
      }
      else if (v_366_6 == 7) ; (366_6)(This Script Error [Integer])
      {
         ; MSGImg4_SE8_de
        ThisImage := v_363_5 "\img\msg\MSGImg4_SE8_" v_365_2 ".png" ; (363_5)(PC Installed Dir)/(365_2)(Current User language)
      }
      else
      {
        ThisImage := v_363_5 "\img\msg\MSGImg4_SE" v_366_6 "_" v_365_2 ".png" ; (363_5)(PC Installed Dir)/(366_6)(This Script Error [Integer])/(365_2)(Current User language)
      }
      ; -------------------------------------------
      if FileExist(ThisImage)
      {
        ; -------------------------------------------
        if (ThisImage != DataArray.137.3) ; (137_3)(Message Image 4: Image Path)
        {
          DataArray.137.3 := ThisImage ; (137_3)(Message Image 4: Image Path)
          GuiControl, PopUpMenu:, g_137, %ThisImage% ; (137_1)(GUI Object: Message Image 4)
        }
        GuiControl, PopUpMenu:Show, g_137 ; (137_1)(GUI Object: Message Image 4)
        ; -------------------------------------------
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("137", 0, 0, DataArray) ; (137_1)(GUI Object: Message Image 4)
      }
    } ; (137_1)(GUI Object: Message Image 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_138_1") ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 7) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("138", 2, 0, DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("138", 1, 0, DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_139_1") ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "cpl") ; (366_5)(Script Type)
        {
          if (v_300_2 == 8) ; (300_2)([cpl] Menu Number #_X_[X])
          {
            DataArray := GuiControlImage_PopUpMenu("139", 2, 0, DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("139", 1, 0, DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
          }
        } ; End (366_5)(Script Type) (cpl)
      }
    } ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_140_1") ; (140_1)(GUI Object: [mnu] Addon Extra)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 1) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              CkImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(140)_1_" v_365_2 ".png" ; (365_2)(Current User language)
              if FileExist(CkImage)
              {
                ; -------------------------------------------
                if (DataArray.140.2 == 0 or DataArray.140.2 == 1) ; (140_2)([mnu] Addon Extra: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                {
                  ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(140)_1_" v_365_2 ".png" ; (365_2)(Current User language)
                }
                else if (DataArray.140.2 == 2) ; (140_2)([mnu] Addon Extra: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                {
                  ThisImage := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\img\(140)_2_" v_365_2 ".png" ; (365_2)(Current User language)
                }
                if (ThisImage != DataArray.140.3) ; (140_3)([mnu] Addon Extra: Image Path)
                {
                  DataArray.140.3 := ThisImage ; (140_3)([mnu] Addon Extra: Image Path)
                  GuiControl, PopUpMenu:, g_140, %ThisImage% ; (140_1)(GUI Object: [mnu] Addon Extra)
                }
                GuiControl, PopUpMenu:Show, g_140 ; (140_1)(GUI Object: [mnu] Addon Extra)
              }
            }
          }
        }
      }
    } ; (140_1)(GUI Object: [mnu] Addon Extra)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_141_1") ; (141_1)(GUI Object: <Displayed Text> Title 3)
    {
      ; -------------------------------------------
      if (v_133_2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        ; -------------------------------------------
        GuiControl, PopUpMenu:Hide, g_141 ; (141_1)(GUI Object: <Displayed Text> Title 3)
        ; -------------------------------------------
      } ; End (133_2)(Delete Shortcut) = (2)
      ; -------------------------------------------
      else
      {
        ; -------------------------------------------
        ; [ScriptError == 3] (Invalid KeyStroke)
        ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
        {
          DataArray := GuiControlImage_PopUpMenu("141", 0, 0, DataArray) ; (141_1)(GUI Object: <Displayed Text> Title 3)
        }
        else if (v_366_6 == 3 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
        {
          if (v_366_5 == "mnu" or v_366_5 == "cpl" or v_366_5 == "key" or v_366_5 == "rwh") ; (366_5)(Script Type)/(366_5)(Script Type)
          {
            if (v_366_5 == "rwh") ; (366_5)(Script Type)
            {
              ; -------------------------------------------
              FontColor := "921297" ; (Purple)
              ; -------------------------------------------
              ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
              SplitPath, v_305_5, v_141_3 ; (305_5)([rwh] Selected Opening Application [Full File Path])/(141_3)(<Displayed Text> Title 3: Value)
              ; -------------------------------------------
            }
            ; ------------------------------------------- Not_Used
            ; [ScriptError == 3] (Invalid KeyStroke)
            ; ------------------------------------------- Not_Used
            ; ("Invalid Keystroke")
            if (v_366_6 == 3) ; (366_6)(This Script Error [Integer])
            {
              ; -------------------------------------------
              FontColor := "a30404" ; (Red)
              ; -------------------------------------------
              { ; (141)(Title Text 3) = ("Invalid Keystroke")
                ; -------------------------------------------
                if (v_365_2 == "de") ; (365_2)(Current User language)
                {
                  v_141_3 := "Ungültiger Tastenanschlag" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "en") ; (365_2)(Current User language)
                {
                  v_141_3 := "Invalid Keystroke" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "es") ; (365_2)(Current User language)
                {
                  v_141_3 := "Pulsación de tecla no válida" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "fr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Frappe non valide" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "it") ; (365_2)(Current User language)
                {
                  v_141_3 := "Sequenza di tasti non valida" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pl") ; (365_2)(Current User language)
                {
                  v_141_3 := "Nieprawidłowe naciśnięcie klawisza" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pt") ; (365_2)(Current User language)
                {
                  v_141_3 := "Tecla inválida" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "ru") ; (365_2)(Current User language)
                {
                  v_141_3 := "Недействительный ключ-удар" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "sv") ; (365_2)(Current User language)
                {
                  v_141_3 := "Ogiltig tangenttryckning" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "tr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Geçersiz Tuş vuruşu" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
              } ; End (141)(Title Text 3) = ("Invalid Keystroke")
              ; -------------------------------------------
            } ; End (366_6)(This Script Error) = 3
            ; ------------------------------------------- Not_Used
            ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
            ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
            ; ------------------------------------------- Not_Used
            ; (366_6)(This Script Error [Integer])
            ; ("No Selected Item")
            else if (v_366_6 == "Not_Used") ; (366_6)(This Script Error [Integer])
            {
              ; -------------------------------------------
              FontColor := "a30404" ; (Red)
              ; -------------------------------------------
              { ; (141)(Title Text 3) = ("No Selected Item")
                ; -------------------------------------------
                if (v_365_2 == "de") ; (365_2)(Current User language)
                {
                  v_141_3 := "Kein ausgewähltes Element" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "en") ; (365_2)(Current User language)
                {
                  v_141_3 := "No Selected Item" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "es") ; (365_2)(Current User language)
                {
                  v_141_3 := "Sin elemento seleccionado" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "fr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Aucun élément sélectionné" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "it") ; (365_2)(Current User language)
                {
                  v_141_3 := "Nessun elemento selezionato" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pl") ; (365_2)(Current User language)
                {
                  v_141_3 := "Brak zaznaczonego elementu" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pt") ; (365_2)(Current User language)
                {
                  v_141_3 := "Nenhum item selecionado" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "ru") ; (365_2)(Current User language)
                {
                  v_141_3 := "Нет выбранного элемента" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "sv") ; (365_2)(Current User language)
                {
                  v_141_3 := "Inget markerat objekt" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "tr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Seçili Öğe Yok" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
              } ; End (141)(Title Text 3) = ("No Selected Item")
              ; -------------------------------------------
            } ; End (366_6)(This Script Error) = 10 or = 11
            ; -------------------------------------------
            ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
            ; -------------------------------------------
            ; ("Changing Application")
            else if (v_366_6 == 13) ; (366_6)(This Script Error [Integer])
            {
              ; -------------------------------------------
              FontColor := "a30404" ; (Red)
              ; -------------------------------------------
              { ; (141)(Title Text 3) = ("Changing Application")
                ; -------------------------------------------
                if (v_365_2 == "de") ; (365_2)(Current User language)
                {
                  v_141_3 := "Ändern der Anwendung" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "en") ; (365_2)(Current User language)
                {
                  v_141_3 := "Changing Application" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "es") ; (365_2)(Current User language)
                {
                  v_141_3 := "Cambio de aplicación" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "fr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Modification de l’application" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "it") ; (365_2)(Current User language)
                {
                  v_141_3 := "Modifica dell'applicazione" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pl") ; (365_2)(Current User language)
                {
                  v_141_3 := "Zmiana aplikacji" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "pt") ; (365_2)(Current User language)
                {
                  v_141_3 := "Alteração de aplicação" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "ru") ; (365_2)(Current User language)
                {
                  v_141_3 := "Изменение приложения" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "sv") ; (365_2)(Current User language)
                {
                  v_141_3 := "Ändra program" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
                else if (v_365_2 == "tr") ; (365_2)(Current User language)
                {
                  v_141_3 := "Uygulamayı Değiştirme" ; (141_3)(<Displayed Text> Title 3: Value)
                }
                ; -------------------------------------------
              } ; End (141)(Title Text 3) = ("Changing Application")
              ; -------------------------------------------
            } ; End (366_6)(This Script Error) = 13
            ; -------------------------------------------
            FontSize := 14
            Text_Adjust_PopUpMenu("g_141", v_141_3, v_366_2, FontSize, FontColor, 200) ; (141_3)(<Displayed Text> Title 3: Value)/(366_2)(GuiFont Set in DataArray_Set)/(141_1)(GUI Object: <Displayed Text> Title 3)
          }
        }
      }
    } ; (141_1)(GUI Object: <Displayed Text> Title 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_154_1") ; (154_1)(GUI Object: [pum] Pum Select Background)
    {
      if (InStr(v_366_5, "pumSet") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumBG") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("154", 2, 1, DataArray) ; (154_1)(GUI Object: [pum] Pum Select Background)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("154", 1, 1, DataArray) ; (154_1)(GUI Object: [pum] Pum Select Background)
        }
      }
    } ; (154_1)(GUI Object: [pum] Pum Select Background)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_155_1") ; (155_1)(GUI Object: [pum] Pum Select Display Text)
    {
      if (InStr(v_366_5, "pumSet") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumDes") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("155", 2, 1, DataArray) ; (155_1)(GUI Object: [pum] Pum Select Display Text)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("155", 1, 1, DataArray) ; (155_1)(GUI Object: [pum] Pum Select Display Text)
        }
      }
    } ; (155_1)(GUI Object: [pum] Pum Select Shortcut Description Text)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_156_1") ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
    {
      if (InStr(v_366_5, "pumSet") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumDim") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("156", 2, 1, DataArray) ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("156", 1, 1, DataArray) ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
        }
      }
    } ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_157_1") ; (157_1)(GUI Object: [pum] Pum Select Settings)
    {
      if (InStr(v_366_5, "pum") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumSet") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("157", 2, 1, DataArray) ; (157_1)(GUI Object: [pum] Pum Select Settings)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("157", 1, 1, DataArray) ; (157_1)(GUI Object: [pum] Pum Select Settings)
        }
      }
    } ; (157_1)(GUI Object: [pum] Pum Select Settings)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_158_1") ; (158_1)(GUI Object: [pum] Pum Shortcut)
    {
      if (InStr(v_366_5, "pum") > 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("158", 1, 1, DataArray) ; (158_1)(GUI Object: [pum] Pum Shortcut)
      }
    } ; (158_1)(GUI Object: [pum] Pum Shortcut)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_159_1") ; (159_1)(GUI Object: [pum] Select Custom Pum)
    {
      if (InStr(v_366_5, "pum") > 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("159", 1, 1, DataArray) ; (159_1)(GUI Object: [pum] Select Custom Pum)
      }
    } ; (159_1)(GUI Object: [pum] Select Custom Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_160_1") ; (160_1)(GUI Object: [pum] Select Application Pum)
    {
      if (InStr(v_366_5, "pum") > 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("160", 1, 1, DataArray) ; (160_1)(GUI Object: [pum] Select Application Pum)
      }
    } ; (160_1)(GUI Object: [pum] Select Application Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_161_1") ; (161_1)(GUI Object: [pum] Delete Pum)
    {
      if (InStr(v_366_5, "pum") > 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("161", 1, 1, DataArray) ; (161_1)(GUI Object: [pum] Delete Pum)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_162_1") ; (162_1)(GUI Object: Message Image 5)
    {
      if (InStr(v_366_5, "pumImg") > 0) ; (366_5)(Script Type)
      {
        v_368_5 := DataArray.368.5 ; (368_5)(Selected Pum Background [Full Path])
        GuiControl, PopUpMenu:, g_162, %v_368_5% ; (368_5)(Selected Pum Background [Full Path])/(162_1)(GUI Object: Message Image 5)
        GuiControl, PopUpMenu:Show, g_162 ; (162_1)(GUI Object: Message Image 5)
      }
    } ; (162_1)(GUI Object: Message Image 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_163_1") ; (163_1)(GUI Object: Message Image 6)
    {
      if (v_366_5 == "pum") ; (366_5)(Script Type)
      {
        GuiControl, PopUpMenu:Hide, g_163 ; (163_1)(GUI Object: Message Image 6)
      }
    } ; (163_1)(GUI Object: Message Image 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_164_1") ; (164_1)(GUI Object: Message Image 7)
    {
      if (v_366_5 == "pum") ; (366_5)(Script Type)
      {
        GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(GUI Object: Message Image 7)
      }
    } ; (163_1)(GUI Object: Message Image 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_165_1") ; (165_1)(GUI Object: [pum] Backgroung Image Select)
    {
      if (InStr(v_366_5, "pumBG") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumImg") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("165", 2, 1, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("165", 1, 1, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
        }
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_166_1") ; (166_1)(GUI Object: [pum] Backgroung Color Select)
    {
      if (InStr(v_366_5, "pumBG") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumCol") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("166", 2, 1, DataArray) ; (166_1)(GUI Object: [pum] Backgroung Color Select)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("166", 1, 1, DataArray) ; (166_1)(GUI Object: [pum] Backgroung Color Select)
        }
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_167_1") ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
    {
      if (InStr(v_366_5, "pumImg") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumFit") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("167", 2, 1, DataArray) ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("167", 1, 1, DataArray) ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
        }
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_168_1") ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
    {
      if (InStr(v_366_5, "pumImg") > 0) ; (366_5)(Script Type)
      {
        if (InStr(v_366_5, "pumCho") > 0) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("168", 2, 1, DataArray) ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("168", 1, 1, DataArray) ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
        }
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
  {
    DataArray := Extract_Icons_From_File(DataArray)
  }
  ; -------------------------------------------
  else if (v_366_5 == "mnu") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    v_366_4 := DataArray.366.4 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    ; -------------------------------------------
    if ((v_365_2 == "de" && DataArray.321.3 == 1) or (v_365_2 == "en" && DataArray.322.3 == 1) or (v_365_2 == "es" && DataArray.323.3 == 1) or (v_365_2 == "fr" && DataArray.324.3 == 1) or (v_365_2 == "it" && DataArray.325.3 == 1) or (v_365_2 == "pl" && DataArray.326.3 == 1) or (v_365_2 == "pt" && DataArray.327.3 == 1) or (v_365_2 == "ru" && DataArray.328.3 == 1) or (v_365_2 == "sv" && DataArray.329.3 == 1) or (v_365_2 == "tr" && DataArray.330.3 == 1)) ; (321_3)([mnu] de German Addon Installed [1/0])/(322_3)([mnu] en English Addon Installed [1/0])/(323_3)([mnu] es Spanish Addon Installed [1/0])/(324_3)([mnu] fr French Addon Installed [1/0])/(325_3)([mnu] it Italian Addon Installed [1/0])/(326_3)([mnu] pl Polish Addon Installed [1/0])/(327_3)([mnu] pt Portuguese Addon Installed [1/0])/(328_3)([mnu] ru Russian Addon Installed [1/0])/(329_3)([mnu] sv Swedish Addon Installed [1/0])/(330_3)([mnu] tr Turkish Addon Installed [1/0])/(365_2)(Current User language)/(365_2)(Current User language)/(365_2)(Current User language)/(365_2)(Current User language)/(365_2)(Current User language)
    {
      ; -------------------------------------------
      { ; [SET] MenuArray
        ; -------------------------------------------
        ; <(321)> de_MenuArray - <(330)> tr_MenuArray
        ; [SET] in F _ mnu _ AddOn.ahk
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.321.2 ; (321_2)([mnu] de German Menu Array de_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "en") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.322.2 ; (322_2)([mnu] en English Menu Array en_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "es") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.323.2 ; (323_2)([mnu] es Spanish Menu Array es_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "fr") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.324.2 ; (324_2)([mnu] fr French Menu Array fr_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "it") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.325.2 ; (325_2)([mnu] it Italian Menu Array it_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "pl") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.326.2 ; (326_2)([mnu] pl Polish Menu Array pl_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "pt") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.327.2 ; (327_2)([mnu] pt Portuguese Menu Array pt_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "ru") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.328.2 ; (328_2)([mnu] ru Russian Menu Array ru_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "sv") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.329.2 ; (329_2)([mnu] sv Swedish Menu Array sv_MenuArray)
        }
        ; -------------------------------------------
        else if (v_365_2 == "tr") ; (365_2)(Current User language)
        {
          MenuArray := DataArray.330.2 ; (330_2)([mnu] tr Turkish Menu Array tr_MenuArray)
        }
        ; -------------------------------------------
      } ; End [SET] MenuArray
      ; -------------------------------------------
      { ; [GET] Selected Value App Menu Bar / [SET] ArrayNum_AppMenu# = VarArrayNum.(#)
        Num := 1
        ; <321 - 330> App Context Menu 1 - 11
        VarArrayNum := 321 ; (088)_(mnu)(App Context Menu 1)_(2)Select_(3)Image
        Loop %v_302_6% ; (302_6)([mnu] Menu Size [#])
        {
          Select_AppMenu%Num% := DataArray[VarArrayNum][2] ; [Get] Select [0]Hide/[1]Nor/[2]Sel/[3]Dis for App Context Menu
          ArrayNum_AppMenu%Num% := VarArrayNum ; [SET] ArrayNum_AppMenu# = VarArrayNum.(#)
          VarArrayNum := VarArrayNum + 1
          Num := Num + 1
        } ; End Loop
      } ; End [GET] Selected Value App Menu Bar / [SET] ArrayNum_AppMenu# = VarArrayNum.(#)
      ; -------------------------------------------
      { ; [SET] Individual Menu Arrays
        for Index, ThisItem in MenuArray
        {
          ArrayName := ThisItem.1
          ArrayItem := ThisItem.2
          %ArrayName% := ArrayItem ; %(String)% := (Array)
        } ; End for Index, ThisItem in MenuArray
      } ; End [SET] Individual Menu Arrays
      ; -------------------------------------------
      { ; List Text / <Displayed Text> Top 2 / <Edit Feild> Status Bar Description
        ; -------------------------------------------
        ; Empty Var Values
        ListArray1 := ""
        ListArray2 := ""
        ListArray3 := ""
        v_110_3 := "" ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
        v_111_3 := "" ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
        v_112_3 := "" ; (112_3)([mnu] <Displayed Text> Right List: Value)
        v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
        v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
        ComCheck :=  ""
        IsValid := 0
        ; -------------------------------------------
        ListArray0 := %v_365_2%_MenuArray_0 ; (365_2)(Current User language)
        ; -------------------------------------------
        if (v_302_2 > 0) ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          ; -------------------------------------------
          ListArray1 := %v_365_2%_MenuArray_%v_302_2% ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])
          ; -------------------------------------------
          { ; (#_X_X_[X] > 0) / [UPDATE][Gui_Control][VALUE][SHOW] / (110)(Left List Text)
            ; -------------------------------------------
            ; (#_X_X_[X] > 0) / [VALUE]
            ; (302_2)([mnu] Menu Item #_X_X_[X])
            v_110_3 := ListArray0[v_302_2] ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(302_2)([mnu] Menu Number #_X_X_[X])
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              ; -------------------------------------------
              v_110_3 := StrReplace(v_110_3, " >" , "") ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
              v_110_3 := StrReplace(v_110_3, "&" , "&&") ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
              ; -------------------------------------------
              v_110_3 := Unicode_In_String(v_110_3) ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
              DataArray.110.3 := v_110_3 ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
              FontColor := "921297" ; (Purple)
              FontSize := 12
              MaxWidth := 158
              Text_Adjust_PopUpMenu("g_110", v_110_3, v_366_2, FontSize, FontColor, MaxWidth) ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(366_2)(GuiFont Set in DataArray_Set)/(110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
              ; -------------------------------------------
              DataArray.110.2 := 1 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              ; -------------------------------------------
            } ; End (Divider == 0)
            ; -------------------------------------------
          } ; End (#_X_X_[X] > 0) / [UPDATE][Gui_Control][VALUE][SHOW] / (110)(Left List Text)
          ; -------------------------------------------
          if (v_302_3 > 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
          {
            ; -------------------------------------------
            ListArray2 := %v_365_2%_MenuArray_%v_302_2%_%v_302_3% ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])
            ; -------------------------------------------
            { ; (X_#_X_[X] > 0) / (111)(Center List Text)
              ; -------------------------------------------
              ; (X_#_X_[X] > 0) / [VALUE]
              v_111_3 := ListArray1[v_302_3][2] ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(302_3)([mnu] Menu Number X_#_X_[X])
              if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
              {
                ; -------------------------------------------
                v_111_3 := StrReplace(v_111_3, " >" , "") ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                v_111_3 := StrReplace(v_111_3, "&" , "&&") ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                ; -------------------------------------------
                v_111_3 := Unicode_In_String(v_111_3) ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                DataArray.111.3 := v_111_3 ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                FontColor := "921297" ; (Purple)
                FontSize := 12
                MaxWidth := 158
                ; (366_2)(GuiFont Set in DataArray_Set)
                Text_Adjust_PopUpMenu("g_111", v_111_3, v_366_2, FontSize, FontColor, MaxWidth) ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(366_2)(GuiFont Set in DataArray_Set)/(111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
                ; -------------------------------------------
                DataArray.111.2 := 1 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                ; -------------------------------------------
              } ; End (Divider == 0)
              ; -------------------------------------------
            } ; End (X_#_X_[X] > 0) / (111)(Center List Text_2)Select_(3)Value
            ; -------------------------------------------
            if (v_302_4 > 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
            {
              ; -------------------------------------------
              ; (302_2)([mnu] Menu Item #_X_X_[X])
              ; (302_3)([mnu] Menu Item X_#_X_[X])
              ; (302_4)([mnu] Menu Item X_X_#_[X])
              ListArray3 := %v_365_2%_MenuArray_%v_302_2%_%v_302_3%_%v_302_4% ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_4)([mnu] Menu Number X_X_#_[X])
              ; -------------------------------------------
              { ; (X_X_#_[X] > 0) / (112)(Right List Text)
                ; -------------------------------------------
                ; (X_X_#_[X] > 0) / ([VALUE]
                ; (302_4)([mnu] Menu Item X_X_#_[X])
                v_112_3 := ListArray2[v_302_4][2] ; (112_3)([mnu] <Displayed Text> Right List: Value)/(302_4)([mnu] Menu Number X_X_#_[X])
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  ; -------------------------------------------
                  v_112_3 := StrReplace(v_112_3, " >" , "") ; (112_3)([mnu] <Displayed Text> Right List: Value)
                  v_112_3 := StrReplace(v_112_3, "&" , "&&") ; (112_3)([mnu] <Displayed Text> Right List: Value)
                  ; -------------------------------------------
                  v_112_3 := Unicode_In_String(v_112_3) ; (112_3)([mnu] <Displayed Text> Right List: Value)
                  DataArray.112.3 := v_112_3 ; (112_3)([mnu] <Displayed Text> Right List: Value)
                  FontColor := "921297" ; (Purple)
                  FontSize := 12
                  MaxWidth := 158
                  ; (366_2)(GuiFont Set in DataArray_Set)
                  Text_Adjust_PopUpMenu("g_112", v_112_3, v_366_2, FontSize, FontColor, MaxWidth) ; (112_3)([mnu] <Displayed Text> Right List: Value)/(366_2)(GuiFont Set in DataArray_Set)/(112_1)(GUI Object: [mnu] <Displayed Text> Right List)
                  ; -------------------------------------------
                  DataArray.112.2 := 1 ; (112_2)([mnu] <Displayed Text> Right List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  ; -------------------------------------------
                } ; End (Divider == 0 )
                ; -------------------------------------------
              } ; End (X_X_#_[X] > 0) / (112)(Right List Text_2)Select_(3)Value
              ; -------------------------------------------
              if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
              {
                ; -------------------------------------------
                SelectedItem := ListArray3[v_302_5][2] ; (302_5)([mnu] Menu Number X_X_X_[#])
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  ; -------------------------------------------
                  SelectedItem := StrReplace(SelectedItem, "&" , "&&") ; (302_5)([mnu] Menu Number X_X_X_[#])
                  ComCheck := ListArray2[v_302_5][1] ; (302_5)([mnu] Menu Number X_X_X_[#])
                  ; -------------------------------------------
                  { ; (X_X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                    ; -------------------------------------------
                    ; [VALUE]
                    ; (110_3)([cpl][mnu] Left List Text: Value)
                    ; (111_3)([cpl][mnu] Center List Text: Value)
                    ; (112_3)([mnu] Right List Text: Value)
                    v_105_3 := v_110_3 " > " v_111_3 " > " v_112_3 " > " SelectedItem ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(112_3)([mnu] <Displayed Text> Right List: Value)
                    v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                    DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                    ; -------------------------------------------
                    { ; (X_X_X_[#] > 0) / Font Size Adjust
                      ; -------------------------------------------
                      FontColor := "199524" ; (Green)
                      FontSize := 12
                      MaxWidth := 480
                      Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                      ; -------------------------------------------
                      DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                      ; -------------------------------------------
                    } ; End (X_X_X_[#] > 0) / Font Size Adjust
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  { ; (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                    ; -------------------------------------------
                    ; [VALUE]
                    ; (110_3)([cpl][mnu] Left List Text: Value)
                    ; (111_3)([cpl][mnu] Center List Text: Value)
                    ; (112_3)([mnu] Right List Text: Value)
                    ; (302_5)([mnu] Menu Item X_X_X_[#])
                    v_122_3 := "(" v_110_3 ")_(" v_111_3 ")_(" v_112_3 ")_(" SelectedItem ")" ; (122_3)(<Edit Feild> Status Bar Description: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(112_3)([mnu] <Displayed Text> Right List: Value)
                    v_122_3 := StrReplace(v_122_3, "()_", "") ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    v_122_3 := Unicode_In_String(v_122_3) ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    ; -------------------------------------------
                    ; [SHOW]
                    DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                } ; End (Divider == 0)
                ; -------------------------------------------
              } ; End (X_X_X_[#] > 0)
              ; -------------------------------------------
              else if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
              {
                ; -------------------------------------------
                { ; (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                  {
                    ; -------------------------------------------
                    ; (X_X_X_[#] == 0) / [VALUE]
                    ; (110_3)([cpl][mnu] Left List Text: Value)
                    ; (111_3)([cpl][mnu] Center List Text: Value)
                    ; (112_3)([mnu] Right List Text: Value)
                    v_105_3 := v_110_3 " > " v_111_3 " > " v_112_3 " > " ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(112_3)([mnu] <Displayed Text> Right List: Value)
                    v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                    DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                    ;
                    { ; (X_X_X_[#] == 0) / Font Size Adjust
                      FontColor := "a30404" ; (Red)
                      FontSize := 12
                      MaxWidth := 480
                      ; (366_2)(GuiFont Set in DataArray_Set)
                      Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                    } ; End (X_X_X_[#] == 0) / Font Size Adjust
                    ; -------------------------------------------
                    DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    ; -------------------------------------------
                  } ; End (Divider == 0)
                  ; -------------------------------------------
                } ; End (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                { ; (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                  ; [REMOVE VALUE]
                  v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                  ; -------------------------------------------
                  ; [SHOW]
                  DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                } ; End (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
              } ; End (X_X_X_[#] == 0)
              ; -------------------------------------------
            } ; End (X_X_#_[X] > 0)
            ; -------------------------------------------
            else if (v_302_4 == 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
            {
              ; -------------------------------------------
              { ; (X_X_#_[X] == 0) / (112)(Right List Text_2)Select_(3)Value
                ; -------------------------------------------
                ; (X_X_#_[X] == 0) / [VALUE]
                DataArray.112.3 := "" ; (112_3)([mnu] <Displayed Text> Right List: Value)
                ; -------------------------------------------
                ; (X_X_#_[X] == 0) / [HIDE]
                DataArray.112.2 := 0 ; (112_2)([mnu] <Displayed Text> Right List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Hide, g_112 ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
                ; -------------------------------------------
              } ; End (X_X_#_[X] == 0) / (112)(Right List Text_2)Select_(3)Value
              ; -------------------------------------------
              if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
              {
                ; -------------------------------------------
                SelectedItem := ListArray2[v_302_5][2] ; (302_5)([mnu] Menu Number X_X_X_[#])
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  ; -------------------------------------------
                  SelectedItem := StrReplace(SelectedItem, "&" , "&&") ; (302_5)([mnu] Menu Number X_X_X_[#])
                  ComCheck := ListArray2[v_302_5][1] ; (302_5)([mnu] Menu Number X_X_X_[#])
                  ; -------------------------------------------
                  { ; (X_X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                    ; -------------------------------------------
                    ; (X_X_X_[#] > 0) / [VALUE]
                    v_105_3 := v_110_3 " > " v_111_3 " > " SelectedItem ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                    v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                    DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                    ;
                    { ; (X_X_X_[#] > 0) / Font Size Adjust
                      FontColor := "199524" ; (Green)
                      FontSize := 12
                      MaxWidth := 480
                      ; (366_2)(GuiFont Set in DataArray_Set)
                      Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                    } ; End (X_X_X_[#] > 0) / Font Size Adjust
                    ; -------------------------------------------
                    DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  { ; (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                    ; -------------------------------------------
                    ; [VALUE]
                    ; (110_3)([cpl][mnu] Left List Text: Value)
                    ; (111_3)([cpl][mnu] Center List Text: Value)
                    ; (302_5)([mnu] Menu Item X_X_X_[#])
                    v_122_3 := "(" v_110_3 ")_(" v_111_3 ")_(" SelectedItem ")" ; (122_3)(<Edit Feild> Status Bar Description: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                    v_122_3 := StrReplace(v_122_3, "()_", "") ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    v_122_3 := Unicode_In_String(v_122_3) ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    ; -------------------------------------------
                    ; [SHOW]
                    DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                } ; End (Divider == 0)
                ; -------------------------------------------
              } ; End (X_X_X_[#] > 0)
              ; -------------------------------------------
              else if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
              {
                ; -------------------------------------------
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  ; -------------------------------------------
                  { ; (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                    ; -------------------------------------------
                    ; (X_X_X_[#] == 0) / [VALUE]
                    ; (110_3)([cpl][mnu] Left List Text: Value)
                    ; (111_3)([cpl][mnu] Center List Text: Value)
                    v_105_3 := v_110_3 " > " v_111_3 " > " ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                    v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                    DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                    ;
                    { ; (X_X_X_[#] == 0) / Font Size Adjust
                      FontColor := "a30404" ; (Red)
                      FontSize := 12
                      MaxWidth := 480
                      ; (366_2)(GuiFont Set in DataArray_Set)
                      Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                    } ; End (X_X_X_[#] == 0) / Font Size Adjust
                    ; -------------------------------------------
                    DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  { ; (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                    ; -------------------------------------------
                    ; [REMOVE VALUE]
                    v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                    GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    ; -------------------------------------------
                    ; (X_X_X_[#] == 0) / [SHOW]
                    DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                    GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                    DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                    ; -------------------------------------------
                  } ; End (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                } ; End (Divider == 0)
                ; -------------------------------------------
              } ; End (X_X_X_[#] == 0)
              ; -------------------------------------------
            } ; End (X_X_#_[X] == 0)
            ; -------------------------------------------
          } ; End (X_#_X_[X] > 0)
          else if (v_302_3 == 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
          {
            ; -------------------------------------------
            { ; (X_#_X_[X] == 0) / (111_1)(GUI Object: [cpl][mnu] Center List Text)
              ; -------------------------------------------
              ; (X_#_X_[X] == 0) / [REMOVE VALUE]
              DataArray.111.3 := "" ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
              ; -------------------------------------------
              ; (X_#_X_[X] == 0) / [HIDE]
              DataArray.111.2 := 0 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
              ; -------------------------------------------
            } ; End (X_#_X_[X] == 0) / (111_1)(GUI Object: [cpl][mnu] Center List Text)
            ; -------------------------------------------
            if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
            {
              ; -------------------------------------------
              if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
              {
                ; -------------------------------------------
                SelectedItem := ListArray1[v_302_5][2] ; (302_5)([mnu] Menu Number X_X_X_[#])
                SelectedItem := StrReplace(SelectedItem, "&" , "&&") ; (302_5)([mnu] Menu Number X_X_X_[#])
                ComCheck := ListArray2[v_302_5][1] ; (302_5)([mnu] Menu Number X_X_X_[#])
                ; -------------------------------------------
                { ; (X_X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  ; [VALUE]
                  ; (110_3)([cpl][mnu] Left List Text: Value)
                  ; (302_5)([mnu] Menu Item X_X_X_[#])
                  v_105_3 := v_110_3 " > " SelectedItem ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)
                  v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                  DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                  ;
                  { ; (X_X_X_[#] > 0) / Font Size Adjust
                    FontColor := "199524" ; (Green)
                    FontSize := 12
                    MaxWidth := 480
                    ; (366_2)(GuiFont Set in DataArray_Set)
                    Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                  } ; End (X_X_X_[#] > 0) / Font Size Adjust
                  ; -------------------------------------------
                  DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  ; -------------------------------------------
                } ; End (X_X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                { ; (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                  ; [VALUE]
                  ; (110_3)([cpl][mnu] Left List Text: Value)
                  ; (302_5)([mnu] Menu Item X_X_X_[#])
                  v_122_3 := "(" v_110_3 ")_(" SelectedItem ")" ; (122_3)(<Edit Feild> Status Bar Description: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)
                  v_122_3 := StrReplace(v_122_3, "()_", "") ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  v_122_3 := Unicode_In_String(v_122_3) ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
                  ; -------------------------------------------
                  ; [SHOW]
                  DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                  DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                  ; -------------------------------------------
                } ; End (X_X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
              } ; End (Divider == 0)
              ; -------------------------------------------
            } ; End (X_X_X_[#] > 0)
            ; -------------------------------------------
            else if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
            {
              ; -------------------------------------------
              if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
              {
                ; -------------------------------------------
                { ; (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                  ; -------------------------------------------
                  ; [VALUE]
                  ; (110_3)([cpl][mnu] Left List Text: Value)
                  v_105_3 := v_110_3 " > " ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)
                  v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                  DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                  ;
                  { ; (X_X_X_[#] == 0) / Font Size Adjust
                    FontColor := "a30404" ; (Red)
                    FontSize := 12
                    MaxWidth := 480
                    ; (366_2)(GuiFont Set in DataArray_Set)
                    Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                  } ; End (X_X_X_[#] == 0) / Font Size Adjust
                  ; -------------------------------------------
                  DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  ; -------------------------------------------
                } ; End (X_X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                { ; (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                  ; -------------------------------------------
                  ; [REMOVE VALUE]
                  v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                  GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                  ; -------------------------------------------
                  ; [SHOW]
                  DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                  DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                  ; -------------------------------------------
                } ; End (X_X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
              } ; End (Divider == 0)
              ; -------------------------------------------
            } ; End (X_X_X_[#] == 0)
            ; -------------------------------------------
          } ; End (X_#_X_[X] == 0)
          ; -------------------------------------------
        } ; End (#_X_X_[X] > 0)
        ; -------------------------------------------
        else if (v_302_2 == 0) ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          ; -------------------------------------------
          { ; (#_X_X_[X] == 0) / [UPDATE][Gui_Control][REMOVE VALUE][HIDE] ; (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value 
            ; -------------------------------------------
            ; (#_X_X_[X] == 0) / [REMOVE VALUE]
            DataArray.110.3 := "" ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
            ; -------------------------------------------
            ; (#_X_X_[X] == 0) / [HIDE]
            DataArray.110.2 := 0 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
            ; -------------------------------------------
          } ; End (#_X_X_[X] == 0) / [UPDATE][Gui_Control][REMOVE VALUE][HIDE] ; (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value 
          ; -------------------------------------------
          { ; (#_X_X_[X] == 0) / [REMOVE VALUE] / [HIDE] / (105)(Text> Top 2)
            ; -------------------------------------------
            ; (#_X_X_[X] == 0) / [REMOVE VALUE]
            v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
            DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
            GuiControl, PopUpMenu:, g_105, ; (105_1)(GUI Object: <Displayed Text> Top 2)
            ; -------------------------------------------
            ; (#_X_X_[X] == 0) / [HIDE]
            DataArray.105.2 := 0 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
          } ; End (#_X_X_[X] == 0) / [REMOVE VALUE] / [HIDE] / (105)(Text> Top 2)
          ; -------------------------------------------
          { ; (#_X_X_[X] == 0) / [REMOVE VALUE] / (122)(Edit Status Bar)
            ; -------------------------------------------
            ; [REMOVE VALUE]
            v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
            DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
            GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
            ; -------------------------------------------
          } ; End (#_X_X_[X] == 0) / [REMOVE VALUE] / (122)(Edit Status Bar)
          ; -------------------------------------------
        } ; End (#_X_X_[X] == 0)
        ; -------------------------------------------
      } ; End List Text / <Displayed Text> Top 2 / <Edit Feild> Status Bar Description
      ; -------------------------------------------
      { ; [SET] ListBox#
        ; -------------------------------------------
        ; Empty Var Values
        ListBox1 := ""
        ListBox2 := ""
        ListBox3 := ""
        ; -------------------------------------------
        if ListArray1
        {
          ListBox1 := Array_to_ListBox(ListArray1, "mnu")
        } ; End if ListArray1
        ; -------------------------------------------
        if ListArray2
        {
          ListBox2 := Array_to_ListBox(ListArray2, "mnu")
        } ; End if ListArray2
        ; -------------------------------------------
        if ListArray3
        {
          ListBox3 := Array_to_ListBox(ListArray3, "mnu")
        } ; End if ListArray3
        ; -------------------------------------------
      } ; End [SET] ListBox#
      ; -------------------------------------------
      { ; Display List
        ; -------------------------------------------
        if (v_302_2 > 0) ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          ; -------------------------------------------
          if (v_302_3 > 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
          {
            ; -------------------------------------------
            if (v_302_4 > 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
            {
              ; -------------------------------------------
              { ; (X_X_#_[X] > 0) / [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
                ; -------------------------------------------
                { ; (X_X_#_[X] > 0) / [HIDE]
                  ; -------------------------------------------
                  DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Hide, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                  ; -------------------------------------------
                  DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] > 0) / [HIDE]
                ; -------------------------------------------
                { ; (X_X_#_[X] > 0) / [VALUE]
                  ; -------------------------------------------
                  CkListBox1 := DataArray.118.3 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
                  if (CkListBox1 != ListBox1)
                  {
                    DataArray.118.3 := ListBox1 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
                    GuiControl, PopUpMenu:, g_118, %ListBox1% ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                  } ; End if (CkListBox1 != ListBox1)
                  ; -------------------------------------------
                  CkListBox2 := DataArray.120.3 ; (120_3)([mnu] List Center 1/3: ListBox)
                  if (CkListBox2 != ListBox2)
                  {
                    DataArray.120.3 := ListBox2 ; (120_3)([mnu] List Center 1/3: ListBox)
                    GuiControl, PopUpMenu:, g_120, %ListBox2% ; (120_1)(GUI Object: [mnu] List Center 1/3)
                  } ; End if (CkListBox2 != ListBox2)
                  ; -------------------------------------------
                  CkListBox3 := DataArray.121.3 ; (121_3)([mnu] Right 1/3: ListBox)
                  if (CkListBox3 != ListBox3)
                  {
                    DataArray.121.3 := ListBox3 ; (121_3)([mnu] Right 1/3: ListBox)
                    GuiControl, PopUpMenu:, g_121, %ListBox3% ; (121_1)(GUI Object: [mnu] List Right 1/3)
                  } ; End if (CkListBox3 != ListBox3)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] > 0) / [VALUE]
                ; -------------------------------------------
                { ; (X_X_#_[X] > 0) / [CHOOSE][FOCUS]
                  ; -------------------------------------------
                  if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                  {
                    GuiControl, PopUpMenu:Choose, g_118, %v_302_3% ; (302_3)([mnu] Menu Number X_#_X_[X])/(118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                    GuiControl, PopUpMenu:Choose, g_120, %v_302_4% ; (302_4)([mnu] Menu Number X_X_#_[X])/(120_1)(GUI Object: [mnu] List Center 1/3)
                  } ; End (Divider == 0)
                  ; -------------------------------------------
                  if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
                  {
                    if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                    {
                      GuiControl, PopUpMenu:Choose, g_121, %v_302_5% ; (302_5)([mnu] Menu Number X_X_X_[#])/(121_1)(GUI Object: [mnu] List Right 1/3)
                      GuiControl, PopUpMenu:Focus, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
                    } ; End (Divider == 0)
                  } ; End (X_X_X_[#] > 0)
                  ; -------------------------------------------
                  else if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
                  {
                    if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                    {
                      GuiControl, PopUpMenu:Choose, g_121, 0 ; (121_1)(GUI Object: [mnu] List Right 1/3)
                      GuiControl, PopUpMenu:Focus, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
                    } ; End (Divider == 0)
                  } ; End (X_X_X_[#] == 0)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] > 0) / [CHOOSE][FOCUS]
                ; -------------------------------------------
                { ; (X_X_#_[X] > 0) / [SHOW]
                  ; -------------------------------------------
                  DataArray.118.2 := 1 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                  ; -------------------------------------------
                  DataArray.120.2 := 1 ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
                  ; -------------------------------------------
                  DataArray.121.2 := 1 ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] > 0) / [SHOW]
                ; -------------------------------------------
              } ; End (X_X_#_[X] > 0) / [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
              ; -------------------------------------------
            } ; End (X_X_#_[X] > 0)
            ; -------------------------------------------
            else ; (X_X_#_[X] == 0)
            {
              ; -------------------------------------------
              { ; (X_X_#_[X] == 0) > [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
                ; -------------------------------------------
                { ; (X_X_#_[X] == 0) > [HIDE] 
                  ; -------------------------------------------
                  DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Hide, g_116  ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                  ; -------------------------------------------
                  DataArray.120.2 := 0 ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Hide, g_120  ; (120_1)(GUI Object: [mnu] List Center 1/3)
                  ; -------------------------------------------
                  DataArray.121.2 := 0 ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Hide, g_121  ; (121_1)(GUI Object: [mnu] List Right 1/3)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] == 0) > [HIDE] 
                ; -------------------------------------------
                { ; (X_X_#_[X] == 0) > [VALUE]
                ; -------------------------------------------
                  CkListBox1 := DataArray.118.3 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
                  if (CkListBox1 != ListBox1)
                  {
                    DataArray.118.3 := ListBox1 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
                    GuiControl, PopUpMenu:, g_118, %ListBox1% ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                  }
                  ; -------------------------------------------
                  CkListBox2 := DataArray.117.3 ; (117_3)([cpl][mnu] List Right 2/3: ListBox)
                  if (CkListBox2 != ListBox2)
                  {
                    DataArray.117.3 := ListBox2 ; (117_3)([cpl][mnu] List Right 2/3: ListBox)
                    GuiControl, PopUpMenu:, g_117, %ListBox2% ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                  }
                  ; -------------------------------------------
                } ; End (X_X_#_[X] == 0) > [VALUE]
                ; -------------------------------------------
                { ; (X_X_#_[X] == 0) > [CHOOSE][FOCUS]
                  ; -------------------------------------------
                  if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                  {
                    GuiControl, PopUpMenu:Choose, g_118, %v_302_3% ; (302_3)([mnu] Menu Number X_#_X_[X])/(118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                  } ; End (Divider == 0)
                  if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
                  {
                    if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                    {
                      GuiControl, PopUpMenu:Choose, g_117, %v_302_5% ; (302_5)([mnu] Menu Number X_X_X_[#])/(117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                      GuiControl, PopUpMenu:Focus, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                    } ; End (Divider == 0)
                  } ; End (X_X_X_[#] > 0)
                  ; -------------------------------------------
                  else if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
                  {
                    if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                    {
                      GuiControl, PopUpMenu:Choose, g_117, 0 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                      GuiControl, PopUpMenu:Focus, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                    } ; End (Divider == 0)
                  } ; End (X_X_X_[#] == 0)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] == 0) > [CHOOSE][FOCUS]
                ; -------------------------------------------
                { ; (X_X_#_[X] == 0) > [SHOW]
                  ; -------------------------------------------
                  DataArray.118.2 := 1 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                  ; -------------------------------------------
                  DataArray.117.2 := 1 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                  GuiControl, PopUpMenu:Show, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] == 0) > [SHOW]
                ; -------------------------------------------
              } ; End (X_X_#_[X] == 0) > [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
              ; -------------------------------------------
            } ; End (X_X_#_[X] == 0)
            ; -------------------------------------------
          } ; End (X_#_X_[X] > 0)
          ; -------------------------------------------
          else if (v_302_3 == 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
          {
            ; -------------------------------------------
            { ; (X_#_X_[X] == 0) > [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
              ; -------------------------------------------
              { ; (X_#_X_[X] == 0) > [HIDE]
                ; -------------------------------------------
                DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                ; -------------------------------------------
                DataArray.118.2 := 0 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Hide, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                ; -------------------------------------------
                DataArray.120.2 := 0 ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Hide, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
                ; -------------------------------------------
                DataArray.121.2 := 0 ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Hide, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
                ; -------------------------------------------
              } ; End (X_#_X_[X] == 0) > [HIDE]
              ; -------------------------------------------
              { ; (X_#_X_[X] == 0) > [Value]
                ; -------------------------------------------
                CkListBox1 := DataArray.116.3 ; (116_3)([cpl][mnu] List Full Across: ListBox)
                if (CkListBox1 != ListBox1)
                {
                  DataArray.116.3 := ListBox1 ; (116_3)([cpl][mnu] List Full Across: ListBox)
                  GuiControl, PopUpMenu:, g_116, %ListBox1% ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                } ; End if (CkListBox1 != ListBox1)
                ; -------------------------------------------
              } ; End (X_#_X_[X] == 0) > [Value]
              ; -------------------------------------------
              { ; (X_#_X_[X] == 0) > [CHOOSE][FOCUS]
                ; -------------------------------------------
                if (v_302_5 > 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
                {
                  if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                  {
                    GuiControl, PopUpMenu:Choose, g_116, %v_302_5% ; (302_5)([mnu] Menu Number X_X_X_[#])/(116_1)(GUI Object: [cpl][mnu] List Full Across)
                    GuiControl, PopUpMenu:Focus, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                  } ; End (Divider == 0)
                } ; End (X_X_X_[#] > 0)
                ; -------------------------------------------
              } ; End (X_#_X_[X] == 0) > [CHOOSE][FOCUS]
              ; -------------------------------------------
              { ; (X_#_X_[X] == 0) > [SHOW]
                ; -------------------------------------------
                DataArray.116.2 := 1 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Show, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                ; -------------------------------------------
              } ; End (X_#_X_[X] == 0) > [SHOW]
              ; -------------------------------------------
            } ; End (X_#_X_[X] == 0) > [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
            ; -------------------------------------------
          } ; End (X_#_X_[X] == 0)
          ; -------------------------------------------
        } ; End (#_X_X_[X] > 0
        ; -------------------------------------------
        else if (v_302_2 == 0) ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          ; -------------------------------------------
          { ; (#_X_X_[X] == 0) > [UPDATE][HIDE] List / Text_L#
            ; -------------------------------------------
            { ; (#_X_X_[X] == 0) > [HIDE]
              ; -------------------------------------------
              DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
              ; -------------------------------------------
              DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
              ; -------------------------------------------
              DataArray.118.2 := 0 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
              ; -------------------------------------------
              DataArray.120.2 := 0 ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
              ; -------------------------------------------
              DataArray.121.2 := 0 ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
              ; -------------------------------------------
              DataArray.110.2 := 0 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
              ; -------------------------------------------
              DataArray.111.2 := 0 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
              ; -------------------------------------------
              DataArray.112.2 := 0 ; (112_2)([mnu] <Displayed Text> Right List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_112 ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
              ; -------------------------------------------
            } ; End (#_X_X_[X] == 0) > [HIDE]
            ; -------------------------------------------
          } ; End (#_X_X_[X] == 0) > [UPDATE][HIDE] List / Text_L#
          ; -------------------------------------------
        } ; End (#_X_X_[X] == 0)
        ; -------------------------------------------
      } ; End Display List
      ; -------------------------------------------
      { ; (Temp_Icon)(Ok Button)
        ; -------------------------------------------
        if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
        {
          ; -------------------------------------------
          { ; [SET] Temp_Icon / [SET] IsValid (0/1)
            ; -------------------------------------------
            DataArray.102.2 := 1 ; (102_2)(Main Display Icon: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            ; -------------------------------------------
            if (v_302_2 > 0 && v_302_5 > 0) ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
            {
              ; -------------------------------------------
              if (v_302_3 > 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
              {
                ; -------------------------------------------
                if (v_302_4 > 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
                {
                  ; -------------------------------------------
                  Temp_Icon := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\ico\" v_302_2 "_" v_302_3 "_" v_302_4 "_(" v_302_5 ").ico" ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_4)([mnu] Menu Number X_X_#_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                  MissingIconNum := v_302_2 "_" v_302_3 "_" v_302_4 "_(" v_302_5 ")" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_4)([mnu] Menu Number X_X_#_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                  if (ComCheck == "MKB")
                  {
                    IsValid := 0
                  } ; End (ComCheck == "MKB")
                  else ; (ComCheck != "MKB")
                  {
                    if FileExist(Temp_Icon)
                    {
                      IsValid := 1
                    } ; End FileExist(Temp_Icon)
                    else ; !FileExist(Temp_Icon)
                    {
                      Temp_Icon := v_363_5 "\ico\Missing.png" ; (363_5)(PC Installed Dir)
                      IsValid := 0
                    } ; End !FileExist(Temp_Icon)
                  } ; End (ComCheck != "MKB")
                  ; -------------------------------------------
                  DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] > 0)
                ; -------------------------------------------
                else if (v_302_4 == 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
                {
                  ; -------------------------------------------
                  Temp_Icon := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\ico\" v_302_2 "_" v_302_3 "_(" v_302_5 ").ico" ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                  MissingIconNum := v_302_2 "_" v_302_3 "_(" v_302_5 ")" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                  if (ComCheck == "MKB")
                  {
                    IsValid := 0
                  } ; End (ComCheck == "MKB")
                  else ; (ComCheck != "MKB")
                  {
                    if FileExist(Temp_Icon)
                    {
                      IsValid := 1
                    } ; End FileExist(Temp_Icon)
                    else ; !FileExist(Temp_Icon)
                    {
                      Temp_Icon := v_363_5 "\ico\Missing.png" ; (363_5)(PC Installed Dir)
                      IsValid := 0
                    } ; End !FileExist(Temp_Icon)
                  } ; End (ComCheck != "MKB")
                  ; -------------------------------------------
                  DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
                  ; -------------------------------------------
                } ; End (X_X_#_[X] == 0)
                ; -------------------------------------------
              } ; End (X_#_X_[X] > 0)
              ; -------------------------------------------
              else if (v_302_3 == 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
              {
                ; -------------------------------------------
                Temp_Icon := A_AppDataCommon "\PopUpMenu_PUM\addons\" ActiveProcess "\" v_365_2 "\ico\" v_302_2 "_(" v_302_5 ").ico" ; (365_2)(Current User language)/(302_2)([mnu] Menu Number #_X_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                MissingIconNum := v_302_2 "_(" v_302_5 ")" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
                if (ComCheck == "MKB")
                {
                  IsValid := 0
                } ; End (ComCheck == "MKB")
                else ; (ComCheck != "MKB")
                {
                  if FileExist(Temp_Icon)
                  {
                    IsValid := 1
                  } ; End FileExist(Temp_Icon)
                  else ; !FileExist(Temp_Icon)
                  {
                    Temp_Icon := v_363_5 "\ico\Missing.png" ; (363_5)(PC Installed Dir)
                    IsValid := 0
                  } ; End !FileExist(Temp_Icon)
                } ; End (ComCheck != "MKB")
                ; -------------------------------------------
                DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
                ; -------------------------------------------
              } ; End (X_#_X_[X] == 0)
              ; -------------------------------------------
            } ; End (#_X_X_[X] > 0) && (X_X_X_[#] > 0)
            ; -------------------------------------------
            ; (302_2)([mnu] Menu Item #_X_X_[X])
            else if (v_302_5 == 0 or v_302_2 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])/(302_2)([mnu] Menu Number #_X_X_[X])
            {
              ; -------------------------------------------
              GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
              IsValid := 0
              ; -------------------------------------------
            } ; End (#_X_X_[X] == 0) && (X_X_X_[#] == 0)
            ; -------------------------------------------
          } ; End [SET] Temp_Icon / [SET] IsValid (0/1)
          ; -------------------------------------------
          { ; (IsValid)
            ; -------------------------------------------
            if (IsValid == 1)
            {
              ; -------------------------------------------
              if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
              {
                DataArray := GuiControlImage_PopUpMenu("004", 1, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
              } ; End (Delete Shortcut != 2)
              DataArray := GuiControlImage_PopUpMenu("005", 1, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
              DataArray := GuiControlImage_PopUpMenu("006", 1, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
              DataArray := GuiControlImage_PopUpMenu("063", 1, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
              DataArray := GuiControlImage_PopUpMenu("064", 1, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
              DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
              DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
              DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
              ; -------------------------------------------
            } ; End (IsValid == 1)
            ; -------------------------------------------
            else if (IsValid == 0)
            {
              ; -------------------------------------------
              if (ComCheck == "MKB")
              {
                ; ------------------------------------------- 
                { ; (MKB)(Messsage)(By Language)
                  if (v_365_2 == "de") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Wählen Sie Tastatur, um einen Tastenanschlag für diesen Befehl einzugeben." ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Interner Direktbefehl nicht verfügbar" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Überprüfen der " v_367_2 " Tastenkombinationseigenschaften" ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "en") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Select Keyboard, to Enter keystroke for this command" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Internal Direct Command Unalivable" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Check " v_367_2 " Keystroke Customization Properties" ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "es") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Seleccione Teclado, para introducir la pulsación de tecla para este comando" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Comando interno directo no disponible" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Comprobar Propiedades de acceso directo del teclado de " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "fr") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Sélectionnez Clavier, pour entrer la touche pour cette commande" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Commande directe interne non disponible" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Vérifier Les propriétés du raccourci Clavier " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "it") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Selezionare Tastiera per immettere la sequenza di tasti per questo comando" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Comando diretto interno non disponibile" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Controllare le proprietà delle scelte rapide da tastiera di " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "pl") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Wybierz klawiatury, aby wprowadzić naciśnięcie klawisza dla tego polecenia" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Wewnętrzne polecenie bezpośrednie niedostępne" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Sprawdzanie właściwości skrótu klawiaturowego programu " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "pt") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Selecione Teclado, para digitar teclas para este comando" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Comando interno direto não disponível" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Verifique as propriedades do atalho do teclado do " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "ru") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Выберите Клавиатуры, чтобы ввести нажатие клавиши для этой команды" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Внутреннее прямое командование недоступно" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Проверьте " v_367_2 " Клавиатура ярлык Свойства" ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "sv") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Välj Tangentbord om du vill ange tangenttryckning för det här kommandot" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Internt direktkommando är inte tillgängligt" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := "Kontrollera egenskaper för kortkommandon i " v_367_2 ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                  else if (v_365_2 == "tr") ; (365_2)(Current User language)
                  {
                    v_100_3 := "Bu komut için tuş vuruşunu girmek için Klavye seçin" ; (100_3)(<Displayed Text> Top 1: Value)
                    v_104_3 := "Dahili Doğrudan Komut Kullanılamıyor" ; (104_3)(<Displayed Text> Bottom 1: Value)
                    v_107_3 := v_367_2 " Klavye kısayol özelliklerini kontrol et" ; (107_3)(<Displayed Text> Bottom 2: Value)/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
                  }
                } ; End (MKB)(Messsage)(By Language)
                ; -------------------------------------------
                DataArray.100.2 := 1 ; (100_2)(<Displayed Text> Top 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                v_100_3 := Unicode_In_String(v_100_3) ; (100_3)(<Displayed Text> Top 1: Value)
                DataArray.100.3 := v_100_3 ; (100_3)(<Displayed Text> Top 1: Value)
                ;
                DataArray.104.2 := 1 ; (104_2)(<Displayed Text> Bottom 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                v_104_3 := Unicode_In_String(v_104_3) ; (104_3)(<Displayed Text> Bottom 1: Value)
                DataArray.104.3 := v_104_3 ; (104_3)(<Displayed Text> Bottom 1: Value)
                ;
                DataArray.107.2 := 1 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                v_107_3 := Unicode_In_String(v_107_3) ; (107_3)(<Displayed Text> Bottom 2: Value)
                DataArray.107.3 := v_107_3 ; (107_3)(<Displayed Text> Bottom 2: Value)
                ;
                ; -------------------------------------------
                FontColor := "a30404" ; (Red)
                FontSize := 12
                MaxWidth := 480
                ; (366_2)(GuiFont Set in DataArray_Set)
                Text_Adjust_PopUpMenu("g_100", v_100_3, v_366_2, FontSize, FontColor, MaxWidth) ; (100_3)(<Displayed Text> Top 1: Value)/(366_2)(GuiFont Set in DataArray_Set)/(100_1)(GUI Object: <Displayed Text> Top 1)
                Text_Adjust_PopUpMenu("g_104", v_104_3, v_366_2, FontSize, FontColor, MaxWidth) ; (104_3)(<Displayed Text> Bottom 1: Value)/(366_2)(GuiFont Set in DataArray_Set)/(104_1)(GUI Object: <Displayed Text> Bottom 1)
                Text_Adjust_PopUpMenu("g_107", v_107_3, v_366_2, FontSize, FontColor, MaxWidth) ; (107_3)(<Displayed Text> Bottom 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(107_1)(GUI Object: <Displayed Text> Bottom 2)
                ; -------------------------------------------
                DataArray := GuiControlImage_PopUpMenu("063", 0, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
                DataArray := GuiControlImage_PopUpMenu("064", 0, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
                DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
                DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
                ; -------------------------------------------
                if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
                {
                  DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
                } ; End (Delete Shortcut)
                ; -------------------------------------------
              } ; End (ComCheck == "MKB")
              else ; (ComCheck != "MKB")
              {
                ; -------------------------------------------
                if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
                {
                  DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
                } ; End (Delete Shortcut != 2)
                DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
                DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
                DataArray := GuiControlImage_PopUpMenu("063", 0, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
                DataArray := GuiControlImage_PopUpMenu("064", 0, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
                DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
                DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
                DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
                ; -------------------------------------------
              } ; End (ComCheck != "MKB")
              ; -------------------------------------------
            } ; End (IsValid == 0)
            ; -------------------------------------------
          } ; End (IsValid)
          ; -------------------------------------------
        } ; End (Selected List Item is a Divider [0/1])
        ; -------------------------------------------
      } ; End (Temp_Icon)(Ok Button)
      ; -------------------------------------------
    } ; End Has Menu Array
    ; -------------------------------------------
    if (v_366_4 == 1) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    {
      ; -------------------------------------------
      v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
      GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
      ; -------------------------------------------
      GuiControl, PopUpMenu:Hide, g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
      v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
      GuiControl, PopUpMenu:, g_105, %v_105_3% ; (105_3)(<Displayed Text> Top 2: Value)/(105_1)(GUI Object: <Displayed Text> Top 2)
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
      DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
      DataArray := GuiControlImage_PopUpMenu("063", 0, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
      DataArray := GuiControlImage_PopUpMenu("064", 0, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
      DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
      DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
      DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
      } ; End (Delete Shortcut != 2)
      ; -------------------------------------------
    } ; End (Selected List Item is a Divider [0/1])
    ; -------------------------------------------
  } ; End (Script Type == "mnu")
  ; -------------------------------------------
  else if (v_366_5 == "cpl") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    v_366_4 := DataArray.366.4 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; v_(341-350)_1 := DataArray.(341-350).1
    ; v_(341-350)_1.1.1 = Menu Name
    ; v_(341-350)_1.1.2 = Menu Content
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; [SET] cplArray
      ; -------------------------------------------
      DataArray := cpl_TextFile_to_Array(DataArray)
      ; -------------------------------------------
      if (v_365_2 == "de") ; (365_2)(Current User language)
      {
        cplArray := DataArray.341 ; (341_1)([cpl] de German Menu Array de_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "en") ; (365_2)(Current User language)
      {
        cplArray := DataArray.342 ; (342_1)([cpl] en English Menu Array en_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "es") ; (365_2)(Current User language)
      {
        cplArray := DataArray.343 ; (343_1)([cpl] es Spanish Menu Array es_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "fr") ; (365_2)(Current User language)
      {
        cplArray := DataArray.344 ; (344_1)([cpl] fr French Menu Array fr_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "it") ; (365_2)(Current User language)
      {
        cplArray := DataArray.345 ; (345_1)([cpl] it Italian Menu Array it_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "pl") ; (365_2)(Current User language)
      {
        cplArray := DataArray.346 ; (346_1)([cpl] pl Polish Menu Array pl_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "pt") ; (365_2)(Current User language)
      {
        cplArray := DataArray.347 ; (347_1)([cpl] pt Portuguese Menu Array pt_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "ru") ; (365_2)(Current User language)
      {
        cplArray := DataArray.348 ; (348_1)([cpl] ru Russian Menu Array ru_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "sv") ; (365_2)(Current User language)
      {
        cplArray := DataArray.349 ; (349_1)([cpl] sv Swedish Menu Array sv_cpl)
      }
      ; -------------------------------------------
      else if (v_365_2 == "tr") ; (365_2)(Current User language)
      {
        cplArray := DataArray.350 ; (350_1)([cpl] tr Turkish Menu Array tr_cpl)
      }
      ; -------------------------------------------
    } ; End [SET] cplArray
    ; -------------------------------------------
    { ; Break cplArray into Individual List
      ; -------------------------------------------
      for Index, ThisItem in cplArray
      {
        ; -------------------------------------------
        cplMenuNum := ThisItem.1
        ArrayLen := ThisItem.MaxIndex()
        ArrayLen := ArrayLen - 1
        Num := 1
        cplMenuItem := ""
        ; -------------------------------------------
        Loop %ArrayLen%
        {
          Num := Num + 1
          ThisText := ThisItem[Num] ; 2 for first
          cplMenuItem := Array_Add(cplMenuItem, ThisText, "End")
        } ; End Loop %ArrayLen%
        %cplMenuNum% := cplMenuItem ; %(String)% := (Array)
      } ; End for Index, ThisItem in cplArray
      ; -------------------------------------------
    } ; End Break cplArray into Individual List
    ; -------------------------------------------
    { ; (105)(Decriptive Top Text 2_2)Select_(3)Value
      ; -------------------------------------------
      ; Empty Var Values
      ListArray1 := ""
      ListArray2 := ""
      ListArray3 := ""
      v_110_3 := "" ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
      v_111_3 := "" ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
      v_112_3 := "" ; (112_3)([mnu] <Displayed Text> Right List: Value)
      v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
      v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
      IsValid := 0
      ; -------------------------------------------
      ListArray0 := %v_365_2%_cpl_0 ; (365_2)(Current User language)
      ; -------------------------------------------
      if (v_300_2 > 0) ; (300_2)([cpl] Menu Number #_X_[X])
      {
        ; -------------------------------------------
        ListArray1 := %v_365_2%_cpl_%v_300_2% ; (365_2)(Current User language)/(300_2)([cpl] Menu Number #_X_[X])
        ; -------------------------------------------
        { ; [UPDATE][Gui_Control][VALUE][SHOW] (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value
          ; -------------------------------------------
          ; [VALUE]
          v_110_3 := ListArray0[v_300_2] ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(300_2)([cpl] Menu Number #_X_[X])
          if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
          {
            ; -------------------------------------------
            v_110_3 := StrReplace(v_110_3, " >" , "") ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
            v_110_3 := StrReplace(v_110_3, "&" , "&&") ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
            ; -------------------------------------------
            v_110_3 := Unicode_In_String(v_110_3) ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
            DataArray.110.3 := v_110_3 ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
            FontColor := "921297" ; (Purple)
            FontSize := 12
            MaxWidth := 158
            ; (366_2)(GuiFont Set in DataArray_Set)
            ; (110_3)([cpl][mnu] Left List Text: Value)
            Text_Adjust_PopUpMenu("g_110", v_110_3, v_366_2, FontSize, FontColor, MaxWidth) ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(366_2)(GuiFont Set in DataArray_Set)/(110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
            ; -------------------------------------------
            DataArray.110.2 := 1 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            ; -------------------------------------------
          } ; End (Divider == 0)
          ; -------------------------------------------
        } ; End [UPDATE][Gui_Control][VALUE][SHOW] (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value
        ; -------------------------------------------
        if (v_300_3 > 0) ; (300_3)([cpl] Menu Number X_#_[X])
        {
          ; -------------------------------------------
          ; (365_2)(Current language)
          ; (300_2)([cpl] Menu Item #_X_[X])
          ; (300_3)([cpl] Menu Item X_#_[X])
          ListArray2 := %v_365_2%_cpl_%v_300_2%_%v_300_3% ; (365_2)(Current User language)/(300_2)([cpl] Menu Number #_X_[X])/(300_3)([cpl] Menu Number X_#_[X])
          ; -------------------------------------------
          { ; (X_#_[X] > 0) / (111)(Center List Text_2)Select_(3)Value
            ; -------------------------------------------
            ; [VALUE]
            ; (300_3)([cpl] Menu Item X_#_[X])
            v_111_3 := ListArray1[v_300_3] ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(300_3)([cpl] Menu Number X_#_[X])
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              v_111_3 := StrReplace(v_111_3, " >" , "") ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
              v_111_3 := StrReplace(v_111_3, "&" , "&&") ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
              v_111_3 := Unicode_In_String(v_111_3) ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
              DataArray.111.3 := v_111_3 ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
              FontColor := "921297" ; (Purple)
              FontSize := 12
              MaxWidth := 158
              ; (366_2)(GuiFont Set in DataArray_Set)
              Text_Adjust_PopUpMenu("g_111", v_111_3, v_366_2, FontSize, FontColor, MaxWidth) ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)/(366_2)(GuiFont Set in DataArray_Set)/(111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
              ; -------------------------------------------
              DataArray.111.2 := 1 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              ; -------------------------------------------
            } ; End (Divider == 0)
            ; -------------------------------------------
          } ; End (X_#_[X] > 0) / (111)(Center List Text_2)Select_(3)Value
          ; -------------------------------------------
          if (v_300_4 > 0) ; (300_4)([cpl] Menu Number X_X_[#])
          {
            ; -------------------------------------------
            SelectedItem_Text := ListArray2[v_300_4] ; (300_4)([cpl] Menu Number X_X_[#])
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              ; -------------------------------------------
              SelectedItem_Text := StrReplace(SelectedItem_Text, "&" , "&&") ; (300_4)([cpl] Menu Number X_X_[#])
              ; -------------------------------------------
              { ; (X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                ; (110_3)([cpl][mnu] Left List Text: Value)
                ; (111_3)([cpl][mnu] Center List Text: Value)
                ; (300_4)([cpl] Menu Item X_X_[#])
                v_105_3 := v_110_3 " > " v_111_3 " > " SelectedItem_Text ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                ; -------------------------------------------
                { ; (X_X_[#] > 0) / Font Size Adjust
                  FontColor := "199524" ; (Green)
                  FontSize := 12
                  MaxWidth := 480
                  ; (366_2)(GuiFont Set in DataArray_Set)
                  Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                } ; End (X_X_[#] > 0) / Font Size Adjust
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                ; -------------------------------------------
              } ; End (X_X_[#] > 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
              ; -------------------------------------------
              { ; (X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                v_122_3 := SelectedItem_Text ; (122_3)(<Edit Feild> Status Bar Description: Value)
                v_122_3 := Unicode_In_String(v_122_3) ; (122_3)(<Edit Feild> Status Bar Description: Value)
                DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                ;
                DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                ; -------------------------------------------
              } ; End (X_X_[#] > 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
              ; -------------------------------------------
            } ; End (Divider == 0)
            ; -------------------------------------------
          } ; End (X_X_[#] > 0)
          ; -------------------------------------------
          else if (v_300_4 == 0) ; (300_4)([cpl] Menu Number X_X_[#])
          {
            ; -------------------------------------------
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              ; -------------------------------------------
              { ; (X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                ; (110_3)([cpl][mnu] Left List Text: Value)
                ; (111_3)([cpl][mnu] Center List Text: Value)
                v_105_3 := v_110_3 " > " v_111_3 " > " ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)/(111_3)([cpl][mnu] <Displayed Text> Center List: Value)
                v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                ;
                { ; (X_X_[#] == 0) / Font Size Adjust
                  FontColor := "a30404" ; (Red)
                  FontSize := 12
                  MaxWidth := 480
                  ; (366_2)(GuiFont Set in DataArray_Set)
                  Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                } ; End (X_X_[#] == 0) / Font Size Adjust
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                ; -------------------------------------------
              } ; End (X_X_[#] == 0) / (105)(Decriptive Top Text 2_2)Select_(3)Value
              ; -------------------------------------------
              { ; (X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
                ; [REMOVE VALUE]
                v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
                DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                ; -------------------------------------------
              } ; End (X_X_[#] == 0) / (122)(Edit Status Bar Description_2)Select_(3)Value
              ; -------------------------------------------
            } ; End (Divider == 0)
            ; -------------------------------------------
          } ; End (X_X_[#] == 0)
          ; -------------------------------------------
        } ; End (X_#_[X] > 0)
        else if (v_300_3 == 0) ; (300_3)([cpl] Menu Number X_#_[X])
        {
          ; -------------------------------------------
          { ; (111)(Center List Text_2)Select_(3)Value
            ; -------------------------------------------
            ; [REMOVE VALUE]
            DataArray.111.3 := "" ; (111_3)([cpl][mnu] <Displayed Text> Center List: Value)
            ; -------------------------------------------
            ; [HIDE]
            if (DataArray.111.2 == 1) ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            {
              DataArray.111.2 := 0 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
            }
            ; -------------------------------------------
          }
          ; -------------------------------------------
          if (v_300_4 > 0) ; (300_4)([cpl] Menu Number X_X_[#])
          {
            ; -------------------------------------------
            SelectedItem_Text := ListArray1[v_300_4] ; (300_4)([cpl] Menu Number X_X_[#])
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              ; -------------------------------------------
              SelectedItem_Text := StrReplace(SelectedItem_Text, "&" , "&&") ; (300_4)([cpl] Menu Number X_X_[#])
              ; -------------------------------------------
              { ; (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                ; (110_3)([cpl][mnu] Left List Text: Value)
                ; (300_4)([cpl] Menu Item X_X_[#])
                v_105_3 := v_110_3 " > " SelectedItem_Text ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)
                v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                ;
                { ; Font Size Adjust
                  FontColor := "199524" ; (Green)
                  FontSize := 12
                  MaxWidth := 480
                  Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                }
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                ; -------------------------------------------
              }
              ; -------------------------------------------
              { ; (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                v_122_3 := SelectedItem_Text ; (122_3)(<Edit Feild> Status Bar Description: Value)
                v_122_3 := Unicode_In_String(v_122_3) ; (122_3)(<Edit Feild> Status Bar Description: Value)
                DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                ; -------------------------------------------
              }
              ; -------------------------------------------
            }
            ; -------------------------------------------
          }
          ; -------------------------------------------
          else if (v_300_4 == 0) ; (300_4)([cpl] Menu Number X_X_[#])
          {
            ; -------------------------------------------
            if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
            {
              ; -------------------------------------------
              { ; (105)(Decriptive Top Text 2_2)Select_(3)Value
                ; -------------------------------------------
                ; [VALUE]
                ; (110_3)([cpl][mnu] Left List Text: Value)
                v_105_3 := v_110_3 " > " ; (105_3)(<Displayed Text> Top 2: Value)/(110_3)([cpl][mnu] <Displayed Text> Left List: Value)
                v_105_3 := Unicode_In_String(v_105_3) ; (105_3)(<Displayed Text> Top 2: Value)
                DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
                ;
                { ; Font Size Adjust
                  FontColor := "a30404" ; (Red)
                  FontSize := 12
                  MaxWidth := 480
                  ; (105_3)(<Displayed Text> Top 2: Value)
                  Text_Adjust_PopUpMenu("g_105", v_105_3, v_366_2, FontSize, FontColor, MaxWidth) ; (105_3)(<Displayed Text> Top 2: Value)/(366_2)(GuiFont Set in DataArray_Set)/(105_1)(GUI Object: <Displayed Text> Top 2)
                }
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                ; -------------------------------------------
              }
              ; -------------------------------------------
              { ; (122)(Edit Status Bar Description_2)Select_(3)Value
                ; -------------------------------------------
                ; [REMOVE VALUE]
                v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
                DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
                GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
                DataArray := GuiControlImage_PopUpMenu("065", 1, 1, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
                ; -------------------------------------------
              }
              ; -------------------------------------------
            }
            ; -------------------------------------------
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      else if (v_300_2 == 0) ; (300_2)([cpl] Menu Number #_X_[X])
      {
        ; -------------------------------------------
        { ; [UPDATE][Gui_Control][REMOVE VALUE][HIDE] (110)_(mnu)(cpl)(Left List Text)_(2)Select_(3)Value 
          ; -------------------------------------------
          ; [REMOVE VALUE]
          DataArray.110.3 := "" ; (110_3)([cpl][mnu] <Displayed Text> Left List: Value)
          ; -------------------------------------------
          ; [HIDE]
          if (DataArray.110.2 == 1) ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray.110.2 := 0 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        { ; (105)(Decriptive Top Text 2_2)Select_(3)Value
          ; -------------------------------------------
          ; [REMOVE VALUE]
          v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
          DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
          GuiControl, PopUpMenu:, g_105, ; (105_1)(GUI Object: <Displayed Text> Top 2)
          ; -------------------------------------------
          ; [HIDE]
          if (DataArray.105.2 == 1) ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray.105.2 := 0 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
          }
        }
        ; -------------------------------------------
        { ; (122)(Edit Status Bar Description_2)Select_(3)Value
          ; -------------------------------------------
          ; [REMOVE VALUE]
          v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
          DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
          GuiControl, PopUpMenu:, g_122, ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
          ; -------------------------------------------
          ; [HIDE]
          ; -------------------------------------------
          ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
          ; (065_1)(GUI Object: <Image Text> Status Bar Description)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------                  
    }
    ; -------------------------------------------
    { ; [SET] ListBox#
      ; -------------------------------------------
      ; Empty Var Values
      ListBox1 := ""
      ListBox2 := ""
      ListBox3 := ""
      ; -------------------------------------------
      if ListArray1
      {
        ListBox1 := Array_to_ListBox(ListArray1, "cpl")
      }
      ; -------------------------------------------
      if ListArray2
      {
        ListBox2 := Array_to_ListBox(ListArray2, "cpl")
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    { ; [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
      ; -------------------------------------------
      if (v_300_2 > 0) ; (300_2)([cpl] Menu Number #_X_[X])
      {
        ; -------------------------------------------
        if (v_300_3 > 0) ; (300_3)([cpl] Menu Number X_#_[X])
        {
          ; -------------------------------------------
          { ; (X_#_[X] > 0) / [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List 
            ; -------------------------------------------
            { ; (X_#_[X] > 0) / [HIDE]
              ; -------------------------------------------
              DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_116  ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
              ; -------------------------------------------
            } ; End (X_#_[X] > 0) / [HIDE]
            ; -------------------------------------------
            { ; (X_#_[X] > 0) / [VALUE]
            ; -------------------------------------------
              CkListBox1 := DataArray.118.3 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
              if (CkListBox1 != ListBox1)
              {
                DataArray.118.3 := ListBox1 ; (118_3)([cpl][mnu] List Left 1/3: ListBox)
                GuiControl, PopUpMenu:, g_118, %ListBox1% ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
              } ; End (CkListBox1 != ListBox1)
              ; -------------------------------------------
              CkListBox2 := DataArray.117.3 ; (117_3)([cpl][mnu] List Right 2/3: ListBox)
              if (CkListBox2 != ListBox2)
              {
                DataArray.117.3 := ListBox2 ; (117_3)([cpl][mnu] List Right 2/3: ListBox)
                GuiControl, PopUpMenu:, g_117, %ListBox2% ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
              } ; End (CkListBox2 != ListBox2)
              ; -------------------------------------------
            } ; End (X_#_[X] > 0) / [VALUE]
            ; -------------------------------------------
            { ; (X_#_[X] > 0) / [CHOOSE][FOCUS]
              ; -------------------------------------------
              if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
              {
                GuiControl, PopUpMenu:Choose, g_118, %v_300_3% ; (300_3)([cpl] Menu Number X_#_[X])/(118_1)(GUI Object: [cpl][mnu] List Left 1/3)
              } ; End (Divider == 0)
              if (v_300_4 > 0) ; (300_4)([cpl] Menu Number X_X_[#])
              {
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  GuiControl, PopUpMenu:Choose, g_117, %v_300_4% ; (300_4)([cpl] Menu Number X_X_[#])/(117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                  GuiControl, PopUpMenu:Focus, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                } ; End (Divider == 0)
              } ; End (X_X_[#] > 0)
              ; -------------------------------------------
              else if (v_300_4 == 0) ; (300_4)([cpl] Menu Number X_X_[#])
              {
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  GuiControl, PopUpMenu:Choose, g_117, 0 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
                  GuiControl, PopUpMenu:Focus, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
                } ; End (Divider == 0)
              } ; End (X_X_[#] == 0)
              ; -------------------------------------------
            } ; End (X_#_[X] > 0) / [CHOOSE][FOCUS]
            ; -------------------------------------------
            { ; (X_#_[X] > 0) / [SHOW]
              ; -------------------------------------------
              DataArray.118.2 := 1 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Show, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
              ; -------------------------------------------
              DataArray.117.2 := 1 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Show, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
              ; -------------------------------------------
            } ; End (X_#_[X] > 0) / [SHOW]
            ; -------------------------------------------
          } ; End (X_#_[X] > 0)
          ; -------------------------------------------
        } ; End (X_#_[X] > 0)
        ; -------------------------------------------
        else if (v_300_3 == 0) ; (300_3)([cpl] Menu Number X_#_[X])
        {
          ; -------------------------------------------
          { ; (X_#_[X] == 0) / [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List 
            ; -------------------------------------------
            { ; (X_#_[X] == 0) / [HIDE]
              ; -------------------------------------------
              DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
              ; -------------------------------------------
              DataArray.118.2 := 0 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Hide, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
              ; -------------------------------------------
            } ; End (X_#_[X] == 0) / [HIDE]
            ; -------------------------------------------
            { ; (X_#_[X] == 0) / [Value]
              ; -------------------------------------------
              CkListBox1 := DataArray.116.3 ; (116_3)([cpl][mnu] List Full Across: ListBox)
              if (CkListBox1 != ListBox1)
              {
                DataArray.116.3 := ListBox1 ; (116_3)([cpl][mnu] List Full Across: ListBox)
                GuiControl, PopUpMenu:, g_116, %ListBox1% ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
              } ; End (CkListBox1 != ListBox1)
              ; -------------------------------------------
            } ; End (X_#_[X] == 0) / [Value]
            ; -------------------------------------------
            { ; (X_#_[X] == 0) / [CHOOSE][FOCUS]
              ; -------------------------------------------
              if (v_300_4 > 0) ; (300_4)([cpl] Menu Number X_X_[#])
              {
                if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
                {
                  GuiControl, PopUpMenu:Choose, g_116, %v_300_4% ; (300_4)([cpl] Menu Number X_X_[#])/(116_1)(GUI Object: [cpl][mnu] List Full Across)
                  GuiControl, PopUpMenu:Focus, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
                } ; End (Divider == 0])
              } ; End (X_X_[#] > 0)
              ; -------------------------------------------
            } ; End (X_#_[X] == 0) / [CHOOSE][FOCUS]
            ; -------------------------------------------
            { ; (X_#_[X] == 0) / [SHOW]
              ; -------------------------------------------
              DataArray.116.2 := 1 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
              GuiControl, PopUpMenu:Show, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
              ; -------------------------------------------
            } ; End (X_#_[X] == 0) / [SHOW]
            ; -------------------------------------------
          } ; End (X_#_[X] == 0) / [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List 
          ; -------------------------------------------
        } ; End (X_#_[X] == 0)
        ; -------------------------------------------
      } ; End (#_X_[X] > 0)
      ; -------------------------------------------
      else if (v_300_2 == 0) ; (300_2)([cpl] Menu Number #_X_[X])
      {
        ; -------------------------------------------
        { ; (#_X_[X] == 0) / [UPDATE][HIDE] List
          ; -------------------------------------------
          { ; (#_X_[X] == 0) / [HIDE]
            ; -------------------------------------------
            DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
            ; -------------------------------------------
            DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
            ; -------------------------------------------
            DataArray.118.2 := 0 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
            ; -------------------------------------------
            DataArray.110.2 := 0 ; (110_2)([cpl][mnu] <Displayed Text> Left List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
            ; -------------------------------------------
            DataArray.111.2 := 0 ; (111_2)([cpl][mnu] <Displayed Text> Center List: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
            ; -------------------------------------------
          } ; End (#_X_[X] == 0) / [HIDE]
          ; -------------------------------------------
        } ; End (#_X_[X] == 0) / [UPDATE][HIDE] List
        ; -------------------------------------------
      } ; End (#_X_[X] == 0)
      ; -------------------------------------------
    } ; End [UPDATE][Gui_Control][HIDE][VALUE][CHOOSE][FOCUS][SHOW] List
    ; -------------------------------------------
    { ; (004)(Ok Button_2)Select_(3)Image
      ; -------------------------------------------
      if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
      {
        ; -------------------------------------------
        { ; [SET] Temp_Icon / [SET] IsValid (0/1)
          ; -------------------------------------------
          if (v_366_4 == 0) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
          {
            ; -------------------------------------------
            DataArray.102.2 := 1 ; (102_2)(Main Display Icon: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            ; -------------------------------------------
            if (v_300_4 > 0 && v_300_2 > 0) ; (300_4)([cpl] Menu Number X_X_[#])/(300_2)([cpl] Menu Number #_X_[X])
            {
              ; -------------------------------------------
              if (v_300_3 > 0) ; (300_3)([cpl] Menu Number X_#_[X])
              {
                ; -------------------------------------------
                IsValid := 1
                Temp_Icon := v_363_5 "\cpl\ico\" v_300_2 "_" v_300_3 "_(" v_300_4 ").ico" ; (363_5)(PC Installed Dir)/(300_2)([cpl] Menu Number #_X_[X])/(300_3)([cpl] Menu Number X_#_[X])/(300_4)([cpl] Menu Number X_X_[#])
                MissingIconNum := v_300_2 "_" v_300_3 "_(" v_300_4 ")" ; (300_2)([cpl] Menu Number #_X_[X])/(300_3)([cpl] Menu Number X_#_[X])/(300_4)([cpl] Menu Number X_X_[#])
                ; -------------------------------------------
              } ; End (X_#_[X] > 0)
              ; -------------------------------------------
              else if (v_300_3 == 0) ; (300_3)([cpl] Menu Number X_#_[X])
              {
                ; -------------------------------------------
                IsValid := 1
                Temp_Icon := v_363_5 "\cpl\ico\" v_300_2 "_(" v_300_4 ").ico" ; (363_5)(PC Installed Dir)/(300_2)([cpl] Menu Number #_X_[X])/(300_4)([cpl] Menu Number X_X_[#])
                MissingIconNum := v_300_2 "_(" v_300_4 ")" ; (300_2)([cpl] Menu Number #_X_[X])/(300_4)([cpl] Menu Number X_X_[#])
                ; -------------------------------------------
              } ; End (X_#_[X] == 0)
              ; -------------------------------------------
            } ; End (X_X_[#] > 0) & (#_X_[X] > 0)
            ; -------------------------------------------
            ; (300_2)([cpl] Menu Item #_X_[X])
            else if (v_300_4 == 0 or v_300_2 == 0) ; (300_4)([cpl] Menu Number X_X_[#])/(300_2)([cpl] Menu Number #_X_[X])
            {
              ; -------------------------------------------
              IsValid := 0
              ; -------------------------------------------
            } ; End (X_X_[#] == 0) or (#_X_[X] == 0)
            ; -------------------------------------------
          } ; End (Divider == 0)
          ; -------------------------------------------
          else if (v_366_4 == 1) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
          {
            ; -------------------------------------------
            IsValid := 0
            ; -------------------------------------------
          } ; End (Divider == 1)
          ; -------------------------------------------
        } ; End [SET] Temp_Icon / [SET] IsValid (0/1)
        ; -------------------------------------------
        { ; [VALUE] (102)_(---)(Main Display Icon)
          ; -------------------------------------------
          DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
          ; -------------------------------------------
        } ; End [VALUE] (102)_(---)(Main Display Icon)
        ; -------------------------------------------
        { ; (005)(Icon Rotate Left_2)Select_(3)Image
          ; -------------------------------------------
          if (IsValid == 1)
          {
            ; -------------------------------------------
            if FileExist(Temp_Icon)
            {
              DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
            } ; End FileExist(Temp_Icon)
            else ; !FileExist(Temp_Icon)
            {
              Temp_Icon := v_363_5 "\ico\Missing.png" ; (363_5)(PC Installed Dir)
              DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
              ToolTip, %MissingIconNum%, 0, 0
              Msg := ""
            } ; End !FileExist(Temp_Icon)
            ; -------------------------------------------
            if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
            {
              DataArray := GuiControlImage_PopUpMenu("004", 1, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
            } ; End (Delete Shortcut != 2)
            DataArray := GuiControlImage_PopUpMenu("005", 1, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
            DataArray := GuiControlImage_PopUpMenu("006", 1, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
            DataArray := GuiControlImage_PopUpMenu("063", 1, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
            DataArray := GuiControlImage_PopUpMenu("064", 1, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
            DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
            DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
            DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
            ; -------------------------------------------
          } ; End (IsValid == 1)
          ; -------------------------------------------
          else if (IsValid == 0)
          {
            ; -------------------------------------------
            DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
            ; -------------------------------------------
            if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
            {
              DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
            } ; End (Delete Shortcut != 2)
            DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
            DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
            DataArray := GuiControlImage_PopUpMenu("063", 0, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
            DataArray := GuiControlImage_PopUpMenu("064", 0, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
            DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
            DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
            DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
            ; -------------------------------------------
          } ; End (IsValid == 0)
          ; -------------------------------------------
        } ; End (005)(Icon Rotate Left_2)Select_(3)Image
        ; -------------------------------------------
      } ; End (Divider == 0)
      ; -------------------------------------------
    } ; End (004)(Ok Button_2)Select_(3)Image
    ; -------------------------------------------
    if (v_366_4 == 1) ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    {
      ; -------------------------------------------
      v_122_3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
      DataArray.122.3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
      GuiControl, PopUpMenu:, g_122, %v_122_3% ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
      ; -------------------------------------------
      GuiControl, PopUpMenu:Hide, g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
      v_105_3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
      DataArray.105.3 := "" ; (105_3)(<Displayed Text> Top 2: Value)
      GuiControl, PopUpMenu:, g_105, %v_105_3% ; (105_3)(<Displayed Text> Top 2: Value)/(105_1)(GUI Object: <Displayed Text> Top 2)
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
      }
      DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
      DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
      DataArray := GuiControlImage_PopUpMenu("063", 0, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
      DataArray := GuiControlImage_PopUpMenu("064", 0, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
      DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
      DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
      DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      ; -------------------------------------------
    } ; End (Divider == 1)
    ; -------------------------------------------
  } ; End (366_5)(Script Type) (cpl)
  ; -------------------------------------------
  DataArray.363.9 := ""  ; (363_9)(Limited DataArray)
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Script_Close(DataArray.384.1) ; (384_1)(Disable_KeySelect.ahk)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
