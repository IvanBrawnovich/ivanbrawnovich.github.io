﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
~XButton1::
{
  ; -------------------------------------------
  ifWinActive, ahk_class AfxMDIFrame140u ; Acad
  {
    Send, {Esc 2}
    Send, Zoom
    Send, {Enter}
    Send, e
    Send, {Enter}
  } ; End ifWinActive, ahk_class AfxMDIFrame140u ; Acad
  ; -------------------------------------------
  else ifWinActive, ahk_class indesign
  {
    Send, {Ctrl Down}{Alt Down}0{Alt Up}{Ctrl Up}
  } ; End else ifWinActive, ahk_class indesign
  ; -------------------------------------------
    else ifWinActive, ahk_class Photoshop
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
  else ifWinActive, ahk_class illustrator
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_class illustrator
  ; -------------------------------------------
  else ifWinActive, ahk_exe Publisher.exe
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_exe Publisher.exe
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; End ~XButton1::
return
; -------------------------------------------
~XButton2::
{
  ; -------------------------------------------
  ifWinActive, ahk_class AfxMDIFrame140u ; Acad
  {
    Send, {Esc 2}
    Send, Zoom
    Send, {Enter}
    Send, e
    Send, {Enter}
  } ; End ifWinActive, ahk_class AfxMDIFrame140u ; Acad
  ; -------------------------------------------
  else ifWinActive, ahk_class indesign
  {
    Send, {Ctrl Down}{Alt Down}0{Alt Up}{Ctrl Up}
  } ; End else ifWinActive, ahk_class indesign
  ; -------------------------------------------
    else ifWinActive, ahk_class Photoshop
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
  else ifWinActive, ahk_class illustrator
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_class illustrator
  ; -------------------------------------------
  else ifWinActive, ahk_exe Publisher.exe
  {
    Send, {Ctrl down}{Numpad0}{Ctrl up}
  } ; End else ifWinActive, ahk_exe Publisher.exe
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; End ~XButton2::
return
; -------------------------------------------
Insert::
{
  ; -------------------------------------------
  ifWinActive, ahk_class Photoshop
  {
    Send, {Ctrl Down}{Shift Down}v{Shift Up}{Ctrl Up}
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
  else ifWinActive, ahk_class indesign
  {
    Send, {Ctrl Down}{Alt Down}{Shift Down}v{Shift Up}{Alt Up}{Ctrl Up}
  } ; End ifWinActive, ahk_class indesign
  ; -------------------------------------------
  else
  {
    return
  } ; End else
  ; -------------------------------------------
} ; End Insert::
return
; -------------------------------------------
Shift & WheelDown:: ; Photoshop
{
  ; -------------------------------------------
  ifWinActive, ahk_exe Photoshop.exe
  {
    Send, [
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
  ifWinActive, ahk_exe Adobe Audition.exe
  {
    Send, -

  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
} ; End Shift & WheelDown::
return
; -------------------------------------------
Shift & WheelUp:: ; Photoshop
{
  ; -------------------------------------------
  ifWinActive, ahk_exe Photoshop.exe
  {
    Send, ]
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
  ifWinActive, ahk_exe Adobe Audition.exe
  {
    Send, =
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
} ; End Shift & WheelDown::
return
; -------------------------------------------




~PGUP::
{
  ifWinActive, ahk_class Photoshop
  {
    ; Previous Tab
    Send, {Shift Down}{Ctrl Down}{Tab}{Ctrl Up}{Shift Up}
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
}
return
; -------------------------------------------
~PGDN::
{
  ifWinActive, ahk_class Photoshop
  {
    ; Next Tab
    Send, {Ctrl Down}{Tab}{Ctrl Up}
  } ; End ifWinActive, ahk_class Photoshop
  ; -------------------------------------------
}
return
; -------------------------------------------
~F2:: ; Photoshop
{
  ifWinActive, ahk_class Photoshop
  {
    ; Rename Layer/Group...
    ; -------------------------------------------
    PostMessage, 0x111, 2983, , , ahk_class Photoshop
    ; -------------------------------------------
  } ; End ifWinActive, ahk_class Photoshop
}
