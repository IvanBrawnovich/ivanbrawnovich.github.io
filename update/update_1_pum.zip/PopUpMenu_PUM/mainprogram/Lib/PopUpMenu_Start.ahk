﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Splash_Script("500", 0) ; Var_Number_Error
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; -------------------------------------------
Pc_TxtFile_UserHotKey := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
if FileExist(Pc_TxtFile_UserHotKey) ; (381_3)(User HotKey Text File [User Text File Path])
{
  ; -------------------------------------------
  Current_UserHotKey := "" ; (369_2)(Current User Hotkey)
  Pc_TxtFile_UserHotKey  := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
  FileReadLine, Current_UserHotKey, %Pc_TxtFile_UserHotKey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
  ; -------------------------------------------
  if (Current_UserHotKey == "") ; (369_2)(Current User Hotkey)
  {
    Splash_Script("Off", 0)
    Hotkey_gui(DataArray) ; DataArray
  } ; HasUserHotKey Has No Value
  else ; HasUserHotKey OK
  {
    HasUserHotKey := 1
  } ; End HasUserHotKey OK
} ; (381_3)(User HotKey Text File [User Text File Path])
else ; (381_3)(User HotKey Text File [User Text File Path])
{
  Splash_Script("Off", 0)
  Hotkey_gui(DataArray) ; DataArray
} ; (381_3)(User HotKey Text File [User Text File Path])
; -------------------------------------------
if (HasUserHotKey == 1)
{
  ; -------------------------------------------
  Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HasAdminRights.ahk
  File_HasAdminRights := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\HasAdminRights.txt"
  End_Time := A_TickCount + 1000
  while !FileExist(File_HasAdminRights) && A_TickCount < End_Time
  {
  }
  if FileExist(File_HasAdminRights)
  {
    FileReadLine, HasAdminRights, %File_HasAdminRights%, 1
  }
  ; -------------------------------------------
  if (HasAdminRights == 1)
  {
    Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\StartUp_StandAlone.ahk
  }
  ; -------------------------------------------
  Run, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Copy_Pum_Lib.ahk
  ; -------------------------------------------
  HotKey_AppSpicific := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\HotKey_AppSpicific.ahk" ; (384_7)(HotKey_AppSpicific [Script File Path])/(363_5)(PC Installed Dir)
  if FileExist(HotKey_AppSpicific) ; (384_7)(HotKey_AppSpicific [Script File Path])
  {
    ; HotKeys (App Spicific)
    ; Stand Alone Script
    ; Hidden Window
    Run, %HotKey_AppSpicific% ; (384_7)(HotKey_AppSpicific [Script File Path])
  }
  ; -------------------------------------------
  ; Visable in Tray / Shortcut GUI
  ; Stand Alone Script
  Ahk_PUM := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\PUM.ahk" ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])/(363_5)(PC Installed Dir)
  Run, %Ahk_PUM%,,, Script_Ahk_PUM ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  Process, Priority, %Script_Ahk_PUM%, High ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  ; -------------------------------------------
  while (Is_Script_Running(Ahk_PUM) == 0)
  {
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
} ; End else if (HasUserHotKey == 1) ; User Hot Key is Set
; -------------------------------------------
{ ; #Include Lib Folder
  ; -------------------------------------------
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S1_C.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S2_H.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\_S3_S.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Application_Request.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Add.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_From_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_From_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Exist.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Is_In_Mult.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Item_Position.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Replace_Item.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Reverse.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_Subtract.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_To_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Array_to_ListBox.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Benchmark.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Connect_Check.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ResizeToBmp.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ChopToBmp.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Convert_ToIco.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\cpl_TextFile_to_Array.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\DataArray_Set.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Default_Application.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Default_Browser.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Download_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Existing_Shortcut.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_Get.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetAll.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetPath.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetSelected.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Explorer_GetWindow.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Extract_Icons_From_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Find_Windows_Public_Folder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_004.ahk ; (004_1)(GUI Object: Ok Button)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_005.ahk ; (005_1)(GUI Object: Icon Rotate Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_006.ahk ; (006_1)(GUI Object: Icon Rotate Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_008.ahk ; (008_1)(GUI Object: [key] Alt)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_009.ahk ; (009_1)(GUI Object: [key] Alt Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_010.ahk ; (010_1)(GUI Object: [key] Alt Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_011.ahk ; (011_1)(GUI Object: [key] Alt Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_012.ahk ; (012_1)(GUI Object: [key] Alt Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_013.ahk ; (013_1)(GUI Object: [key] Caps Lock)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_014.ahk ; (014_1)(GUI Object: [key] Ctrl Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_015.ahk ; (015_1)(GUI Object: [key] Ctrl Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_016.ahk ; (016_1)(GUI Object: [key] Ctrl Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_017.ahk ; (017_1)(GUI Object: [key] Ctrl Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_018.ahk ; (018_1)(GUI Object: [key] Enter)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_019.ahk ; (019_1)(GUI Object: [key] Enter X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_020.ahk ; (020_1)(GUI Object: [key] Esc)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_021.ahk ; (021_1)(GUI Object: [key] Esc X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_022.ahk ; (022_1)(GUI Object: [key] F1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_023.ahk ; (023_1)(GUI Object: [key] F2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_024.ahk ; (024_1)(GUI Object: [key] F3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_025.ahk ; (025_1)(GUI Object: [key] F4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_026.ahk ; (026_1)(GUI Object: [key] F5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_027.ahk ; (027_1)(GUI Object: [key] F6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_028.ahk ; (028_1)(GUI Object: [key] F7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_029.ahk ; (029_1)(GUI Object: [key] F8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_030.ahk ; (030_1)(GUI Object: [key] F9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_031.ahk ; (031_1)(GUI Object: [key] F10)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_032.ahk ; (032_1)(GUI Object: [key] F11)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_033.ahk ; (033_1)(GUI Object: [key] F12)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_034.ahk ; (034_1)(GUI Object: [key] Numpad 0)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_035.ahk ; (035_1)(GUI Object: [key] Numpad 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_036.ahk ; (036_1)(GUI Object: [key] Numpad 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_037.ahk ; (037_1)(GUI Object: [key] Numpad 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_038.ahk ; (038_1)(GUI Object: [key] Numpad 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_039.ahk ; (039_1)(GUI Object: [key] Numpad 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_040.ahk ; (040_1)(GUI Object: [key] Numpad 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_041.ahk ; (041_1)(GUI Object: [key] Numpad 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_042.ahk ; (042_1)(GUI Object: [key] Numpad 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_043.ahk ; (043_1)(GUI Object: [key] Numpad 9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_044.ahk ; (044_1)(GUI Object: [key] Numpad Add)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_045.ahk ; (045_1)(GUI Object: [key] Numpad Divide)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_046.ahk ; (046_1)(GUI Object: [key] Numpad Dot)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_047.ahk ; (047_1)(GUI Object: [key] Numpad Enter)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_048.ahk ; (048_1)(GUI Object: [key] Numpad Multiply)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_049.ahk ; (049_1)(GUI Object: [key] Numpad Subtract)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_050.ahk ; (050_1)(GUI Object: [key] Shift)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_051.ahk ; (051_1)(GUI Object: [key] Shift Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_052.ahk ; (052_1)(GUI Object: [key] Shift Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_053.ahk ; (053_1)(GUI Object: [key] Shift Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_054.ahk ; (054_1)(GUI Object: [key] Shift Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_055.ahk ; (055_1)(GUI Object: [key] Tab)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_056.ahk ; (056_1)(GUI Object: [key] Tab X2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_057.ahk ; (057_1)(GUI Object: [key] Windows Key)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_058.ahk ; (058_1)(GUI Object: [key] Windows Key Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_059.ahk ; (059_1)(GUI Object: [key] Windows Key Left)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_060.ahk ; (060_1)(GUI Object: [key] Windows Key Right)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_061.ahk ; (061_1)(GUI Object: [key] Windows Key Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_062.ahk ; (062_1)(GUI Object: Cancel)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_063.ahk ; (063_1)(GUI Object: Select Icon Image)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_064.ahk ; (064_1)(GUI Object: Reset Icon Image)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_068.ahk ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_069.ahk ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_070.ahk ; (070_1)(GUI Object: [cpl] Select Control)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_071.ahk ; (071_1)(GUI Object: [url] Select URL)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_072.ahk ; (072_1)(GUI Object: [key] Application Only)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_073.ahk ; (073_1)(GUI Object: [run] As Admin)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_074.ahk ; (074_1)(GUI Object: [key] Ctrl)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_075.ahk ; (075_1)(GUI Object: [key] Delete)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_076.ahk ; (076_1)(GUI Object: [key] End)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_077.ahk ; (077_1)(GUI Object: [key] Home)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_078.ahk ; (078_1)(GUI Object: [key] Insert)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_079.ahk ; (079_1)(GUI Object: [key] Page Down)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_080.ahk ; (080_1)(GUI Object: [key] Page Up)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_081.ahk ; (081_1)(GUI Object: [run][rwh] Select File)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_082.ahk ; (082_1)(GUI Object: [ofl] Select Folder)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_083.ahk ; (083_1)(GUI Object: [ToM] Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_084.ahk ; (084_1)(GUI Object: [ToM] File Url Folder)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_085.ahk ; (085_1)(GUI Object: [key] Select Keyboard)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_086.ahk ; (086_1)(GUI Object: [ToM] Menu Control Key)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_087.ahk ; (087_1)(GUI Object: [mnu] Select Menu)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_088.ahk ; (088_1)(GUI Object: [mnu] App Context Menu 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_089.ahk ; (089_1)(GUI Object: [mnu] App Context Menu 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_090.ahk ; (090_1)(GUI Object: [mnu] App Context Menu 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_091.ahk ; (091_1)(GUI Object: [mnu] App Context Menu 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_092.ahk ; (092_1)(GUI Object: [mnu] App Context Menu 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_093.ahk ; (093_1)(GUI Object: [mnu] App Context Menu 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_094.ahk ; (094_1)(GUI Object: [mnu] App Context Menu 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_095.ahk ; (095_1)(GUI Object: [mnu] App Context Menu 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_096.ahk ; (096_1)(GUI Object: [mnu] App Context Menu 9)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_097.ahk ; (097_1)(GUI Object: [mnu] App Context Menu 10)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_098.ahk ; (098_1)(GUI Object: [mnu] App Context Menu 11)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_099.ahk ; (099_1)(GUI Object: Web Site Image Link)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_102.ahk ; (102_1)(GUI Object: Main Display Icon)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_106.ahk ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_116.ahk ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_117.ahk ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_118.ahk ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_120.ahk ; (120_1)(GUI Object: [mnu] List Center 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_121.ahk ; (121_1)(GUI Object: [mnu] List Right 1/3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_123.ahk ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_124.ahk ; (124_1)(GUI Object: <Drop Down List> Language)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_125.ahk ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_126.ahk ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_127.ahk ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_128.ahk ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_129.ahk ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_130.ahk ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_131.ahk ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_132.ahk ; (132_1)(GUI Object: [url] Select Get URL Data)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_133.ahk ; (133_1)(GUI Object: Delete Shortcut)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_134.ahk ; (134_1)(GUI Object: Message Image 1)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_135.ahk ; (135_1)(GUI Object: Message Image 2)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_136.ahk ; (136_1)(GUI Object: Message Image 3)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_137.ahk ; (137_1)(GUI Object: Message Image 4)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_138.ahk ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_139.ahk ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_140.ahk ; (140_1)(GUI Object: [mnu] Addon Extra)
  
  
  
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_154.ahk ; (154_1)(GUI Object: [pum] Pum Select Background)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_155.ahk ; (155_1)(GUI Object: [pum] Pum Select Display Text)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_156.ahk ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_157.ahk ; (157_1)(GUI Object: [pum] Pum Select Settings)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_158.ahk ; (158_1)(GUI Object: [pum] Pum Shortcut)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_159.ahk ; (159_1)(GUI Object: [pum] Select Custom Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_160.ahk ; (160_1)(GUI Object: [pum] Select Application Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_161.ahk ; (161_1)(GUI Object: [pum] Delete Pum)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_165.ahk ; (165_1)(GUI Object: [pum] Backgroung Image Select)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_166.ahk ; (166_1)(GUI Object: [pum] Backgroung Color Select)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_167.ahk ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\f_168.ahk ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
  
  
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Function_Flow.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Function_Msg.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Find_Windows_Public_Folder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GetActiveBrowserURL.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GetSelected_ListNumber.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GuiControlImage_PopUpMenu.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\GuiControlImage_HotKeySelect.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Gui_Text_Width.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Cancel.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Check_Selected.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Hotkey_gui.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Ok.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Select_Key.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Text_Display_Language.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_UnSelect_Key.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Validate.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Is_Script_Running.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Display.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_KeyIsIn.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Numbers.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_SelectKey.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Shortcut.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\KeyArray_Validate.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\mnu_TextAddon_to_MenuArray.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Mouse_IsIn_Window.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Product_ID.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Close.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Run.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Reset_Vars.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Script_Close.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Select_FileFolder.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Send_Email.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Shortcut_Config.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Shortcut_Info.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\SleepTime.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Splash_Script.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\String_Reverse.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_Adjust_PopUpMenu.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_Adjust_HotKeySelect.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Text_File.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_In_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_to_String.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Unicode_String_To.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_PageIcon.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_PageIcon_Title.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_Get_URL_Address.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\url_HtmlCode_to_Text.ahk
  ; -------------------------------------------
} ; End #Include Lib Folder
; -------------------------------------------
