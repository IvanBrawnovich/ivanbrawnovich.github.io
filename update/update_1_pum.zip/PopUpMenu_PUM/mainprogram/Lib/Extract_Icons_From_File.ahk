﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Extract_Icons_From_File(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("Extract_Icons_From_File", DataArray)
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_102_3 := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
    ;
    v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
    ;
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    v_366_6 := DataArray.366.6 ; (366_6)(This Script Error [Integer])
    ;
    v_383_1 := DataArray.383.1 ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
    ;
    v_386_1 := DataArray.386.1 ; (386_1)(Extracted Application Icons [System Folder Path])
    v_386_7 := DataArray.386.7 ; (386_7)(Default Script Type Icon [Folder Path])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  if (v_366_5 == "run") ; (366_5)(Script Type)
  {
    ThisProcessPath := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
  }
  else if (v_366_5 == "rwh") ; (366_5)(Script Type)
  {
    ThisProcessPath := DataArray.305.5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
  }
  ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ThisProcessPath, ThisProcessExt, , , ThisProcess ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
  ; -------------------------------------------
  if FileExist(ThisProcessPath) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
  {
    { ; Check Directory / Create Directory
      ; -------------------------------------------
      if !FileExist(v_386_1) ; (386_1)(Extracted Application Icons [System Folder Path])
      {
        FileCreateDir, %v_386_1% ; (386_1)(Extracted Application Icons [System Folder Path])
      }
      ; -------------------------------------------
      ; (368_4)(This Application Icons Folder [Extracted])
      ; (386_1)(Extracted Application Icons [System Folder Path])
      ; -------------------------------------------
      v_368_4 := v_386_1 "\" ThisProcess ; (368_4)(This Application Icons Folder [Extracted])/(386_1)(Extracted Application Icons [System Folder Path])
      DataArray.368.4 := v_368_4 ; (368_4)(This Application Icons Folder [Extracted])
      ; -------------------------------------------
      if !FileExist(v_368_4) ; (368_4)(This Application Icons Folder [Extracted])
      {
        FileCreateDir, %v_368_4% ; (368_4)(This Application Icons Folder [Extracted])
      }
    } ; End Check Directory / Create Directory
    ; -------------------------------------------
    DataArray.64.2 := 0 ; (064_2)(Reset Icon Image: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    GuiControl, PopUpMenu:Hide, g_064 ; (064_1)(GUI Object: Reset Icon Image)
    ; -------------------------------------------
    ; (368_4)(This Application Icons Folder [Extracted])
    ; (386_1)(Extracted Application Icons [System Folder Path])
    ; -------------------------------------------
    IconNum := 0
    IconFile := v_368_4 "\" ThisProcess "_" IconNum ".ico" ; (368_4)(This Application Icons Folder [Extracted])
    Temp_Icon := IconFile
    IcoArray := []
    NoIcons_TextFile := v_368_4 "\NoIcons.txt" ; (368_4)(This Application Icons Folder [Extracted])
    ProccessPath_TextFile := v_368_4 "\ProccessPath.txt" ; (368_4)(This Application Icons Folder [Extracted])
    ; -------------------------------------------
    if FileExist(ProccessPath_TextFile) ; Check is this is a New App with same name
    {
      FileReadLINE, Check_ThisProcessPath, %ProccessPath_TextFile%, 1 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      if (Check_ThisProcessPath != ThisProcessPath) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      {
        FileDelete, %v_368_4%\*.ico ; (368_4)(This Application Icons Folder [Extracted])
        FileDelete, %NoIcons_TextFile%
        FileDelete, %ProccessPath_TextFile%
        FileAppend, %ThisProcessPath%, %ProccessPath_TextFile%, UTF-8 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      }
    }
    else
    {
      FileAppend, %ThisProcessPath%, %ProccessPath_TextFile%, UTF-8 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    }
    ; -------------------------------------------
    if FileExist(NoIcons_TextFile)
    {
      ; -------------------------------------------
      { ; Hide (No Icons in exe)
        ; -------------------------------------------
        DataArray.1.2 := 0 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Hide, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
        ; -------------------------------------------
        DataArray.2.2 := 0 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Hide, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
        ; -------------------------------------------
        DataArray.3.2 := 0 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Hide, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
        ; -------------------------------------------
        DataArray.7.2 := 0 ; (007_2)(Icon Image 4: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Hide, g_007 ; (007_1)(GUI Object: Icon Image 4)
        ; -------------------------------------------
        DataArray.106.2 := 0 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Hide, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
        ; -------------------------------------------
        DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
        ; -------------------------------------------
      } ; End Hide (No Icons in exe)
      ; -------------------------------------------
      { ; Show (No Icons in exe)
        v_108_3 := ThisProcessExt ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)
        DataArray.108.3 := v_108_3 ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)
        GuiControl, PopUpMenu:, g_108, %v_108_3% ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)/(108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
        DataArray.108.2 := 1 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Show, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
        ; -------------------------------------------
        if (v_365_2 == "de") ; (365_2)(Current User language)
        {
          v_109_3 := "Hat keine Symbole" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (de German)
        ; -------------------------------------------
        else if (v_365_2 == "en") ; (365_2)(Current User language)
        {
          v_109_3 := "Has No Icons" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (en English)
        ; -------------------------------------------
        else if (v_365_2 == "es") ; (365_2)(Current User language)
        {
          v_109_3 := "No tiene iconos" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (es Spanish)
        ; -------------------------------------------
        else if (v_365_2 == "fr") ; (365_2)(Current User language)
        {
          v_109_3 := "N'a pas d'icônes" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (fr French)
        ; -------------------------------------------
        else if (v_365_2 == "it") ; (365_2)(Current User language)
        {
          v_109_3 := "Non ha icone" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (it Italian)
        ; -------------------------------------------
        else if (v_365_2 == "pl") ; (365_2)(Current User language)
        {
          v_109_3 := "Nie ma ikon" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (pl Polish)
        ; -------------------------------------------
        else if (v_365_2 == "pt") ; (365_2)(Current User language)
        {
          v_109_3 := "Não tem ícones" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (pt Portuguese)
        ; -------------------------------------------
        else if (v_365_2 == "ru") ; (365_2)(Current User language)
        {
          v_109_3 := "Не имеет иконок" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (ru Russian)
        ; -------------------------------------------
        else if (v_365_2 == "sv") ; (365_2)(Current User language)
        {
          v_109_3 := "Har inga ikoner" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (sv Swedish)
        ; -------------------------------------------
        else if (v_365_2 == "tr") ; (365_2)(Current User language)
        {
          v_109_3 := "Simge Yok" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        } ; End (tr Turkish)
        ; -------------------------------------------
        DataArray.109.3 := v_109_3 ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
        GuiControl, PopUpMenu:, g_109, %v_109_3% ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)/(109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
        DataArray.109.2 := 1 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
        GuiControl, PopUpMenu:Show, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
        ; -------------------------------------------
        if (v_366_5 == "run") ; (366_5)(Script Type)
        {
          ThisIcon := v_386_7 "\exe.ico" ; (386_7)(Default Script Type Icon [Folder Path])
        } ; (366_5)(Script Type)
        else if (v_366_5 == "rwh") ; (366_5)(Script Type)
        {
          ThisIcon := v_386_7 "\rwh.ico" ; (386_7)(Default Script Type Icon [Folder Path])
        } ; (366_5)(Script Type)
        ; -------------------------------------------
        if (v_102_3 == "") ; (102_3)(Main Display Icon: Image Path)
        {
          ; (No Icons in exe) 
          DataArray := f_102(ThisIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
        }
        ; -------------------------------------------
        DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      } ; End Show (No Icons in exe)
      ; -------------------------------------------
    } ; End FileExist(NoIcons_TextFile)
    else
    {
      { ; [MAKE] IcoArray
        ; -------------------------------------------
        if FileExist(IconFile) ; IconFile Exist (NO Need to Extract Icons)
        {
          Loop Files, %v_368_4%\*.ico ; (368_4)(This Application Icons Folder [Extracted])
          {
            IcoArray.Push(A_LoopFileFullPath)
          } ; (368_4)(Extracted Application Icons)
        } ; End FileExist(IconFile)
        ; -------------------------------------------
        else ; IconFile NOT Exist (Must Extract Icons)
        {
          ; -------------------------------------------
          ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
          ; (305_4)([File Name] [File Ext] [File Path])
          RunThis := v_383_1 " ""-res=" ThisProcessPath "`," IconNum """ ""-icon=" IconFile """ -formats=32`,48`,256 -pngc" ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          Splash_Script("505", 0) ; 
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
          DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
          DataArray := GuiControlImage_PopUpMenu("063", 0, 0, DataArray) ; (063_1)(GUI Object: Select Icon Image)
          ; -------------------------------------------
          RunWait, %RunThis%, , Hide
          ; -------------------------------------------
          if FileExist(IconFile)
          {
            IcoArray.Push(IconFile)
          } ; End FileExist(IconFile)
          ; -------------------------------------------
          End_Time := A_TickCount + 3000
          While FileExist(IconFile)
          {
            ; -------------------------------------------
            if (A_TickCount > End_Time)
            {
              break
            }
            ; -------------------------------------------
            IconNum := IconNum + 1
            IconFile := v_368_4 "\" ThisProcess "_" IconNum ".ico" ; (368_4)(This Application Icons Folder [Extracted])
            ; -------------------------------------------
            ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
            ; (305_4)([File Name] [File Ext] [File Path])
            RunThis := v_383_1 " ""-res=" ThisProcessPath "`," IconNum """ ""-icon=" IconFile """ -formats=32`,48`,256 -pngc" ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
            RunWait, %RunThis%, , Hide
            ; -------------------------------------------
            if FileExist(IconFile)
            {
              IcoArray.Push(IconFile)
            } ; End FileExist(IconFile)
            ; -------------------------------------------
          } ; End While FileExist(IconFile)
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          Splash_Script("Off", 0)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("005", 1, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
          DataArray := GuiControlImage_PopUpMenu("006", 1, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
          DataArray := GuiControlImage_PopUpMenu("063", 1, 2, DataArray) ; (063_1)(GUI Object: Select Icon Image)
          ; -------------------------------------------
        } ; End IconFile NOT Exist
        ; -------------------------------------------
      } ; End [MAKE] IcoArray
      ; -------------------------------------------
      if IcoArray[1]
      {
        ThisIco := IcoArray[1]
      }
      ; -------------------------------------------
      if (v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        if FileExist(ThisIco) ; 1 or more Icon in IcoArray
        {
          v_103_3 := ThisIco ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
        } ; End FileExist(ThisIco)
        ; -------------------------------------------
        else
        {
          ; -------------------------------------------
          ; There Was a Error 
          ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
          ; Was Not Found
          ; -------------------------------------------
          v_103_3 := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\img\Error.png" ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
        {
          DataArray.103.3 := v_103_3 ; (103_3)([rwh][url] Opening Application Image: Application Full Path)
          DataArray.103.2 := 1 ; (103_2)([rwh][url] Opening Application Image: Select [0]Hide/[1]Nor)
          GuiControl, PopUpMenu:, g_103, %v_103_3% ; (103_3)([rwh][url] Opening Application Image: Application Full Path)/(103_1)(GUI Object: [rwh][url] Opening Application Image)
          GuiControl, PopUpMenu:MoveDraw, g_103, +w30 +h30 ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
          GuiControl, PopUpMenu:Show, g_103 ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
        }
        ; -------------------------------------------
      } ; End (366_5)(Script Type) (rwh)
      ; -------------------------------------------
      if FileExist(ThisIco) ; 1 or more Icon in IcoArray
      {
        ; -------------------------------------------
        if FileExist(NoIcons_TextFile)
        {
          FileDelete, %NoIcons_TextFile%
        }
        ; -------------------------------------------  
        if v_102_3 ; (102_3)(Main Display Icon: Image Path)
        {
          ; -------------------------------------------
          ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
          SplitPath, v_102_3, Check_v_102_3 ; (102_3)(Main Display Icon: Image Path)
          ; -------------------------------------------
          if (Check_v_102_3 == "PopUpMenu.png") ; (102_3)(Main Display Icon: Image Path)
          {
            v_102_3 := "" ; (102_3)(Main Display Icon: Image Path)
          }
        }
        ; -------------------------------------------
        if (v_102_3 == "") ; (102_3)(Main Display Icon: Image Path)
        {
          DataArray := f_102(ThisIco, DataArray) ; (102_1)(GUI Object: Main Display Icon)
        }
        else
        {
          DataArray := f_102(v_102_3, DataArray) ; (102_3)(Main Display Icon: Image Path)/(102_1)(GUI Object: Main Display Icon)
        }
        ; -------------------------------------------
        IcoArrayLen := IcoArray.MaxIndex()
        ; -------------------------------------------
        if (IcoArrayLen == 1)
        {
          ; -------------------------------------------
          if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            { ; Hide (IcoArrayLen == 1)
              ; -------------------------------------------
              DataArray.108.2 := 0 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
              DataArray.109.2 := 0 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
              ; -------------------------------------------
              DataArray.2.2 := 0 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              DataArray.3.2 := 0 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              DataArray.7.2 := 0 ; (007_2)(Icon Image 4: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_007 ; (007_1)(GUI Object: Icon Image 4)
              ; -------------------------------------------
              DataArray.106.2 := 0 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
              ; -------------------------------------------
            } ; End Hide (IcoArrayLen == 1)
            ; -------------------------------------------
            { ; Show (IcoArrayLen == 1)
              ; -------------------------------------------
              v_001_3 := IcoArray[1] ; (001_3)([run][rwh] First App Icon: Image Path)
              DataArray.1.3 := v_001_3 ; (001_3)([run][rwh] First App Icon: Image Path)
              DataArray.1.2 := 1 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:, g_001, %v_001_3% ; (001_3)([run][rwh] First App Icon: Image Path)/(001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:Show, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              ; -------------------------------------------
            } ; End Show (IcoArrayLen == 1)
          } ; End (366_6)(This Script Error [Integer])
          ; -------------------------------------------
        } ; End if (IcoArrayLen == 1)
        ; -------------------------------------------
        else if (IcoArrayLen == 2)
        {
          ; -------------------------------------------
          if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            { ; Hide (IcoArrayLen == 2)
              ; -------------------------------------------
              DataArray.108.2 := 0 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
              DataArray.109.2 := 0 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
              DataArray.3.2 := 0 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              DataArray.7.2 := 0 ; (007_2)(Icon Image 4: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_007 ; (007_1)(GUI Object: Icon Image 4)
              DataArray.106.2 := 0 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
              ; -------------------------------------------
            } ; End Hide (IcoArrayLen == 2)
            ; -------------------------------------------
            { ; Show (IcoArrayLen == 2)
              ; -------------------------------------------
              v_001_3 := IcoArray[1] ; (001_3)([run][rwh] First App Icon: Image Path)
              DataArray.1.2 := 1 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
              DataArray.1.3 := v_001_3 ; (001_3)([run][rwh] First App Icon: Image Path)
              GuiControl, PopUpMenu:, g_001, %v_001_3% ; (001_3)([run][rwh] First App Icon: Image Path)/(001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:Show, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              ; -------------------------------------------
              v_002_3 := IcoArray[2] ; (002_3)([run][rwh] Second App Icon: Image Path)
              DataArray.2.2 := 1 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
              DataArray.2.3 := v_002_3 ; (002_3)([run][rwh] Second App Icon: Image Path)
              GuiControl, PopUpMenu:, g_002, %v_002_3% ; (002_3)([run][rwh] Second App Icon: Image Path)/(002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_002, +w40 +h40 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:Show, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              ; -------------------------------------------
            } ; End Show (IcoArrayLen == 2)
          } ; End (366_6)(This Script Error [Integer])
          ; -------------------------------------------
        } ; End else if (IcoArrayLen == 2)
        ; -------------------------------------------
        else if (IcoArrayLen == 3)
        {
          ; -------------------------------------------
          if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            { ; Hide (IcoArrayLen == 3)
              ; -------------------------------------------
              DataArray.108.2 := 0 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
              DataArray.109.2 := 0 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
              DataArray.7.2 := 0 ; (007_2)(Icon Image 4: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_007 ; (007_1)(GUI Object: Icon Image 4)
              DataArray.106.2 := 0 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
              ; -------------------------------------------
            } ; End Hide (IcoArrayLen == 3)
            ; -------------------------------------------
            { ; Show (IcoArrayLen == 3)
              ; -------------------------------------------
              v_001_3 := IcoArray[1] ; (001_3)([run][rwh] First App Icon: Image Path)
              DataArray.1.2 := 1 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
              DataArray.1.3 := v_001_3 ; (001_3)([run][rwh] First App Icon: Image Path)
              GuiControl, PopUpMenu:, g_001, %v_001_3% ; (001_3)([run][rwh] First App Icon: Image Path)/(001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:Show, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              ; -------------------------------------------
              v_002_3 := IcoArray[2] ; (002_3)([run][rwh] Second App Icon: Image Path)
              DataArray.2.2 := 1 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
              DataArray.2.3 := v_002_3 ; (002_3)([run][rwh] Second App Icon: Image Path)
              GuiControl, PopUpMenu:, g_002, %v_002_3% ; (002_3)([run][rwh] Second App Icon: Image Path)/(002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_002, +w40 +h40 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:Show, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              ; -------------------------------------------            
              v_003_3 := IcoArray[3] ; (003_3)([run][rwh] Third App Icon: Image Path)
              DataArray.3.2 := 1 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
              DataArray.3.3 := v_003_3 ; (003_3)([run][rwh] Third App Icon: Image Path)
              GuiControl, PopUpMenu:, g_003, %v_003_3% ; (003_3)([run][rwh] Third App Icon: Image Path)/(003_1)(GUI Object: [run][rwh] Third App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_003, +w40 +h40 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              GuiControl, PopUpMenu:Show, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              ; -------------------------------------------
            } ; End Show (IcoArrayLen == 3)
            ; -------------------------------------------
          } ; End (366_6)(This Script Error [Integer])
          ; -------------------------------------------
        } ; End else if (IcoArrayLen == 3)
        ; -------------------------------------------
        else if (IcoArrayLen > 3)
        {
          if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            { ; Hide (IcoArrayLen > 3)
              ; -------------------------------------------
              DataArray.108.2 := 0 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
              DataArray.109.2 := 0 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Hide, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
              ; -------------------------------------------
            } ; End Hide (IcoArrayLen > 3)
            ; -------------------------------------------
            { ; Show (IcoArrayLen > 3)
              ; -------------------------------------------
              v_001_3 := IcoArray[1] ; (001_3)([run][rwh] First App Icon: Image Path)
              DataArray.1.2 := 1 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
              DataArray.1.3 := v_001_3 ; (001_3)([run][rwh] First App Icon: Image Path)
              GuiControl, PopUpMenu:, g_001, %v_001_3% ; (001_3)([run][rwh] First App Icon: Image Path)/(001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_001, +w40 +h40 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              GuiControl, PopUpMenu:Show, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
              ; -------------------------------------------
              v_002_3 := IcoArray[2] ; (002_3)([run][rwh] Second App Icon: Image Path)
              DataArray.2.2 := 1 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
              DataArray.2.3 := v_002_3 ; (002_3)([run][rwh] Second App Icon: Image Path)
              GuiControl, PopUpMenu:, g_002, %v_002_3% ; (002_3)([run][rwh] Second App Icon: Image Path)/(002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_002, +w40 +h40 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              GuiControl, PopUpMenu:Show, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
              ; -------------------------------------------
              v_003_3 := IcoArray[3] ; (003_3)([run][rwh] Third App Icon: Image Path)
              DataArray.3.2 := 1 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
              DataArray.3.3 := v_003_3 ; (003_3)([run][rwh] Third App Icon: Image Path)
              GuiControl, PopUpMenu:, g_003, %v_003_3% ; (003_3)([run][rwh] Third App Icon: Image Path)/(003_1)(GUI Object: [run][rwh] Third App Icon)
              GuiControl, PopUpMenu:MoveDraw, g_003, +w40 +h40 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              GuiControl, PopUpMenu:Show, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
              ; -------------------------------------------
              DataArray := GuiControlImage_PopUpMenu("007", 1, 0, DataArray) ; (007_1)(GUI Object: Icon Image 4)
              ; -------------------------------------------
              v_106_3 := IcoArrayLen ; (106_3)([rwh][run] Extra App Icons: Image Path)
              DataArray.106.3 := v_106_3 ; (106_3)([rwh][run] Extra App Icons: Image Path)
              GuiControl, PopUpMenu:, g_106, %v_106_3% ; (106_3)([rwh][run] Extra App Icons: Image Path)/(106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
              DataArray.106.2 := 1 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
              GuiControl, PopUpMenu:Show, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
              ; -------------------------------------------
            } ; End Show (IcoArrayLen > 3)
            ; -------------------------------------------
          } ; End (366_6)(This Script Error [Integer])
          ; -------------------------------------------
        } ; End else if (IcoArrayLen > 3)
        ; -------------------------------------------
      } ; End if FileExist(ThisIco)
      ; -------------------------------------------
      else ; (No Icons in exe) in IcoArray Copy Default
      {
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 2) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          FileAppend, NoIcons, %NoIcons_TextFile%, UTF-8
          ; -------------------------------------------
          { ; Hide (No Icons in exe)
            ; -------------------------------------------
            DataArray.1.2 := 0 ; (001_2)([run][rwh] First App Icon: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Hide, g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
            ; -------------------------------------------
            DataArray.2.2 := 0 ; (002_2)([run][rwh] Second App Icon: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Hide, g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
            ; -------------------------------------------
            DataArray.3.2 := 0 ; (003_2)([run][rwh] Third App Icon: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Hide, g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
            ; -------------------------------------------
            DataArray.7.2 := 0 ; (007_2)(Icon Image 4: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Hide, g_007 ; (007_1)(GUI Object: Icon Image 4)
            ; -------------------------------------------
            DataArray.106.2 := 0 ; (106_2)([rwh][run] Extra App Icons: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Hide, g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
            ; -------------------------------------------
            DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
            ; -------------------------------------------
          } ; End Hide (No Icons in exe)
          ; -------------------------------------------
          { ; Show (No Icons in exe)
            v_108_3 := ThisProcessExt ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)
            DataArray.108.3 := v_108_3 ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)
            GuiControl, PopUpMenu:, g_108, %v_108_3% ; (108_3)([rwh][run] <Displayed Text> Icon Warning Top: Value)/(108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
            DataArray.108.2 := 1 ; (108_2)([rwh][run] <Displayed Text> Icon Warning Top: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Show, g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
            ; -------------------------------------------
            if (v_365_2 == "de") ; (365_2)(Current User language)
            {
              v_109_3 := "Hat keine Symbole" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (de German)
            ; -------------------------------------------
            else if (v_365_2 == "en") ; (365_2)(Current User language)
            {
              v_109_3 := "Has No Icons" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (en English)
            ; -------------------------------------------
            else if (v_365_2 == "es") ; (365_2)(Current User language)
            {
              v_109_3 := "No tiene iconos" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (es Spanish)
            ; -------------------------------------------
            else if (v_365_2 == "fr") ; (365_2)(Current User language)
            {
              v_109_3 := "N'a pas d'icônes" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (fr French)
            ; -------------------------------------------
            else if (v_365_2 == "it") ; (365_2)(Current User language)
            {
              v_109_3 := "Non ha icone" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (it Italian)
            ; -------------------------------------------
            else if (v_365_2 == "pl") ; (365_2)(Current User language)
            {
              v_109_3 := "Nie ma ikon" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (pl Polish)
            ; -------------------------------------------
            else if (v_365_2 == "pt") ; (365_2)(Current User language)
            {
              v_109_3 := "Não tem ícones" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (pt Portuguese)
            ; -------------------------------------------
            else if (v_365_2 == "ru") ; (365_2)(Current User language)
            {
              v_109_3 := "Не имеет иконок" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (ru Russian)
            ; -------------------------------------------
            else if (v_365_2 == "sv") ; (365_2)(Current User language)
            {
              v_109_3 := "Har inga ikoner" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (sv Swedish)
            ; -------------------------------------------
            else if (v_365_2 == "tr") ; (365_2)(Current User language)
            {
              v_109_3 := "Simge Yok" ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            } ; End (tr Turkish)
            ; -------------------------------------------
            DataArray.109.3 := v_109_3 ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)
            GuiControl, PopUpMenu:, g_109, %v_109_3% ; (109_3)([rwh][run] <Displayed Text> Icon Warning Bottom: Value)/(109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
            DataArray.109.2 := 1 ; (109_2)([rwh][run] <Displayed Text> Icon Warning Bottom: Select [0]Hide/[1]Nor)
            GuiControl, PopUpMenu:Show, g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
            ; -------------------------------------------
            if (v_366_5 == "run") ; (366_5)(Script Type)
            {
              ThisIcon := v_386_7 "\exe.ico" ; (386_7)(Default Script Type Icon [Folder Path])
            } ; (366_5)(Script Type)
            else if (v_366_5 == "rwh") ; (366_5)(Script Type)
            {
              ThisIcon := v_386_7 "\rwh.ico" ; (386_7)(Default Script Type Icon [Folder Path])
            } ; (366_5)(Script Type)
            ; -------------------------------------------
            if (v_102_3 == "") ; (102_3)(Main Display Icon: Image Path)
            {
              ; (No Icons in exe) 
              DataArray := f_102(ThisIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
            }
            ; -------------------------------------------
            DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
            GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
          } ; End Show (No Icons in exe)
          ; -------------------------------------------
        } ; End (366_6)(This Script Error [Integer])
        ; -------------------------------------------
      } ; End (No Icons in exe) in IcoArray Copy Default
      ; -------------------------------------------
    }
  } ; (305_4)(File Path with Name & Extension)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
