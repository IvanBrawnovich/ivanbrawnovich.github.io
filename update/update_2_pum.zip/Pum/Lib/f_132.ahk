﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_132(DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_132", DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
  ; -------------------------------------------
  if (Connect_Check(flag=0x40) == 1)
  {
    Browsers := "ApplicationFrameWindow,Chrome_WidgetWin_0,Chrome_WidgetWin_1,Maxthon3Cls_MainFrm,MozillaWindowClass,Slimjet_WidgetWin_1,IEFrame,OperaWindowClass"
    v_367_4 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
    ; -------------------------------------------
    GuiControlGet, v_131_3, PopUpMenu:, g_131 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
    URL_CurrentCk := v_131_3 ; (131_3)(<Edit Feild> [url] URL Address: Value)
    URL_CurrentCk := StrReplace(URL_CurrentCk, "http://", "")
    URL_CurrentCk := StrReplace(URL_CurrentCk, "https://", "")
    URL_CurrentCk := StrReplace(URL_CurrentCk, "ftp://", "")
    URL_CurrentCk := StrReplace(URL_CurrentCk, A_Space, "")
    CkStrLen := StrLen(URL_CurrentCk)
    ; -------------------------------------------
    if (CkStrLen > 0) ; (131_3)(<Edit Feild> [url] URL Address: Value) [Is Not Empty]
    {
      DataArray.307.2 := v_131_3 ; (307_2)([url] Current URL)/(131_3)(<Edit Feild> [url] URL Address: Value)
      v_307_2 := v_131_3 ; (307_2)([url] Current URL)/(131_3)(<Edit Feild> [url] URL Address: Value)
    }
    else if (DataArray.307.2 != "") ; (307_2)([url] Current URL)
    {
      URL_CurrentCk := DataArray.307.2 ; (307_2)([url] Current URL)
      URL_CurrentCk := StrReplace(URL_CurrentCk, "http://", "")
      URL_CurrentCk := StrReplace(URL_CurrentCk, "https://", "")
      URL_CurrentCk := StrReplace(URL_CurrentCk, "ftp://", "")
      URL_CurrentCk := StrReplace(URL_CurrentCk, A_Space, "")
      CkStrLen := StrLen(URL_CurrentCk)
      if (CkStrLen > 0) ; (307_2)([url] Current URL) [Is Not Empty]
      {
        v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
      }
    }
    else if v_367_4 in % Browsers ; (367_4)([Line 3] Active Process Class)
    {
      DataArray := url_Get_URL_Address(DataArray)
      v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
    }
    ; -------------------------------------------
    if (v_307_2 != "") ; (307_2)([url] Current URL)
    {
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("132", 2, 1, DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
      ; -------------------------------------------
      IsHttp := 0
      IsHttps := 0
      IsFtps := 0
      ; -------------------------------------------
      if (Substr(v_307_2, 1, 7) == "http://") ; (307_2)([url] Current URL)
      {
        IsHttp := 1
      }
      else if (Substr(v_307_2, 1, 8) == "https://") ; (307_2)([url] Current URL)
      {
        IsHttps := 1
      }
      else if (Substr(v_307_2, 1, 6) == "ftp://") ; (307_2)([url] Current URL)
      {
        IsFtps := 1
      }
      ; -------------------------------------------
      if (IsHttp == 0 && IsHttps == 0 && IsFtps == 0)
      {
        ; -------------------------------------------
        v_307_2 := "http://" v_307_2 ; (307_2)([url] Current URL)
        
        ; -------------------------------------------
      }
      ; -------------------------------------------
      v_131_3 := v_307_2 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(307_2)([url] Current URL)
      GuiControl, PopUpMenu:, g_131, %v_131_3% ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
      DataArray.307.2 := v_307_2 ; (307_2)([url] Current URL)
      DataArray.307.8 := v_307_2 ; (307_8)([url] Previous URL)/(307_2)([url] Current URL)
      ; -------------------------------------------
      DataArray.102.3 := DataArray.369.10 ; (102_3)(Main Display Icon: Image Path)/(369_10)(PopUpMenu.png Icon Tray Menu)
      DataArray := url_Get_PageIcon_Title(DataArray)
      ; -------------------------------------------
      ; (122_3)(<Edit Feild> Status Bar Description: Value)
      ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("132", 1, 1, DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
      ; -------------------------------------------
    } ; End (307_2)([url] Current URL) [Is Not Empty]
    ; -------------------------------------------
  } ; End if (Connect_Check(flag=0x40) == 1)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
