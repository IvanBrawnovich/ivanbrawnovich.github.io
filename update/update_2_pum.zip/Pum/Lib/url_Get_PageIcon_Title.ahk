﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
url_Get_PageIcon_Title(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("url_Get_PageIcon_Title", DataArray)
  ; -------------------------------------------
  StartTime := A_TickCount
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; (504_1)(Splash Info Script File: Getting URL Data)
  Splash_Script("504", 0) ; Img_Num ("Off"/Number), Sleep_Time > Nothing
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
  ; -------------------------------------------
  ; Downloads ThisSource
  ; Used to get Title and Icon
  ; -------------------------------------------
  SavePath := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\"
  ThisSource := SavePath "SourceFile.txt"
  ; -------------------------------------------
  if FileExist(ThisSource)
  {
    FileDelete, %ThisSource%
  } ; End FileExist(ThisSource)
  ; -------------------------------------------
  v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
  UrlDownloadToFile, %v_307_2%, %ThisSource% ; (307_2)([url] Current URL)
  ; -------------------------------------------
  if FileExist(ThisSource)
  {
    ; -------------------------------------------
    DataArray.307.3 := 1 ; (307_3)([url] Source URL Downloaded Ok [0/1])
    ; -------------------------------------------
    HeadStartFound := 0
    HeadEndFound := 0
    LineNum := 0
    StopLoop := 0
    ThisIcon := ""
    ThisTitle := ""
    DefaultIcon := 0
    ; -------------------------------------------
    ThisFile := FileOpen(ThisSource, "r", "UTF-8")
    ; -------------------------------------------
    Len_Array := Array_From_File(ThisSource) ; > Array
    LoopNum := Len_Array.MaxIndex()
    ; -------------------------------------------
    Loop %LoopNum%
    {
      ; -------------------------------------------
      LineNum := LineNum + 1
      ThisLine := ThisFile.ReadLine()
      ThisLen := StrLen(ThisLine)
      ; -------------------------------------------
      if (ThisLen > 0) ; Not a Empty Line
      {
        ; -------------------------------------------
        StopLoop := 0
        if (HeadStartFound == 0)
        {
          HeadStartPos := InStr(ThisLine, "<head") ; <head
          if (HeadStartPos > 0)
          {
            HeadStartFound := 1
            HtmlHead := ThisLine
          } ; End (HeadStartPos > 0)
          HeadEndPos := InStr(ThisLine, "</head") ; </head
          if (HeadEndPos > 0)
          {
            HeadEndFound := 1
            break
          } ; End (HeadEndPos > 0)
        } ; End (HeadStartFound == 0)
        else
        {
          HeadEndPos := InStr(ThisLine, "</head") ; </head
          if (HeadEndPos > 0)
          {
            HeadEndFound := 1
            HtmlHead := HtmlHead ThisLine
            break
          } ; End (HeadEndPos > 0)
          else
          {
            HtmlHead := HtmlHead ThisLine
          } ; End else
        } ; End else
        ; -------------------------------------------
      } ; End else
    } ; End Loop to get <head></head> (BREAK LOOP IF) (100 Empty lines are found) -OR- (LineNum > 1000) -OR- (HeadEndPos > 0)
    ; -------------------------------------------
    ThisFile.Close()
    ; -------------------------------------------
    TitleEndPos := InStr(HtmlHead, "</title") ; <head
    ; -------------------------------------------
    if (TitleEndPos > 0) ; Title
    {
      ; -------------------------------------------
      TitleStartPos := TitleEndPos - 1 ; TitlePos is End
      FindStart := SubStr(HtmlHead, TitleStartPos, 1)
      While (FindStart != ">")
      {
        TitleStartPos := TitleStartPos - 1
        FindStart := SubStr(HtmlHead, TitleStartPos, 1)
      } ; End (FindStart != ">")
      TitleStartPos := TitleStartPos + 1
      ; -------------------------------------------
      Title_Len := TitleEndPos - TitleStartPos
      Title_Len := Title_Len
      ThisTitle := SubStr(HtmlHead, TitleStartPos, Title_Len)
      ThisTitle := StrReplace(ThisTitle, A_Tab, "")
      ; -------------------------------------------
      { ; Search & Replace Html Code (387_2) in ThisTitle
        ; -------------------------------------------
        FoundPos2 := InStr(ThisTitle, ";")
        StopWhile := 0
        While (FoundPos2 > 0)
        {
          ; -------------------------------------------
          if (StopWhile == 100) ; break if have searched 100 times (This to prevent Infinite loop, for unknown html code)
          {
            break
          } ; End (StopWhile == 100)
          else
          {
            StopWhile := StopWhile + 1
          } ; End else
          ThisValue := ""
          ; -------------------------------------------
          v_387_2 := DataArray.387.2 ; (387_2)(Html Array)
          ; -------------------------------------------
          for Index, ThisItem in v_387_2 ; (387_2)(Html Array)
          {
            ThisCode := ThisItem.1
            FoundPos3 := InStr(ThisTitle, ThisCode, true)
            ; -------------------------------------------
            if (FoundPos3 > 0)
            {
              ThisValue := ThisItem.2
              ThisTitle := StrReplace(ThisTitle, ThisCode, ThisValue)
              break ; Once Finding a Matching Code Break Out of the Loop
            } ; End (FoundPos3 > 0)
            ; -------------------------------------------
          } ; (387_2)(Html Array)
          ; -------------------------------------------
          FoundPos2 := InStr(ThisTitle, ";") ; Get Next Code in Title
          ; -------------------------------------------
        } ; End While (FoundPos2 > 0)
        ; -------------------------------------------
      } ; End Search & Replace Html Code (387_2) in ThisTitle
      ; -------------------------------------------
    } ; End (TitleEndPos > 0) ; Title
    ; -------------------------------------------
    IconStartPos := InStr(HtmlHead, "rel=""shortcut icon""") ; <head
    ; -------------------------------------------
    if (IconStartPos > 0) ; Icon (rel="shortcut icon")
    {
      ; -------------------------------------------
      IconStartPos := IconStartPos - 1
      ; -------------------------------------------
      FindStart := SubStr(HtmlHead, IconStartPos, 1)
      While (FindStart != "<")
      {
        IconStartPos := IconStartPos - 1
        FindStart := SubStr(HtmlHead, IconStartPos, 1)
      } ; End (FindStart != "<")
      ; -------------------------------------------
      Icon_End := IconStartPos + 1
      FindEnd := SubStr(HtmlHead, Icon_End, 1)
      While (FindEnd != ">")
      {
        Icon_End := Icon_End + 1
        FindEnd := SubStr(HtmlHead, Icon_End, 1)
      } ; End (FindEnd != ">")
      Icon_Len := Icon_End - IconStartPos
      Icon_Len := Icon_Len + 1
      FoundIconLine := SubStr(HtmlHead, IconStartPos, Icon_Len)
      ; -------------------------------------------
      Href_Pos := InStr(FoundIconLine, "href=")
      ThisIcon := SubStr(FoundIconLine, Href_Pos)
      Href_Start := InStr(ThisIcon, """")
      Href_Start := Href_Start + 1
      ThisIcon := SubStr(ThisIcon, Href_Start)
      Href_End := InStr(ThisIcon, """")
      ThisIcon := SubStr(ThisIcon, 1, Href_End - 1)
      ; -------------------------------------------
      Icon_End_ico := InStr(ThisIcon, ".ico")
      if (Icon_End_ico > 0)
      {
        ThisIcon := Substr(ThisIcon, 1, Icon_End_ico + 3)
      } ; End (Icon_End_ico > 0)
      Icon_End_png := InStr(ThisIcon, ".png")
      if (Icon_End_png > 0)
      {
        ThisIcon := Substr(ThisIcon, 1, Icon_End_png + 3)
      } ; End (Icon_End_png > 0)
      Icon_End_jpg := InStr(ThisIcon, ".jpg")
      if (Icon_End_jpg > 0)
      {
        ThisIcon := Substr(ThisIcon, 1, Icon_End_jpg + 3)
      } ; End (Icon_End_jpg > 0)
      Ck_Icon := InStr(ThisIcon, "//")
      if (Ck_Icon > 0) ; // Is In ThisIcon
      {
        Icon_Absolute := 1
        Ck_Icon := InStr(ThisIcon, "http")
        if (Ck_Icon == 0) ; http NOT in ThisIcon
        {
          if (Substr(ThisIcon, 1, 3) == "://")
          {
            ThisIcon := StrReplace(ThisIcon, "://", "http://")
          } ; End (Substr(ThisIcon, 1, 3) == "://")
          else if (Substr(ThisIcon, 1, 2) == "//")
          {
            ThisIcon := StrReplace(ThisIcon, "//", "http://")
          } ; End (Substr(ThisIcon, 1, 2) == "//")
        } ; End (Ck_Icon == 0) ; http NOT in ThisIcon
      } ; End (Ck_Icon > 0) ; // Is In ThisIcon
      else if (Ck_Icon == 0) ; // NOT in ThisIcon
      {
        Icon_Absolute := 0
      } ; End else if (Ck_Icon == 0) ; // NOT in ThisIcon
    } ; End (IconStartPos > 0) ; Icon
    ; ------------------------------------------
    ; ThisIcon is a URL Address
    if (ThisIcon == "") ; Icon Not (rel="shortcut icon") so check (rel="icon")
    {
      ; -------------------------------------------
      IconStartPos := InStr(HtmlHead, "rel=""icon""") ; <head
      ; -------------------------------------------
      if (IconStartPos > 0) ; Icon (rel="icon")
      {
        ; -------------------------------------------
        IconStartPos := IconStartPos - 1
        ; -------------------------------------------
        FindStart := SubStr(HtmlHead, IconStartPos, 1)
        While (FindStart != "<")
        {
          IconStartPos := IconStartPos - 1
          FindStart := SubStr(HtmlHead, IconStartPos, 1)
        } ; End (FindStart != "<")
        ; -------------------------------------------
        Icon_End := IconStartPos + 1
        FindEnd := SubStr(HtmlHead, Icon_End, 1)
        While (FindEnd != ">")
        {
          Icon_End := Icon_End + 1
          FindEnd := SubStr(HtmlHead, Icon_End, 1)
        } ; End (FindEnd != ">")
        Icon_Len := Icon_End - IconStartPos
        Icon_Len := Icon_Len + 1
        FoundIconLine := SubStr(HtmlHead, IconStartPos, Icon_Len)
        ; -------------------------------------------
        Href_Pos := InStr(FoundIconLine, "href=")
        ThisIcon := SubStr(FoundIconLine, Href_Pos)
        Href_Start := InStr(ThisIcon, """")
        Href_Start := Href_Start + 1
        ThisIcon := SubStr(ThisIcon, Href_Start)
        Href_End := InStr(ThisIcon, """")
        ThisIcon := SubStr(ThisIcon, 1, Href_End - 1)
        ; -------------------------------------------
        Icon_End_ico := InStr(ThisIcon, ".ico")
        if (Icon_End_ico > 0)
        {
          ThisIcon := Substr(ThisIcon, 1, Icon_End_ico + 3)
        } ; End (Icon_End_ico > 0)
        Icon_End_png := InStr(ThisIcon, ".png")
        if (Icon_End_png > 0)
        {
          ThisIcon := Substr(ThisIcon, 1, Icon_End_png + 3)
        } ; End (Icon_End_png > 0)
        Icon_End_jpg := InStr(ThisIcon, ".jpg")
        if (Icon_End_jpg > 0)
        {
          ThisIcon := Substr(ThisIcon, 1, Icon_End_jpg + 3)
        } ; End (Icon_End_jpg > 0)
        Ck_Icon := InStr(ThisIcon, "//")
        if (Ck_Icon > 0) ; // Is In ThisIcon
        {
          Icon_Absolute := 1
          Ck_Icon := InStr(ThisIcon, "http")
          if (Ck_Icon == 0) ; http NOT in ThisIcon
          {
            if (Substr(ThisIcon, 1, 3) == "://")
            {
              ThisIcon := StrReplace(ThisIcon, "://", "http://")
            } ; End (Substr(ThisIcon, 1, 3) == "://")
            else if (Substr(ThisIcon, 1, 2) == "//")
            {
              ThisIcon := StrReplace(ThisIcon, "//", "http://")
            } ; End (Substr(ThisIcon, 1, 2) == "//")
          } ; End (Ck_Icon == 0) ; http NOT in ThisIcon
        } ; End (Ck_Icon > 0) ; // Is In ThisIcon
        else if (Ck_Icon == 0) ; // NOT in ThisIcon
        {
          Icon_Absolute := 0
        } ; End else if (Ck_Icon == 0) ; // NOT in ThisIcon
      ; -------------------------------------------
      } ; End (IconStartPos > 0) ; Icon
      ; -------------------------------------------
    } ; End (ThisIcon == "")
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      Temp_Icon := SavePath "Temp_Icon.ico"
      UrlDownloadToFile, %ThisIcon%, %Temp_Icon% ; (307_2)([url] Current URL)
      ; -------------------------------------------
      Check_Icon := Array_From_File(Temp_Icon) ; > Array
      for Index, This_Check in Check_Icon
      {
        if (InStr(This_Check, "404") > 0)
        {
          FileDelete, %Temp_Icon%
          Temp_Icon := ""
          ThisIcon := ""
          break
        }
      }
    }
    if (ThisIcon == "")
    {
      ; -------------------------------------------
      Url_Len := StrLen(v_307_2) ; (307_2)([url] Current URL)
      Url_Pos2 := InStr(v_307_2, "/", , , 3) ; (307_2)([url] Current URL)
      if (Url_Pos2 > 0)
      {
        URL_Root := SubStr(v_307_2, 1, Url_Pos2) ; (307_2)([url] Current URL)
      }
      else if (Url_Pos2 == 0)
      {
        URL_Root := v_307_2 "/" ; (307_2)([url] Current URL)
      }
      ; ------------------------------------------
      Temp_Icon := SavePath "Temp_Icon.ico"
      Url_Icon := URL_Root "favicon.ico"
      UrlDownloadToFile, %Url_Icon%, %Temp_Icon%
    }
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      if (Icon_Absolute == 0 or Icon_Absolute == 1)
      {
        ; -------------------------------------------
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, ThisIcon , S_FileNameExt, S_Folder, S_Ext, S_FileName, S_DriveLetter
        ThisIconExt := S_Ext
        Temp_Icon := SavePath "Temp_Icon." ThisIconExt
        ; -------------------------------------------
        if (Icon_Absolute == 1)
        {
          Url_Icon := ThisIcon
        } ; End (Icon_Absolute == 1)
        ; -------------------------------------------
        else if (Icon_Absolute == 0)
        {
          ; -------------------------------------------
          Url_Len := StrLen(v_307_2) ; (307_2)([url] Current URL)
          Url_Pos2 := InStr(v_307_2, "/", , , 3) ; (307_2)([url] Current URL)
          ; -------------------------------------------
          if (Url_Pos2 > 0)
          {
            URL_Root := SubStr(v_307_2, 1, Url_Pos2) ; (307_2)([url] Current URL)
          }
          ; -------------------------------------------
          else if (Url_Pos2 == 0)
          {
            URL_Root := v_307_2 "/" ; (307_2)([url] Current URL)
          }
          ; -------------------------------------------
          CkThisIcon := SubStr(ThisIcon, 1, 1)
          ; -------------------------------------------
          if (CkThisIcon == "/")
          {
            ThisIcon := SubStr(ThisIcon, 2)
          } ; End if (CkThisIcon == "/")
          ; -------------------------------------------
          Url_Icon := URL_Root ThisIcon
          ; -------------------------------------------
        } ; End else if (Icon_Absolute == 0)
        ; -------------------------------------------
        UrlDownloadToFile, %Url_Icon%, %Temp_Icon%
        ; -------------------------------------------
      } ; End if (Icon_Absolute == 0 or Icon_Absolute == 1)
      ; -------------------------------------------
    } ; End else
    ; -------------------------------------------
    if FileExist(Temp_Icon)
    {
      ; -------------------------------------------
      ; Check if Download Icon is a Imange
      ; Not a html file
      ; -------------------------------------------
      CkIconFile := ""
      NumCnt := 0
      ; -------------------------------------------
      While (CkIconFile == "")
      {
        ; -------------------------------------------
        if (NumCnt > 10)
        {
          break
        } ; End (NumCnt > 10)
        CkIconFile := StrReplace(CkIconFile, A_Tab, "")
        CkIconFile := StrReplace(CkIconFile, A_Space, "")        
        NumCnt := NumCnt + 1
        FileReadLine, CkIconFile, %Temp_Icon%, NumCnt
      } ; End While (CkIconFile == "")
      ; -------------------------------------------
      if (InStr(CkIconFile, "DOCTYPE") > 0 or InStr(CkIconFile, "HTML") > 0 or InStr(CkIconFile, "PUBLIC") > 0) ; Is A Html file Not a Icon
      {
        DefaultIcon := 1
      } ; End (CkPos1 > 0 or CkPos2 > 0 or CkPos3 > 0)
      ; -------------------------------------------
      else
      {
        ; -------------------------------------------
        ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, Temp_Icon , , , CkTemp_IconExt
        StringLower, CkTemp_IconExt, CkTemp_IconExt
        OldTemp_Icon := Temp_Icon
        ; -------------------------------------------
        if (CkTemp_IconExt != "ico")
        {
          ; -------------------------------------------
          v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
          NewTemp_Icon := SavePath "Temp_Icon.ico"
          RunThis := v_383_2 " convert """ Temp_Icon """ -define icon:auto-resize=64`,48`,32`,16 """ NewTemp_Icon """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])
          RunWait, %RunThis%, , Hide
          Temp_Icon := NewTemp_Icon
          ; -------------------------------------------
        } ; End (CkTemp_IconExt != "ico")
        IsIcon := LoadPicture(Temp_Icon)
        if (IsIcon == 0)
        {
          DefaultIcon := 1
        }
        else
        {
          ; -------------------------------------------
          v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
          RunThis := v_383_2 " """ Temp_Icon """ -rotate 270 """ Temp_Icon """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
          RunWait, %RunThis%, , Hide
          RunThis := v_383_2 " """ Temp_Icon """ -rotate 90 """ Temp_Icon """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
          RunWait, %RunThis%, , Hide
          DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
          ; -------------------------------------------
        }
      } ; End else (CkPos1 > 0 or CkPos2 > 0 or CkPos3 > 0)
      ; -------------------------------------------
    } ; End FileExist(Temp_Icon)
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      Url_Len := StrLen(v_307_2) ; (307_2)([url] Current URL)
      Url_Pos2 := InStr(v_307_2, "/", , , 3) ; (307_2)([url] Current URL)
      if (Url_Pos2 > 0)
      {
        URL_Root := SubStr(v_307_2, 1, Url_Pos2) ; (307_2)([url] Current URL)
      }
      else if (Url_Pos2 == 0)
      {
        URL_Root := v_307_2 "/" ; (307_2)([url] Current URL)
      }
      ; -------------------------------------------
      Temp_Icon := SavePath "Temp_Icon.ico"
      Url_Icon := URL_Root "favicon.ico"
      UrlDownloadToFile, %Url_Icon%, %Temp_Icon%
      ; -------------------------------------------
      if FileExist(Temp_Icon)
      {
        ; -------------------------------------------
        ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
        SplitPath, Temp_Icon , S_FileNameExt, S_Folder, S_Ext, S_FileName, S_DriveLetter
        CkTemp_IconExt := S_Ext
        StringLower, CkTemp_IconExt, CkTemp_IconExt
        OldTemp_Icon := Temp_Icon
        ; -------------------------------------------
        if (CkTemp_IconExt != "ico")
        {
          v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
          NewTemp_Icon := SavePath "Temp_Icon.ico"
          RunThis := v_383_2 " convert """ Temp_Icon """ -define icon:auto-resize=64`,48`,32`,16 """ NewTemp_Icon """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])
          RunWait, %RunThis%, , Hide
          Temp_Icon := NewTemp_Icon
        } ; End (CkTemp_IconExt != "ico")
        ; -------------------------------------------
        IsIcon := LoadPicture(Temp_Icon)
        if (IsIcon == 0)
        {
          DefaultIcon := 1
        }
        else
        {
          ; -------------------------------------------
          DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      } ; End FileExist(Temp_Icon)
      ; -------------------------------------------
      else if !FileExist(Temp_Icon)
      {
        DefaultIcon := 1
      } ; End !FileExist(Temp_Icon)
      ; -------------------------------------------
    } ; End else FileExist(Temp_Icon)
    ; -------------------------------------------
    if (ThisTitle == "")
    {
      ThisTitle := v_307_2 ; (307_2)([url] Current URL)
    } ; End (ThisTitle == "")
    ; -------------------------------------------
    { ; Delete Old Files
      if FileExist(ThisSource)
      {
        ;~ FileDelete, %ThisSource%
      } ; End FileExist(ThisSource)
      if FileExist(OldTemp_Icon)
      {
        FileDelete, %OldTemp_Icon%
      } ; End FileExist(Temp_Icon)
      if FileExist(Temp_Icon)
      {
        FileDelete, %Temp_Icon%
      } ; End FileExist(Temp_Icon)
    } ; End Delete Old Files
    ; -------------------------------------------
    if (DefaultIcon == 1)
    {
      ; -------------------------------------------
      if !FileExist(url_Icon)
      {
        ; -------------------------------------------
        v_383_1 := DataArray.383.1 ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])
        v_367_6 := DataArray.367.6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
        v_386_1 := DataArray.386.1 ; (386_1)(Extracted Application Icons [System Folder Path])
        SplitPath, v_367_6, , , , ThisProcess ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
        v_368_4 := v_386_1 "\" ThisProcess ; (368_4)(This Application Icons Folder [Extracted])/(386_1)(Extracted Application Icons [System Folder Path])
        url_Icon := v_368_4 "\" ThisProcess "_0.ico" ; (368_4)(This Application Icons Folder [Extracted])
        ; -------------------------------------------
        if !FileExist(v_386_1) ; (386_1)(Extracted Application Icons [System Folder Path])
        {
          FileCreateDir, %v_386_1% ; (386_1)(Extracted Application Icons [System Folder Path])
        }
        ; -------------------------------------------
        if !FileExist(v_368_4) ; (368_4)(This Application Icons Folder [Extracted])
        {
          FileCreateDir, %v_368_4% ; (368_4)(This Application Icons Folder [Extracted])
        }
        ; -------------------------------------------
        if !FileExist(url_Icon)
        {
          RunThis := v_383_1 " ""-res=" v_367_6 "`,0"" ""-icon=" url_Icon """ -formats=32`,48`,256 -pngc" ; (383_1)([Icon Extract] PumIconExtract.exe [Support Program File Path])/(367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
          RunWait, %RunThis%, , Hide
        }
      }
      DataArray := f_102(url_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      ; -------------------------------------------
    }
     ; -------------------------------------------
     DataArray.122.3 := ThisTitle ; (122_3)(<Edit Feild> Status Bar Description: Value)
     DataArray.307.4 := ThisTitle ; (307_4)([url] Page Title)
    ; -------------------------------------------
  } ; End FileExist(ThisSource)
  else ; !FileExist(ThisSource)
  {
    DataArray.307.3 := 0 ; (307_3)([url] Source URL Downloaded Ok [0/1])
  }
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  return DataArray
}
