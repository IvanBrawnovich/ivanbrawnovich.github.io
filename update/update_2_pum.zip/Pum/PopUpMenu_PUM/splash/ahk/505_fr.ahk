; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (505)(1)(Splash Info Script File: Extracting Icons)
; (fr)(French)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\505_fr.png"
; -------------------------------------------
Gui, SI505FR:Margin , 0, 0
Gui, SI505FR:Add, Picture,, %ThisSplash%
Gui, SI505FR:Color, 573694
Gui, SI505FR:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI505FR:Show, NoActivate
return