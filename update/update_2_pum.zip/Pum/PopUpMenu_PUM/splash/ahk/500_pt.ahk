; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (500)(Splash Info Script File: PopUpMenu Loading)
; (pt)(Portuguese)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\500_pt.png"
; -------------------------------------------
Gui, SI500PT:Margin , 0, 0
Gui, SI500PT:Add, Picture,, %ThisSplash%
Gui, SI500PT:Color, 573694
Gui, SI500PT:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI500PT:Show, NoActivate
return