; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (508)(1)(Splash Info Script File: Thank You Request Sent)
; (sv)(Swedish)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\508_sv.png"
; -------------------------------------------
Gui, SI508SV:Margin , 0, 0
Gui, SI508SV:Add, Picture,, %ThisSplash%
Gui, SI508SV:Color, 573694
Gui, SI508SV:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI508SV:Show, NoActivate
return