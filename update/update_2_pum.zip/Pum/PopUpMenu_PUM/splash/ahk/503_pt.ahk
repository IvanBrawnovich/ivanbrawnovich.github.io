; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (503)(1)(Splash Info Script File: Getting App Data)
; (pt)(Portuguese)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\503_pt.png"
; -------------------------------------------
Gui, SI503PT:Margin , 0, 0
Gui, SI503PT:Add, Picture,, %ThisSplash%
Gui, SI503PT:Color, 573694
Gui, SI503PT:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI503PT:Show, NoActivate
return