; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (502)(1)(Splash Info Script File: Checking Internet Connection)
; (pl)(Polish)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\502_pl.png"
; -------------------------------------------
Gui, SI502PL:Margin , 0, 0
Gui, SI502PL:Add, Picture,, %ThisSplash%
Gui, SI502PL:Color, 573694
Gui, SI502PL:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI502PL:Show, NoActivate
return