; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (507)(1)(Splash Info Script File: Sending Request)
; (en)(English)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\507_en.png"
; -------------------------------------------
Gui, SI507EN:Margin , 0, 0
Gui, SI507EN:Add, Picture,, %ThisSplash%
Gui, SI507EN:Color, 573694
Gui, SI507EN:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI507EN:Show, NoActivate
return