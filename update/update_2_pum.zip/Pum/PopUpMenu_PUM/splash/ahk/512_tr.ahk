; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; (512)(1)(Splash Info Script File: Updating PUM)
; (tr)(Turkish)
; -------------------------------------------
ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\512_tr.png"
; -------------------------------------------
Gui, SI511TR:Margin , 0, 0
Gui, SI511TR:Add, Picture,, %ThisSplash%
Gui, SI511TR:Color, 573694
Gui, SI511TR:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border
Winset, TransColor, 573694
Gui, +AlwaysOnTop
Gui, SI511TR:Show, NoActivate
return