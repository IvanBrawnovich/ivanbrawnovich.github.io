﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
HotKey_Cancel(DataArray) ; > DataArray
{
  
  Splash_Script("Off", 0)
  PopUpMenu_Start := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\PopUpMenu_Start.ahk"
  Script_Close(PopUpMenu_Start) ; (384_1)(Disable_KeySelect.ahk)
  
  
  ; -------------------------------------------
  ; Set These GUI Image to Nothing so the Images will be in Reloaded
  DataArray.4.3 := "Nothing" ; (004_3)(Ok Button: Image Path)
  DataArray.62.3 := "Nothing" ; (062_3)(Cancel: Image Path)
  ; -------------------------------------------
  Num := 142
  while (Num < 154)
  {
    DataArray[Num][3] := "Nothing"
    Num := Num + 1
  }
  Gui, HotKeySelect:Destroy
  ExitApp
  Splash_Script("Off", 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
