﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Folder
; -------------------------------------------
f_082(DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_082", DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
  ; ------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; -------------------------------------------
  Selected_File := Select_FileFolder(v_365_2, "Folder") ; (365_2)(Current User language)
  ; -------------------------------------------
  if (Selected_File != "")
  {
    ; -------------------------------------------
    InStalled_Dir := A_AppDataCommon "\PopUpMenu_PUM\mainprogram"
    IfInString, Selected_File, %InStalled_Dir%
    {
      Selected_File := ""
    } ; End IfInString, Selected_File, %InStalled_Dir%
    else
    {
      ; -------------------------------------------
      SplitPath, Selected_File , , , Check_SelectedFile_Ext
      ;
      if (Check_SelectedFile_Ext == "lnk")
      {
        FileGetShortcut, %Selected_File%, Selected_File
      }
      ; -------------------------------------------
    }
  } ; End (Selected_File != "")
  ; -------------------------------------------
  else if (DataArray.303.2 != "") ; (303_2)([ofl] Folder Path)
  {
    v_303_2 := DataArray.303.2 ; (303_2)([ofl] Folder Path)
  }
  ; -------------------------------------------
  if (Selected_File != "") ; (303_2)([ofl] Folder Path)
  {
    ; -------------------------------------------
    v_303_2 := Selected_File ; (303_2)([ofl] Folder Path)
    ; -------------------------------------------
    DataArray.366.5 := "ofl" ; (366_5)(Script Type)
    DataArray.303.2 := v_303_2 ; (303_2)([ofl] Folder Path)
    ; -------------------------------------------
    Reversed_String_1 := String_Reverse(v_303_2) ; (303_2)([ofl] Folder Path)
    Backslash_Position := InStr(Reversed_String_1, "\")
    Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
    v_303_3 := String_Reverse(Reversed_String_2) ; (303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray.303.3 := v_303_3 ; (303_3)([ofl] Folder Name [NO Folder Path])
    DataArray.122.3 := v_303_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray.122.3 := v_303_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------            
  } ; (303_2)([ofl] Folder Path)
  else ; (Folder Path == "")
  {
    ; -------------------------------------------
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick UnSelect
      ; -------------------------------------------
      if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("081", 2, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      ; -------------------------------------------
      if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("071", 2, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      ; -------------------------------------------
      if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("082", 2, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      ; -------------------------------------------
    } ; End Quick UnSelect
  } ; End (Folder Path == "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
