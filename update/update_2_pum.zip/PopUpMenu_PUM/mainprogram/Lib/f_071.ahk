﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_071(DataArray) ; (071_1)(GUI Object: [url] Select URL)
{
  ; -------------------------------------------
  v_071_2 := DataArray.71.2 ; (071_2)([ruf] Select URL: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_071_2 == 1) ; (071_2)([ruf] Select URL: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    v_384_1 := DataArray.384.1 ; (384_1)(Disable_KeySelect.ahk)
    ; (384_1)(Disable_KeySelect.ahk)
    ; (384_1)(Disable_KeySelect.ahk)
    ;~ { ; Wait until 
    ;~ }
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    DataArray.122.3 := "" ; (122_3)(<Edit Feild> Status Bar Description: Value)
    ; -------------------------------------------
    DataArray.366.5 := "url" ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick Select/UnSelect
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      DataArray := GuiControlImage_PopUpMenu("071", 2, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      ; -------------------------------------------
    } ; End Quick Select/UnSelect
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    v_366_6 := DataArray.366.6 ; (366_6)(This Script Error [Integer])
    ; -------------------------------------------
    ; [(366_6) ScriptError == 19] (url)(No Internet Connection)
    ; -------------------------------------------
    if (v_366_6 != 19) ; (366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      Browsers := "ApplicationFrameWindow,Chrome_WidgetWin_0,Chrome_WidgetWin_1,Maxthon3Cls_MainFrm,MozillaWindowClass,Slimjet_WidgetWin_1,IEFrame,OperaWindowClass"
      v_367_4 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
      if v_367_4 in % Browsers ; (367_4)([Line 3] Active Process Class)
      {
        DataArray := url_Get_URL_Address(DataArray)
      }
      ; -------------------------------------------
      v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
      ; -------------------------------------------
      if (v_307_2 == "") ; (307_2)([url] Current URL)
      {
        CkStrLen := 0
      }
      else
      {
        URL_CurrentCk := v_307_2 ; (307_2)([url] Current URL)
        URL_CurrentCk := StrReplace(URL_CurrentCk, "http://", "")
        URL_CurrentCk := StrReplace(URL_CurrentCk, "https://", "")
        URL_CurrentCk := StrReplace(URL_CurrentCk, "ftp://", "")
        URL_CurrentCk := StrReplace(URL_CurrentCk, A_Space, "")
        CkStrLen := StrLen(URL_CurrentCk)
      }
      ; -------------------------------------------
      if (CkStrLen != 0) ; Valid Url
      {
        ; -------------------------------------------
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        Splash_Script("504", 0) ; (504_1)(Splash Info Script File: Getting URL Data)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; -------------------------------------------
        DataArray := url_Get_PageIcon_Title(DataArray)
        ; -------------------------------------------
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        Splash_Script("Off", 0) ; (504)(Splash Info Script File: Getting URL Data)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; -------------------------------------------
        DataArray := _S1_C(DataArray)
        v_366_6 := DataArray.366.6 ; (366_6)(This Script Error [Integer])
        ; -------------------------------------------
        ; [(366_6) ScriptError == 18] (url)(Source Not Found)
        ; -------------------------------------------
        if (v_366_6 != 18) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          v_307_5 := DataArray.367.6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])/(307_5)([url] Selected Opening Browser [Full File Path])
          DataArray.307.5 := v_307_5 ; (307_5)([url] Selected Opening Browser [Full File Path])
          v_307_6 := DataArray.307.6 ; (307_6)([url] Default Browser [Full File Path])
          ; -------------------------------------------
          if (v_307_5 == v_307_6) ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_6)([url] Default Browser [Full File Path])
          {
            DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
          }
          else
          {
            DataArray.307.7 := 0 ; (307_7)([url] Use Default Browser [0/1])
          }
          ; -------------------------------------------
        } ; End ; [(366_6) ScriptError == 18] (url)(Source Not Found)
      } ; End (CkStrLen == 0) ; Valid Url
    } ; End ; [(366_6) ScriptError == 19] (url)(No Internet Connection) (!=)
    ; -------------------------------------------
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Script_Close(DataArray.384.1) ; (384_1)(Disable_KeySelect.ahk)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
  } ; (071_2)([ruf] Select URL: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  
  Script_Close(DataArray.384.1) ; (384_1)(Disable_KeySelect.ahk)
  
  
  return DataArray
  ; -------------------------------------------
}
