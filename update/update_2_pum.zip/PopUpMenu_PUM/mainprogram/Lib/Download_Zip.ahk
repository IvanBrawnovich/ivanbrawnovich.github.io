﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
DL_FileNamePath := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\SourceFile.txt"
; -------------------------------------------
URL_Address := "http://download-installer.cdn.mozilla.net/pub/firefox/releases/26.0/win32/en-US/Firefox%20Setup%2026.0.exe"
;~ URL_Address := "https://www.bobty1.com/accessLimit"
;~ URL_Address := "https://www.bob.com"
; ------------------------------------------
;~ Splash_Img := A_AppDataCommon "\PopUpMenu_PUM\splash\504_en.png" ; (365_2)(Current User language)
; -------------------------------------------
Download_Zip(URL_Address, DL_FileNamePath, Splash_Img)
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Download_Zip(URL_Address, DL_FileNamePath, Splash_Img)
{
  ; -------------------------------------------
  URL_Ext := SubStr(URL_Address, StrLen(URL_Address) - 3)
  ; -------------------------------------------
  if (URL_Ext == ".exe" or URL_Ext == ".zip")
  {
    ; -------------------------------------------
    SysGet, Mon1, Monitor
    v_364_2 := Mon1Bottom ; (364_2)(Monitor Height [Integer])
    v_364_3 := Mon1Right ; (364_3)(Monitor Width [Integer])
    PosY := Ceil(v_364_2 / 2) ; (364_2)(Monitor Height [Integer])
    PosY := PosY + 10
    PosX := Ceil((v_364_3 - 148)  / 2) ; (364_3)(Monitor Width [Integer])
    PosX := PosX - 36
    ; -------------------------------------------
    SplashImage, %Splash_Img%, b
    ; -------------------------------------------
    ExpectedFileSize := 0
    ; -------------------------------------------
    ;Check if the file already exists and if we must not overwrite it
    ;Check if the user wants a progressbar
    ;Initialize the WinHttpRequest Object
    WebRequest := ComObjCreate("WinHttp.WinHttpRequest.5.1")
    ;Download the headers
    WebRequest.Open("HEAD", URL_Address)
    WebRequest.Send()
    try
    {
      ;Store the header which holds the file size in a variable:
      FinalSize := WebRequest.GetResponseHeader("Content-Length")
    } catch e {
      ; Cannot get "Content-Length" header
      FinalSize := ExpectedFileSize
    }
    ;Create the progressbar and the timer
    Progress, CWd3befa CB39b54a w220 h50 x%PosX% y%PosY% b
    LastSizeTick := 0
    LastSize := 0
    ; Enable progress bar updating if the system knows file size
    SetTimer, Update_Progress_Bar, 500
    ;Download the file
    UrlDownloadToFile, %URL_Address%, %DL_FileNamePath%
    ;Remove the timer and the progressbar because the download has finished
    Progress, Off
    SetTimer, Update_Progress_Bar, Off
    Update_Progress_Bar:
    {
      ;Get the current filesize and tick
      CurrentSize := FileOpen(DL_FileNamePath, "r").Length ;FileGetSize wouldn't return reliable results
      CurrentSizeTick := A_TickCount
      ;Calculate the downloadspeed
      SpeedOrig  := Round((CurrentSize/1024-LastSize/1024)/((CurrentSizeTick-LastSizeTick)/1000))
      SpeedUnit  := "KB/s"
      Speed      := SpeedOrig
      if (Speed > 1024)
      {
        ; Convert to megabytes
        SpeedUnit := "MB/s"
        Speed := Round(Speed/1024, 2)
      }
      SpeedText := Speed . " " . SpeedUnit
      ;Save the current filesize and tick for the next time
      LastSizeTick := CurrentSizeTick
      LastSize := FileOpen(DL_FileNamePath, "r").Length
      if (FinalSize == 0)
      {
        PercentDone := 100
      }
      else
      {
        ;Calculate percent done
        PercentDone := Round(CurrentSize/FinalSize*100)
        SpeedText := SpeedText
      }
      ;Update the ProgressBar
      ;~ Progress, CWd3befa CB39b54a w220 h50 x%PosX% y%PosY% b
      Progress, %PercentDone%, %PercentDone%`% (%SpeedText%)
    }
    return
  }
}
