﻿;~ ; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Existing_Shortcut(DataArray) ; > DataArray
{
  ; -------------------------------------------
  DataArray := Function_Flow("Existing_Shortcut", DataArray)
  ; -------------------------------------------
  DataArray.361.2 := "" ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
  ; -------------------------------------------
  if WinExist("ahk_class TfrmToolbox") ; Exist PUM
  {
    ; -------------------------------------------
    CoordMode, Mouse , Window
    ; -------------------------------------------
    WinHide, ahk_class TfrmHint
    WinActivate, ahk_class TfrmToolbox
    ; -------------------------------------------
    MouseGetPos , v_361_11, v_361_12, , , 1 ; (361_11)(Pum Mouse Position X [Integer])/(361_12)(Pum Mouse Position Y [Integer])
    ; -------------------------------------------
    WinGet, PumExt, ProcessName , ahk_class TfrmToolbox
    SplitPath, PumExt, , , , PumName
    v_361_15 := StrReplace(PumName, "pum_", "") ; (361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
    v_361_9 := A_AppData "\PopUpMenu_PUM\pums\" v_361_15 "\settings\toolbox0.xml" ; (361_9)(Pum toolbox0.xml File Path [Full File Path])/(361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
    v_361_8 := A_AppData "\PopUpMenu_PUM\pums\" v_361_15 ; (361_8)(Pum [Specific Folder Path])/(361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
    ; -------------------------------------------
    { ; (Pum Config Vars) from (Pum toolbox0.xml)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 3)
      ; <toolbox name="PopUpMenu - Desktop" rows="11" columns="15" left="150" top="100" stayontop="-1" >
      ; -------------------------------------------
      FileReadLine, Toolbox_String, %v_361_9%, 3 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      ToolBox_Array     := Array_From_String(6, Toolbox_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_2 := ToolBox_Array.1 ; (362_2)([XML][Line 3] Pum Display Name in TitleBar)
      v_362_3 := ToolBox_Array.2 ; (362_3)([XML][Line 3] Pum Total Height (Y) Rows)
      v_362_4 := ToolBox_Array.3 ; (362_4)([XML][Line 3] Pum Total Width (X) Columns)
      v_362_5 := ToolBox_Array.4 ; (362_5)([XML][Line 3] Pum Window Position (X) Left)
      v_362_6 := ToolBox_Array.5 ; (362_6)([XML][Line 3] Pum Window Position (Y) Top)
      v_362_7 := ToolBox_Array.6 ; (362_7)([XML][Line 3] Pum stayontop [Always -1])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 5)
      ; <titlebar visible="-1" height="32" />
      ; -------------------------------------------
      FileReadLine, Titlebar_String, %v_361_9%, 5 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Titlebar_Array  := Array_From_String(2, Titlebar_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_8  := Titlebar_Array.1 ; (362_8)([XML][Line 5] Titlebar visible [-1 On / 0 Off])
      v_362_9 := Titlebar_Array.2  ; (362_9)([XML][Line 5] Titlebar height [4 - 32])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 7)
      ; <statusbar visible="-1" height="32" hint="-1" />
      ; -------------------------------------------
      FileReadLine, Statusbar_String, %v_361_9%, 7 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Statusbar_Array  := Array_From_String(3, Statusbar_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_10  := Statusbar_Array.1 ; (362_10)([XML][Line 7] Ststusbar visible [-1 On / 0 Off])
      v_362_11 := Statusbar_Array.2 ; (362_11)([XML][Line 7] Ststusbar height [4 - 32])
      v_362_12 := Statusbar_Array.3 ; (362_12)([XML][Line 7] Ststusbar hint [Always -1])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 9)
      ; <displaymode type="0" iconsize="64" />
      ; -------------------------------------------
      FileReadLine, Displaymode_String, %v_361_9%, 9 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Displaymode_Array := Array_From_String(2, Displaymode_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_13 := Displaymode_Array.1 ; (362_13)([XML][Line 9] Displaymode type [Always 0])
      v_362_14 := Displaymode_Array.2 ; (362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 11)
      ; width="" & height="" (Always Equal iconsize="") > XML (Line 9) <displaymode type="0" iconsize="16" />
      ; <tile width="64" height="64" cellspacing="0" />
      ; -------------------------------------------
      FileReadLine, TileWidth_String, %v_361_9%, 11 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      TileWidth_Array := Array_From_String(2, TileWidth_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_15 := v_362_14 ; (362_15)([XML][Line 11] Tile width [Same as iconsize])/(362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
      v_362_16 := v_362_14 ; (362_16)([XML][Line 11] Tile height [Same as iconsize])/(362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
      v_362_17 := TileWidth_Array.3 ; (362_17)([XML][Line 11] Tile cellspacing <Shortcut Spacing [0-16]>)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 13)
      ; <border spacing="0" type="0" />
      FileReadLine, Border_String, %v_361_9%, 11 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Border_Array := Array_From_String(2, Border_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      ; -------------------------------------------
      v_362_18 := Border_Array.1 ; (362_18)([XML][Line 13] Border spacing [Always 0])
      v_362_19 := Border_Array.2 ; (362_19)([XML][Line 13] Border type [Always 0])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 15)
      ; <font name="Arial Rounded MT Bold" color="16777215" size="12" shadowtype="0" />
      ; -------------------------------------------
      FileReadLine, Font_String, %v_361_9%, 15 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Font_Array := Array_From_String(2, Font_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_20 := Font_Array.1 ; (362_20)([XML][Line 15] Font name)
      v_362_21 := Font_Array.2 ; (362_21)([XML][Line 15] Font color)
      v_362_22 := Font_Array.3 ; (362_22)([XML][Line 15] Font size [8,9,10,11,12,14,16,18,20,22,24,26,28,36,48,72])
      v_362_23 := Font_Array.4 ; (362_23)([XML][Line 15] Font shadowtype [Always 0])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 17)
      ; <hint show="-1" color="0" background="16777215" />
      ; -------------------------------------------
      FileReadLine, Hint_String, %v_361_9%, 17 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Hint_Array := Array_From_String(2, Hint_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_24 := Hint_Array.1 ; (362_24)([XML][Line 17] Hint show [Floating Text] [-1 On / 0 Off])
      v_362_25 := Hint_Array.2 ; (362_25)([XML][Line 17] Hint color)
      v_362_26 := Hint_Array.3 ; (362_26)([XML][Line 17] Hint background [Floating Text])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 19)
      ; <background color="12632256" type="1" effect="0" opacity="50" >
      ; -------------------------------------------
      FileReadLine, Background_String, %v_361_9%, 19 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
      Background_Array := Array_From_String(2, Background_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
      v_362_27 := Background_Array.1 ; (362_27)([XML][Line 19] Background color)
      v_362_28 := Background_Array.2 ; (362_28)([XML][Line 19] Background type [BG Image 1 / BG Trans 2])
      v_362_29 := Background_Array.3 ; (362_29)([XML][Line 19] Background effect [Always 0])
      v_362_30 := Background_Array.4 ; (362_30)([XML][Line 19] Background opacity [0 - 100])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; XML (Line 20)
      ; <filename>E:\Installed\((_PUM-Construct_))\(((_PUM_Config_)))\Background Image\Background.bmp</filename>
      ; -------------------------------------------
      FileReadLine, v_362_31, %v_361_9%, 20 ; (362_31)([XML][Line 20] Background filename [BMP Full Path])/(361_9)(Pum toolbox0.xml File Path [Full File Path])
      v_362_31 := StrReplace(v_362_31, "    <filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      v_362_31 := StrReplace(v_362_31, "   <filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      v_362_31 := StrReplace(v_362_31, "  <filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      v_362_31 := StrReplace(v_362_31, " <filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      v_362_31 := StrReplace(v_362_31, "<filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      v_362_31 := StrReplace(v_362_31, "</filename>", "") ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
      ; -------------------------------------------
    } ; End (Pum Config Vars) from (Pum toolbox0.xml)
    ; -------------------------------------------
    ; -------------------------------------------
    Factor_Size_X := 1537
    if (A_ScreenWidth > Factor_Size_X)
    {
      FactorX := A_ScreenWidth / Factor_Size_X
      FactorY := A_ScreenHeight / 875
    }
    else
    {
      FactorX := 1
      FactorY := 1
    }
    ; -------------------------------------------
    v_362_9  := v_362_9 * FactorY ; (362_9)([XML][Line 5] Titlebar height [4 - 32])
    v_362_11 := v_362_11 * FactorY ; (362_11)([XML][Line 7] Ststusbar height [4 - 32])
    v_362_14 := v_362_14 * FactorX ; (362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
    ; -------------------------------------------
    if (v_362_8 == "-1") ; (362_8)([XML][Line 5] Titlebar visible [-1 On / 0 Off])
    {
      v_361_12 := v_361_12 - v_362_9 ; (361_12)(Pum Mouse Position Y [Integer])/(362_9)([XML][Line 5] Titlebar height [4 - 32])
    }
    v_370_2 := v_361_11 / v_362_14 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)/(361_11)(Pum Mouse Position X [Integer])/(362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
    v_370_3 := v_361_12 / v_362_14 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)/(361_12)(Pum Mouse Position Y [Integer])/(362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
    v_370_2 := v_370_2 + 1 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    v_370_3 := v_370_3 + 1 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    ; -------------------------------------------
    v_370_2 := Floor(v_370_2) ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    v_370_3 := Floor(v_370_3) ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    ; -------------------------------------------
    if (v_370_2 > v_362_4) ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)/(362_4)([XML][Line 3] Pum Total Width (X) Columns)
    {
      v_370_2 := 0 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    }
    else if (v_370_2 < 0) ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    {
      v_370_2 := 0 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    }
    ; -------------------------------------------
    if (v_370_3 > v_362_3) ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)/(362_3)([XML][Line 3] Pum Total Height (Y) Rows)
    {
      v_370_3 := 0 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    }
    else if (v_370_3 < 0) ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    {
      v_370_3 := 0 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    }
    ; -------------------------------------------
    if (v_370_2 == 0 or v_370_3 == 0) ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)/(370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    {
      DataArray.370.1 := -1 ; (370_1)(XML_SC Line Numer)
    }
    else ; Check for Empty Grid [SET] (370_1)(XML_SC Line Number [-1 = Not in Pum] [0 = Empty Grid] [# = XML Line Number])
    {
      ; -------------------------------------------
      { ; {LButton Up} / {RButton Up}
        ; -------------------------------------------
        GetKeyState, KeyState, LButton
        if (KeyState = "D")
        {
          Send, {LButton Up}
        }
        GetKeyState, KeyState, RButton
        if (KeyState = "D")
        {
          Send, {RButton Up}
        }
        ; -------------------------------------------
      } ; End {LButton Up} / {RButton Up}
      ; -------------------------------------------
      DataArray := Reset_Vars(DataArray) ; > DataArray
      ; -------------------------------------------
      v_361_10 := Array_From_File(v_361_9) ; (361_10)(Pum toolbox0.xml [Array])/(361_9)(Pum toolbox0.xml File Path [Full File Path])
      ; -------------------------------------------
      CheckFor := "<shortcut row=""" v_370_3 """ column=""" v_370_2 """" ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)/(370_2)(XML_SC_L1 [X-Column][Grid Positon)
      v_370_1 := 0 ; (370_1)(XML_SC Line Numer)
      ; -------------------------------------------
      for Index, ThisLine in v_361_10 ; (361_10)(Pum toolbox0.xml [Array])
      {
        if (InStr(ThisLine, CheckFor) > 0)
        {
          ; -------------------------------------------
          v_370_1 := Index ; (370_1)(XML_SC Line Numer)
          ; -------------------------------------------
          if (DataArray.361.17 == 0) ; (361_17)(LButton Was Clicked [0/1])
          {
            ; -------------------------------------------
            Sleep, 100
            ; -------------------------------------------
            { ; (Line 1) <shortcut row="1" column="1" textcolor="16777215" textalign="0" paraalign="0" type="0" >
              Shortcut1_String := v_361_10[v_370_1] ; (361_10)(Pum toolbox0.xml [Array])/(370_1)(XML_SC Line Numer)
              Shortcut1_Array := Array_From_String(6, Shortcut1_String, """") ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
              ; Shortcut1_Array.1 [SET] Above as (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
              ; Shortcut1_Array.2 [SET] Above as (370_2)(XML_SC_L1 [X-Column][Grid Positon)
              v_370_4 := Shortcut1_Array.3 ; (370_4)(XML_SC_L1 [TextColor])
              v_370_5 := Shortcut1_Array.4 ; (370_5)(XML_SC_L1 [TextAlign])
              v_370_6 := Shortcut1_Array.5 ; (370_6)(XML_SC_L1 [ParaAlign])
              v_370_7 := Shortcut1_Array.6 ; (370_7)(XML_SC_L1 [Type])
            } ; End (Line 1) <shortcut row="1" column="1" textcolor="16777215" textalign="0" paraalign="0" type="0" >
            ; -------------------------------------------
            { ; (Line 2) <filename>ahk\key-20191128111115.ahk</filename>
              ; -------------------------------------------
              Script_Name := v_361_10[v_370_1 + 1] ; (361_10)(Pum toolbox0.xml [Array])/(370_1)(XML_SC Line Numer)
              Script_Name := StrReplace(Script_Name, "<filename>ahk\","")
              Script_Name := StrReplace(Script_Name, "</filename>","")
              Script_Name := StrReplace(Script_Name, A_Space ,"")
              v_366_5 := SubStr(Script_Name, 1, 3) ; (366_5)(Script Type)
              v_370_8 := A_AppData "\PopUpMenu_PUM\pums\" v_361_15 "\ahk\" Script_Name ; (370_8)(XML_SC_L2 Script [Full File Path])/(361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
              v_370_9 := v_370_8 ; (370_9)(XML_SC_L2 Old Script [Full File Path])/(370_8)(XML_SC_L2 Script [Full File Path])
              ; -------------------------------------------
            } ; End (Line 2) <filename>ahk\key-20191128111115.ahk</filename>
            ; -------------------------------------------
            { ; (Line 6) <hint>Floating Hint or Status Bar Description</hint>
              ; -------------------------------------------
              v_122_3 := v_361_10[v_370_1 + 5] ; (122_3)(<Edit Feild> Status Bar Description: Value)/(361_10)(Pum toolbox0.xml [Array])/(370_1)(XML_SC Line Numer)
              v_122_3 := StrReplace(v_122_3, "      <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "     <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "    <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "   <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "  <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, " <hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "<hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              v_122_3 := StrReplace(v_122_3, "</hint>","") ; (122_3)(<Edit Feild> Status Bar Description: Value)
              ; -------------------------------------------
            } ; End (Line 6) <hint>Floating Hint or Status Bar Description</hint>
            ; -------------------------------------------
            { ; (Line 8) <icon name="X:\Folder\PopUpMenu_PUM\cache\20191128111115.ico" index="0" />
              ; -------------------------------------------
              ; Var 363_4 = X:\Folder\PopUpMenu_PUM\cache\20191128111115.ico
              ; <icon name="X:\Folder\PopUpMenu_PUM\cache\20191128111115.ico" index="0" />
              ; -------------------------------------------
              v_370_10 := v_361_10[v_370_1 + 7] ; (370_10)(XML_SC_L8 Old Icon [Full File Path])/(361_10)(Pum toolbox0.xml [Array])/(370_1)(XML_SC Line Numer)
              v_370_10 := StrReplace(v_370_10, "<icon name=""","") ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
              v_370_10 := StrReplace(v_370_10, """ index=""0"" />","") ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
              v_370_10 := StrReplace(v_370_10, A_Space,"") ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
              if (SubStr(v_370_10, 1, 12) == "pumiconcache") ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
              {
                v_370_10 := A_AppData "\PopUpMenu_PUM\pums\" v_361_15 "\"  v_370_10 ; (361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])/(370_10)(XML_SC_L8 Old Icon [Full File Path])
              }
              ; -------------------------------------------
              if !FileExist(v_370_10) ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
              {
                ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
                SplitPath, v_370_10, , , , Old_Icon_Name ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
                ; -------------------------------------------
                  ; (386_4)(Pums [AppData] [Folder Path])
                  ; (361_15)(Pum Folder Name [NO (pum_)] [NO Path])
                iconcache_Path := v_386_4 "\" v_361_15 "\iconcache\*.ico" ; (386_4)(Pums [AppData] [Common Folder Path])/(361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
                Loop Files, %iconcache_Path%, R  ; Recurse into subfolders.
                {
                  ; -------------------------------------------
                  This_Icon := A_LoopFileFullPath
                  ; -------------------------------------------
                  ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
                  SplitPath, This_Icon, , , , This_Icon_Name ; FileName ; C__ProgramData_PopUpMenu_PUM_cache_20191128111115.ico,0_(64).ico
                  ; -------------------------------------------
                  if (InStr(This_Icon_Name, Old_Icon_Name) > 0)
                  {
                    v_370_10 := v_386_10 "\" Old_Icon_Name ".ico" ; (370_10)(XML_SC_L8 Old Icon [Full File Path])/(386_10)(All Pums Icon cache [Folder Path])
                    ; FileCopy, SourcePattern, DestPattern , Overwrite
                    FileCopy, %This_Icon%, %v_370_10% , 1 ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
                    break
                  }
                } ; End Loop Files, %iconcache_Path%, R
              } ; End (363_4)(Old Icon File Path) (NOT Exist)
              ; -------------------------------------------
            } ; End (Line 8) <icon name="X:\Folder\PopUpMenu_PUM\cache\20191128111115.ico" index="0" />
            ; -------------------------------------------
          } ; End (361_17)(LButton Was Clicked [0/1])
        } ; End if (InStr(ThisLine, CheckFor) > 0)
      } ; (361_10)(Pum toolbox0.xml [Array])
      ; -------------------------------------------
      DataArray.370.1 := v_370_1 ; (370_1)(XML_SC Line Numer)
      ; -------------------------------------------
      if (DataArray.361.17 == 0) ; (361_17)(LButton Was Clicked [0/1])
      {
        ; -------------------------------------------
        DataArray.102.3 := v_370_10 ; (102_3)(Main Display Icon: Image Path)/(370_10)(XML_SC_L8 Old Icon [Full File Path])
        ; -------------------------------------------
        DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
        ; -------------------------------------------
        DataArray.361.2  := v_361_2 ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
        DataArray.361.3  := v_361_3 ; (361_3)(Pum Factored Width [pixels])
        DataArray.361.4  := v_361_4 ; (361_4)(Pum Factored Height [pixels])
        DataArray.361.7  := v_361_7 ; (361_7)(Pum Executable Name  [File Ext])
        DataArray.361.8  := v_361_8 ; (361_8)(Pum [Specific Folder Path])
        DataArray.361.9  := v_361_9 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
        DataArray.361.10 := v_361_10 ; (361_10)(Pum toolbox0.xml [Array])
        DataArray.361.11 := v_361_11 ; (361_11)(Pum Mouse Position X [Integer])
        DataArray.361.12 := v_361_12 ; (361_12)(Pum Mouse Position Y [Integer])
        DataArray.361.13 := v_361_13 ; (361_13)(Pum Toolbox Icon Cache Path)
        DataArray.361.14 := v_361_14 ; (361_14)(Pum Name [NO Ext] [NO Path])
        DataArray.361.15 := v_361_15 ; (361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
        ; -------------------------------------------
        DataArray.362.2  := v_362_2 ; (362_2)([XML][Line 3] Pum Display Name in TitleBar)
        DataArray.362.3  := v_362_3 ; (362_3)([XML][Line 3] Pum Total Height (Y) Rows)
        DataArray.362.4  := v_362_4 ; (362_4)([XML][Line 3] Pum Total Width (X) Columns)
        DataArray.362.5  := v_362_5 ; (362_5)([XML][Line 3] Pum Window Position (X) Left)
        DataArray.362.6  := v_362_6 ; (362_6)([XML][Line 3] Pum Window Position (Y) Top)
        DataArray.362.7  := v_362_7 ; (362_7)([XML][Line 3] Pum stayontop [Always -1])
        DataArray.362.8  := v_362_8 ; (362_8)([XML][Line 5] Titlebar visible [-1 On / 0 Off])
        DataArray.362.9  := v_362_9 ; (362_9)([XML][Line 5] Titlebar height [4 - 32])
        DataArray.362.10 := v_362_10 ; (362_10)([XML][Line 7] Ststusbar visible [-1 On / 0 Off])
        DataArray.362.11 := v_362_11 ; (362_11)([XML][Line 7] Ststusbar height [4 - 32])
        DataArray.362.12 := v_362_12 ; (362_12)([XML][Line 7] Ststusbar hint [Always -1])
        DataArray.362.13 := v_362_13 ; (362_13)([XML][Line 9] Displaymode type [Always 0])
        DataArray.362.14 := v_362_14 ; (362_14)([XML][Line 9] Displaymode iconsize [16,24,32,48,64,72,96,128])
        DataArray.362.15 := v_362_15 ; (362_15)([XML][Line 11] Tile width [Same as iconsize])
        DataArray.362.16 := v_362_16 ; (362_16)([XML][Line 11] Tile height [Same as iconsize])
        DataArray.362.17 := v_362_17 ; (362_17)([XML][Line 11] Tile cellspacing <Shortcut Spacing [0-16]>)
        DataArray.362.18 := v_362_18 ; (362_18)([XML][Line 13] Border spacing [Always 0])
        DataArray.362.19 := v_362_19 ; (362_19)([XML][Line 13] Border type [Always 0])
        DataArray.362.20 := v_362_20 ; (362_20)([XML][Line 15] Font name)
        DataArray.362.21 := v_362_21 ; (362_21)([XML][Line 15] Font color)
        DataArray.362.22 := v_362_22 ; (362_22)([XML][Line 15] Font size [8,9,10,11,12,14,16,18,20,22,24,26,28,36,48,72])
        DataArray.362.23 := v_362_23 ; (362_23)([XML][Line 15] Font shadowtype [Always 0])
        DataArray.362.24 := v_362_24 ; (362_24)([XML][Line 17] Hint show [Floating Text] [-1 On / 0 Off])
        DataArray.362.25 := v_362_25 ; (362_25)([XML][Line 17] Hint color)
        DataArray.362.26 := v_362_26 ; (362_26)([XML][Line 17] Hint background [Floating Text])
        DataArray.362.27 := v_362_27 ; (362_27)([XML][Line 19] Background color)
        DataArray.362.28 := v_362_28 ; (362_28)([XML][Line 19] Background type [BG Image 1 / BG Trans 2])
        DataArray.362.29 := v_362_29 ; (362_29)([XML][Line 19] Background effect [Always 0])
        DataArray.362.30 := v_362_30 ; (362_30)([XML][Line 19] Background opacity [0 - 100])
        DataArray.362.31 := v_362_31 ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
        ; -------------------------------------------
        DataArray.366.5 := v_366_5 ; (366_5)(Script Type)
        ; -------------------------------------------
        DataArray.370.2  := v_370_2 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
        DataArray.370.3  := v_370_3 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
        DataArray.370.4  := v_370_4 ; (370_4)(XML_SC_L1 [TextColor])
        DataArray.370.5  := v_370_5 ; (370_5)(XML_SC_L1 [TextAlign])
        DataArray.370.6  := v_370_6 ; (370_6)(XML_SC_L1 [ParaAlign])
        DataArray.370.7  := v_370_7 ; (370_7)(XML_SC_L1 [Type])
        DataArray.370.8  := v_370_8 ; (370_8)(XML_SC_L2 Script [Full File Path])
        DataArray.370.9  := v_370_9 ; (370_9)(XML_SC_L2 Old Script [Full File Path])
        DataArray.370.10 := v_370_10 ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
        ; -------------------------------------------
      } ; End (361_17)(LButton Was Clicked [0/1])          
      ; -------------------------------------------
    } ; End (361_17)(LButton Was Clicked [0/1])/(361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
    ; -------------------------------------------
  } ; End ifWinExist, ahk_class TfrmToolbox
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Existing_Shortcut(DataArray)
