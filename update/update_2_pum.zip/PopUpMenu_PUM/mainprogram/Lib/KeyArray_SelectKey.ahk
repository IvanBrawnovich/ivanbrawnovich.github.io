﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
KeyArray_SelectKey(Var_Num, DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("KeyArray_SelectKey", DataArray)
  ; -------------------------------------------
  if (Var_Num != "")
  {
    ; -------------------------------------------
    GuiControlGet, v_122_3 , , g_122 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
    DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
    ; -------------------------------------------
    v_301_2 := DataArray.301.2 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    ; Remove Leading 0
    if (Substr(Var_Num, 1, 1) == "0")
    {
      This_Var_Num := Substr(Var_Num, 2)
    }
    ; -------------------------------------------
    if (Substr(Var_Num, 1, 1) == "0")
    {
      This_Var_Num := Substr(Var_Num, 2)
    }
    ; -------------------------------------------
    IsSelected := DataArray[This_Var_Num][2]
    ; -------------------------------------------
    if (IsSelected == 1) ; Select / Disable
    {
      ; -------------------------------------------
      if (Var_Num == "008") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "009") ; (009_1)(GUI Object: [key] Alt Down)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(008)") > 0) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(008)", 1) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(009)", ThisPos + 1) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(010)", 1) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(009)", ThisPos + 1) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("010", 3, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(011)", 1) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(009)", ThisPos + 1) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("011", 3, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(009)", "End") ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 3, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        DataArray := GuiControlImage_PopUpMenu("009", 3, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        DataArray := GuiControlImage_PopUpMenu("012", 1, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "010") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(008)") > 0) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(008)", "(010)") ; (008_1)(GUI Object: [key] Alt)/(010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(011)", "(010)") ; (011_1)(GUI Object: [key] Alt Right)/(010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(010)", "End") ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(009)") == Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
          DataArray := GuiControlImage_PopUpMenu("010", 2, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
          DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("008", 3, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
          DataArray := GuiControlImage_PopUpMenu("010", 3, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
          DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "011") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(008)") > 0) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(008)", "(011)") ; (008_1)(GUI Object: [key] Alt)/(011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(010)", "(011)") ; (010_1)(GUI Object: [key] Alt Left)/(011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(011)", "End") ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(009)") == Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
          DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
          DataArray := GuiControlImage_PopUpMenu("011", 2, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("008", 3, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
          DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
          DataArray := GuiControlImage_PopUpMenu("011", 3, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "012") ; (012_1)(GUI Object: [key] Alt Up)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(008)") > 0) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(010)", "End") ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(011)", "End") ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        DataArray := GuiControlImage_PopUpMenu("009", 2, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        DataArray := GuiControlImage_PopUpMenu("012", 2, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(010)")) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("010", 2, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        }
        if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("011", 2, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "013") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        v_301_2 := Array_Add(v_301_2, "(013)", "End") ; (013_1)(GUI Object: [key] Caps Lock)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("013", 2, 1, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (Var_Num == "014") ; (014_1)(GUI Object: [key] Ctrl Down)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(074)") > 0) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(074)", 1) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(014)", ThisPos + 1) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(015)", 1) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(014)", ThisPos + 1) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("015", 3, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(016)", 1) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(014)", ThisPos + 1) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("016", 3, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(014)", "End") ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 3, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        DataArray := GuiControlImage_PopUpMenu("014", 3, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        DataArray := GuiControlImage_PopUpMenu("017", 1, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "015") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(074)") > 0) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(074)", "(015)") ; (074_1)(GUI Object: [key] Ctrl)/(015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(016)", "(015)") ; (016_1)(GUI Object: [key] Ctrl Right)/(015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(015)", "End") ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(014)") == Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
          DataArray := GuiControlImage_PopUpMenu("015", 2, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
          DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("074", 3, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
          DataArray := GuiControlImage_PopUpMenu("015", 3, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
          DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "016") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(074)") > 0) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(074)", "(016)") ; (074_1)(GUI Object: [key] Ctrl)/(016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(015)", "(016)") ; (015_1)(GUI Object: [key] Ctrl Left)/(016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(016)", "") ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(014)") == Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
          DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
          DataArray := GuiControlImage_PopUpMenu("016", 2, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("074", 3, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
          DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
          DataArray := GuiControlImage_PopUpMenu("016", 3, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "017") ; (017_1)(GUI Object: [key] Ctrl Up)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(074)") > 0) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(015)", "End") ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(016)", "End") ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        DataArray := GuiControlImage_PopUpMenu("014", 2, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        DataArray := GuiControlImage_PopUpMenu("017", 2, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        
        if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("015", 2, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        }
        if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("016", 2, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "018") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(018)", "End") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("018", 2, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
        DataArray := GuiControlImage_PopUpMenu("019", 1, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        ; -------------------------------------------
      } ; End (018_2)([key] Enter: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "019") ; (019_1)(GUI Object: [key] Enter X2)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(018)", "End") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("018", 2, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
        DataArray := GuiControlImage_PopUpMenu("019", 2, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        ; -------------------------------------------
      } ; End (019_1)(GUI Object: [key] Enter X2)
      ; -------------------------------------------
      else if (Var_Num == "020") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(020)", "End") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("020", 2, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
        DataArray := GuiControlImage_PopUpMenu("021", 1, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        ; -------------------------------------------
      } ; End (020_2)([key] Esc: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "021") ; (021_1)(GUI Object: [key] Esc X2)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(020)", "End") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("020", 2, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
        DataArray := GuiControlImage_PopUpMenu("021", 2, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        ; -------------------------------------------
      } ; End (021_1)(GUI Object: [key] Esc X2)
      ; -------------------------------------------
      else if (Var_Num == "022") ; (022_1)(GUI Object: [key] F1)
      {
        v_301_2 := Array_Add(v_301_2, "(022)", "End") ; (022_1)(GUI Object: [key] F1)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("022", 2, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (Var_Num == "023") ; (023_1)(GUI Object: [key] F2)
      {
        v_301_2 := Array_Add(v_301_2, "(023)", "End") ; (023_1)(GUI Object: [key] F2)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("023", 2, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
      } ; End (023_1)(GUI Object: [key] F2)
      ; -------------------------------------------
      else if (Var_Num == "024") ; (024_1)(GUI Object: [key] F3)
      {
        v_301_2 := Array_Add(v_301_2, "(024)", "End") ; (024_1)(GUI Object: [key] F3)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("024", 2, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
      } ; End (024_1)(GUI Object: [key] F3)
      ; -------------------------------------------
      else if (Var_Num == "025") ; (025_1)(GUI Object: [key] F4)
      {
        v_301_2 := Array_Add(v_301_2, "(025)", "End") ; (025_1)(GUI Object: [key] F4)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("025", 2, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
      } ; End (025_1)(GUI Object: [key] F4)
      ; -------------------------------------------
      else if (Var_Num == "026") ; (026_1)(GUI Object: [key] F5)
      {
        v_301_2 := Array_Add(v_301_2, "(026)", "End") ; (026_1)(GUI Object: [key] F5)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("026", 2, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
      } ; End (026_1)(GUI Object: [key] F5)
      ; -------------------------------------------
      else if (Var_Num == "027") ; (027_1)(GUI Object: [key] F6)
      {
        v_301_2 := Array_Add(v_301_2, "(027)", "End") ; (027_1)(GUI Object: [key] F6)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("027", 2, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
      } ; End (027_1)(GUI Object: [key] F6)
      ; -------------------------------------------
      else if (Var_Num == "028") ; (028_1)(GUI Object: [key] F7)
      {
        v_301_2 := Array_Add(v_301_2, "(028)", "End") ; (028_1)(GUI Object: [key] F7)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("028", 2, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
      } ; End (028_1)(GUI Object: [key] F7)
      ; -------------------------------------------
      else if (Var_Num == "029") ; (029_1)(GUI Object: [key] F8)
      {
        v_301_2 := Array_Add(v_301_2, "(029)", "End") ; (029_1)(GUI Object: [key] F8)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("029", 2, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
      } ; End (029_1)(GUI Object: [key] F8)
      ; -------------------------------------------
      else if (Var_Num == "030") ; (030_1)(GUI Object: [key] F9)
      {
        v_301_2 := Array_Add(v_301_2, "(030)", "End") ; (030_1)(GUI Object: [key] F9)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("030", 2, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
      } ; End (030_1)(GUI Object: [key] F9)
      ; -------------------------------------------
      else if (Var_Num == "031") ; (031_1)(GUI Object: [key] F10)
      {
        v_301_2 := Array_Add(v_301_2, "(031)", "End") ; (031_1)(GUI Object: [key] F10)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("031", 2, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
      } ; End (031_1)(GUI Object: [key] F10)
      ; -------------------------------------------
      else if (Var_Num == "032") ; (032_1)(GUI Object: [key] F11)
      {
        v_301_2 := Array_Add(v_301_2, "(032)", "End") ; (032_1)(GUI Object: [key] F11)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("032", 2, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
      } ; End (032_1)(GUI Object: [key] F11)
      ; -------------------------------------------
      else if (Var_Num == "033") ; (033_1)(GUI Object: [key] F12)
      {
        v_301_2 := Array_Add(v_301_2, "(033)", "End") ; (033_1)(GUI Object: [key] F12)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("033", 2, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
      } ; End (033_1)(GUI Object: [key] F12)
      ; -------------------------------------------
      else if (Var_Num == "034") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        v_301_2 := Array_Add(v_301_2, "(034)", "End") ; (034_1)(GUI Object: [key] Numpad 0)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("034", 2, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
      } ; End (034_1)(GUI Object: [key] Numpad 0)
      ; -------------------------------------------
      else if (Var_Num == "035") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        v_301_2 := Array_Add(v_301_2, "(035)", "End") ; (035_1)(GUI Object: [key] Numpad 1)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("035", 2, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
      } ; End (035_1)(GUI Object: [key] Numpad 1)
      ; -------------------------------------------
      else if (Var_Num == "036") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        v_301_2 := Array_Add(v_301_2, "(036)", "End") ; (036_1)(GUI Object: [key] Numpad 2)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("036", 2, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
      } ; End (036_1)(GUI Object: [key] Numpad 2)
      ; -------------------------------------------
      else if (Var_Num == "037") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        v_301_2 := Array_Add(v_301_2, "(037)", "End") ; (037_1)(GUI Object: [key] Numpad 3)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("037", 2, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
      } ; End (037_1)(GUI Object: [key] Numpad 3)
      ; -------------------------------------------
      else if (Var_Num == "038") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        v_301_2 := Array_Add(v_301_2, "(038)", "End") ; (038_1)(GUI Object: [key] Numpad 4)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("038", 2, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
      } ; End (038_1)(GUI Object: [key] Numpad 4)
      ; -------------------------------------------
      else if (Var_Num == "039") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        v_301_2 := Array_Add(v_301_2, "(039)", "End") ; (039_1)(GUI Object: [key] Numpad 5)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("039", 2, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
      } ; End (039_1)(GUI Object: [key] Numpad 5)
      ; -------------------------------------------
      else if (Var_Num == "040") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        v_301_2 := Array_Add(v_301_2, "(040)", "End") ; (040_1)(GUI Object: [key] Numpad 6)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("040", 2, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
      } ; End (040_1)(GUI Object: [key] Numpad 6)
      ; -------------------------------------------
      else if (Var_Num == "041") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        v_301_2 := Array_Add(v_301_2, "(041)", "End") ; (041_1)(GUI Object: [key] Numpad 7)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("041", 2, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
      } ; End (041_1)(GUI Object: [key] Numpad 7)
      ; -------------------------------------------
      else if (Var_Num == "042") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        v_301_2 := Array_Add(v_301_2, "(042)", "End") ; (042_1)(GUI Object: [key] Numpad 8)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("042", 2, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
      } ; End (042_1)(GUI Object: [key] Numpad 8)
      ; -------------------------------------------
      else if (Var_Num == "043") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        v_301_2 := Array_Add(v_301_2, "(043)", "End") ; (043_1)(GUI Object: [key] Numpad 9)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("043", 2, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
      } ; End (043_1)(GUI Object: [key] Numpad 9)
      ; -------------------------------------------
      else if (Var_Num == "044") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        v_301_2 := Array_Add(v_301_2, "(044)", "End") ; (044_1)(GUI Object: [key] Numpad Add)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("044", 2, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
      } ; End (044_1)(GUI Object: [key] Numpad Add)
      ; -------------------------------------------
      else if (Var_Num == "045") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        v_301_2 := Array_Add(v_301_2, "(045)", "End") ; (045_1)(GUI Object: [key] Numpad Divide)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("045", 2, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
      } ; End (045_1)(GUI Object: [key] Numpad Divide)
      ; -------------------------------------------
      else if (Var_Num == "046") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        v_301_2 := Array_Add(v_301_2, "(046)", "End") ; (046_1)(GUI Object: [key] Numpad Dot)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("046", 2, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
      } ; End (046_1)(GUI Object: [key] Numpad Dot)
      ; -------------------------------------------
      else if (Var_Num == "047") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        v_301_2 := Array_Add(v_301_2, "(047)", "End") ; (047_1)(GUI Object: [key] Numpad Enter)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("047", 2, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
      } ; End (047_1)(GUI Object: [key] Numpad Enter)
      ; -------------------------------------------
      else if (Var_Num == "048") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        v_301_2 := Array_Add(v_301_2, "(048)", "End") ; (048_1)(GUI Object: [key] Numpad Multiply)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("048", 2, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
      } ; End (048_1)(GUI Object: [key] Numpad Multiply)
      ; -------------------------------------------
      else if (Var_Num == "049") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        v_301_2 := Array_Add(v_301_2, "(049)", "End") ; (049_1)(GUI Object: [key] Numpad Subtract)/(301_2)([key] KeyArray_Numbers [Array])
        DataArray := GuiControlImage_PopUpMenu("049", 2, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
      } ; End (049_1)(GUI Object: [key] Numpad Subtract)
      ; -------------------------------------------
      else if (Var_Num == "050") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "051") ; (051_1)(GUI Object: [key] Shift Down)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(050)") > 0) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(050)", 1) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(051)", ThisPos + 1) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(052)", 1) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(051)", ThisPos + 1) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("052", 3, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(053)", 1) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(051)", ThisPos + 1) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("053", 3, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(051)", "End") ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 3, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        DataArray := GuiControlImage_PopUpMenu("051", 3, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        DataArray := GuiControlImage_PopUpMenu("054", 1, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "052") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(050)") > 0) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(050)", "(052)") ; (050_1)(GUI Object: [key] Shift)/(052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(053)", "(052)") ; (053_1)(GUI Object: [key] Shift Right)/(052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(052)", "End") ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(051)") == Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
          DataArray := GuiControlImage_PopUpMenu("052", 2, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
          DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("050", 3, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
          DataArray := GuiControlImage_PopUpMenu("052", 3, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
          DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "053") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(050)") > 0) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(050)", "(053)") ; (050_1)(GUI Object: [key] Shift)/(053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(052)", "(053)") ; (052_1)(GUI Object: [key] Shift Left)/(053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(053)", "End") ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(051)") == Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
          DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
          DataArray := GuiControlImage_PopUpMenu("053", 2, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("050", 3, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
          DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
          DataArray := GuiControlImage_PopUpMenu("053", 3, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "054") ; (054_1)(GUI Object: [key] Shift Up)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(050)") > 0) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(052)", "End") ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(053)", "End") ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        DataArray := GuiControlImage_PopUpMenu("051", 2, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        DataArray := GuiControlImage_PopUpMenu("054", 2, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        
        if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("052", 2, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        }
        if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("053", 2, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "055") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(055)", "End") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("055", 2, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
        DataArray := GuiControlImage_PopUpMenu("056", 1, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        ; -------------------------------------------
      } ; End (055_2)([key] Tab: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "056") ; (056_1)(GUI Object: [key] Tab X2)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(055)", "End") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("055", 2, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
        DataArray := GuiControlImage_PopUpMenu("056", 2, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        ; -------------------------------------------
      } ; End (056_1)(GUI Object: [key] Tab X2)
      ; -------------------------------------------
      else if (Var_Num == "057") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 2, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "058") ; (058_1)(GUI Object: [key] Windows Key Down)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(057)") > 0) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(057)", 1) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(058)", ThisPos + 1) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(059)", 1) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(058)", ThisPos + 1) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("059", 3, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          ; -------------------------------------------
          ThisPos := Array_Item_Position(v_301_2, "(060)", 1) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(058)", ThisPos + 1) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("060", 3, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(058)", "End") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 3, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        DataArray := GuiControlImage_PopUpMenu("058", 3, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        DataArray := GuiControlImage_PopUpMenu("061", 1, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "059") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(057)") > 0) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(057)", "(059)") ; (057_1)(GUI Object: [key] Windows Key)/(059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(060)", "(059)") ; (060_1)(GUI Object: [key] Windows Key Right)/(059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(059)", "End") ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(058)") == Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("057", 2, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
          DataArray := GuiControlImage_PopUpMenu("059", 2, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
          DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("057", 3, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
          DataArray := GuiControlImage_PopUpMenu("059", 3, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
          DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "060") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(057)") > 0) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(057)", "(060)") ; (057_1)(GUI Object: [key] Windows Key)/(060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Replace_Item(v_301_2, "(059)", "(060)") ; (059_1)(GUI Object: [key] Windows Key Left)/(060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        else
        {
          v_301_2 := Array_Add(v_301_2, "(060)", "End") ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(058)") == Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("057", 2, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
          DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
          DataArray := GuiControlImage_PopUpMenu("060", 2, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("057", 3, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
          DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
          DataArray := GuiControlImage_PopUpMenu("060", 3, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "061") ; (061_1)(GUI Object: [key] Windows Key Up)
      {
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(057)") > 0) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(061)", "End") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(059)", "End") ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(061)", "End") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        else if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          v_301_2 := Array_Add(v_301_2, "(060)", "End") ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
          v_301_2 := Array_Add(v_301_2, "(061)", "End") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 2, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        DataArray := GuiControlImage_PopUpMenu("058", 2, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        DataArray := GuiControlImage_PopUpMenu("061", 2, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        
        if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("059", 2, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        }
        if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("060", 2, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "074") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "075") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(075)", "End") ; (075_1)(GUI Object: [key] Delete)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("075", 2, 1, DataArray) ; (075_1)(GUI Object: [key] Delete)
        ; -------------------------------------------
      } ; End (075_1)(GUI Object: [key] Delete)
      ; -------------------------------------------
      else if (Var_Num == "076") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(076)", "End") ; (076_1)(GUI Object: [key] End)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("076", 2, 1, DataArray) ; (076_1)(GUI Object: [key] End)
        ; -------------------------------------------
      } ; End (076_1)(GUI Object: [key] End)
      ; -------------------------------------------
      else if (Var_Num == "077") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(077)", "End") ; (077_1)(GUI Object: [key] Home)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("077", 2, 1, DataArray) ; (077_1)(GUI Object: [key] Home)
        ; -------------------------------------------
      } ; End (077_1)(GUI Object: [key] Home)
      ; -------------------------------------------
      else if (Var_Num == "078") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(078)", "End") ; (078_1)(GUI Object: [key] Insert)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("078", 2, 1, DataArray) ; (078_1)(GUI Object: [key] Insert)
        ; -------------------------------------------
      } ; End (078_1)(GUI Object: [key] Insert)
      ; -------------------------------------------
      else if (Var_Num == "079") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(079)", "End") ; (079_1)(GUI Object: [key] Page Down)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("079", 2, 1, DataArray) ; (079_1)(GUI Object: [key] Page Down)
        ; -------------------------------------------
      } ; End (079_1)(GUI Object: [key] Page Down)
      ; -------------------------------------------
      else if (Var_Num == "080") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Add(v_301_2, "(080)", "End") ; (080_1)(GUI Object: [key] Page Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("080", 2, 1, DataArray) ; (080_1)(GUI Object: [key] Page Up)
        ; -------------------------------------------
      } ; End (080_1)(GUI Object: [key] Page Up)
      ; -------------------------------------------
    } ; End if (IsSelected == 1) ; Select
    ; -------------------------------------------
    else if (IsSelected == 2 or IsSelected == 3) ; UnSelect / Disable
    {
      ; -------------------------------------------
      if (Var_Num == "008") ; (008_1)(GUI Object: [key] Alt)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(008)", 0) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(009)", 0) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(010)", 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(011)", 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(012)", 0) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 1, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        DataArray := GuiControlImage_PopUpMenu("009", 1, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        ; -------------------------------------------
      } ; End (008_1)(GUI Object: [key] Alt)
      ; -------------------------------------------
      else if (Var_Num == "009") ; (009_1)(GUI Object: [key] Alt Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(009)", 0) ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(012)", 0) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(008)", 2) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(010)", 2) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(011)", 2) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 2, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        DataArray := GuiControlImage_PopUpMenu("009", 1, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("010", 2, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        }
        else if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("011", 2, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        ; -------------------------------------------
      } ; End (009_1)(GUI Object: [key] Alt Down)
      ; -------------------------------------------
      else if (Var_Num == "010") ; (010_1)(GUI Object: [key] Alt Left)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(010)", "(008)") ; (010_1)(GUI Object: [key] Alt Left)/(008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("010", 1, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        ; -------------------------------------------
      } ; End (010_1)(GUI Object: [key] Alt Left)
      ; -------------------------------------------
      else if (Var_Num == "011") ; (011_1)(GUI Object: [key] Alt Right)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(011)", "(008)") ; (011_1)(GUI Object: [key] Alt Right)/(008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("011", 1, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        ; -------------------------------------------
      } ; End (011_1)(GUI Object: [key] Alt Right)
      ; -------------------------------------------
      else if (Var_Num == "012") ; (012_1)(GUI Object: [key] Alt Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(008)", 2) ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(010)", 2) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(011)", 2) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(012)", 0) ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(010)") > 0) ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("010", 3, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        }
        else if (Array_Item_Exist(v_301_2, "(011)") > 0) ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("011", 3, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("008", 3, 1, DataArray) ; (008_1)(GUI Object: [key] Alt)
        DataArray := GuiControlImage_PopUpMenu("009", 3, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        DataArray := GuiControlImage_PopUpMenu("012", 1, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        ; -------------------------------------------
      } ; End (012_1)(GUI Object: [key] Alt Up)
      ; -------------------------------------------
      else if (Var_Num == "013") ; (013_1)(GUI Object: [key] Caps Lock)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(013)", 0) ; (013_1)(GUI Object: [key] Caps Lock)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("013", 1, 1, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
        ; -------------------------------------------
      } ; End (013_1)(GUI Object: [key] Caps Lock)
      ; -------------------------------------------
      else if (Var_Num == "014") ; (014_1)(GUI Object: [key] Ctrl Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(014)", 0) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(017)", 0) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(015)", 2) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(016)", 2) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(074)", 2) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 2, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        DataArray := GuiControlImage_PopUpMenu("014", 1, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("015", 2, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        }
        else if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("016", 2, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "015") ; (015_1)(GUI Object: [key] Ctrl Left)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(015)", "(074)") ; (015_1)(GUI Object: [key] Ctrl Left)/(074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "016") ; (016_1)(GUI Object: [key] Ctrl Right)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(016)", "(074)") ; (016_1)(GUI Object: [key] Ctrl Right)/(074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "017") ; (017_1)(GUI Object: [key] Ctrl Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(074)", 2) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(015)", 2) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(016)", 2) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(017)", 0) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(015)") > 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("015", 3, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        }
        else if (Array_Item_Exist(v_301_2, "(016)") > 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("016", 3, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 3, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        DataArray := GuiControlImage_PopUpMenu("014", 3, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        DataArray := GuiControlImage_PopUpMenu("017", 1, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "018") ; (018_1)(GUI Object: [key] Enter)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(018)", 0) ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("018", 1, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
        DataArray := GuiControlImage_PopUpMenu("019", 0, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        ; -------------------------------------------
      } ; End (018_2)([key] Enter: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "019") ; (019_1)(GUI Object: [key] Enter X2)
      {
        ; -------------------------------------------
        ThisPos := Array_Item_Position(v_301_2, "(018)", 1) ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(018)", 0) ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(018)", ThisPos) ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("018", 2, 1, DataArray) ; (018_1)(GUI Object: [key] Enter)
        DataArray := GuiControlImage_PopUpMenu("019", 1, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        ; -------------------------------------------
      } ; End (019_1)(GUI Object: [key] Enter X2)
      ; -------------------------------------------
      else if (Var_Num == "020") ; (020_1)(GUI Object: [key] Esc)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(020)", 0) ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("020", 1, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
        DataArray := GuiControlImage_PopUpMenu("021", 0, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        ; -------------------------------------------
      } ; End (020_2)([key] Esc: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "021") ; (021_1)(GUI Object: [key] Esc X2)
      {
        ; -------------------------------------------
        ThisPos := Array_Item_Position(v_301_2, "(020)", 1) ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(020)", 0) ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(020)", ThisPos) ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("020", 2, 1, DataArray) ; (020_1)(GUI Object: [key] Esc)
        DataArray := GuiControlImage_PopUpMenu("021", 1, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        ; -------------------------------------------
      } ; End (021_1)(GUI Object: [key] Esc X2)
      ; -------------------------------------------
      else if (Var_Num == "022") ; (022_1)(GUI Object: [key] F1)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(022)", 0) ; (022_1)(GUI Object: [key] F1)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("022", 1, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
        ; -------------------------------------------
      } ; End (022_1)(GUI Object: [key] F1)
      ; -------------------------------------------
      else if (Var_Num == "023") ; (023_1)(GUI Object: [key] F2)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(023)", 0) ; (023_1)(GUI Object: [key] F2)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("023", 1, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
        ; -------------------------------------------
      } ; End (023_1)(GUI Object: [key] F2)
      ; -------------------------------------------
      else if (Var_Num == "024") ; (024_1)(GUI Object: [key] F3)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(024)", 0) ; (024_1)(GUI Object: [key] F3)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("024", 1, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
        ; -------------------------------------------
      } ; End (024_1)(GUI Object: [key] F3)
      ; -------------------------------------------
      else if (Var_Num == "025") ; (025_1)(GUI Object: [key] F4)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(025)", 0) ; (025_1)(GUI Object: [key] F4)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("025", 1, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
        ; -------------------------------------------
      } ; End (025_1)(GUI Object: [key] F4)
      ; -------------------------------------------
      else if (Var_Num == "026") ; (026_1)(GUI Object: [key] F5)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(026)", 0) ; (026_1)(GUI Object: [key] F5)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("026", 1, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
        ; -------------------------------------------
      } ; End (026_1)(GUI Object: [key] F5)
      ; -------------------------------------------
      else if (Var_Num == "027") ; (027_1)(GUI Object: [key] F6)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(027)", 0) ; (027_1)(GUI Object: [key] F6)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("027", 1, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
        ; -------------------------------------------
      } ; End (027_1)(GUI Object: [key] F6)
      ; -------------------------------------------
      else if (Var_Num == "028") ; (028_1)(GUI Object: [key] F7)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(028)", 0) ; (028_1)(GUI Object: [key] F7)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("028", 1, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
        ; -------------------------------------------
      } ; End (028_1)(GUI Object: [key] F7)
      ; -------------------------------------------
      else if (Var_Num == "029") ; (029_1)(GUI Object: [key] F8)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(029)", 0) ; (029_1)(GUI Object: [key] F8)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("029", 1, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
        ; -------------------------------------------
      } ; End (029_1)(GUI Object: [key] F8)
      ; -------------------------------------------
      else if (Var_Num == "030") ; (030_1)(GUI Object: [key] F9)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(030)", 0) ; (030_1)(GUI Object: [key] F9)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("030", 1, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
        ; -------------------------------------------
      } ; End (030_1)(GUI Object: [key] F9)
      ; -------------------------------------------
      else if (Var_Num == "031") ; (031_1)(GUI Object: [key] F10)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(031)", 0) ; (031_1)(GUI Object: [key] F10)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("031", 1, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
        ; -------------------------------------------
      } ; End (031_1)(GUI Object: [key] F10)
      ; -------------------------------------------
      else if (Var_Num == "032") ; (032_1)(GUI Object: [key] F11)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(032)", 0) ; (032_1)(GUI Object: [key] F11)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("032", 1, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
        ; -------------------------------------------
      } ; End (032_1)(GUI Object: [key] F11)
      ; -------------------------------------------
      else if (Var_Num == "033") ; (033_1)(GUI Object: [key] F12)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(033)", 0) ; (033_1)(GUI Object: [key] F12)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("033", 1, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
        ; -------------------------------------------
      } ; End (033_1)(GUI Object: [key] F12)
      ; -------------------------------------------
      else if (Var_Num == "034") ; (034_1)(GUI Object: [key] Numpad 0)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(034)", 0) ; (034_1)(GUI Object: [key] Numpad 0)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("034", 1, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
        ; -------------------------------------------
      } ; End (034_1)(GUI Object: [key] Numpad 0)
      ; -------------------------------------------
      else if (Var_Num == "035") ; (035_1)(GUI Object: [key] Numpad 1)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(035)", 0) ; (035_1)(GUI Object: [key] Numpad 1)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("035", 1, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
        ; -------------------------------------------
      } ; End (035_1)(GUI Object: [key] Numpad 1)
      ; -------------------------------------------
      else if (Var_Num == "036") ; (036_1)(GUI Object: [key] Numpad 2)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(036)", 0) ; (036_1)(GUI Object: [key] Numpad 2)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("036", 1, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
        ; -------------------------------------------
      } ; End (036_1)(GUI Object: [key] Numpad 2)
      ; -------------------------------------------
      else if (Var_Num == "037") ; (037_1)(GUI Object: [key] Numpad 3)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(037)", 0) ; (037_1)(GUI Object: [key] Numpad 3)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("037", 1, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
        ; -------------------------------------------
      } ; End (037_1)(GUI Object: [key] Numpad 3)
      ; -------------------------------------------
      else if (Var_Num == "038") ; (038_1)(GUI Object: [key] Numpad 4)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(038)", 0) ; (038_1)(GUI Object: [key] Numpad 4)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("038", 1, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
        ; -------------------------------------------
      } ; End (038_1)(GUI Object: [key] Numpad 4)
      ; -------------------------------------------
      else if (Var_Num == "039") ; (039_1)(GUI Object: [key] Numpad 5)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(039)", 0) ; (039_1)(GUI Object: [key] Numpad 5)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("039", 1, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
        ; -------------------------------------------
      } ; End (039_1)(GUI Object: [key] Numpad 5)
      ; -------------------------------------------
      else if (Var_Num == "040") ; (040_1)(GUI Object: [key] Numpad 6)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(040)", 0) ; (040_1)(GUI Object: [key] Numpad 6)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("040", 1, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
        ; -------------------------------------------
      } ; End (040_1)(GUI Object: [key] Numpad 6)
      ; -------------------------------------------
      else if (Var_Num == "041") ; (041_1)(GUI Object: [key] Numpad 7)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(041)", 0) ; (041_1)(GUI Object: [key] Numpad 7)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("041", 1, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
        ; -------------------------------------------
      } ; End (041_1)(GUI Object: [key] Numpad 7)
      ; -------------------------------------------
      else if (Var_Num == "042") ; (042_1)(GUI Object: [key] Numpad 8)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(042)", 0) ; (042_1)(GUI Object: [key] Numpad 8)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("042", 1, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
        ; -------------------------------------------
      } ; End (042_1)(GUI Object: [key] Numpad 8)
      ; -------------------------------------------
      else if (Var_Num == "043") ; (043_1)(GUI Object: [key] Numpad 9)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(043)", 0) ; (043_1)(GUI Object: [key] Numpad 9)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("043", 1, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
        ; -------------------------------------------
      } ; End (043_1)(GUI Object: [key] Numpad 9)
      ; -------------------------------------------
      else if (Var_Num == "044") ; (044_1)(GUI Object: [key] Numpad Add)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(044)", 0) ; (044_1)(GUI Object: [key] Numpad Add)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("044", 1, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
        ; -------------------------------------------
      } ; End (044_1)(GUI Object: [key] Numpad Add)
      ; -------------------------------------------
      else if (Var_Num == "045") ; (045_1)(GUI Object: [key] Numpad Divide)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(045)", 0) ; (045_1)(GUI Object: [key] Numpad Divide)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("045", 1, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
        ; -------------------------------------------
      } ; End (045_1)(GUI Object: [key] Numpad Divide)
      ; -------------------------------------------
      else if (Var_Num == "046") ; (046_1)(GUI Object: [key] Numpad Dot)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(046)", 0) ; (046_1)(GUI Object: [key] Numpad Dot)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("046", 1, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
        ; -------------------------------------------
      } ; End (046_1)(GUI Object: [key] Numpad Dot)
      ; -------------------------------------------
      else if (Var_Num == "047") ; (047_1)(GUI Object: [key] Numpad Enter)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(047)", 0) ; (047_1)(GUI Object: [key] Numpad Enter)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("047", 1, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
        ; -------------------------------------------
      } ; End (047_1)(GUI Object: [key] Numpad Enter)
      ; -------------------------------------------
      else if (Var_Num == "048") ; (048_1)(GUI Object: [key] Numpad Multiply)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(048)", 0) ; (048_1)(GUI Object: [key] Numpad Multiply)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("048", 1, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
        ; -------------------------------------------
      } ; End (048_1)(GUI Object: [key] Numpad Multiply)
      ; -------------------------------------------
      else if (Var_Num == "049") ; (049_1)(GUI Object: [key] Numpad Subtract)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(049)", 0) ; (049_1)(GUI Object: [key] Numpad Subtract)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("049", 1, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
        ; -------------------------------------------
      } ; End (049_1)(GUI Object: [key] Numpad Subtract)
      ; -------------------------------------------
      else if (Var_Num == "050") ; (050_1)(GUI Object: [key] Shift)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(050)", 0) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(051)", 0) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(054)", 0) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(052)", 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(053)", 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 1, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        DataArray := GuiControlImage_PopUpMenu("051", 1, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "051") ; (051_1)(GUI Object: [key] Shift Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(051)", 0) ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(054)", 0) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(050)", 2) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(052)", 2) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(053)", 2) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 2, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        DataArray := GuiControlImage_PopUpMenu("051", 1, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("052", 2, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        }
        else if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("053", 2, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "052") ; (052_1)(GUI Object: [key] Shift Left)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(052)", "(050)") ; (052_1)(GUI Object: [key] Shift Left)/(050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("052", 1, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "053") ; (053_1)(GUI Object: [key] Shift Right)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(053)", "(050)") ; (053_1)(GUI Object: [key] Shift Right)/(050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("053", 1, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "054") ; (054_1)(GUI Object: [key] Shift Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(050)", 2) ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(052)", 2) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(053)", 2) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(054)", 0) ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(052)") > 0) ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("052", 3, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        }
        else if (Array_Item_Exist(v_301_2, "(053)") > 0) ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("053", 3, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("050", 3, 1, DataArray) ; (050_1)(GUI Object: [key] Shift)
        DataArray := GuiControlImage_PopUpMenu("051", 3, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        DataArray := GuiControlImage_PopUpMenu("054", 1, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "055") ; (055_1)(GUI Object: [key] Tab)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(055)", 0) ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("055", 1, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
        DataArray := GuiControlImage_PopUpMenu("056", 0, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        ; -------------------------------------------
      } ; End (055_2)([key] Tab: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      ; -------------------------------------------
      else if (Var_Num == "056") ; (056_1)(GUI Object: [key] Tab X2)
      {
        ; -------------------------------------------
        ThisPos := Array_Item_Position(v_301_2, "(055)", 1) ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(055)", 0) ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(055)", ThisPos) ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("055", 2, 1, DataArray) ; (055_1)(GUI Object: [key] Tab)
        DataArray := GuiControlImage_PopUpMenu("056", 1, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        ; -------------------------------------------
      } ; End (056_1)(GUI Object: [key] Tab X2)
      ; -------------------------------------------
      else if (Var_Num == "057") ; (057_1)(GUI Object: [key] Windows Key)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(057)", 0) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(058)", 0) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(061)", 0) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(059)", 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(060)", 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 1, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        DataArray := GuiControlImage_PopUpMenu("058", 1, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "058") ; (058_1)(GUI Object: [key] Windows Key Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(058)", 0) ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(061)", 0) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(057)", 2) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(059)", 2) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(060)", 2) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 2, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        DataArray := GuiControlImage_PopUpMenu("058", 1, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("059", 2, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        }
        else if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("060", 2, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "059") ; (059_1)(GUI Object: [key] Windows Key Left)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(059)", "(057)") ; (059_1)(GUI Object: [key] Windows Key Left)/(057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("059", 1, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "060") ; (060_1)(GUI Object: [key] Windows Key Right)
      {
        ; -------------------------------------------
        v_301_2 := Array_Replace_Item(v_301_2, "(060)", "(057)") ; (060_1)(GUI Object: [key] Windows Key Right)/(057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("060", 1, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "061") ; (061_1)(GUI Object: [key] Windows Key Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(057)", 2) ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(059)", 2) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(060)", 2) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(061)", 0) ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        if (Array_Item_Exist(v_301_2, "(059)") > 0) ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("059", 3, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        }
        else if (Array_Item_Exist(v_301_2, "(060)") > 0) ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        {
          DataArray := GuiControlImage_PopUpMenu("060", 3, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("057", 3, 1, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        DataArray := GuiControlImage_PopUpMenu("058", 3, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        DataArray := GuiControlImage_PopUpMenu("061", 1, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "074") ; (074_1)(GUI Object: [key] Ctrl)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(074)", 0) ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(014)", 0) ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(017)", 0) ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(015)", 0) ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Subtract(v_301_2, "(016)", 0) ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("074", 1, 1, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        DataArray := GuiControlImage_PopUpMenu("014", 1, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        DataArray := GuiControlImage_PopUpMenu("015", 1, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        DataArray := GuiControlImage_PopUpMenu("016", 1, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (Var_Num == "075") ; (075_1)(GUI Object: [key] Delete)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(075)", 0) ; (075_1)(GUI Object: [key] Delete)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("075", 1, 1, DataArray) ; (075_1)(GUI Object: [key] Delete)
        ; -------------------------------------------
      } ; End (075_1)(GUI Object: [key] Delete)
      ; -------------------------------------------
      else if (Var_Num == "076") ; (076_1)(GUI Object: [key] End)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(076)", 0) ; (076_1)(GUI Object: [key] End)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("076", 1, 1, DataArray) ; (076_1)(GUI Object: [key] End)
        ; -------------------------------------------
      } ; End (076_1)(GUI Object: [key] End)
      ; -------------------------------------------
      else if (Var_Num == "077") ; (077_1)(GUI Object: [key] Home)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(077)", 0) ; (077_1)(GUI Object: [key] Home)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("077", 1, 1, DataArray) ; (077_1)(GUI Object: [key] Home)
        ; -------------------------------------------
      } ; End (077_1)(GUI Object: [key] Home)
      ; -------------------------------------------
      else if (Var_Num == "078") ; (078_1)(GUI Object: [key] Insert)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(078)", 0) ; (078_1)(GUI Object: [key] Insert)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("078", 1, 1, DataArray) ; (078_1)(GUI Object: [key] Insert)
        ; -------------------------------------------
      } ; End (078_1)(GUI Object: [key] Insert)
      ; -------------------------------------------
      else if (Var_Num == "079") ; (079_1)(GUI Object: [key] Page Down)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(079)", 0) ; (079_1)(GUI Object: [key] Page Down)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("079", 1, 1, DataArray) ; (079_1)(GUI Object: [key] Page Down)
        ; -------------------------------------------
      } ; End (079_1)(GUI Object: [key] Page Down)
      ; -------------------------------------------
      else if (Var_Num == "080") ; (080_1)(GUI Object: [key] Page Up)
      {
        ; -------------------------------------------
        v_301_2 := Array_Subtract(v_301_2, "(080)", 0) ; (080_1)(GUI Object: [key] Page Up)/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("080", 1, 1, DataArray) ; (080_1)(GUI Object: [key] Page Up)
        ; -------------------------------------------
      } ; End (080_1)(GUI Object: [key] Page Up)
      ; -------------------------------------------
    } ; End else if (IsSelected == 2 or IsSelected == 3) ; Was (2 == Sel)/(3 == Dis) [SET] (1 == Nor)
    ; -------------------------------------------
    DataArray.301.2 := v_301_2 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    if (DataArray.301.2.1 != "") ; (301_2)([key] KeyArray_Numbers [Array])
    {
      ; -------------------------------------------
      ; Creates
      ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Display(DataArray) ; > DataArray
      ; -------------------------------------------
      ; Creates
      ; (301_8)([key] KeyArray_Keystroke [Array] for Shortcut)
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Shortcut(DataArray) ; > DataArray
      ; -------------------------------------------
      v_301_7 := DataArray.301.7 ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; -------------------------------------------
      DataArray.105.2 := 1 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      DataArray.105.3 := v_105_3 ; (105_3)(<Displayed Text> Top 2: Value)
      ; -------------------------------------------
      DataArray := KeyArray_Validate(DataArray)
      v_301_3 := DataArray.301.3 ; (301_3)([key] KeyArray is Valid [1/3])
      ; -------------------------------------------
      if (v_301_3 == 1) ; (301_3)([key] KeyArray is Valid [1/3])
      {
        FontColor := "199524" ; (Green)
        DataArray := GuiControlImage_PopUpMenu("004", 1, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
      }
      else
      {
        FontColor := "a30404" ; (Red)
        if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        {
          DataArray := GuiControlImage_PopUpMenu("004", 3, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
        }
      }
      FontSize := 12
      MaxWidth := 480
      ; (105_1)(GUI Object: <Displayed Text> Top 2)
      Text_Adjust_PopUpMenu("g_105", v_301_7, GuiFont, FontSize, FontColor, MaxWidth) ; (301_7)([key] KeyArray_Display [String] [by Lang])/(105_1)(GUI Object: <Displayed Text> Top 2)
      ; -------------------------------------------
    } ; (301_2)([key] KeyArray_Numbers [Array]) [IS NOT EMPTY]
    ; -------------------------------------------
    else ; (301_2)([key] KeyArray_Numbers [Array]) [IS EMPTY]
    {
      ; -------------------------------------------
      DataArray.301.7 := "" ; (301_7)([key] KeyArray_Display [String] [by Lang])
      DataArray.301.8 := "" ; (301_8)([key] KeyArray_Shortcut [Array])
      DataArray.105.2 := 0 ; (105_2)(<Displayed Text> Top 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      GuiControl, PopUpMenu:Hide, g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
      ; -------------------------------------------
    } ; End (301_2)([key] KeyArray_Numbers [Array]) [IS EMPTY]
    ; -------------------------------------------
  } ; End if (Var_Num != "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
