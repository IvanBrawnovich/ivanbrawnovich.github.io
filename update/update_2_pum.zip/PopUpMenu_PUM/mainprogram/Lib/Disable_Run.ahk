﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
#NoTrayIcon
; -------------------------------------------
; This File Must be Ran AsAdmin
; -------------------------------------------
Disable_StayInWindow(This_Id, More_Left, More_Right, More_Up, More_Down)
{
  ; -------------------------------------------
  InWin_X := 0
  InWin_Y := 0
  ; -------------------------------------------
  WinActivate, ahk_id %This_Id%
  CoordMode, Mouse , Window
  MouseGetPos, Pos_X, Pos_Y
  WinGetPos, UpperLeft_X, UpperLeft_Y, Win_Width, Win_Height, ahk_id %This_Id%
  ; -------------------------------------------
  if (More_Up == "")
  {
    More_Up := 0
  }
  if (More_Down == "")
  {
    More_Down := 0
  }
  if (More_Left == "")
  {
    More_Left := 0
  }
  if (More_Right == "")
  {
    More_Right := 0
  }
  ; -------------------------------------------
  Min_X := More_Right
  Max_X := (Win_Width - More_Left)
  Min_Y := More_Down
  Max_Y := (Win_Height - More_Up)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Pos_X < Min_X)
  {
    New_X := Min_X
  }
  else if (Pos_X > Max_X)
  {
    New_X := Max_X
  }
  else
  {
    New_X := Pos_X
  }
  ; -------------------------------------------
  if (Pos_Y < Min_Y)
  {
    New_Y := Min_Y
  }
  else if (Pos_Y > Max_Y)
  {
    New_Y := Max_Y
  }
  else
  {
    New_Y := Pos_Y
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (New_X != Pos_X or New_Y != Pos_Y )
  {
    MouseMove, New_X, New_Y
  } ; End (Pos_X >= Min_X && Pos_X <= Max_X)
  ; -------------------------------------------
} ; End Disable_StayInWindow(This_Id, More_Left, More_Right, More_Up, More_Down)
; -------------------------------------------
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Loop ; While WinExist("PUM -" . "ahk_class #32770")
{
  ; -------------------------------------------
  SetTitleMatchMode, 1
  ; -------------------------------------------
  if WinExist("PUM -" . "ahk_class #32770")
  {
    SetTitleMatchMode, 1
    WinGet, Run_Id, ID , PUM - ahk_class #32770
    WinGetTitle, Run_Title, ahk_id %Run_Id%
    WinGetClass, Run_Class, ahk_id %Run_Id%
    ; -------------------------------------------
  } ; End WinExist("PUM -" . "ahk_class #32770")
  else
  {
    ThisScript := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_KeyDia.ahk"
    DetectHiddenWindows, On
    WinClose, %ThisScript% ahk_class AutoHotkey
    ExitApp
  }
  ; -------------------------------------------
  ; Window Size & Position
  SetTo_W := 750
  SetTo_H := 600
  SetTo_X := Ceil((A_ScreenWidth - SetTo_W) / 2)
  SetTo_Y := Ceil((A_ScreenHeight - SetTo_H) / 2)
  ; -------------------------------------------
  WinGetPos, This_X, This_Y, This_W, This_H
  ; -------------------------------------------
  if (This_X != SetTo_X or This_Y != SetTo_Y or This_W != SetTo_W or This_H != SetTo_H)
  {
    ; -------------------------------------------
    KeyState := GetKeyState("LButton","P") ; User is Physically Holding Down Button
    if (KeyState == 0) ; User is Physically Holding Down Button
    {
      WinMove, ahk_id %Run_id%, , SetTo_X, SetTo_Y, SetTo_W, SetTo_H
    }
  }
  ; -------------------------------------------
  Disable_StayInWindow(Run_id, 25, 25, 22, 22)
  ; -------------------------------------------
} ; End Loop
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
