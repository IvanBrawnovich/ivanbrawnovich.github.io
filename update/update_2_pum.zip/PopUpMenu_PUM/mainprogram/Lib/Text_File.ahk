﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Text_File(VarNum, DataArray) ; File_Path = Path or 0 > DataArray
{
  ; -------------------------------------------
  DataArray := Function_Flow("Text_File", DataArray)
  ; -------------------------------------------
  Num := 1
  Arrays_Match := 1
  ; -------------------------------------------
  This_Var := "v_" VarNum
  This_Var_File := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\" This_Var ".txt"
  ; -------------------------------------------
  { ; Create Text_Array
    ; -------------------------------------------
    Index := 1
    Data_Var := DataArray[VarNum][Index]
    while (Data_Var != "")
    {
      ; -------------------------------------------
      Text_Array := Array_Add(Text_Array, Data_Var, "End") ; Array = [Array], AddThis = ("String") > Array
      ; -------------------------------------------
      Data_Var := DataArray[VarNum][Index]
      ; -------------------------------------------
      Index := Index + 1
      ; -------------------------------------------
    } ; End while (Data_Var != "")
    ; -------------------------------------------
  } ; End Create Text_Array
  ; -------------------------------------------
  if FileExist(This_Var_File)
  {
    ; -------------------------------------------
    File_Array := Array_From_File(This_Var_File) ; (%VarNum%_1)(Application Request Text File)
    Arrays_Match := 1
    ; -------------------------------------------
    for Index, Text_Line in Text_Array
    {
      File_Line := File_Array[Index]
      if (Text_Line != File_Line)
      {
        Arrays_Match := 0
        FileDelete, %This_File%
        break
      } ; End (Text_Line != File_Line)
    } ; End for Index, Text_Line in Text_Array
  }
  else
  {
    Arrays_Match := 0
  }
  ; -------------------------------------------
  if (Arrays_Match == 0)
  {
    Array_To_File(Text_Array, This_Var_File)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
