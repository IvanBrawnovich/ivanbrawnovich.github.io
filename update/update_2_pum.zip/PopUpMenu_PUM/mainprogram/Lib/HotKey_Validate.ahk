﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
HotKey_Validate(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("HotKey_Validate", DataArray)
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  DataArray.4.2 := 1 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  ; -------------------------------------------
  { ; Check for Disable
    ; -------------------------------------------
    ; (All Keys)(None Selected)
    if (DataArray.142.2 == 1 && DataArray.143.2 == 1 && DataArray.144.2 == 1 && DataArray.145.2 == 1 && DataArray.146.2 == 1 && DataArray.147.2 == 1 && DataArray.148.2 == 1 && DataArray.149.2 == 1 && DataArray.150.2 == 1 && DataArray.151.2 == 1 && DataArray.152.2 == 1 && DataArray.153.2 == 1) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(144_2)(HotKey Select Mouse Mouse Middle: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(145_2)(HotKey Select Mouse Wheel Up: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(146_2)(HotKey Select Mouse Wheel Down: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(147_2)(HotKey Select Mouse X1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(148_2)(HotKey Select Mouse X2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray.4.2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    } ; End (All Keys)(None Selected)
    ; -------------------------------------------
    ; (Control Keys, Mouse Left/Right Keys)(One Not Valid)
    if (DataArray.142.2 == 3 or DataArray.143.2 == 3 or DataArray.151.2 == 3 or DataArray.152.2 == 3 or DataArray.153.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    {
      DataArray.4.2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    } ; End (Control Keys, Mouse Left/Right Keys)(One Not Valid)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  { ; Images
    ; -------------------------------------------
    DataArray := GuiControlImage_HotKeySelect("004", DataArray.4.2, 0, DataArray) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    DataArray := GuiControlImage_HotKeySelect("062", 1, 0, DataArray) ; (062_1)(GUI Object: Cancel)
    GuiControl, HotKeySelect:, HK_Header2, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\img\msg\HK_Header2_%v_365_2%.png ; (365_2)(Current User language)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  { ; [SET] Display Text
    ; -------------------------------------------
    ; Sets (231_4)/(231_5)/(231_6)/(231_7)
    DataArray := HotKey_Text_Display_Language(DataArray)
    ; -------------------------------------------
    v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
    v_369_4 := DataArray.369.4 ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
    v_369_5 := DataArray.369.5 ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := DataArray.369.6 ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := DataArray.369.7 ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    FontSize := 12
    MaxWidth := 480
    v_366_2 := DataArray.366.2 ; (366_2)(GuiFont Set in DataArray_Set)
    ; -------------------------------------------
    ; (231_4)(Displayed KeyStroke)/(Choose a Keystroke)
    ; (231_5)(No Keystroke Selected)
    ; (231_6)(This is a good Keystroke)
    ; (231_7)(This keystroke is not good)
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      FontColor := "a30404" ; (Red)
      ; (231_5)(No Keystroke Selected)
      Text_Adjust_HotKeySelect("TextExplain", v_369_5, v_366_2, FontSize, FontColor, MaxWidth) ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)/(366_2)(GuiFont Set in DataArray_Set)
      ; -------------------------------------------
      FontColor := "199524" ; (Green)
      ; (231_4)(Choose a Keystroke)
      Text_Adjust_HotKeySelect("TextKeystroke", v_369_4, v_366_2, FontSize, FontColor, MaxWidth) ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)/(366_2)(GuiFont Set in DataArray_Set)
      ; -------------------------------------------
    }
    else
    {
      if (DataArray.4.2 == 3) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
      {
        ; -------------------------------------------
        FontColor := "a30404" ; (Red)
        ; (231_7)(This keystroke is not good)
        Text_Adjust_HotKeySelect("TextExplain", v_369_7, v_366_2, FontSize, FontColor, MaxWidth) ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)/(366_2)(GuiFont Set in DataArray_Set)
        ; -------------------------------------------
        FontColor := "a30404" ; (Red)
        ; (231_4)(Displayed KeyStroke)
        Text_Adjust_HotKeySelect("TextKeystroke", v_369_4, v_366_2, FontSize, FontColor, MaxWidth) ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)/(366_2)(GuiFont Set in DataArray_Set)
        ; -------------------------------------------
      }
      else if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
      {
        ; -------------------------------------------
        FontColor := "199524" ; (Green)
        ; (231_6)(This is a good Keystroke)
        Text_Adjust_HotKeySelect("TextExplain", v_369_6, v_366_2, FontSize, FontColor, MaxWidth) ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)/(366_2)(GuiFont Set in DataArray_Set)
        ; -------------------------------------------
        FontColor := "199524" ; (Green)
        ; (231_4)(Displayed KeyStroke)
        ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        ; (366_2)(GuiFont Set in DataArray_Set)
        Text_Adjust_HotKeySelect("TextKeystroke", v_369_4, v_366_2, FontSize, FontColor, MaxWidth) ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)/(366_2)(GuiFont Set in DataArray_Set)
        ; -------------------------------------------
      }
    }
    ; -------------------------------------------
  } ; End [SET] Display Text
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
