﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Zip(ZipDir, ZipFile) ; ZipDir = Folder Path, ZipFile = Full Path with Ext
{
  ; -------------------------------------------
  If Not FileExist(ZipFile)
  {
    Header1 := "PK" . Chr(5) . Chr(6)
    VarSetCapacity(Header2, 18, 0)
    file := FileOpen(ZipFile,"w")
    file.Write(Header1)
    file.RawWrite(Header2,18)
    file.close()
  }
  psh := ComObjCreate( "Shell.Application" )
  pzip := psh.Namespace( ZipFile )
  pzip.CopyHere( ZipDir, 4|16 )
  Loop ; Infinite Loop
  {
    sleep 100
    zippedItems := pzip.Items().count
  } Until zippedItems=1 ;because ZipDir is just one file or folder
  ; -------------------------------------------
}
