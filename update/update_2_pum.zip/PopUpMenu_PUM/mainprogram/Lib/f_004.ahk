﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_004(DataArray) ; (004_1)(GUI Object: Ok Button)
{
  ; -------------------------------------------
  if (DataArray.004.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  {
    DataArray := GuiControlImage_PopUpMenu("004", 2, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
    Sleep, 100
    ; -------------------------------------------
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    ; -------------------------------------------
    if (DataArray.133.2 == 2 or v_366_5 == "cpl" or v_366_5 == "key" or v_366_5 == "mnu" or v_366_5 == "ofl" or v_366_5 == "run" or v_366_5 == "rwh" or v_366_5 == "url") ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)/(366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
    {
      ; -------------------------------------------
      GuiControlGet, v_122_3, PopUpMenu:, g_122 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(122_1)(GUI Object: <Edit Feild> Status Bar Description)
      DataArray.122.3 := v_122_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
      ; -------------------------------------------
      DataArray := Shortcut_Config(DataArray) ; > DataArray
      ; -------------------------------------------
    } ; End OkEnable
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("004", 1, 0, DataArray) ; (004_1)(GUI Object: Ok Button)
    ; -------------------------------------------
  }
  return DataArray
  ; -------------------------------------------
} ; (004)(Ok Button_2)Select_(3)Image
