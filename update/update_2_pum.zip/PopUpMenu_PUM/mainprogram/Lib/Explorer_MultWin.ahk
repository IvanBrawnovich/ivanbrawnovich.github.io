; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Explorer_MultWin(WinArray) ; [WinNum, WinSide, FilePath_1, FilePath_2, FilePath_3, FilePath_4, FilePath_5, FilePath_6]
{
  ; -------------------------------------------
  WinNum     := WinArray.1
  WinSide    := WinArray.2
  FilePath_1 := WinArray.3
  FilePath_2 := WinArray.4
  FilePath_3 := WinArray.5
  FilePath_4 := WinArray.6
  FilePath_5 := WinArray.7
  FilePath_6 := WinArray.8
  ; -------------------------------------------
  if (WinNum == "2" or WinNum == "3" or WinNum == "4" or WinNum == "5" or WinNum == "6")
  {
    if (WinSide == "L" or WinSide == "R")
    {
      WinType := WinNum WinSide
    }
    else
    {
      WinType := WinNum
    }
  } ; End (WinNum == "2" or WinNum == "3" or WinNum == "4" or WinNum == "5" or WinNum == "6")
  ; -------------------------------------------
  if (WinType != "")
  {
    Scr_W := A_ScreenWidth
    Scr_H := A_ScreenHeight
    WinGetPos, , , , TaskBar_H, ahk_class Shell_TrayWnd
    Scr_H := Scr_H - TaskBar_H
    ; -------------------------------------------
    Scr_W_5 := Scr_W / 2
    Scr_H_5 := Scr_H / 2
    ; -------------------------------------------
    Scr_W_13 := Scr_W / 3
    Scr_H_13 := Scr_H / 3
    ; -------------------------------------------
    Scr_W_23 := Scr_W_13 * 2
    Scr_H_23 := Scr_H_13 * 2
    ; -------------------------------------------
    if (WinType == "2") ; 1 Left / 1 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == 2)
    else if (WinType == "3L") ; 2 Left / 1 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L2_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == 3L)
    else if (WinType == "3R") ; 1 Left / 2 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
     ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R2_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == 3R)
    else if (WinType == "4") ; 2 Left / 2 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L2_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R2_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_4 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_4%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == 4)
    else if (WinType == "5L") ; 3 Left / 2 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L2_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_13
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L3_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_23
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L3_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_4 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_4%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R2_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %R2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_5 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_5%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == "5L")
    else if (WinType == "5R") ; 2 Left / 3 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L2_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_5
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_5 + 7
      WinMove, ahk_id %L2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R2_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_13
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_4 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_4%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R3_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_23
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R3_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_5 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_5%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == "5R")
    else if (WinType == "6") ; 3 Left / 3 Right
    {
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L1_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_1 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_1%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L2_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_13
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_2 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_2%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      L3_Id := WinExist("A")
      Pos_X := 0 - 7
      Pos_Y := Scr_H_23
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %L3_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_3 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_3%
        Send, {Enter}
        Sleep, 500
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R1_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := 0
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R1_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_4 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_4%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R2_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_13
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R2_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_5 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_5%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
      RunWait, %A_WinDir%\explorer.exe
      Sleep, 500
      R3_Id := WinExist("A")
      Pos_X := Scr_W_5 - 7
      Pos_Y := Scr_H_23
      Win_W := Scr_W_5 + 14
      Win_H := Scr_H_13 + 7
      WinMove, ahk_id %R3_Id%, , Pos_X, Pos_Y , Win_W, Win_H
      if (FilePath_6 != "")
      {
        Send, {Ctrl Down}l{Ctrl Up}
        Sleep, 500
        Send, %FilePath_6%
        Send, {Enter}
        Sleep, 500
      }
      ; -------------------------------------------
    } ; End (WinNum == "6")
    ; -------------------------------------------
  } ; End (WinType != "")
  ; -------------------------------------------
} ; End Explorer_MultWin(WinArray)
