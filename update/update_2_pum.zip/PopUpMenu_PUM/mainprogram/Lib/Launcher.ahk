﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
#NoTrayIcon
; -------------------------------------------
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; Launcher Hotkey
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Pc_TxtFile_UserHotKey := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
FileReadLine, PumLaunch_Hotkey, %Pc_TxtFile_UserHotKey%, 1
Hotkey, %PumLaunch_Hotkey%, PumLaunch
return
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; End Launcher Hotkey
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
PumLaunch: ; Uses User Specified Pum Launch HotKey
{
  ; -------------------------------------------
  SetTitleMatchMode, 1
  ; -------------------------------------------
  if WinExist("PUM -" . "ahk_class #32770") ; File or Folder Dialogbox
  {
    ; -------------------------------------------
    WinClose
    ; -------------------------------------------
    if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
    {
      ; -------------------------------------------
      WinGet, Gui_Id, ID , A
      WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; End "PUM -"
  else if WinExist("Browse For Folder" . "ahk_class #32770") ; File or Folder Dialogbox
  {
    ; -------------------------------------------
    WinClose
    ; -------------------------------------------
    if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
    {
      ; -------------------------------------------
      WinGet, Gui_Id, ID , A
      WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; End "Browse For Folder"
  else if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; File or Folder Dialogbox
  {
    Pum_Close()
  } ; End WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
  else if WinExist("ahk_class TfrmToolbox") ; Exist PUM
  {
    ; -------------------------------------------
    Pum_Close()
    ; -------------------------------------------
  } ; End WinExist("ahk_class TfrmToolbox")
  ; -------------------------------------------
  else ; Pum Not Active
  {
    ; -------------------------------------------
    ; ORG
    Pum_Run() ; > Nothing
    ; -------------------------------------------
  } ; End Pum Not Active
  ; -------------------------------------------
} ; End PumLunch:
return
; -------------------------------------------
#Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HotKey_Cancel.ahk
#Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Close.ahk
#Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Pum_Run.ahk
#Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Script_Close.ahk
#Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Is_Script_Running.ahk
; -------------------------------------------
