﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
SleepTime(ThisTime) ; ThisTime, Benchmark
{
  ; -------------------------------------------
  { ; Read Benchmark File / Create Benchmark if Not Exist
    ; -------------------------------------------
    BenchmarkFile := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\PC_Benchmark.txt"
    ; -------------------------------------------
    if !FileExist(BenchmarkFile)
    {
      SetTitleMatchMode, 2
      DetectHiddenWindows, On
      if !WinExist("Benchmark.ahk" . " ahk_class AutoHotkey") ; Check if Benchmark.ahk is Running
      {
        BenchmarkAhk := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Benchmark.ahk"
        Run, %BenchmarkAhk%
      } ; End !WinExist("Benchmark.ahk" . " ahk_class AutoHotkey")
      ; -------------------------------------------
    } ; End !FileExist(BenchmarkFile)
    ; -------------------------------------------
    FileReadLine, Benchmark, %BenchmarkFile%, 1
    ; -------------------------------------------
  } ; End Read Benchmark File / Create Benchmark if Not Exist
  SleepThisTime := Benchmark * (ThisTime / 1000)
  if (SleepThisTime > 0)
  {
    Sleep, %SleepThisTime%
  }
}
; -------------------------------------------
