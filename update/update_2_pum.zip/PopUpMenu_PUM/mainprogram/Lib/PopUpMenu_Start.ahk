﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#NoTrayIcon
; -------------------------------------------
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Splash_Script("500", 0) ; (500_1)(Splash Info Script File: PopUpMenu Loading)
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; -------------------------------------------
Pc_TxtFile_UserHotKey := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
if FileExist(Pc_TxtFile_UserHotKey) ; (381_3)(User HotKey Text File [User Text File Path])
{
  ; -------------------------------------------
  Current_UserHotKey := "" ; (369_2)(Current User Hotkey)
  Pc_TxtFile_UserHotKey  := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
  FileReadLine, Current_UserHotKey, %Pc_TxtFile_UserHotKey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
  ; -------------------------------------------
  if (Current_UserHotKey == "") ; (369_2)(Current User Hotkey)
  {
    ; -------------------------------------------
    Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Splash_Script_Close.ahk
    RunWait, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Hotkey_gui.ahk
    ; -------------------------------------------
    FileReadLine, Current_UserHotKey, %Pc_TxtFile_UserHotKey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
    if (Current_UserHotKey != "")
    {
      ; -------------------------------------------
      HasUserHotKey := 1
      ; -------------------------------------------
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      Splash_Script("500", 0) ; (500_1)(Splash Info Script File: PopUpMenu Loading)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
  } ; HasUserHotKey Has No Value
  else ; HasUserHotKey OK
  {
    HasUserHotKey := 1
  } ; End HasUserHotKey OK
} ; (381_3)(User HotKey Text File [User Text File Path])
else ; (381_3)(User HotKey Text File [User Text File Path])
{
  ; User HotKey Text File DOES NOT EXIST
  ; -------------------------------------------
  Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Splash_Script_Close.ahk
  RunWait, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Hotkey_gui.ahk
  ; -------------------------------------------
  FileReadLine, Current_UserHotKey, %Pc_TxtFile_UserHotKey%, 1 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
  if (Current_UserHotKey != "")
  {
    ; -------------------------------------------
    HasUserHotKey := 1
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("500", 0) ; (500_1)(Splash Info Script File: PopUpMenu Loading)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  }
  ; -------------------------------------------
} ; (381_3)(User HotKey Text File [User Text File Path])
; -------------------------------------------
if (HasUserHotKey == 1)
{
  ; -------------------------------------------
  Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\HasAdminRights.ahk
  File_HasAdminRights := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\HasAdminRights.txt"
  End_Time := A_TickCount + 1000
  while !FileExist(File_HasAdminRights) && A_TickCount < End_Time
  {
  }
  if FileExist(File_HasAdminRights)
  {
    FileReadLine, HasAdminRights, %File_HasAdminRights%, 1
  }
  ; -------------------------------------------
  if (HasAdminRights == 1)
  {
    Run, *RunAs %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\StartUp_StandAlone.ahk
  }
  ; -------------------------------------------
  Run, %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Copy_Pum_Lib.ahk
  ; -------------------------------------------
  HotKey_AppSpicific := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\HotKey_AppSpicific.ahk" ; (384_7)(HotKey_AppSpicific [Script File Path])/(363_5)(PC Installed Dir)
  if FileExist(HotKey_AppSpicific) ; (384_7)(HotKey_AppSpicific [Script File Path])
  {
    ; HotKeys (App Spicific)
    ; Stand Alone Script
    ; Hidden Window
    Run, %HotKey_AppSpicific% ; (384_7)(HotKey_AppSpicific [Script File Path])
  }
  ; -------------------------------------------
  ; Visable in Tray / Shortcut GUI
  ; Stand Alone Script
  Ahk_PUM := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\PUM.ahk" ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])/(363_5)(PC Installed Dir)
  Run, %Ahk_PUM%,,, Script_Ahk_PUM ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  Process, Priority, %Script_Ahk_PUM%, High ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
  ; -------------------------------------------
  while (Is_Script_Running(Ahk_PUM) == 0)
  {
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
} ; End else if (HasUserHotKey == 1) ; User Hot Key is Set
; -------------------------------------------
{ ; #Include Lib Folder
  ; -------------------------------------------
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Is_Script_Running.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Script_Close.ahk
  #Include %A_AppDataCommon%\PopUpMenu_PUM\mainprogram\Lib\Splash_Script.ahk
  ; -------------------------------------------
} ; End #Include Lib Folder
; -------------------------------------------
