﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Dark Purple 
; Winset, TransColor, 573694
; -------------------------------------------
Splash_Script(Img_Num, Sleep_Time) ; Img_Num ("Off"/Number), Sleep_Time > Nothing
{
  ; -------------------------------------------
  if (Sleep_Time == "")
  {
    Sleep_Time := 1000
  }
  ; -------------------------------------------
  { ; [GET] User Language
    ; -------------------------------------------
    Lang_File := A_AppData "\PopUpMenu_PUM\system\Language.txt" ; (381_2)(User Language Text File [User Text File Path])
    if FileExist(Lang_File) ; (381_2)(User Language Text File [User Text File Path])
    {
      FileReadLINE, This_Lang, %Lang_File%, 1 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      if (This_Lang == "") ; (365_2)(Current User language)
      {
        FileDelete, %Lang_File% ; (381_2)(User Language Text File [User Text File Path])
        This_Lang := "en" ; (365_2)(Current User language)
        FileAppend, %This_Lang%`n, %Lang_File%, UTF-8 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      }
    }
    else
    {
      This_Lang := "en" ; (365_2)(Current User language)
      FileAppend, %This_Lang%`n, %Lang_File%, UTF-8 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
    }
    ; -------------------------------------------
  } ; End [GET] User Language
  ; -------------------------------------------
  if (Img_Num == "Off")
  {
    ; -------------------------------------------
    ; Closes Any Splash Image
    ; Does Not Need DataArray
    ; -------------------------------------------
    if (Sleep_Time > 0)
    {
      Sleep, %Sleep_Time%
    }
    ; -------------------------------------------
    SplashImage, Off
    ; -------------------------------------------
    Array_Lang := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
    Array_Img := ["500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512"]
    for Index_1, Img_Num in Array_Img
    {
      for Index_2, This_Lang in Array_Lang
      {
        This_Splash := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" Img_Num "_" This_Lang ".ahk"
        DetectHiddenWindows, On
        WinClose, %This_Splash% ahk_class AutoHotkey
      } ; End for Index_2, This_Lang in Array_Lang
    } ; End for Index_1, Img_Num in Array_Img
    ; -------------------------------------------
  }
  else
  {
    ; -------------------------------------------
    if (SubStr(Img_Num, 1, 1) == "4")
    {
      ; -------------------------------------------
      File_SplashActive := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\File_SplashActive.txt"
      FileAppend, 1, %File_SplashActive%
      ; -------------------------------------------
      This_Splash := A_AppDataCommon "\PopUpMenu_PUM\splash\" Img_Num "_" This_Lang ".png" ; (365_2)(Current User language)
      SplashImage, %This_Splash%, b
      Sleep, %Sleep_Time%
      SplashImage, Off
      ; -------------------------------------------
      FileDelete, %File_SplashActive%
      ; -------------------------------------------
    }
    else
    {
      This_Splash := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" Img_Num "_" This_Lang ".ahk"
      ; -------------------------------------------
      Run, %This_Splash%,,, This_Splash ; (384_8)(Launcher [Script File Path])
      Process, Priority, %This_Splash%, High ; (384_8)(Launcher [Script File Path])
      ; -------------------------------------------
      if (Sleep_Time > 0)
      {
        Script_Close(This_Splash)
        ; -------------------------------------------
        Sleep, %Sleep_Time%
        ; -------------------------------------------
        Array_Lang := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
        Array_Img := ["500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512"]
        for Index_1, Img_Num in Array_Img
        {
          for Index_2, This_Lang in Array_Lang
          {
            This_Splash := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" Img_Num "_" This_Lang ".ahk"
            DetectHiddenWindows, On
            WinClose, %This_Splash% ahk_class AutoHotkey
          } ; End for Index_2, This_Lang in Array_Lang
        } ; End for Index_1, Img_Num in Array_Img
        ; -------------------------------------------
      }
    }
  }
} ; End Splash_Script(Img_Num, Sleep_Time)
