﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; This File Ran as Admin
; -------------------------------------------
Pc_TxtFile_ActiveApp  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Active_App.txt"
; -------------------------------------------
FileDelete, %Pc_TxtFile_ActiveApp%
; -------------------------------------------
FileAppend, %This_ProcessName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_ProcessExtName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_Class%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_Title%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_ProcessPath%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_ProcessVersion%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_Id%`n, %Pc_TxtFile_ActiveApp%, UTF-8
FileAppend, %This_PID%`n, %Pc_TxtFile_ActiveApp%, UTF-8
; -------------------------------------------
