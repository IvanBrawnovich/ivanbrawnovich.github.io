﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Benchmark(DataArray) ; > DataArray
{
  ; -------------------------------------------
  v_380_5 := DataArray.380.5 ; (380_5)(PC Benchmark [System Text File Path])
  ; -------------------------------------------
  if !FileExist(v_380_5) ; (380_5)(PC Benchmark [System Text File Path])
  {
    ; -------------------------------------------
    StartTime := A_TickCount
    ; -------------------------------------------
    v_380_11 := DataArray.380.11 ; (380_11)(PC Benchmark Test [System Text File Path])
    ; -------------------------------------------
    if FileExist(v_380_5) ; (380_5)(PC Benchmark [System Text File Path])
    {
      FileDelete, %v_380_5% ; (380_5)(PC Benchmark [System Text File Path])
    }
    if FileExist(v_380_11) ; (380_11)(PC Benchmark Test [System Text File Path])
    {
      FileDelete, %v_380_11% ; (380_11)(PC Benchmark Test [System Text File Path])
    }
    ; ------------------------------------------- 
    Factor := 12.29 ; Advrege Returned BenchMark is 1000 (11-Nov-2020)
    ; -------------------------------------------
    WriteNum := Factor * 4.4 
    ReadNum := Factor * 5.6 
    MathNum := Factor * 60000
    ; -------------------------------------------  
    ; ------------------------------------------- [START] Write
    WriteLine := "1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890`n"
    Loop, %WriteNum%
    {
      FileAppend, %WriteLine%, %v_380_11%,  ; (380_11)(PC Benchmark Test [System Text File Path])
    }
    ; ------------------------------------------- [END] Write  
    ; ------------------------------------------- [START] READ
    Loop %ReadNum%
    {
      LineNum := 0
      Loop, %WriteNum%
      {
        LineNum := LineNum + 1
        FileReadLine, ThisLine, %v_380_11%, LineNum ; (380_11)(PC Benchmark Test [System Text File Path])
      } ; End Loop, %WriteNum%
    } ; End Loop %ReadNum%
    ; ------------------------------------------- [END] READ  
    ; ------------------------------------------- [START] Math
    MathLow := 1
    MathHigh := 1000000
    ; -------------------------------------------
    MathCnt := MathLow
    Loop, %MathNum%
    {
      MathCnt := MathCnt * 2
    } ; End Loop, %MathNum%
    MathCnt := MathHigh
    Loop, %MathNum%
    {
      MathCnt := MathCnt / 0.5
    } ; End Loop, %MathNum%
    MathCnt := MathLow
    Loop, %MathNum%
    {
      MathCnt := MathCnt + 1
    } ; End Loop, %MathNum%
    MathCnt := MathHigh
    Loop, %MathNum%
    {
      MathCnt := MathCnt - 1
    } ; End Loop, %MathNum%
    ; ------------------------------------------- [END] Math  
    ; -------------------------------------------
    EndTime := A_TickCount
    v_363_7 := EndTime - StartTime ; (363_7)(PC Benchmark [Integer])
    ; -------------------------------------------
    FileDelete, %v_380_11% ; (380_11)(PC Benchmark Test [System Text File Path])
    ; -------------------------------------------
    FileAppend, %v_363_7%, %v_380_5%, UTF-8 ; (363_7)(PC Benchmark [Integer])/(380_5)(PC Benchmark [System Text File Path])
    ; -------------------------------------------
  }
  else
  {
    FileReadLine, v_363_7, %v_380_5%, 1 ; (363_7)(PC Benchmark [Integer])/(380_5)(PC Benchmark [System Text File Path])
  }
  ; -------------------------------------------
  DataArray.363.7 := v_363_7 ; (363_7)(PC Benchmark [Integer])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Benchmark(DataArray) ; > DataArray
; -------------------------------------------
