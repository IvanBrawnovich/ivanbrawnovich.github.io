﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
HotKey_Ok(DataArray) ; > DataArray
{
  ; -------------------------------------------
  v_004_2 := DataArray.4.2 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  ; -------------------------------------------
  if (v_004_2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  {
    ; -------------------------------------------
    v_365_2  := DataArray.365.2 ; (365_2)(Current User language)
    v_365_3  := DataArray.365.3 ; (365_3)(Language List Number [Integer])
    v_369_2  := DataArray.369.2 ; (369_2)(Current User Hotkey)
    v_380_12 := DataArray.380.12 ; (380_12)(From_PopUpMenu.txt Prevent Launcher.ahk from being ran as stand alone [System Text File Path])
    v_381_3  := DataArray.381.3 ; (381_3)(User HotKey Text File [User Text File Path])
    v_384_2  := DataArray.384.2 ; (384_2)(Empty)
    ; -------------------------------------------
    if (v_369_2 == "#^") ; (369_2)(Current User Hotkey)
    {
      v_369_2 := "#Ctrl" ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    }
    else if (v_369_2 == "#+") ; (369_2)(Current User Hotkey)
    {
      v_369_2 := "#Shift" ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    }
    else if (v_369_2 == "#!") ; (369_2)(Current User Hotkey)
    {
      v_369_2 := "#Alt" ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    }
    ; -------------------------------------------
    if FileExist(v_381_3) ; (381_3)(User HotKey Text File [User Text File Path])
    {
      FileDelete, %v_381_3% ; (381_3)(User HotKey Text File [User Text File Path])
      while FileExist(v_381_3) ; (381_3)(User HotKey Text File [User Text File Path])
      {
      }
    }
    FileAppend, %v_369_2%, %v_381_3%, UTF-8 ; (369_2)(Current User Hotkey)/(381_3)(User HotKey Text File [User Text File Path])
    DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    Gui, HotKeySelect:Destroy
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("511", 1000) ; (511_1)(Splash Info Script File: Hot Key Saved)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; Visable in Tray / Shortcut GUI
    ; Stand Alone Script
    ;~ Ahk_PUM := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\PUM.ahk" ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])/(363_5)(PC Installed Dir)
    ;~ if (CheckScriptRunning(Ahk_PUM) == 0)
    ;~ {
      ;~ Run, %Ahk_PUM%,,, Script_Ahk_PUM ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
      ;~ Process, Priority, %Script_Ahk_PUM%, High ; (384_13)(PopUpMenu [Shortcut GUI] [Script File Path])
      ;~ ; -------------------------------------------
      ;~ while (Is_Script_Running(Ahk_PUM) == 0)
      ;~ {
      ;~ }
    ;~ }
    ExitApp
  }
  ; -------------------------------------------
}
; -------------------------------------------
CheckScriptRunning(ScriptPath)
{
  ; -------------------------------------------
  ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ScriptPath, , ,  , ThisScript
  ; -------------------------------------------
  
  ScriptRunning := 0
  DetectHiddenWindows, On
  WinGet, ahk_list, List, ahk_class AutoHotkey
  ; -------------------------------------------
  Loop % ahk_list
  {
    ; -------------------------------------------
    WinGetTitle, ahk_win, % "ahk_id" ahk_list%A_Index%
    RegExMatch(ahk_win,"^.*?\.ahk",m)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, m, AhkName
    StringLower, AhkName, AhkName
    ; -------------------------------------------
    Check_AhkName := AhkName
    Check_AhkName := StrReplace(Check_AhkName, ".ahk", "")
    StringLower, ThisScript, ThisScript
    StringLower, Check_AhkName, Check_AhkName
    if (Check_AhkName == ThisScript)
    {
      ScriptRunning := ScriptRunning + 1
      break
    } ; End (AhkName == ThisScript)
    ; -------------------------------------------
  } ; End Loop % ahk_list
  ; -------------------------------------------
  return ScriptRunning
}
