﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
KeyArray_Validate(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("KeyArray_Validate", DataArray)
  ; -------------------------------------------
  /* Info
  [CHECK] v_301_2 Length (Longer than 0) ; (301_2)([key] KeyArray_Numbers [Array])
  [CHECK] XXX_Down to XXX_Up Keys
  [SET] (123) KeyValid (0,1)
  */
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; StartUpVars
    v_301_2 := DataArray.301.2 ; (301_2)([key] KeyArray_Numbers [Array])
    KeyArrayLen := v_301_2.MaxIndex() ; (301_2)([key] KeyArray_Numbers [Array])
    v_004_2 := 1 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  } ; End StartUpVars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (KeyArrayLen == "")
  {
    v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  } ; End !KeyArrayLen
  ; -------------------------------------------
  { ; (VALIDATE) Up,Down Keys
    ; -------------------------------------------
    if (Array_Item_Exist(v_301_2, "(009)") != Array_Item_Exist(v_301_2, "(012)")) ; (009_1)(GUI Object: [key] Alt Down)/(012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    ; -------------------------------------------
    if (Array_Item_Exist(v_301_2, "(014)") != Array_Item_Exist(v_301_2, "(017)")) ; (014_1)(GUI Object: [key] Ctrl Down)/(017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    ; -------------------------------------------
    if (Array_Item_Exist(v_301_2, "(051)") != Array_Item_Exist(v_301_2, "(054)")) ; (051_1)(GUI Object: [key] Shift Down)/(054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    ; -------------------------------------------
    if (Array_Item_Exist(v_301_2, "(058)") != Array_Item_Exist(v_301_2, "(061)")) ; (058_1)(GUI Object: [key] Windows Key Down)/(061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
    {
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    ; -------------------------------------------
  } ; End (VALIDATE) Up,Down Keys
  ; -------------------------------------------
  { ; (VALIDATE) Check if (123)(Edit Text Input) is Enpty
    ; -------------------------------------------
    GuiControlGet, v_123, PopUpMenu:, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ThisStrLen := StrLen(v_123) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ; -------------------------------------------
    if (ThisStrLen == 0 && KeyArrayLen == "")
    {
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    } ; End (ThisStrLen == 0 && !Check_KeyArray)
  } ; End (VALIDATE) ? is any Key Selected / (123)(Edit Text Input) is Enpty
  ; -------------------------------------------
  DataArray.301.3 := v_004_2 ; (301_3)([key] KeyArray is Valid [1/3])/(004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    DataArray := GuiControlImage_PopUpMenu("004", v_004_2, 0, DataArray) ; (004_1)(GUI Object: Ok Button)/(004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
