﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_Lang := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
Array_Img := ["500", "501", "502", "503", "504", "505", "506", "507", "508", "509", "510", "511", "512"]
for Index_1, Img_Num in Array_Img
{
  for Index_2, This_Lang in Array_Lang
  {
    This_Splash := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" Img_Num "_" This_Lang ".ahk"
    DetectHiddenWindows, On
    WinClose, %This_Splash% ahk_class AutoHotkey
  } ; End for Index_2, This_Lang in Array_Lang
} ; End for Index_1, Img_Num in Array_Img
