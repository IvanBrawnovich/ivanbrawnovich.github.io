﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Download_File(ThisUrl, DownloadedFile) ; > File Downloaded OK
{
  ; -------------------------------------------
  URLDownloadToFile, %ThisUrl%, %DownloadedFile%
  ; -------------------------------------------
  if (ErrorLevel == 0)
  {
    ; -------------------------------------------
    if FileExist(DownloadedFile)
    {
      FileReadLine, LineOne, %DownloadedFile%, 1 ; Number of the Last Update that was ran
      if (InStr(LineOne, "DOCTYPE") > 0)
      {
        FileOK := 0
      }
      else if (InStr(LineOne, "html") > 0)
      {
        FileOK := 0
      }
      else
      {
        FileOK := 1
      }
    } ; End FileExist(DownloadedFile)
    else
    {
      FileOK := 0
    } ; End !FileExist(DownloadedFile)
  } ; End (ErrorLevel == 0)
  else
  {
    FileOK := 0
  } ; End (ErrorLevel != 0)
  ; -------------------------------------------
  if (FileOK == 0)
  {
    FileDelete, %DownloadedFile%
  }
  ; -------------------------------------------
  return FileOK
  ; -------------------------------------------
} ; End StarUp_DownloadFile(ThisUrl, DownloadedFile) ; > File Downloaded OK
