﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Pum_Run() ; > Nothing
{
  ; -------------------------------------------
  { ; (Active Process)
    ; -------------------------------------------
    GetKeyState, KeyState, LButton
    if (KeyState = "D")
    {
      Send, {LButton Up}
    }
    GetKeyState, KeyState, RButton
    if (KeyState = "D")
    {
      Send, {RButton Up}
    }
    ; -------------------------------------------
    ; Get Current Process Name
    WinGetTitle, This_Title, A
    WinGetClass, This_Class, A
    WinGet, This_ProcessExtName , ProcessName, A
    SplitPath, This_ProcessExtName, , , , This_ProcessName
    WinGet, This_ProcessPath, ProcessPath , A
    FileGetVersion, This_ProcessVersion, %This_ProcessPath%
    WinGet, This_Id, ID , A
    WinGet, This_PID, PID , A
    ; -------------------------------------------
    FoundSideBar := InStr(This_ProcessExtName, "sidebar")
    if (FoundSideBar > 0)
    {
      CkClass := "sidebar"
    }
    StringLower, CkClass, CkClass
    ; -------------------------------------------
    if (CkClass == "progman" or CkClass == "workerw" or CkClass == "sidebar" or CkClass == "shell_traywnd")
    {
      ; -------------------------------------------
      This_ProcessName    := "Windows"
      This_ProcessExtName := "Windows"
      This_Class          := "Windows"
      This_Title          := "Windows"
      This_ProcessPath    := "Windows"
      This_ProcessVersion := "Windows"
      This_Id             := "Windows"
      This_PID            := "Windows"
      ; -------------------------------------------
    } ; End if (CkClass == "progman" or CkClass == "workerw" or CkClass == "sidebar" or CkClass == "shell_traywnd")
  } ; End (Active Process)
  ; -------------------------------------------
  { ; Pum .exe/.xml
    ; -------------------------------------------
    Pc_Folder_PumCommon  := A_AppData "\PopUpMenu_PUM\pums"
    ; -------------------------------------------
    StringLower, This_ProcessLowerName, This_ProcessName
    Pum_Executable := Pc_Folder_PumCommon "\" This_ProcessLowerName "\pum_" This_ProcessLowerName ".exe"
    Pc_XmlFile_PumFullPath := Pc_Folder_PumCommon "\" This_ProcessLowerName "\settings\toolbox0.xml"
    ; -------------------------------------------
  } ; End Pum .exe/.xml
  ; -------------------------------------------
  Disable_KeyPum := A_AppDataCommon "\PopUpMenu_PUM\mainprogram\Lib\Disable_KeyPum.ahk"
  ; -------------------------------------------
  if FileExist(Pum_Executable)
  {
    ; -------------------------------------------
    { ; Run PUM / Wait until PUM is Active / [SET] AlwaysOnTop
      ; -------------------------------------------
      Run, %Pum_Executable%,,, S_Pum_Executable
      Process, Priority, %S_Pum_Executable%, High
      WinHide, ahk_class TfrmToolbox
      WinSet, AlwaysOnTop, On, ahk_class TfrmToolbox
      ; -------------------------------------------
      { ; (Write File) (Active Process Info)
        ; -------------------------------------------
        Pc_TxtFile_ActiveApp  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Active_App.txt"
        ; -------------------------------------------
        FileDelete, %Pc_TxtFile_ActiveApp%
        ; -------------------------------------------
        FileAppend, %This_ProcessName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_ProcessExtName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_Class%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_Title%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_ProcessPath%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_ProcessVersion%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_Id%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        FileAppend, %This_PID%`n, %Pc_TxtFile_ActiveApp%, UTF-8
        ; -------------------------------------------
      } ; End (Write File) (Active Process Info)
      ; -------------------------------------------
      Run, %Disable_KeyPum%
      ; -------------------------------------------
    } ; End Run PUM / Wait until PUM is Active
    ; -------------------------------------------
  } ; End if FileExist(Pum_Executable)
  else ; No PUM for Current Application [Run Default PUM]
  {
    ; -------------------------------------------
    { ; Run Default PUM / Wait until PUM is Active / [SET] AlwaysOnTop
      Pum_Executable := Pc_Folder_PumCommon "\default\pum_default.exe"
      if FileExist(Pum_Executable) ; Check if Default PUM Exist
      {
        ; -------------------------------------------
        Run, %Pum_Executable%,,, S_Pum_Executable
        Process, Priority, %S_Pum_Executable%, High
        WinHide, ahk_class TfrmToolbox
        WinSet, AlwaysOnTop, On, ahk_class TfrmToolbox
        ; -------------------------------------------
        { ; (Write File) (Active Process Info)
          ; -------------------------------------------
          Pc_TxtFile_ActiveApp  := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\Active_App.txt"
          ; -------------------------------------------
          FileDelete, %Pc_TxtFile_ActiveApp%
          ; -------------------------------------------
          FileAppend, %This_ProcessName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_ProcessExtName%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_Class%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_Title%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_ProcessPath%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_ProcessVersion%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_Id%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          FileAppend, %This_PID%`n, %Pc_TxtFile_ActiveApp%, UTF-8
          ; -------------------------------------------
        } ; End (Write File) (Active Process Info)
        ; -------------------------------------------
        Run, %Disable_KeyPum%
        ; -------------------------------------------
      } ; End if FileExist(Pum_Executable)
      else ; Default PUM Does Not Exist Send Message
      {
        MsgBox, 262160, ,Default PopUpMenu Does Not Exist`n%Pum_Executable%`nPum Executable Could Not Be Found`nF_PumLuncher, 5
      } ; End Default PUM Does Not Exist Send Message
    } ; End Run Default PUM / Wait until PUM is Active / [SET] AlwaysOnTop
  } ; End No PUM for Current Application [Run Default PUM]
  ; -------------------------------------------
} ; End Pum_Run
