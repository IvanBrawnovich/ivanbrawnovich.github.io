﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
File_HasAdminRights := A_AppDataCommon "\PopUpMenu_PUM\systemtemp\HasAdminRights.txt"
End_Time := A_TickCount + 1000
while FileExist(File_HasAdminRights) && A_TickCount < End_Time
{
  FileDelete, %File_HasAdminRights%
}
; -------------------------------------------
HasAdminRights := A_IsAdmin
FileAppend, %HasAdminRights%, %File_HasAdminRights%, UTF-8
