﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_165(DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
{
  ; -------------------------------------------
  v_165_2 := DataArray.165.2 ; (165_2)([pum] Backgroung Image Select: [0]Hide/[1]Nor/[2]Sel)
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; -------------------------------------------
  if (v_165_2 == "") ; (165_2)([pum] Backgroung Image Select: [0]Hide/[1]Nor/[2]Sel)
  {
    v_165_2 := 1 ; (165_2)([pum] Backgroung Image Select: [0]Hide/[1]Nor/[2]Sel)
  }
  ; -------------------------------------------
  if (v_165_2 == 1) ; (165_2)([pum] Backgroung Image Select: [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    PicturesDir := Find_Windows_Public_Folder("Pictures", 0)
    ; -------------------------------------------
    { ; Language Set DialogText [SET] DialogText := "PUM - Select Shortcut Image"
      ; -------------------------------------------
      if (v_365_2 == "de") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Wählen Sie Hintergrundbild"
      } ; End (de German)
      ; -------------------------------------------
      else if (v_365_2 == "en") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Select Background Image"
      } ; End (en English)
      ; -------------------------------------------
      else if (v_365_2 == "es") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Seleccionar imagen de fondo"
      } ; End (es Spanish)
      ; -------------------------------------------
      else if (v_365_2 == "fr") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Sélectionnez l'image d'arrière-plan"
      } ; End (fr French)
      ; -------------------------------------------
      else if (v_365_2 == "it") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Seleziona Immagine di sfondo"
      } ; End (it Italian)
      ; -------------------------------------------
      else if (v_365_2 == "pl") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Wybierz Obraz tła"
      } ; End (pl Polish)
      ; -------------------------------------------
      else if (v_365_2 == "pt") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Selecione a imagem de fundo"
      } ; End (pt Portuguese)
      ; -------------------------------------------
      else if (v_365_2 == "ru") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Выбрать фоновое изображение"
      } ; End (ru Russian)
      ; -------------------------------------------
      else if (v_365_2 == "sv") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Välj bakgrundsbild"
      } ; End (sv Swedish)
      ; -------------------------------------------
      else if (v_365_2 == "tr") ; (365_2)(Current User language)
      {
        DialogText := "PUM - Arka Plan Resmi Seçin"
      } ; End (tr Turkish)
      ; -------------------------------------------
    } ; End Language Set DialogText
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("165", 2, 1, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
    ; -------------------------------------------
    if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
    {
      ; -------------------------------------------
      WinGet, Gui_Id, ID , A
      WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
      ; -------------------------------------------
    }
    ; -------------------------------------------
    FileSelectFile, ThisFile, 3, %PicturesDir%, %DialogText%, Images (*.svg; *.gif; *.bmp; *.jpeg; *.jpg; *.png; *.webp; *.tiff; *.tif; *.exe)
    ; -------------------------------------------
    if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
    {
      ; -------------------------------------------
      WinGet, Gui_Id, ID , A
      WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if ThisFile
    {
      ; -------------------------------------------
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, ThisFile , NameIco, , ThisExt
      StringLower, ThisExt, ThisExt
      ; -------------------------------------------
      if (ThisExt == "svg" or ThisExt == "gif" or ThisExt == "bmp" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "webp" or ThisExt == "tiff" or ThisExt == "tif")
      {
        ; -------------------------------------------
        ; Selected ThisFile is a Image
        ; -------------------------------------------
        DataArray.366.5 := "pum_pumSet_pumBG_pumImg" ; (366_5)(Script Type)
        ; -------------------------------------------
        v_368_5 := ThisFile ; (368_5)(Selected Pum Background [Full Path])
        ; -------------------------------------------
        { ; [ReSize][RePosition] (162)(Message Image 5 Picture Frame) to Match Ratio of (368)(Selected Pum Background)
          ; -------------------------------------------
          Gui, ImageSize:Add, Picture, hwndmypic, %v_368_5% ; (368_5)(Selected Pum Background [Full Path])
          ControlGetPos, , , v_368_6, v_368_7, , ahk_id %mypic% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
          Gui, ImageSize:Destroy
          ; -------------------------------------------
          if (v_368_6 > v_368_7) ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
          {
            Factor_X := 1
            Factor_Y := v_368_7 / v_368_6 ; (368_7)(Pum Background Image Y_Height)/(368_6)(Pum Background Image X_Width)
          }
          else if (v_368_7 > v_368_6) ; (368_7)(Pum Background Image Y_Height)/(368_6)(Pum Background Image X_Width)
          {
            Factor_X := v_368_6 / v_368_7 ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
            Factor_Y := 1
          }
          else
          {
            Factor_X := 1
            Factor_Y := 1
          }
          ; -------------------------------------------
          ; (162_1)(GUI Object: Message Image 5)
          ; x190 y295 w300 h300 
          ; -------------------------------------------
          W_GuiSize := Ceil(300 * Factor_X)
          H_GuiSize := Ceil(300 * Factor_Y)
          ;
          X_GuiPos := Ceil(190 + ((300 - (300 * Factor_X)) / 2 ))
          Y_GuiPos := Ceil(295 + ((300 - (300 * Factor_Y)) / 2 ))
          ; -------------------------------------------
          GuiControl, PopUpMenu:Move, g_162, x%X_GuiPos% y%Y_GuiPos% w%W_GuiSize% h%H_GuiSize% ; (162_1)(GUI Object: Message Image 5)
          ; -------------------------------------------
        } ; End [ReSize][RePosition] (162)(Message Image 5 Picture Frame) to Match Ratio of (368)(Selected Pum Background)
        ; -------------------------------------------
        { ; 
          
        }
        
        
        
        DataArray.368.5 := v_368_5 ; (368_5)(Selected Pum Background [Full Path])
        DataArray.368.6 := v_368_6 ; (368_6)(Pum Background Image X_Width)
        DataArray.368.7 := v_368_7 ; (368_7)(Pum Background Image Y_Height)
        
        
        
        DataArray := _S3_S(DataArray)
        
        
        ; -------------------------------------------
      } ; if (ThisExt == "A Image Ext")
      else
      {
        ; -------------------------------------------
        DataArray := GuiControlImage_PopUpMenu("165", 1, 1, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
        ; -------------------------------------------
      }
    } ; End if ThisFile
    else
    {
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("165", 1, 1, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
      ; -------------------------------------------
    }
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
