﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_062(DataArray) ; (062_1)(GUI Object: Cancel)
{
  ; -------------------------------------------
  DataArray := GuiControlImage_PopUpMenu("062", 2, 0, DataArray) ; (062_1)(GUI Object: Cancel)
  Sleep, 100
  ; -------------------------------------------
  while GetKeyState("LButton", "P") ; User is Physically Holding Down Button
  {
  } ; End while GetKeyState("LButton", "P")
  ; -------------------------------------------
  WinSet, Enable ,, ahk_class TfrmToolbox
  Pum_Close() ; > Nothing
  ToolTip
  ; -------------------------------------------
  DataArray := GuiControlImage_PopUpMenu("062", 1, 0, DataArray) ; (062_1)(GUI Object: Cancel)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
