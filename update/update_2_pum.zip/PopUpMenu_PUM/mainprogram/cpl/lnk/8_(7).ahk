﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; 8_(5) Open Charms
; Windows 8 Only
; -------------------------------------------
RegRead, v_360_3, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName ; (360_3)(World Location: Continent)
Win_Ver := A_OSVersion
if (SubStr(Win_Ver, 1, 2) == "8.")
{
  Send, {LWin Down}c{LWin Up}
}
else
{
  Send, {LWin}
}
