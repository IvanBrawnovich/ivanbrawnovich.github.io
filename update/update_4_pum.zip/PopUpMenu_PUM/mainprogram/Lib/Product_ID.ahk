﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Product_ID(DataArray) ; > DataArray
{
  ; -------------------------------------------
  v_380_3 := DataArray.380.3 ; (380_3)(Product ID [System Text File Path])
  ; -------------------------------------------
  if !FileExist(v_380_3) ; (380_3)(Product ID [System Text File Path])
  {
    ; -------------------------------------------
    if (Connect_Check(flag=0x40) == 1)
    {
      ; -------------------------------------------
      FormatTime, TimeRightNow , , yyyyMMddHHmmss
      TimeRightNow := TimeRightNow A_TickCount
      ; -------------------------------------------
      This_Benchmark := Benchmark()
      ; -------------------------------------------
      { ; Get IP
        ; -------------------------------------------
        v_380_6 := DataArray.380.6 ; (380_6)(Get IP [System Text File Path])
        v_385_8 := DataArray.385.8 ; (385_8)(Get IP [www.netikus.net URL Address])
        URLDownloadToFile, %v_385_8%, %v_380_6% ; (385_8)(Get IP [www.netikus.net URL Address])/(380_6)(Get IP [System Text File Path])
        ; -------------------------------------------
        if (ErrorLevel == 1)
        {
          ; -------------------------------------------
          v_360_7 := "NoIp" ; (360_7)(Public IP)
          v_360_8 := "NoIp" ; (360_8)(Private IP)
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          FileReadLINE, v_360_7, %v_380_6%, 1 ; (360_7)(Public IP)/(380_6)(Get IP [System Text File Path])
          v_360_8 := A_IPAddress1 ; (360_8)(Private IP)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        if FileExist(v_380_6) ; (380_6)(Get IP [System Text File Path])
        {
          FileDelete, %v_380_6% ; (380_6)(Get IP [System Text File Path])
        }
        ; -------------------------------------------
        if (v_360_7 != "NoIp") ; (360_7)(Public IP)
        {
          IPsearch := "https://whatismyipaddress.com/ip/" . v_360_7 ; (360_7)(Public IP)
          whr := ComObjCreate("WinHttp.WinHttpRequest.5.1")
          whr.Open("GET", IPsearch)
          whr.Send()
          sleep 100
          version := whr.ResponseText
          RegExMatch(version, "Continent(.*)Latitude", Location)
          Location1 := RegExReplace(Location1,"<.+?>")
          Location1 := StrReplace(Location1, A_Tab, "")
          Location1 := StrReplace(Location1, " Country: ", "|")
          Location1 := StrReplace(Location1, " State/Region: ", "|")
          Location1 := StrReplace(Location1, " City: ", "|")
          LocationArray  := StrSplit(Location1, "|", "")
          ; -------------------------------------------
          v_360_3 := LocationArray.1 ; (360_3)(World Location: Continent)
          v_360_3 := StrReplace(v_360_3, ": ", "") ; (360_3)(World Location: Continent)
          v_360_3 := StrReplace(v_360_3, "`n", "") ; (360_3)(World Location: Continent)
          v_360_4 := LocationArray.2 ; (360_4)(World Location: Country)
          v_360_4 := StrReplace(v_360_4, "`n", "") ; (360_4)(World Location: Country)
          v_360_5 := LocationArray.3 ; (360_5)(World Location: Region)
          v_360_5 := StrReplace(v_360_5, "`n", "") ; (360_5)(World Location: Region)
          v_360_6 := LocationArray.4 ; (360_6)(World Location: This City)
          v_360_6 := StrReplace(v_360_6, "`n", "") ; (360_6)(World Location: This City)
          Pos_1 := InStr(v_360_6, "Javascript") ; (360_6)(World Location: This City)
          if (Pos_1 > 0)
          {
            Pos_1 := Pos_1 - 2
            v_360_6 := SubStr(v_360_6, 1, Pos_1) ; (360_6)(World Location: This City)
          }
          ; -------------------------------------------
        }
        else
        {
          v_360_3 := "NoIp" ; (360_3)(World Location: Continent)
          v_360_4 := "NoIp" ; (360_4)(World Location: Country)
          v_360_5 := "NoIp" ; (360_5)(World Location: Region)
          v_360_6 := "NoIp" ; (360_6)(World Location: This City)
        }
        ; -------------------------------------------
      } ; End Get IP
      ; -------------------------------------------
      { ; (360_1)(Product ID) / (360_2)(AutoHotKey Version) / (360_3)(Windows Version)
        ; -------------------------------------------
        v_360_1 := "PUM_(" v_360_7 ")_(" v_360_8 ")_(" TimeRightNow ")" ; (360_1)(Product ID)/(360_7)(Public IP)/(360_8)(Private IP)
        RegRead, v_360_2, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName ; (360_2)(Windows Version)
      }
      ; -------------------------------------------
      { ; Send E-Mail
        ; -------------------------------------------
        Email_Subject := "PUM-ID " v_360_1 ; (360_1)(Product ID)
        Email_Body := ""
        ; -------------------------------------------
        Email_Body := Email_Body "`n`n"
        ; -------------------------------------------
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Product ID:`n"
        Email_Body := Email_Body v_360_1 "`n`n" ; (360_1)(Product ID)
        ;
        Email_Body := Email_Body "User Name:`n"
        Email_Body := Email_Body A_UserName "`n`n"
        ;
        Email_Body := Email_Body "Benchmark:`n"
        Email_Body := Email_Body This_Benchmark "`n`n" ; (363_7)(PC Benchmark [Integer])
        ;
        Email_Body := Email_Body "AutoHotKey Version:`n"
        Email_Body := Email_Body A_AhkVersion "`n`n"
        ;
        Email_Body := Email_Body "Windows Version:`n"
        Email_Body := Email_Body v_360_2 "`n`n" ; (360_2)(Windows Version)
        ;
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Continent:`n"
        Email_Body := Email_Body v_360_3 "`n`n" ; (360_3)(World Location: Continent)
        ;
        Email_Body := Email_Body "Country:`n"
        Email_Body := Email_Body v_360_4 "`n`n" ; (360_4)(World Location: Country)
        ;
        Email_Body := Email_Body "Region:`n"
        Email_Body := Email_Body v_360_5 "`n`n" ; (360_5)(World Location: Region)
        ;
        Email_Body := Email_Body "City:`n"
        Email_Body := Email_Body v_360_6 "`n" ; (360_6)(World Location: This City)
        Email_Body := Email_Body "----------------------------------`n"
        Email_Body := Email_Body "Public IP:`n"
        Email_Body := Email_Body v_360_7 "`n`n" ; (360_7)(Public IP)
        ;
        Email_Body := Email_Body "Private IP:`n"
        Email_Body := Email_Body v_360_8 "`n" ; (360_8)(Private IP)
        Email_Body := Email_Body "----------------------------------`n"
        ; -------------------------------------------
        Email_Sent := Send_Email(Email_Subject, Email_Body, AttachFile)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (Email_Sent == 1)
      {
        ; -------------------------------------------
        ; Does Not Exist
        ; (380_3)(Product ID [System Text File Path])
        ; -------------------------------------------
        This_File := FileOpen(v_380_3, "rw")
        ; -------------------------------------------
        v_360_1 := v_360_1 "`r`n"  ; (360_1)(Product ID)
        This_File.Write(v_360_1) ; (360_1)(Product ID)
        ; -------------------------------------------
        v_360_2 := v_360_2 "`r`n"  ; (360_2)(Windows Version)
        This_File.Write(v_360_2) ; (360_2)(Windows Version)
        ; -------------------------------------------
        v_360_3 := v_360_3 "`r`n"  ; (360_3)(World Location: Continent)
        This_File.Write(v_360_3) ; (360_3)(World Location: Continent)
        ; -------------------------------------------
        v_360_4 := v_360_4 "`r`n"  ; (360_4)(World Location: Country)
        This_File.Write(v_360_4) ; (360_4)(World Location: Country)
        ; -------------------------------------------
        v_360_5 := v_360_5 "`r`n"  ; (360_5)(World Location: Region)
        This_File.Write(v_360_5) ; (360_5)(World Location: Region)
        ; -------------------------------------------
        v_360_6 := v_360_6 "`r`n"  ; (360_6)(World Location: This City)
        This_File.Write(v_360_6) ; (360_6)(World Location: This City)
        ; -------------------------------------------
        v_360_7 := v_360_7 "`r`n"  ; (360_7)(Public IP)
        This_File.Write(v_360_7) ; (360_7)(Public IP)
        ; -------------------------------------------
        v_360_8 := v_360_8 "`r`n"  ; (360_8)(Private IP)
        This_File.Write(v_360_8) ; (360_8)(Private IP)
        ; -------------------------------------------
        This_File.Close()
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
  } ; (380_3)(Product ID [System Text File Path]) (NOT Exist)
  ; -------------------------------------------
  else
  {
    FileReadLine, v_360_1, %v_380_3%, 1 ; (360_1)(Product ID)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_2, %v_380_3%, 2 ; (360_2)(Windows Version)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_3, %v_380_3%, 3 ; (360_3)(World Location: Continent)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_4, %v_380_3%, 4 ; (360_4)(World Location: Country)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_5, %v_380_3%, 5 ; (360_5)(World Location: Region)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_6, %v_380_3%, 6 ; (360_6)(World Location: This City)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_7, %v_380_3%, 7 ; (360_7)(Public IP)/(380_3)(Product ID [System Text File Path])
    FileReadLine, v_360_8, %v_380_3%, 8 ; (360_8)(Private IP)/(380_3)(Product ID [System Text File Path])
  }
  ; -------------------------------------------
  DataArray.360.1 := v_360_1 ; (360_1)(Product ID)
  DataArray.360.2 := v_360_2 ; (360_2)(Windows Version)
  DataArray.360.3 := v_360_3 ; (360_3)(World Location: Continent)
  DataArray.360.4 := v_360_4 ; (360_4)(World Location: Country)
  DataArray.360.5 := v_360_5 ; (360_5)(World Location: Region)
  DataArray.360.6 := v_360_6 ; (360_6)(World Location: This City)
  DataArray.360.7 := v_360_7 ; (360_7)(Public IP)
  DataArray.360.8 := v_360_8 ; (360_8)(Private IP)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} 
