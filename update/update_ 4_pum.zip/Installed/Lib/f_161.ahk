﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_161(DataArray) ; (161_1)(GUI Object: [pum] Delete Pum)
{
  ; -------------------------------------------
  v_161_2 := DataArray.161.2 ; (161_2)([pum] Delete Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_161_2 == "") ; (161_2)([pum] Delete Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_161_2 := 1 ; (161_2)([pum] Delete Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_161_2 == 1) ; (161_2)([pum] Delete Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumDel" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
