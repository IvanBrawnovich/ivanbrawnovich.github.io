﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_018(DataArray) ; (018_1)(GUI Object: [key] Enter)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_018", DataArray) ; (018_1)(GUI Object: [key] Enter)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("018", DataArray) ; (018_1)(GUI Object: [key] Enter)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
