﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HotKey_UnSelect_Key(ThisKey, DataArray)
{
  ; -------------------------------------------
  if (ThisKey == "v_142") ; (142_1)(GUI Object: HotKey Select Mouse Left)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
     DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (142) (HotKey Select Mouse Left)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_143") ; (143_1)(GUI Object: HotKey Select Mouse Right)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (143) (HotKey Select Mouse Right)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_144") ; (144_1)(GUI Object: HotKey Select Mouse Middle)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; (144) (HotKey Select Mouse Middle)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_145") ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUP", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (145) (HotKey Select Mouse Wheel Up)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_146") ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (146) (HotKey Select Mouse Wheel Down)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_147") ; (147_1)(GUI Object: HotKey Select Mouse X1)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (147) (HotKey Select Mouse X1)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_148") ; (148_1)(GUI Object: HotKey Select Mouse X2)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (148) (HotKey Select Mouse X2)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_149") ; (149_1)(GUI Object: HotKey Windows Key Left)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "#", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("149", 1, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
    DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than Mouse (142)Left/(143)Right Key) (No Keys Selected)
    if (HotKey_Check_Selected([142, 143], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)
    {
      if (DataArray.142.2 == 2) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 2) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
    }
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
  } ; (149) (HotKey Windows Key Left)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_150") ; (150_1)(GUI Object: HotKey Windows Key Right)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "#", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("149", 1, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
    DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than Mouse (142)Left/(143)Right Key) (No Keys Selected)
    if (HotKey_Check_Selected([142, 143], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)
    {
      if (DataArray.142.2 == 2) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 2) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
    }
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
  } ; (150) (HotKey Windows Key Right)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_151") ; (151_1)(GUI Object: HotKey Ctrl Key)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "^", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      ; (Other Than_149_150)(Windows Key)(No Keys Selected)
      if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
      {
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
      }
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("151", 1, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than Mouse (142)Left/(143)Right Key) (No Keys Selected)
    if (HotKey_Check_Selected([142, 143], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)
    {
      if (DataArray.142.2 == 2) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 2) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
    }
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (151) (HotKey Ctrl Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_152") ; (152_1)(GUI Object: HotKey Alt Key)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "!", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      ; (Other Than_149_150)(Windows Key)(No Keys Selected)
      if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
      {
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
      }
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("152", 1, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than Mouse (142)Left/(143)Right Key) (No Keys Selected)
    if (HotKey_Check_Selected([142, 143], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)
    {
      if (DataArray.142.2 == 2) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 2) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
    }
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_153)(HotKey Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      if (DataArray.153.2 == 2) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (152) (HotKey Alt Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_153") ; (153_1)(GUI Object: HotKey Shift Key)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "+", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      ; (Other Than_149_150)(Windows Key)(No Keys Selected)
      if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
      {
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
      }
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := GuiControlImage_HotKeySelect("153", 1, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; (Other Than Mouse (142)Left/(143)Right Key) (No Keys Selected)
    if (HotKey_Check_Selected([142, 143], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)
    {
      if (DataArray.142.2 == 2) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 2) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
    }
    ; -------------------------------------------
    ; (Other Than_151)(HotKey Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      if (DataArray.151.2 == 2) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_152)(HotKey Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      if (DataArray.152.2 == 2) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
    }
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
        v_369_2 := StrReplace(v_369_2, "#", "LWin") ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      }
    }
    ; -------------------------------------------
  } ; (152) (HotKey Shift Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
