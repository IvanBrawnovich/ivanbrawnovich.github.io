﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_Reverse(ThisArray) ; ThisArray > ThisArray Reversed
{
  ThisArrayLen := ThisArray.MaxIndex()
  RevArray := []
  While (ThisArrayLen > 0)
  {
    Item := ThisArray[ThisArrayLen]
    ThisArrayLen := ThisArrayLen - 1
    RevArray.Push(Item)
  } ; End (ThisArrayLen > 0)
  return RevArray
}
