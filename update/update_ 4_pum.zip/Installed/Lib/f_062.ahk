﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_062(DataArray) ; (062_1)(GUI Object: Cancel)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_062", DataArray) ; (062_1)(GUI Object: Cancel)
  ; -------------------------------------------
  while GetKeyState("LButton", "P") ; User is Physically Holding Down Button
  {
  } ; End while GetKeyState("LButton", "P")
  ; -------------------------------------------
  WinSet, Enable ,, ahk_class TfrmToolbox
  Pum_Close() ; > Nothing
  ToolTip
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
