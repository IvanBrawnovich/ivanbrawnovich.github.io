﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_005(DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_005", DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
  ; -------------------------------------------
  v_102_3 := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
  v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
  ; -------------------------------------------
  ; This will be displayed only if the Image is a Ico
  ; -------------------------------------------
  if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  {
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("005", 2, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
    ; -------------------------------------------
    ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_102_3, , , ThisExt ; (102_3)(Main Display Icon: Image Path)
    StringLower, ThisExt, ThisExt
    ; -------------------------------------------
    ; Rotate Ico
    if (ThisExt == "ico")
    {
      RunThis := v_383_2 " """ v_102_3 """ -rotate 270 """ v_102_3 """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
      RunWait, %RunThis%, , Hide
      GuiControl, PopUpMenu:, g_102, %v_102_3% ; (102_3)(Main Display Icon: Image Path)/(102_1)(GUI Object: Main Display Icon)
      GuiControl, PopUpMenu:MoveDraw, g_102 , +w80 +h80 ; (102_1)(GUI Object: Main Display Icon)
      GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
    } ; End if (ThisExt == "ico")
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("005", 1, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
    ; -------------------------------------------
  } ; End if OK (IsEnabled == 1)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (005_1)(GUI Object: Icon Rotate Left)
