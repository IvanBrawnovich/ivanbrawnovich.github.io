﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Mouse_IsIn_Window(ThisX, ThisY, ThisClass, TopArea, BottomArea) ; > InWin [X_Pos, Y_Pos]/[0, 0]
{
  ; -------------------------------------------
  ; ThisClass(Class of Window)
  ; TopArea(Area at Top of Window to Ignore as Clickable area)
  ; BottomArea(Area at Bottom of Window to Ignore as Clickable area)
  ; -------------------------------------------
  ifWinExist, ahk_class %ThisClass%
  {
    if !TopArea
    {
      TopArea := 0
    } ; End !TopArea
    if !BottomArea
    {
      BottomArea := 0
    } ; End !BottomArea
    ; -------------------------------------------
    WinActivate, ahk_class %ThisClass%
    ; -------------------------------------------
    X_InWin := 0
    Y_InWin := 0
    ; -------------------------------------------
    WinActivate, ahk_class %ThisClass%
    if (!ThisX or !ThisY)
    {
      CoordMode, Mouse , Window
      MouseGetPos, ThisX, ThisY
    } ; End (!ThisX or !ThisY)
    WinGetPos, X, Y, Width, Height, ahk_class %ThisClass%
    ; -------------------------------------------
    X_Min := 0
    X_Max := Width
    Y_Min := 0 + TopArea
    Y_Max := Height - BottomArea
    ; -------------------------------------------
    if (ThisX >= X_Min && ThisX <= X_Max)
    {
      X_InWin := 1
    } ; End (ThisX >= X_Min && ThisX <= X_Max)
    if (ThisY >= Y_Min && ThisY <= Y_Max)
    {
      Y_InWin := 1
    } ; End (ThisY >= Y_Min && ThisY <= Y_Max)
    ; -------------------------------------------
    if (Y_InWin == 1 && X_InWin == 1)
    {
      InWin := [ThisX, ThisY]
    } ; End (Y_InWin == 1 && X_InWin == 1)
    else
    {
      InWin := [0, 0]
    }
    ; -------------------------------------------
  } ; End WinExist("ahk_class " ThisClass)
  ; -------------------------------------------
  return InWin
  ; -------------------------------------------
}
