﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_135(DataArray) ; (135_1)(GUI Object: Message Image 2)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_135", DataArray) ; (135_1)(GUI Object: Message Image 2)
  ; -------------------------------------------
  if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(Script Type)
  {
    DataArray := f_070(DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
  }
  else if (DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(Script Type)
  {
    DataArray := f_071(DataArray) ; (071_1)(GUI Object: [url] Select URL)
  }
  return DataArray
  ; -------------------------------------------
}
