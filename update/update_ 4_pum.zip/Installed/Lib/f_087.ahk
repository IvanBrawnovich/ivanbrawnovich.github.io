﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_087(DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_087", DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
  ; -------------------------------------------
  if (DataArray.87.2 == 1 && DataArray.302.7 == 1) ; (087_2)([mnu] Select Menu: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(302_7)([mnu] Active Process Has a Addon Installed [0/1])
  {
    ; -------------------------------------------
    DataArray.366.5 := "mnu" ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick Select/UnSelect
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("087", 2, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
      DataArray := GuiControlImage_PopUpMenu("070", 1, 1, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
      DataArray := GuiControlImage_PopUpMenu("085", 1, 1, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
      ; -------------------------------------------
    } ; End Quick Select/UnSelect
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  return DataArray
  ; -------------------------------------------
}
