﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
url_Get_URL_Address(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("url_Get_URL_Address", DataArray)
  ; -------------------------------------------
  ; Get URL from currently Active Browser
  ; -------------------------------------------
  v_367_4 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
  v_367_3 := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
  v_307_2 := GetActiveBrowserURL(v_367_3, v_367_4) ; (307_2)([url] Current URL)/(367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])/(367_4)([Line 3] Active Process Class)
  DataArray.307.2 := v_307_2 ; (307_2)([url] Current URL)
  ; -------------------------------------------
  return DataArray
}
