﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Folder
; -------------------------------------------
f_082(DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_082", DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
  ; ------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; -------------------------------------------
  { ; Quick Select
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
    DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
    DataArray := GuiControlImage_PopUpMenu("082", 2, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
    ; -------------------------------------------
  } ; End Quick Select
  ; -------------------------------------------
  { ; Language Set DialogText [SET] DialogText := "PUM - Shortcut to Folder"
    ; -------------------------------------------
    if (v_365_2 == "de") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Verknüpfung zum Ordner"
    } ; End (de German)
    else if (v_365_2 == "en") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Shortcut to Folder"
    } ; End (en English)
    else if (v_365_2 == "es") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Acceso directo a la carpeta"
    } ; End (es Spanish)
    else if (v_365_2 == "fr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Raccourci vers Folder"
    } ; End (fr French)
    else if (v_365_2 == "it") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Collegamento alla cartella"
    } ; End (it Italian)
    else if (v_365_2 == "pl") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Skrót do folderu"
    } ; End (pl Polish)
    else if (v_365_2 == "pt") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Atalho para pasta"
    } ; End (pt Portuguese)
    else if (v_365_2 == "ru") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Короткий отрезок для Фолдера"
    } ; End (ru Russian)
    else if (v_365_2 == "sv") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Genväg till mapp"
    } ; End (sv Swedish)
    else if (v_365_2 == "tr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Klasöre Kısayol"
    } ; End (tr Turkish)
  } ; End Language Set DialogText [SET] DialogText := "PUM - Shortcut to Folder"
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  FileSelectFolder, v_303_2, , 3 , %DialogText% ; (303_2)([ofl] Folder Path)
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (v_303_2 != "") ; (303_2)([ofl] Folder Path)
  {
    ; -------------------------------------------
    IfInString, v_303_2, %A_ScriptDir% ; (303_2)([ofl] Folder Path)
    {
      ; -------------------------------------------
      ; User has Selected a Folder in Pum Install Dir
      ; Set to ""
      ; -------------------------------------------
      v_303_2 := "" ; (303_2)([ofl] Folder Path)
    } ; End IfInString, ThisFile, %A_ScriptDir%
  } ; (303_2)([ofl] Folder Path)
  ; -------------------------------------------
  ; Check for Last Folder Location
  ; if Exist 
  ; -------------------------------------------
  else if (DataArray.303.2 != "") ; (303_2)([ofl] Folder Path)
  {
    v_303_2 := DataArray.303.2 ; (303_2)([ofl] Folder Path)
  }
  ; -------------------------------------------
  if (v_303_2 != "") ; (303_2)([ofl] Folder Path)
  {
    ; -------------------------------------------
    DataArray.366.5 := "ofl" ; (366_5)(Script Type)
    DataArray.303.2 := v_303_2 ; (303_2)([ofl] Folder Path)
    ; -------------------------------------------
    Reversed_String_1 := String_Reverse(v_303_2) ; (303_2)([ofl] Folder Path)
    Backslash_Position := InStr(Reversed_String_1, "\")
    Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
    v_303_3 := String_Reverse(Reversed_String_2) ; (303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray.303.3 := v_303_3 ; (303_3)([ofl] Folder Name [NO Folder Path])
    DataArray.122.3 := v_303_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray.122.3 := v_303_3 ; (122_3)(<Edit Feild> Status Bar Description: Value)/(303_3)([ofl] Folder Name [NO Folder Path])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------            
  } ; (303_2)([ofl] Folder Path)
  else ; (Folder Path == "")
  {
    ; -------------------------------------------
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick UnSelect
      ; -------------------------------------------
      if (v_366_5 == "run" or v_366_5 == "rwh") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("081", 2, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      ; -------------------------------------------
      if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("071", 2, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      ; -------------------------------------------
      if (v_366_5 == "ofl") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("082", 2, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      ; -------------------------------------------
    } ; End Quick UnSelect
  } ; End (Folder Path == "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
