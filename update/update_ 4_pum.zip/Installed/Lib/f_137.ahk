﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_137(DataArray) ; (137_1)(GUI Object: Message Image 4)
{
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; (450_1)(Last Function [Array])
  ; -------------------------------------------
  DataArray := Function_Flow("f_137", DataArray) ; (137_1)(GUI Object: Message Image 4)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  v_366_6 := DataArray.366.6 ; (366_6)(This Script Error [Integer])
  v_385_4 := DataArray.385.4 ; (385_4)(Application Addon Buy Page [PopUpMenu URL Address])
  ; -------------------------------------------
  ; [(366_6) ScriptError == 5] (Addon Not Installed)(Addon is Available)
  ; -------------------------------------------
  if (v_366_6 == 5) ; (366_6)(This Script Error [Integer])
  {
    ; -------------------------------------------
    ; User Clicked Download Addon
    ; Go to WebSite Addon Page
    ; -------------------------------------------
    v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
    v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    StringLower, ActiveProcess, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    ; -------------------------------------------
    ProcessAddon := ActiveProcess "_" v_365_2 ; (365_2)(Current User language)
    ; -------------------------------------------
    ; Url Buy Download Page for this AddOn
    ThisUrl := v_385_4 ProcessAddon ".html" ; (385_4)(Application Addon Buy Page [PopUpMenu URL Address])
    ; -------------------------------------------
    if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Check for File/Folder/Icon Select dialog exist (Close)
    {
      Pum_Close() ; > Nothing
    } ; End WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
    ; -------------------------------------------
    if WinExist("ahk_class TfrmToolbox") ; Close Any PUM
    {
      Pum_Close() ; > Nothing
    } ; End WinExist("ahk_class TfrmToolbox") 
    ; -------------------------------------------
    Run, %ThisUrl%
    ; -------------------------------------------
  } ; (366_6)(This Script Error [Integer])
  ; -------------------------------------------
  else if (v_366_6 == 17) ; (366_6)(This Script Error [Integer])
  {
    ; -------------------------------------------
    ; (366_6)(This Script Error [Integer])
    ; -------------------------------------------
    DataArray := Application_Request(DataArray)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (366_6)(This Script Error [Integer])
  ; -------------------------------------------
  ;~ Function_Msg(0, DataArray) ; (450)Function Array /  SleepTime, DataArray > Nothing
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
