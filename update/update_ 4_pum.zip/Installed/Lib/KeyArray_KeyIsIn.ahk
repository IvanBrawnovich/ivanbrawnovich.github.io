﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
KeyArray_KeyIsIn(ThisKey, DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("KeyArray_KeyIsIn", DataArray)
  ; -------------------------------------------
  ; Set
  ; (301_4)([key] Key is in KeyArray [0/1])
  ; to 1 or 0
  ; -------------------------------------------
  ; (301_2)([key] KeyArray_Numbers)
  ; (301_4)([key] Key is in KeyArray [0/1])
  ; -------------------------------------------
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  ; -------------------------------------------
  DataArray.301.4 := 0 ; (301_4)([key] Key is in KeyArray [0/1/2])
  ; -------------------------------------------
  if (v_366_5 == "key") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    v_301_2 := DataArray.301.2 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    Ckeck_Array := v_301_2.1 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    if (Ckeck_Array != "") ; Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
    {
      ; -------------------------------------------      
      if (ThisKey == "(050)" or ThisKey == "(052)" or ThisKey == "(053)") ; (Shift)
      {
        ; -------------------------------------------
        ; (050_1)(GUI Object: [key] Shift)
        ; (051_1)(GUI Object: [key] Shift Down)
        ; (052_1)(GUI Object: [key] Shift Left)
        ; (053_1)(GUI Object: [key] Shift Right)
        ; (054_1)(GUI Object: [key] Shift Up)
        ; -------------------------------------------
        CheckArray := ["(050)", "(052)", "(053)"]
        for Index, CheckItem in CheckArray
        {
          CheckIt := Array_Item_Exist(v_301_2, CheckItem) ; (301_2)([key] KeyArray_Numbers [Array])
          if (CheckIt > 0)
          {
            Num_Dn := Array_Item_Exist(v_301_2, "(051)") ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
            Num_Up := Array_Item_Exist(v_301_2, "(054)") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
            if (Num_Dn == Num_Up)
            {
              DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            else
            {
              DataArray.301.4 := 2 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            break
          } ; End (CheckIt > 0)
        } ; End for Index, CheckItem in CheckArray
      } ; End (Shift)
      ; -------------------------------------------
      else if (ThisKey == "(057)" or ThisKey == "(059)" or ThisKey == "(060)") ; (Windows Key)
      {
        ; -------------------------------------------
        ; (057_1)(GUI Object: [key] Windows Key)
        ; (058_1)(GUI Object: [key] Windows Key Down)
        ; (059_1)(GUI Object: [key] Windows Key Left)
        ; (060_1)(GUI Object: [key] Windows Key Right)
        ; (061_1)(GUI Object: [key] Windows Key Up)
        ; -------------------------------------------
        CheckArray := ["(057)", "(059)", "(060)"]
        for Index, CheckItem in CheckArray
        {
          CheckIt := Array_Item_Exist(v_301_2, CheckItem) ; (301_2)([key] KeyArray_Numbers [Array])
          if (CheckIt > 0)
          {
            Num_Dn := Array_Item_Exist(v_301_2, "(058)") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
            Num_Up := Array_Item_Exist(v_301_2, "(061)") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
            if (Num_Dn == Num_Up)
            {
              DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            else
            {
              DataArray.301.4 := 2 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            break
          } ; End (CheckIt > 0)
        } ; End for Index, CheckItem in CheckArray
      } ; End (Windows Key)
      ; -------------------------------------------
      else if (ThisKey == "(074)" or ThisKey == "(015)" or ThisKey == "(016)") ; (Ctrl)
      {
        ; -------------------------------------------
        ; (074_1)(GUI Object: [key] Ctrl)
        ; (014_1)(GUI Object: [key] Ctrl Down)
        ; (015_1)(GUI Object: [key] Ctrl Left)
        ; (016_1)(GUI Object: [key] Ctrl Right)
        ; (017_1)(GUI Object: [key] Ctrl Up)
        ; -------------------------------------------
        CheckArray := ["(074)", "(015)", "(016)"]
        for Index, CheckItem in CheckArray
        {
          CheckIt := Array_Item_Exist(v_301_2, CheckItem) ; (301_2)([key] KeyArray_Numbers [Array])
          if (CheckIt > 0)
          {
            Num_Dn := Array_Item_Exist(v_301_2, "(014)") ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
            Num_Up := Array_Item_Exist(v_301_2, "(017)") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
            if (Num_Dn == Num_Up)
            {
              DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            else
            {
              DataArray.301.4 := 2 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            break
          } ; End (CheckIt > 0)
        } ; End for Index, CheckItem in CheckArray
      } ; End (Ctrl)
      ; -------------------------------------------
      else if (ThisKey == "(008)" or ThisKey == "(010)" or ThisKey == "(011)") ; (Alt)
      {
        ; -------------------------------------------
        ; (008_1)(GUI Object: [key] Alt)
        ; (009_1)(GUI Object: [key] Alt Down)
        ; (010_1)(GUI Object: [key] Alt Left)
        ; (011_1)(GUI Object: [key] Alt Right)
        ; (012_1)(GUI Object: [key] Alt Up)
        ; -------------------------------------------
        CheckArray := ["(008)", "(010)", "(011)"]
        for Index, CheckItem in CheckArray
        {
          CheckIt := Array_Item_Exist(v_301_2, CheckItem) ; (301_2)([key] KeyArray_Numbers [Array])
          if (CheckIt > 0)
          {
            Num_Dn := Array_Item_Exist(v_301_2, "(009)") ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
            Num_Up := Array_Item_Exist(v_301_2, "(012)") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
            if (Num_Dn == Num_Up)
            {
              DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            else
            {
              DataArray.301.4 := 2 ; (301_4)([key] Key is in KeyArray [0/1/2])
            }
            break
          } ; End (CheckIt > 0)
        } ; End for Index, CheckItem in CheckArray
      } ; End (Alt)
      ; -------------------------------------------
      else if (ThisKey == "(018)") ; (Enter)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(018)") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 1 or Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (ThisKey == "(019)") ; (Enter X2)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(018)") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (ThisKey == "(020)") ; (Esc)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(020)") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 1 or Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (ThisKey == "(021)") ; (Esc X2)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(020)") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (ThisKey == "(055)") ; (Tab)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(055)") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 1 or Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (ThisKey == "(056)") ; (Tab X2)
      {
        ; -------------------------------------------
        Check_Num := Array_Item_Exist(v_301_2, "(055)") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
        if (Check_Num == 2)
        {
          DataArray.301.4 := 1 ; (301_4)([key] Key is in KeyArray [0/1/2])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else
      {
        ; -------------------------------------------
        Check_ThisKey := ThisKey
        DataArray.301.4 := Array_Item_Exist(v_301_2, Check_ThisKey) ; (301_4)([key] Key is in KeyArray [0/1/2])/(301_2)([key] KeyArray_Numbers [Array])
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End (Ckeck_Array != "") Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
    ; -------------------------------------------
  } ; (366_5)(Script Type) (key)
  ; -------------------------------------------
  if (DataArray.301.4 != 0 && DataArray.301.4 != 1 && DataArray.301.4 != 2) ; (301_4)([key] Key is in KeyArray [0/1/2])
  {
    DataArray.301.4 := 0 ; (301_4)([key] Key is in KeyArray [0/1/2])
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
