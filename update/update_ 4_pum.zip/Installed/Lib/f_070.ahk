﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_070(DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_070", DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
  ; -------------------------------------------
  v_070_2 := DataArray.70.2 ; (070_2)([cpl] Select Control: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  if (v_070_2 == 1) ; (070_2)([cpl] Select Control: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "cpl" ; (366_5)(Script Type)
    ; -------------------------------------------
    v_386_2 := DataArray.386.2 ; (386_2)(Temporary Icon [System Folder Path])
    Delete_Icons := v_386_2 "\*.ico" ; (386_2)(Temporary Icon [System Folder Path])
    FileDelete, %Delete_Icons%
    ; -------------------------------------------
    { ; Quick Select/UnSelect
      ; -------------------------------------------
      v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
      v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      ; -------------------------------------------
      if (v_367_2 != "Windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      {
        ; -------------------------------------------
        v_302_7 := DataArray.302.7 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        if (v_302_7 == 1) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        {
          DataArray := GuiControlImage_PopUpMenu("087", 1, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
        }
        else if (v_302_7 == 0) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        {
          DataArray := GuiControlImage_PopUpMenu("087", 3, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
        }
        ; -------------------------------------------
      } ; (367_3)(Active Process Name With Ext)
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("070", 2, 1, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
      DataArray := GuiControlImage_PopUpMenu("085", 1, 1, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
      ; -------------------------------------------
    } ; End Quick Select/UnSelect
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (070_2)([cpl] Select Control: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  return DataArray
  ; -------------------------------------------
}
