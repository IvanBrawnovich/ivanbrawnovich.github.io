﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_017(DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_017", DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("017", DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
