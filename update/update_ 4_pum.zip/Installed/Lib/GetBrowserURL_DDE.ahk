﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  (url) GetBrowserURL_DDE
GetBrowserURL_DDE(sExe, sClass)
{
  WinGet, sServer, ProcessName, % "ahk_class " sClass
  StringTrimRight, sServer, sServer, 4
  iCodePage := A_IsUnicode ? 0x04B0 : 0x03EC ; 0x04B0 = CP_WINUNICODE, 0x03EC = CP_WINANSI
  DllCall("DdeInitialize", "UPtrP", idInst, "Uint", 0, "Uint", 0, "Uint", 0)
  hServer := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", sServer, "int", iCodePage)
  hTopic := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", "WWW_GetWindowInfo", "int", iCodePage)
  hItem := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", "0xFFFFFFFF", "int", iCodePage)
  hConv := DllCall("DdeConnect", "UPtr", idInst, "UPtr", hServer, "UPtr", hTopic, "Uint", 0)
  hData := DllCall("DdeClientTransaction", "Uint", 0, "Uint", 0, "UPtr", hConv, "UPtr", hItem, "UInt", 1, "Uint", 0x20B0, "Uint", 10000, "UPtrP", nResult) ; 0x20B0 = XTYP_REQUEST, 10000 = 10s timeout
  sData := DllCall("DdeAccessData", "Uint", hData, "Uint", 0, "Str")
  DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hServer)
  DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hTopic)
  DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hItem)
  DllCall("DdeUnaccessData", "UPtr", hData)
  DllCall("DdeFreeDataHandle", "UPtr", hData)
  DllCall("DdeDisconnect", "UPtr", hConv)
  DllCall("DdeUninitialize", "UPtr", idInst)
  csvWindowInfo := StrGet(&sData, "CP0")
  StringSplit, sWindowInfo, csvWindowInfo, `" ;"; comment to avoid a syntax highlighting issue in autohotkey.com/boards
  return sWindowInfo2
}
