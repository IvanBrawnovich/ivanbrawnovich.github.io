﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_084(DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_084", DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
  ; -------------------------------------------
  v_084_2 := DataArray.84.2 ; (084_2)([ToM] File Url Folder: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_084_2 == 1) ; (084_2)([ToM] File Url Folder: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "run_rwh_url_ofl" ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick Select/UnSelect
      ; -------------------------------------------
      if (DataArray.104.2 == 1) ; (104_2)(<Displayed Text> Bottom 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray.104.2 := 0 ; (104_2)(<Displayed Text> Bottom 1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        GuiControl, PopUpMenu:Hide, g_104,  ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
      }
      if (DataArray.107.2 == 1) ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        GuiControl, PopUpMenu:Hide, g_107,  ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      }
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("081", 1, 1, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      DataArray := GuiControlImage_PopUpMenu("071", 1, 1, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      DataArray := GuiControlImage_PopUpMenu("082", 1, 1, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("084", 2, 1, DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
      DataArray := GuiControlImage_PopUpMenu("086", 1, 1, DataArray) ; (086_1)(GUI Object: [ToM] Menu Control Key)
      DataArray := GuiControlImage_PopUpMenu("083", 1, 0, DataArray) ; (083_1)(GUI Object: [ToM] Pum)
      ; -------------------------------------------
    } ; End Quick Select/UnSelect
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
