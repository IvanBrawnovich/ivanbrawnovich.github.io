﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
#NoTrayIcon
; -------------------------------------------
Loop ; While WinExist("ahk_class TfrmToolbox")
{
  if !WinExist("ahk_class TfrmToolbox")
  {
    ExitApp
  }
}
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; Disable Mouse
^LButton::return ; (Ctrl)(LButton)
!LButton::return ; (Alt)(LButton)
#LButton::return ; (Win)(LButton)  
; (BELOW SEE NOTE) #LButton::return ; (Shift)(LButton)
; -------------------------------------------
^#LButton::return ; (Ctrl)(Win)(LButton)
^+LButton::return ; (Ctrl)(Shift)(LButton)
^!LButton::return ; (Ctrl)(Alt)(LButton)
; -------------------------------------------
^#!LButton::return ; (Ctrl)(Win)(Alt)(LButton)
^#+LButton::return ; (Ctrl)(Win)(Shift)(LButton)
^!+LButton::return ; (Ctrl)(Alt)(Shift)(LButton)
; -------------------------------------------
^!+#LButton::return ; (Ctrl)(Alt)(Shift)(Win)(LButton)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; REMARKED OUT FOR TESTING
; Modified Key Stroke
;~ ~+LButton::
;~ {
  ;~ Send, {Alt Down}
  ;~ while GetKeyState("LButton", "P") ; User is Physically Holding Down Button
  ;~ {
  ;~ } ; End while GetKeyState("LButton", "P")
  ;~ Tooltip
  ;~ Sleep, 500
  ;~ Send, {Alt Up}
;~ }
;~ return ; (Shift)(LButton)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Modified Key Stroke
Alt & Tab::
{
  ; -------------------------------------------
  if WinExist("ahk_class TfrmToolbox") ; Exist PUM
  {
    ; -------------------------------------------
    WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    IfInString, PumProcess, pum_
    {
      Process, Close, %PumProcess%
    } ; End IfInString, PumProcess, pum_
  }
  if WinExist("ahk_class TfrmMain") ; Exist PUM
  {
    WinClose
  }
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
}
return ; (Application Switch)
; -------------------------------------------
