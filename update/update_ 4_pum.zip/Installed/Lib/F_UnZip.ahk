﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
F_UnZip(ZipFile, UnZipDir) ; ZipFile, UnZipDir
{
  ; -------------------------------------------
  /*
    ThisFunction(ZipDir, ZipFile)
    ZipDir = This is a Folder, This "Folder" will be Created in the zip, contianing all files in that Folder
    ZipFile = the File to be Ziped
    
    ThisFunction(ZipFile, UnZipDir)
    ZipFile = the File to be UnZiped
    UnZipDir = Should be one Folder Back,
      The Last Folder from Zip File F_Zip "ZipDir"
      will be created if does not exist
  */
  ; -------------------------------------------
  fso := ComObjCreate("Scripting.FileSystemObject")
  If Not fso.FolderExists(UnZipDir)
  {
    fso.CreateFolder(UnZipDir)
  }
  psh  := ComObjCreate("Shell.Application")
  psh.Namespace( UnZipDir ).CopyHere( psh.Namespace( ZipFile ).items, 4|16 )
  ; -------------------------------------------
}
