﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Shortcut_Info(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("Shortcut_Info", DataArray)
 ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; -------------------------------------------
  { ; Scirpt Model
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ; Script_Line_2 := "#_#_(#)"            (cpl) %(365_2)%_cpl_%(300_2)%_%(300_3)%_(%(300_4)%) "XXX_XXX_(XXX)"
    ; Script_Line_3 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_4 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_5 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_6 := ""                   (cpl) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; Script_Line_2 := 1/2                  (key) (072_2)
    ; Script_Line_3 := ["[Key]", "~X~"]     (key) (301_8)
    ; Script_Line_4 := "App Class"          (key) (301_5)
    ; Script_Line_5 := "App Process"        (key) (301_6)
    ; Script_Line_6 := ""                   (key) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; Script_Line_2 := 2                    (mnu) (072_2) (Always Selected = 2)
    ; Script_Line_3 := "#_#_#_(#)"          (mnu) %(302_2)%_%(302_3)%_%(302_4)%_(%(302_5)%) "XXX_XXX_XXX_(XXX)"
    ; Script_Line_4 := "App Class"          (mnu) (301_5)
    ; Script_Line_5 := "App Process"        (mnu) (301_6)
    ; Script_Line_6 := "Lang"               (mnu) (365_2)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; Script_Line_2 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_3 := "D:\Pictures"        (ofl) (303_2)
    ; Script_Line_4 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_5 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_6 := ""                   (ofl) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    ; Script_Line_3 := "E:\Application.exe" (run) (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    ; Script_Line_4 := ""                   (run) *** EMPTY ***
    ; Script_Line_5 := ""                   (run) *** EMPTY ***
    ; Script_Line_6 := ""                   (run) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    ; Script_Line_3 := "E:\FilePath.EXT"    (rwh) (305_4)([File Name] [File Ext] [File Path])
    ; Script_Line_4 := "C:\Application.exe" (rwh) (305_5)(Selected Opening Application [Full File Path])
    ; Script_Line_5 := ""                   (rwh) *** EMPTY ***
    ; Script_Line_6 := ""                   (rwh) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; -------------------------------------------
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; Script_Line_2 := 0/1                  (url) (307_7)([url] Use Default Browser [0/1])
    ; Script_Line_3 := "https://Site.com/"  (url) (307_2)([url] Current URL)
    ; Script_Line_4 := "C:\Browser.exe"     (url) (307_5)([url] Opening Browser [Full File Path])
    ; Script_Line_5 := ""                   (url) *** EMPTY ***
    ; Script_Line_6 := ""                   (url) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; -------------------------------------------
  } ; End Scirpt Model
  ; -------------------------------------------
  { ; Reset Vars
    ; -------------------------------------------
    DataArray.72.2   := "" ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    DataArray.73.2   := "" ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    DataArray.123.3  := "" ; (123_3)(<Edit Feild> [key] Text Input: Value)
    DataArray.300.2  := "" ; (300_2)([cpl] Menu Number #_X_[X])
    DataArray.300.3  := "" ; (300_3)([cpl] Menu Number X_#_[X])
    DataArray.300.4  := "" ; (300_4)([cpl] Menu Number X_X_[#])
    DataArray.301.2  := "" ; (301_2)([key] KeyArray_Numbers [Array])
    DataArray.301.5  := "" ; (301_5)([key][mnu] [Line 4] Application Only Class)
    DataArray.301.6  := "" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
    DataArray.301.7  := "" ; (301_7)([key] KeyArray_Display [String] [by Lang])
    DataArray.301.8  := "" ; (301_8)([key] KeyArray_Shortcut [Array])
    DataArray.302.2  := "" ; (302_2)([mnu] Menu Number #_X_X_[X])
    DataArray.302.3  := "" ; (302_3)([mnu] Menu Number X_#_X_[X])
    DataArray.302.4  := "" ; (302_4)([mnu] Menu Number X_X_#_[X])
    DataArray.302.5  := "" ; (302_5)([mnu] Menu Number X_X_X_[#])
    DataArray.303.2  := "" ; (303_2)([ofl] Folder Path)
    DataArray.303.3  := "" ; (303_3)([ofl] Folder Name [NO Folder Path])
    DataArray.305.2  := "" ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
    DataArray.305.3  := "" ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
    DataArray.305.4  := "" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    DataArray.305.5  := "" ; (305_5)([rwh] Selected Opening Application [Full File Path])
    DataArray.305.9  := "" ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
    DataArray.305.10 := "" ; (305_10)([run] Selected File [File Ext] WithOut [.])
    DataArray.307.2  := "" ; (307_2)([url] Current URL)
    DataArray.307.5  := "" ; (307_5)([url] Selected Opening Browser [Full File Path])
    DataArray.307.7  := "" ; (307_7)([url] Use Default Browser [0/1])
    DataArray.366.4  := "" ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    ; -------------------------------------------
  } ; End Reset Vars
  ; -------------------------------------------
  { ; StartUp Vars
    ; -------------------------------------------
    v_366_5  := DataArray.366.5 ; (366_5)(Script Type)
    v_370_8  := DataArray.370.8 ; (370_8)(XML_SC_L2 Script [Full File Path])
    ; -------------------------------------------
  } ; End StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; Pum Read Shortcut Script
    ; -------------------------------------------
    FileReadLine, Script_Line_2, %v_370_8%, 2 ; (370_8)(XML_SC_L2 Script [Full File Path])
    FileReadLine, Script_Line_3, %v_370_8%, 3 ; (370_8)(XML_SC_L2 Script [Full File Path])
    FileReadLine, Script_Line_4, %v_370_8%, 4 ; (370_8)(XML_SC_L2 Script [Full File Path])
    FileReadLine, Script_Line_5, %v_370_8%, 5 ; (370_8)(XML_SC_L2 Script [Full File Path])
    FileReadLine, Script_Line_6, %v_370_8%, 6 ; (370_8)(XML_SC_L2 Script [Full File Path])
    ; -------------------------------------------
  } ; End Pum XML Info (<filename>) / Read Script.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (v_366_5 = "cpl") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    ; Script_Line_2 := "#_#_(#)"            (cpl) %(365_2)%_cpl_%(300_2)%_%(300_3)%_(%(300_4)%) "XXX_XXX_(XXX)"
    ; Script_Line_3 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_4 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_5 := ""                   (cpl) *** EMPTY ***
    ; Script_Line_6 := ""                   (cpl) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
    { ; [SET] Var form ScriptFile
      ; -------------------------------------------
      v_300_2 := 0 ; (300_2)([cpl] Menu Number #_X_[X])
      v_300_3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
      v_300_4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
      ; -------------------------------------------
      Menu_Num := SubStr(Script_Line_2, 11)
      Underscore_Position := InStr(Menu_Num, "_")
      MenuNum1_End := Underscore_Position - 1
      v_300_2 := SubStr(Menu_Num, 1, MenuNum1_End) ; (300_2)([cpl] Menu Number #_X_[X])
      Underscore_Position := Underscore_Position + 1
      Menu_Num := SubStr(Menu_Num, Underscore_Position)
      ; -------------------------------------------
      if InStr(Menu_Num, "_")
      {
        Underscore_Position := InStr(Menu_Num, "_")
        MenuNum2_End := Underscore_Position - 1
        v_300_3 := SubStr(Menu_Num, 1, MenuNum2_End) ; (300_3)([cpl] Menu Number X_#_[X])
        Underscore_Position := Underscore_Position + 1
        Menu_Num := SubStr(Menu_Num, Underscore_Position)
        if InStr(Menu_Num, "_")
        {
          Underscore_Position := InStr(Menu_Num, "_")
          MenuNum3_End := Underscore_Position - 1
          v_300_4 := SubStr(Menu_Num, 1, MenuNum3_End) ; (300_4)([cpl] Menu Number X_X_[#])
          Underscore_Position := Underscore_Position + 1
          Menu_Num := SubStr(Menu_Num, Underscore_Position)
          if InStr(Menu_Num, "(")
          {
            Parentheses_Position_1 := InStr(Menu_Num, "(")
            Parentheses_Position_1 := Parentheses_Position_1 + 1
            Parentheses_Position_2 := InStr(Menu_Num, ")")
            v_300_4 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End if InStr(Menu_Num, "(")
        } ; End if InStr(Menu_Num, "_")
        else ; (##)
        {
          if InStr(Menu_Num, "(")
          {
            Parentheses_Position_1 := InStr(Menu_Num, "(")
            Parentheses_Position_1 := Parentheses_Position_1 + 1
            Parentheses_Position_2 := InStr(Menu_Num, ")")
            v_300_4 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End if InStr(Menu_Num, "(")
        } ; End else (##)
      } ; End if InStr(Menu_Num, "_")
      ; -------------------------------------------
      else ; (##)
      {
        if InStr(Menu_Num, "(")
        {
          Parentheses_Position_1 := InStr(Menu_Num, "(")
          Parentheses_Position_1 := Parentheses_Position_1 + 1
          Parentheses_Position_2 := InStr(Menu_Num, ")")
          v_300_4 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (300_4)([cpl] Menu Number X_X_[#])
        } ; End if InStr(Menu_Num, "(")
      } ; End else (##)
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      DataArray.300.2 := v_300_2 ; (300_2)([cpl] Menu Number #_X_[X])
      DataArray.300.3 := v_300_3 ; (300_3)([cpl] Menu Number X_#_[X])
      DataArray.300.4 := v_300_4 ; (300_4)([cpl] Menu Number X_X_[#])
      ; -------------------------------------------
      DataArray.366.4 := 0 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
      ; -------------------------------------------
    } ; End [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(cpl)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "key") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; Script_Line_2 := 1/2                  (key) (072_2)
    ; Script_Line_3 := ["[Key]", "~X~"]     (key) (301_8)
    ; Script_Line_4 := "App Class"          (key) (301_5)
    ; Script_Line_5 := "App Process"        (key) (301_6)
    ; Script_Line_6 := ""                   (key) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile [SET] (301_8)([key] KeyArray_Shortcut [Array])
      ; -------------------------------------------
      v_301_8_Temp := SubStr(Script_Line_3, 9) ; (301_8)([key] KeyArray_Shortcut [Array])
      v_301_8_Temp := SubStr(v_301_2_Temp, 3, StrLen(v_301_2_Temp) - 3) ; (301_8)([key] KeyArray_Shortcut [Array])/(301_2)([key] KeyArray_Numbers [Array])
      ; -------------------------------------------
      v_301_8_Temp := SubStr(Script_Line_3, 9) ; (301_8)([key] KeyArray_Shortcut [Array])
      v_301_8_Temp := SubStr(v_301_8_Temp, 3, StrLen(v_301_8_Temp) - 3) ; (301_8)([key] KeyArray_Shortcut [Array])
      NextKey_Pos := InStr(v_301_8_Temp, "`,") ; (301_8)([key] KeyArray_Shortcut [Array])
      ; -------------------------------------------
      if (NextKey_Pos == 0)
      {
        ThisKey := SubStr(v_301_8_Temp, 2, NextKey_Pos - 1) ; (301_8)([key] KeyArray_Shortcut [Array])
        v_301_8 := Array_Add(v_301_8, ThisKey, "End") ; (301_8)([key] KeyArray_Shortcut [Array])
      }
      else 
      {
        ; -------------------------------------------
        while (NextKey_Pos > 0)
        {
          ThisKey := SubStr(v_301_8_Temp, 2, NextKey_Pos - 3) ; (301_8)([key] KeyArray_Shortcut [Array])
          v_301_8_Temp := SubStr(v_301_8_Temp, NextKey_Pos + 2) ; (301_8)([key] KeyArray_Shortcut [Array])
          v_301_8 := Array_Add(v_301_8, ThisKey, "End") ; (301_8)([key] KeyArray_Shortcut [Array])
          NextKey_Pos := InStr(v_301_8_Temp, "`,") ; (301_8)([key] KeyArray_Shortcut [Array])
          if (NextKey_Pos == 0)
          {
            ThisKey := SubStr(v_301_8_Temp, 2, NextKey_Pos - 1) ; (301_8)([key] KeyArray_Shortcut [Array])
            v_301_8 := Array_Add(v_301_8, ThisKey, "End") ; (301_8)([key] KeyArray_Shortcut [Array])
          }
        } ; End while (NextKey_Pos > 0)
      }
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile [SET] (301_8)([key] KeyArray_Shortcut [Array])
    ; -------------------------------------------
    v_072_2 := Substr(Script_Line_2, 10, 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    v_301_5 := Substr(Script_Line_4, 11, StrLen(Script_Line_4) - 11) ; (301_5)([key][mnu] [Line 4] Application Only Class)
    v_301_6 := Substr(Script_Line_5, 11, StrLen(Script_Line_5) - 11) ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (key)
      DataArray.72.2  := v_072_2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      DataArray.301.5 := v_301_5 ; (301_5)([key][mnu] [Line 4] Application Only Class)
      DataArray.301.6 := v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
      DataArray.301.8 := v_301_8 ; (301_8)([key] KeyArray_Shortcut [Array])
      DataArray.123.3 := v_123_3 ; (123_3)(<Edit Feild> [key] Text Input: Value)
      ; -------------------------------------------
      ; Creates
      ; (301_2)([key] KeyArray_Numbers [Array])
      ; From
      ; (301_8)([key] KeyArray_Keystroke [Array] for Shortcut)
      DataArray := KeyArray_Numbers(DataArray) ; > DataArray
      ; -------------------------------------------
      ; Creates
      ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Display(DataArray) ; > DataArray
      ; -------------------------------------------
      ; (Enable/Disable) (key)            
      ; -------------------------------------------
      ; [SET] Below
      ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
      ; (102_1)(GUI Object: Main Display Icon)
      ; -------------------------------------------
    } ; End ; [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "mnu") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; Script_Line_2 := 2                    (mnu) (072_2) (Always Selected = 2)
    ; Script_Line_3 := "#_#_#_(#)"          (mnu) %(302_2)%_%(302_3)%_%(302_4)%_(%(302_5)%) "XXX_XXX_XXX_(XXX)"
    ; Script_Line_4 := "App Class"          (mnu) (301_5)
    ; Script_Line_5 := "App Process"        (mnu) (301_6)
    ; Script_Line_6 := "Lang"               (mnu) (365_2)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile / (302_2_3_4_5) Menu Number
      ; -------------------------------------------
      v_302_2 := 0 ; (302_2)([mnu] Menu Number #_X_X_[X])
      v_302_3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
      v_302_4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
      v_302_5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      ; -------------------------------------------
      Menu_Num := SubStr(Script_Line_3, 11)
      Underscore_Position := InStr(Menu_Num, "_")
      MenuNum1_End := Underscore_Position - 1
      v_302_2 := SubStr(Menu_Num, 1, MenuNum1_End) ; (302_2)([mnu] Menu Number #_X_X_[X])
      Underscore_Position := Underscore_Position + 1
      Menu_Num := SubStr(Menu_Num, Underscore_Position)
      ; -------------------------------------------
      if InStr(Menu_Num, "_")
      {
        Underscore_Position := InStr(Menu_Num, "_")
        MenuNum2_End := Underscore_Position - 1
        v_302_3 := SubStr(Menu_Num, 1, MenuNum2_End) ; (302_3)([mnu] Menu Number X_#_X_[X])
        Underscore_Position := Underscore_Position + 1
        Menu_Num := SubStr(Menu_Num, Underscore_Position)
        if InStr(Menu_Num, "_")
        {
          Underscore_Position := InStr(Menu_Num, "_")
          MenuNum3_End := Underscore_Position - 1
          v_302_4 := SubStr(Menu_Num, 1, MenuNum3_End) ; (302_4)([mnu] Menu Number X_X_#_[X])
          Underscore_Position := Underscore_Position + 1
          Menu_Num := SubStr(Menu_Num, Underscore_Position)
          if InStr(Menu_Num, "(")
          {
            Parentheses_Position_1 := InStr(Menu_Num, "(")
            Parentheses_Position_1 := Parentheses_Position_1 + 1
            Parentheses_Position_2 := InStr(Menu_Num, ")")
            v_302_5 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End if InStr(Menu_Num, "(")
        } ; End if InStr(Menu_Num, "_")
        else ; (##)
        {
          if InStr(Menu_Num, "(")
          {
            Parentheses_Position_1 := InStr(Menu_Num, "(")
            Parentheses_Position_1 := Parentheses_Position_1 + 1
            Parentheses_Position_2 := InStr(Menu_Num, ")")
            v_302_5 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End if InStr(Menu_Num, "(")
        } ; End else (##)
      } ; End if InStr(Menu_Num, "_")
      ; -------------------------------------------
      else ; (##)
      {
        if InStr(Menu_Num, "(")
        {
          Parentheses_Position_1 := InStr(Menu_Num, "(")
          Parentheses_Position_1 := Parentheses_Position_1 + 1
          Parentheses_Position_2 := InStr(Menu_Num, ")")
          v_302_5 := SubStr(Menu_Num, Parentheses_Position_1, Parentheses_Position_2 - Parentheses_Position_1) ; (302_5)([mnu] Menu Number X_X_X_[#])
        } ; End if InStr(Menu_Num, "(")
      } ; End else (##)
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile / (302_2_3_4_5) Menu Number
    ; -------------------------------------------
    v_072_2 := Substr(Script_Line_2, 10, 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    v_301_5 := Substr(Script_Line_4, 11, StrLen(Script_Line_4) - 11) ; (301_5)([key][mnu] [Line 4] Application Only Class)
    v_301_6 := Substr(Script_Line_5, 11, StrLen(Script_Line_5) - 11) ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (mnu)
      DataArray.302.2 := v_302_2 ; (302_2)([mnu] Menu Number #_X_X_[X])
      DataArray.302.3 := v_302_3 ; (302_3)([mnu] Menu Number X_#_X_[X])
      DataArray.302.4 := v_302_4 ; (302_4)([mnu] Menu Number X_X_#_[X])
      DataArray.302.5 := v_302_5 ; (302_5)([mnu] Menu Number X_X_X_[#])
      ; -------------------------------------------
      DataArray.72.2  := v_072_2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      DataArray.301.5  := v_301_5 ; (301_5)([key][mnu] [Line 4] Application Only Class)
      DataArray.301.6  := v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
      ; -------------------------------------------
      DataArray.366.4 := 0 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
      ; -------------------------------------------
    } ; End [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(mnu)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "ofl") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; Script_Line_2 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_3 := "D:\Pictures"        (ofl) (303_2)
    ; Script_Line_4 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_5 := ""                   (ofl) *** EMPTY ***
    ; Script_Line_6 := ""                   (ofl) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile
      ; -------------------------------------------
      v_303_2 := Substr(Script_Line_3, 11, StrLen(Script_Line_3) - 11) ; (303_2)([ofl] Folder Path)
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (ofl)
      ; -------------------------------------------
      Reversed_String_1 := String_Reverse(v_303_2) ; (303_2)([ofl] Folder Path)
      Backslash_Position := InStr(Reversed_String_1, "\")
      Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
      v_303_3 := String_Reverse(Reversed_String_2) ; (303_3)([ofl] Folder Name [NO Folder Path])
      ; -------------------------------------------
      DataArray.303.2 := v_303_2 ; (303_2)([ofl] Folder Path)
      DataArray.303.3 := v_303_3 ; (303_3)([ofl] Folder Name [NO Folder Path])
      ; -------------------------------------------
    } ; End [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(ofl)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "run") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    ; Script_Line_3 := "E:\Application.exe" (run) (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    ; Script_Line_4 := ""                   (run) *** EMPTY ***
    ; Script_Line_5 := ""                   (run) *** EMPTY ***
    ; Script_Line_6 := ""                   (run) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile
      ; -------------------------------------------
      v_073_2 := Substr(Script_Line_2, 10, 1) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      v_305_4 := Substr(Script_Line_3, 11, StrLen(Script_Line_3) - 11) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (run)
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, v_305_4, v_305_3, v_305_9, v_305_10, v_305_2, ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])/(305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])/(305_10)([run] Selected File [File Ext] WithOut [.])/(305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      ; -------------------------------------------
      v_305_9 := v_305_9 "\" ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
      StringLower, v_305_10, v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
      ; -------------------------------------------
      DataArray.73.2 := v_073_2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      DataArray.305.2 := v_305_2 ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      DataArray.305.3 := v_305_3 ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
      DataArray.305.4 := v_305_4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      DataArray.305.9 := v_305_9 ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
      DataArray.305.10 := v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
      ; -------------------------------------------
    } ; End [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(run)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "rwh") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
    ; Script_Line_3 := "E:\FilePath.EXT"    (rwh) (305_4)([File Name] [File Ext] [File Path])
    ; Script_Line_4 := "C:\Application.exe" (rwh) (305_5)(Selected Opening Application [Full File Path])
    ; Script_Line_5 := ""                   (rwh) *** EMPTY ***
    ; Script_Line_6 := ""                   (rwh) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile
      ; -------------------------------------------
      v_073_2 := Substr(Script_Line_2, 10, 1) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      v_305_4 := Substr(Script_Line_3, 11, StrLen(Script_Line_3) - 11) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      v_305_5 := Substr(Script_Line_4, 11, StrLen(Script_Line_4) - 11) ; (305_5)([rwh] Selected Opening Application [Full File Path])
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (rwh)
      ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
      ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
      ; (305_10)([run] Selected File [File Ext] WithOut [.])
      ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      ;
      ; SplitPath, ThisFilePath , FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, v_305_4, v_305_3, v_305_9, v_305_10, v_305_2, ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])/(305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])/(305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])/(305_10)([run] Selected File [File Ext] WithOut [.])/(305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      ; -------------------------------------------
      v_305_9 := v_305_9 "\" ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
      StringLower, v_305_10, v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
      ; -------------------------------------------
      DataArray.73.2 := v_073_2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      DataArray.305.2 := v_305_2 ; (305_2)([run] Selected File [File Name] / [NO File Ext] [NO File Path])
      DataArray.305.3 := v_305_3 ; (305_3)([run] Selected File [File Name] [File Ext] / [NO File Path])
      DataArray.305.4 := v_305_4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      DataArray.305.5 := v_305_5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
      DataArray.305.9 := v_305_9 ; (305_9)([run] Selected File [Folder Path] With [\] [No File Ext] [No File Name])
      DataArray.305.10 := v_305_10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
      ; -------------------------------------------
      
      ;~ Msg := Msg "(073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)`n"
      ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      
      ;~ Msg := Msg "(073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)`n"
      ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      
      ;~ Tooltip, %Msg%, -100, 200
      ;~ Msg := ""
      
      
      
      
      
      
    } ; End [UPDATE] DataArray
  } ; End (Script Type)(rwh)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (v_366_5 = "url") ; (366_5)(Script Type)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; Script_Line_2 := 0/1                  (url) (307_7)([url] Use Default Browser [0/1])
    ; Script_Line_3 := "https://Site.com/"  (url) (307_2)([url] Current URL)
    ; Script_Line_4 := "C:\Browser.exe"     (url) (307_5)([url] Opening Browser [Full File Path])
    ; Script_Line_5 := ""                   (url) *** EMPTY ***
    ; Script_Line_6 := ""                   (url) *** EMPTY ***
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
    ; -------------------------------------------
    { ; [SET] Var form ScriptFile
      ; -------------------------------------------
      v_307_7 := Substr(Script_Line_2, 10, 1) ; (307_7)([url] Use Default Browser [0/1])
      v_307_2 := Substr(Script_Line_3, 11, StrLen(Script_Line_3) - 11) ; (307_2)([url] Current URL)
      v_307_5 := Substr(Script_Line_4, 11, StrLen(Script_Line_4) - 11) ; (307_5)([url] Selected Opening Browser [Full File Path])
      ; -------------------------------------------
    } ; End [SET] Var form ScriptFile
    ; -------------------------------------------
    { ; [UPDATE] DataArray
      ; -------------------------------------------
      ; (Value) (rwh)
      DataArray.307.7 := v_307_7 ; (307_7)([url] Use Default Browser [0/1])
      DataArray.307.2 := v_307_2 ; (307_2)([url] Current URL)
      DataArray.307.5 := v_305_5 ; (307_5)([url] Selected Opening Browser [Full File Path])/(305_5)([rwh] Selected Opening Application [Full File Path])
      DataArray.307.8 := v_307_2 ; (307_8)([url] Previous URL)/(307_2)([url] Current URL)
      ; -------------------------------------------
    } ; End [UPDATE] DataArray
    ; -------------------------------------------
  } ; End (Script Type)(url)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
