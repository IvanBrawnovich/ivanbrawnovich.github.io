﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_131(DataArray) ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_131", DataArray) ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
  ; -------------------------------------------
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  ; -------------------------------------------
  if (v_366_5 == "url") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    Gui, PopUpMenu:Submit, NoHide
    Pre_Url := DataArray.307.8 ; (307_8)([url] Previous URL)
    ; -------------------------------------------
    ; Edit Feild Current Value
    GuiControlGet, v_131_3, PopUpMenu:, g_131 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
    DataArray.131.3 := v_131_3 ; (131_3)(<Edit Feild> [url] URL Address: Value)
    DataArray.307.2 := v_131_3 ; (307_2)([url] Current URL)/(131_3)(<Edit Feild> [url] URL Address: Value)
    ; -------------------------------------------
    LimitedArray := [["v_137_1"], ["v_004_1"]] ; (137_1)(GUI Object: Message Image 4)/(004_1)(GUI Object: Ok Button)
    DataArray.363.9 := LimitedArray ; (363_9)(Limited DataArray)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (366_5)(Script Type) (key)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; (123)_(---)(Edit Text Input)_(2)Select_(3)Value
