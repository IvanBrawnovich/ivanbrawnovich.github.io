﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
; -------------------------------------------
/*
  ; (384_13)(PopUpMenu [standalone Folder] [Shortcut GUI] [Script File Path])/(363_5)(PC Installed Dir)
  ; Shortcut GUI
  ; in Installed Directory/Lib 
  ; -------------------------------------------
  ; This is to Insure
  ; This File Launcher.ahk
  ; is not ran as from a dubble click
  ; in file explorer
  ; -------------------------------------------
  ; -------------------------------------------
  FontColor := "199524" ; (Green)
  FontColor := "a30404" ; (Red)
  FontColor := "000000" ; (Black)
  FontColor := "921297" ; (Purple)
  FontColor := "040e47" ; (Dark Blue) As Admin Color
  ; -------------------------------------------
*/
; -------------------------------------------
DataArray := DataArray_Set()
; -------------------------------------------
v_363_5  := DataArray.363.5 ; (363_5)(PC Installed Dir)
v_365_2  := DataArray.365.2 ; (365_2)(Current User language)
v_369_8  := DataArray.369.8 ; (369_8)(Tray_Exit.png Icon Tray Menu)
v_369_9  := DataArray.369.9 ; (369_9)(Tray_HotKey.png Icon Tray Menu)
v_369_10 := DataArray.369.10 ; (369_10)(PopUpMenu.png Icon Tray Menu)
v_380_5  := DataArray.380.5 ; (380_5)(PC Benchmark [System Text File Path])
; -------------------------------------------
; -------------------------------------------
{ ; Tray Icon Menu / Launcher Hot Key
  ; -------------------------------------------
  { ; Set Language for Menu Items
    ; -------------------------------------------
    if (v_365_2 == "de") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0048}{U+006F}{U+0074}{U+0020}{U+004B}{U+0065}{U+0079}{U+0020}{U+00C4}{U+006E}{U+0064}{U+0065}{U+0072}{U+006E}")
      MenuText_Exit := Unicode_To_String("{U+0042}{U+0065}{U+0065}{U+006E}{U+0064}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "en") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0043}{U+0068}{U+0061}{U+006E}{U+0067}{U+0065}{U+0020}{U+0048}{U+006F}{U+0074}{U+0020}{U+004B}{U+0065}{U+0079}")
      MenuText_Exit := Unicode_To_String("{U+0045}{U+0078}{U+0069}{U+0074}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "es") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0072}{U+0020}{U+0074}{U+0065}{U+0063}{U+006C}{U+0061}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0063}{U+0063}{U+0065}{U+0073}{U+006F}{U+0020}{U+0072}{U+00E1}{U+0070}{U+0069}{U+0064}{U+006F}")
      MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+006C}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "fr") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0043}{U+0068}{U+0061}{U+006E}{U+0067}{U+0065}{U+0072}{U+0020}{U+004C}{U+0061}{U+0020}{U+0054}{U+006F}{U+0075}{U+0063}{U+0068}{U+0065}{U+0020}{U+0044}{U+0065}{U+0020}{U+0052}{U+0061}{U+0063}{U+0063}{U+006F}{U+0075}{U+0072}{U+0063}{U+0069}")
      MenuText_Exit := Unicode_To_String("{U+0051}{U+0075}{U+0069}{U+0074}{U+0074}{U+0065}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "it") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0020}{U+0054}{U+0061}{U+0073}{U+0074}{U+006F}{U+0020}{U+0044}{U+0069}{U+0020}{U+0053}{U+0063}{U+0065}{U+006C}{U+0074}{U+0061}{U+0020}{U+0052}{U+0061}{U+0070}{U+0069}{U+0064}{U+0061}")
      MenuText_Exit := Unicode_To_String("{U+0045}{U+0073}{U+0063}{U+0069}{U+0020}{U+0064}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "pl") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+005A}{U+006D}{U+0069}{U+0065}{U+0144}{U+0020}{U+006B}{U+006C}{U+0061}{U+0077}{U+0069}{U+0073}{U+007A}{U+0020}{U+0067}{U+006F}{U+0072}{U+0105}{U+0063}{U+0061}")
      MenuText_Exit := Unicode_To_String("{U+0057}{U+0079}{U+006A}{U+0064}{U+017A}{U+0020}{U+007A}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "pt") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+}{U+006C}{U+0074}{U+0065}{U+0072}{U+0061}{U+0072}{U+0020}{U+0063}{U+0068}{U+0061}{U+0076}{U+0065}{U+0020}{U+0071}{U+0075}{U+0065}{U+006E}{U+0074}{U+0065}")
      MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "ru") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+0418}{U+0437}{U+043C}{U+0435}{U+043D}{U+0438}{U+0442}{U+044C}{U+0020}{U+0413}{U+043E}{U+0440}{U+044F}{U+0447}{U+0443}{U+044E}{U+0020}{U+041A}{U+043B}{U+0430}{U+0432}{U+0438}{U+0448}{U+0443}")
      MenuText_Exit := Unicode_To_String("{U+0412}{U+044B}{U+0445}{U+043E}{U+0434}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "sv") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+00C4}{U+006E}{U+0064}{U+0072}{U+0061}{U+0020}{U+0068}{U+0065}{U+0074}{U+0061}{U+0020}{U+006E}{U+0079}{U+0063}{U+006B}{U+0065}{U+006C}{U+006E}")
      MenuText_Exit := Unicode_To_String("{U+}{U+0076}{U+0073}{U+006C}{U+0075}{U+0074}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
    }
    else if (v_365_2 == "tr") ; (365_2)(Current User language)
    {
      MenuText_HotKey := Unicode_To_String("{U+004B}{U+0131}{U+0073}{U+0061}{U+0079}{U+006F}{U+006C}{U+0020}{U+0054}{U+0075}{U+015F}{U+0075}{U+006E}{U+0075}{U+0020}{U+0044}{U+0065}{U+011F}{U+0069}{U+015F}{U+0074}{U+0069}{U+0072}")
      MenuText_Exit := Unicode_To_String("{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}{U+0027}{U+0064}{U+0065}{U+006E}{U+0020}{U+00E7}{U+0131}{U+006B}")
    }
    ; -------------------------------------------
  } ; End Set Language for Menu Items
  ; -------------------------------------------
  Pc_TxtFile_UserHotKey := A_AppData "\PopUpMenu_PUM\system\User_HotKey.txt" ; (381_3)(User HotKey Text File [User Text File Path])
  FileReadLine, PumLaunch_Hotkey, %Pc_TxtFile_UserHotKey%, 1
  Hotkey, %PumLaunch_Hotkey%, PumLaunch
  Menu, Tray, NoStandard
  Menu, Tray, Add, %MenuText_HotKey%, Label_SetHotkey
  Menu, Tray, Add, %MenuText_Exit%, Label_Exit
  Menu, Tray, Icon, %MenuText_HotKey%, %v_369_9% ; (369_9)(Tray_HotKey.png Icon Tray Menu)
  Menu, Tray, Icon, %MenuText_Exit%, %v_369_8% ; (369_8)(Tray_Exit.png Icon Tray Menu)
  Menu, Tray, Default, %MenuText_Exit%
  Menu, Tray, Icon, %v_369_10% ; (369_10)(PopUpMenu.png Icon Tray Menu)
  ; -------------------------------------------
  return
  ; -------------------------------------------
} ; End Tray Icon Menu / Launcher Hot Key
; -------------------------------------------
{ ; Labels
  ; -------------------------------------------
  PumLaunch: ; Uses User Specified Pum Launch HotKey
  {
    ; -------------------------------------------
    SetTitleMatchMode, 1
    ; -------------------------------------------
    if WinExist("PUM -" . "ahk_class #32770") ; File or Folder Dialogbox
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
      {
        ; -------------------------------------------
        WinGet, Gui_Id, ID , A
        WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End "PUM -"
    else if WinExist("Browse For Folder" . "ahk_class #32770") ; File or Folder Dialogbox
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
      {
        ; -------------------------------------------
        WinGet, Gui_Id, ID , A
        WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End "Browse For Folder"
    else if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; File or Folder Dialogbox
    {
      Pum_Close()
    } ; End WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
    else if WinExist("ahk_class TfrmToolbox") ; Exist PUM
    {
      ; -------------------------------------------
      Pum_Close()
      ; -------------------------------------------
    } ; End WinExist("ahk_class TfrmToolbox")
    ; -------------------------------------------
    else ; Pum Not Active
    {
      ; -------------------------------------------
      ; ORG
      Pum_Run() ; > Nothing
      ; -------------------------------------------
    } ; End Pum Not Active
    ; -------------------------------------------
  } ; End PumLunch:
  return  
  ; -------------------------------------------
  Label_SetHotkey:
  {
    ; -------------------------------------------
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\Lib"
    }
    Disable_KeySelect  := Script_Dir "\Disable_KeySelect.ahk"
    Script_Close(Disable_KeySelect) ; (384_1)(Disable_KeySelect.ahk)
    ; -------------------------------------------
    DataArray := Hotkey_gui(DataArray)
    ; (384_9)(HotKey_gui.ahk [Set User Hotkey] [Script File Path])
    ; -------------------------------------------
  } ; End Label_SetHotkey:
  return
  ; -------------------------------------------
  Label_Exit:
  {
    ; -------------------------------------------
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\Lib"
    }
    ; -------------------------------------------
    Disable_Persistent := Script_Dir "\Disable_Persistent.ahk"
    Disable_Gui        := Script_Dir "\Disable_Gui.ahk"
    Disable_Ofl        := Script_Dir "\Disable_Ofl.ahk"
    Disable_Run        := Script_Dir "\Disable_Run.ahk"
    Disable_KeyDia     := Script_Dir "\Disable_KeyDia.ahk"
    Disable_KeyGui     := Script_Dir "\Disable_KeyGui.ahk"
    Disable_KeySelect  := Script_Dir "\Disable_KeySelect.ahk"
    Disable_KeyPum     := Script_Dir "\Disable_KeyPum.ahk"
    ; -------------------------------------------
    while (Is_Script_Running(Disable_Persistent) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_Persistent% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_Gui) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_Gui% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_Ofl) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_Ofl% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_Run) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_Run% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_KeyDia) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_KeyDia% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_KeyGui) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_KeyGui% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_KeySelect) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_KeySelect% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_KeyPum) > 0)
    {
      DetectHiddenWindows, On
      WinClose, %Disable_KeyPum% ahk_class AutoHotkey
    }
    ; -------------------------------------------
    ; Delete Old Benchmark File
    if FileExist(v_380_5) ; (380_5)(PC Benchmark [System Text File Path])
    {
      FileDelete, %v_380_5% ; (380_5)(PC Benchmark [System Text File Path])
    } ; End FileExist
    ; -------------------------------------------
    ;
    ;
    Script_Close(DataArray.384.7) ; (384_7)(HotKey_AppSpicific [Script File Path])
    Script_Close(DataArray.384.2) ; (384_2)(Empty)
    Script_Close(DataArray.384.8) ; (384_8)(Launcher [Script File Path])
    ;
    Script_Close(DataArray.384.9) ; (384_9)(HotKey_gui [Script File Path])
    ;
    ; -------------------------------------------
    ;~ Splash_Script("Off", 0)
    ; -------------------------------------------
    SetTitleMatchMode, 2
    ; -------------------------------------------
    WinSet, AlwaysOnTop, Off, ahk_class TfrmToolbox
    WinSet, AlwaysOnTop, Off, ahk_class AutoHotkeyGUI
    ; -------------------------------------------
    if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Check for File/Folder/Icon Select dialog exist (Close)
    {
      WinClose
      WinGet, Pum, ProcessName, ahk_class #32770
      if (Pum == "AutoHotkey.exe")
      {
        WinClose, ahk_class #32770
      } ; End if Pum
    } ; End Check for File/Folder/Icon Select dialog exist (Close)
    ; -------------------------------------------
    if WinExist("ahk_class TfrmToolbox") ; Close Any PUM
    {
      WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
      IfInString, PumProcess, pum_
      {
        Process, Close, %PumProcess%
      } ; End IfInString, PumProcess, pum_
    } ; End if WinExist("ahk_class TfrmToolbox")
    ; -------------------------------------------
    ExitApp ; Close (This Script) PopUpMenuGui.ahk/exe
    ; -------------------------------------------
  } ; End Label_Exit:
  return
  ; -------------------------------------------
} ; End Labels
; -------------------------------------------
{ ; Standard HotKeys
  ~Esc::
  {
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Script_Close(Disable_KeySelect)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    SetTitleMatchMode, 1
    ; -------------------------------------------
    if WinExist("PUM -" . "ahk_class #32770") ; File or Folder Dialogbox
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
      {
        ; -------------------------------------------
        WinGet, Gui_Id, ID , A
        WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End "PUM -"
    else if WinExist("Browse For Folder" . "ahk_class #32770") ; File or Folder Dialogbox
    {
      ; -------------------------------------------
      WinClose
      ; -------------------------------------------
      if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
      {
        ; -------------------------------------------
        WinGet, Gui_Id, ID , A
        WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End "Browse For Folder"
    else if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; File or Folder Dialogbox
    {
      Pum_Close() ; > Nothing
    } ; End WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
    else if WinExist("HotKey PopUpMenu") ; File or Folder Dialogbox
    {
      DataArray := HotKey_Cancel(DataArray) ; > DataArray
      Pum_Close() ; > Nothing
    } ; End WinExist("HotKey PopUpMenu")
    else if WinExist("ahk_class TfrmToolbox") ; Exist PUM
    {
      Pum_Close() ; > Nothing
    } ; End WinExist("ahk_class TfrmToolbox")
    ; -------------------------------------------
  } ; End ~Esc::
  return
  ; -------------------------------------------
  ~Lbutton::
  {
    ; -------------------------------------------
    SetTitleMatchMode, 2
    ; -------------------------------------------  
    if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Keep Shortcut Gui Active
    {
      ; -------------------------------------------
      WinSet, Disable ,, ahk_class TfrmToolbox
      ; -------------------------------------------
      While GetKeyState("LButton","P") ; User is Physically Holding Down Button
      {
        SetTitleMatchMode, 2
        if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Keep Shortcut Gui Active
        {
          WinActivate
        } ; End ("PopUpMenu" . "ahk_class AutoHotkeyGUI")
      } ; End While GetKeyState("LButton","P")
      ; -------------------------------------------
    } ; End WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
    ; -------------------------------------------
    else if WinExist("ahk_class TfrmToolbox") ; Exist PUM
    {
      ; -------------------------------------------
      WinSet, Enable ,, ahk_class TfrmToolbox
      ; -------------------------------------------
      DataArray.361.17 := 1 ; (361_17)(LButton Was Clicked [0/1])
      ; -------------------------------------------
      DataArray := Existing_Shortcut(DataArray) ; > DataArray
      ; -------------------------------------------
      v_361_2 := DataArray.361.2 ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
      if (v_361_2.1 == 0) ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
      {
        Pum_Close() ; > Nothing
      } ; End Mouse Click NOT in PUM (Close PUM)
      else
      {
        ; -------------------------------------------
        v_370_1 := DataArray.370.1 ; (370_1)(XML_SC Line Numer)
        ; -------------------------------------------
        if (v_370_1 == 0 or v_370_1 == -1) ; (370_1)(XML_SC Line Numer)
        {
          Pum_Close() ; > Nothing
        } ; End Mouse Click Over Empty PUM Grid  (Close PUM)
      } ; End Mouse Click in PUM
    } ; End else if WinExist("ahk_class TfrmToolbox") ; Exist PUM
    ; -------------------------------------------
  } ; End ~Lbutton::
  return      
  ; -------------------------------------------
  ~Rbutton::
  {
    ; -------------------------------------------
    if WinExist("ahk_class TfrmToolbox") ; Exist PUM
    {
      ; -------------------------------------------
      DataArray.361.17 := 0 ; (361_17)(LButton Was Clicked [0/1])
      ; -------------------------------------------
      if WinActive("ahk_class TfrmToolbox") ; Exist PUM
      {
        WinGetActiveStats, A, v_361_5, v_361_6, X, Y ; (361_5)(Pum Actual Window Width [pixels])/(361_6)(Pum Actual Window Height [pixels])
        DataArray.361.5 := v_361_5 ; (361_5)(Pum Actual Window Width [pixels])
        DataArray.361.6 := v_361_6 ; (361_6)(Pum Actual Window Height [pixels])
      }
      ; -------------------------------------------
      DataArray := Existing_Shortcut(DataArray) ; > DataArray      
      ; -------------------------------------------
      v_361_2 := DataArray.361.2 ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
      if (v_361_2.1 == 0) ; (361_2)(Mouse Position in Pum [(X_Pos), (Y_Pos) / [0, 0])
      {
        ; -------------------------------------------
        Pum_Close() ; > Nothing
        ; -------------------------------------------
      } ; End Mouse Click NOT in PUM (Close PUM)
      else ; Mouse Click in PUM
      {
        v_370_1 := DataArray.370.1 ; (370_1)(XML_SC Line Numer)
        if (v_370_1 == -1) ; (370_1)(XML_SC Line Numer)
        {
          ; -------------------------------------------
          Pum_Close() ; > Nothing
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          GetKeyState, KeyState, RButton
          if (KeyState = "D")
          {
            Send, {RButton Up}
          } ; End (KeyState = "D")
          ; -------------------------------------------
          v_380_4 := DataArray.380.4 ; (380_4)(Active Application [System Text File Path])
          ; -------------------------------------------
          FileReadLine, v_367_2, %v_380_4%, 1 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(380_4)(Active Application [System Text File Path])
          FileReadLine, v_367_3, %v_380_4%, 2 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])/(380_4)(Active Application [System Text File Path])
          FileReadLine, v_367_4, %v_380_4%, 3 ; (367_4)([Line 3] Active Process Class)/(380_4)(Active Application [System Text File Path])
          FileReadLine, v_367_5, %v_380_4%, 4 ; (367_5)([Line 4] Active Process Title)/(380_4)(Active Application [System Text File Path])
          FileReadLine, v_367_6, %v_380_4%, 5 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])/(380_4)(Active Application [System Text File Path])
          FileReadLine, v_367_7, %v_380_4%, 6 ; (367_7)([Line 6] Active Process Version)/(380_4)(Active Application [System Text File Path])
          ; -------------------------------------------
          DataArray.367.2 := v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
          DataArray.367.3 := v_367_3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
          DataArray.367.4 := v_367_4 ; (367_4)([Line 3] Active Process Class)
          DataArray.367.5 := v_367_5 ; (367_5)([Line 4] Active Process Title)
          DataArray.367.6 := v_367_6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
          DataArray.367.7 := v_367_7 ; (367_7)([Line 6] Active Process Version)
          ; -------------------------------------------
          DataArray.450 := "" ; (450_1)(Last Function [Array])
          DataArray := gui_Shortcut(DataArray) ; > DataArray
          ; -------------------------------------------
        } ; End (370_1)(XML_SC Line Numer) (== -1) Mouse Click over Title Bar or Status Bar
      } ; End Mouse Click in PUM
      ; -------------------------------------------
    } ; End else if WinExist("ahk_class TfrmToolbox")
    ; -------------------------------------------
  } ; End ~Rbutton::
  return        
  ; -------------------------------------------
} ; End Standard HotKeys
; -------------------------------------------
{ ; gui_Shortcut
  ; -------------------------------------------
  gui_Shortcut(DataArray) ; > DataArray
  {
    ; -------------------------------------------
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    DataArray := Function_Flow("gui_Shortcut", DataArray)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; [GET] Process Info
      v_380_4  := DataArray.380.4 ; (380_4)(Active Application [System Text File Path])
      if FileExist(v_380_4) ; (380_4)(Active Application [System Text File Path])
      {
        ; -------------------------------------------
        FileReadLine, v_367_2, %v_380_4%, 1 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(380_4)(Active Application [System Text File Path])
        FileReadLine, v_367_3, %v_380_4%, 2 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])/(380_4)(Active Application [System Text File Path])
        FileReadLine, v_367_4, %v_380_4%, 3 ; (367_4)([Line 3] Active Process Class)/(380_4)(Active Application [System Text File Path])
        FileReadLine, v_367_5, %v_380_4%, 4 ; (367_5)([Line 4] Active Process Title)/(380_4)(Active Application [System Text File Path])
        FileReadLine, v_367_6, %v_380_4%, 5 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])/(380_4)(Active Application [System Text File Path])
        FileReadLine, v_367_7, %v_380_4%, 6 ; (367_7)([Line 6] Active Process Version)/(380_4)(Active Application [System Text File Path])
        ; -------------------------------------------
        DataArray.367.2 := v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
        DataArray.367.3 := v_367_3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
        DataArray.367.4 := v_367_4 ; (367_4)([Line 3] Active Process Class)
        DataArray.367.5 := v_367_5 ; (367_5)([Line 4] Active Process Title)
        DataArray.367.6 := v_367_6 ; (367_6)([Line 5] Active Process [File Name] [File Ext] [File Path])
        DataArray.367.7 := v_367_7 ; (367_7)([Line 6] Active Process Version)
        ; -------------------------------------------
      }
    } ; End [GET] Process Info
    ; -------------------------------------------
    WinSet, Disable ,, ahk_class TfrmToolbox
    WinSet, AlwaysOnTop, Off, ahk_class TfrmToolbox
    ; -------------------------------------------
    { ; [SET] global Var(s)
      ; -------------------------------------------
      global g_001 ; (001_1)(GUI Object: [run][rwh] First App Icon)
      global g_002 ; (002_1)(GUI Object: [run][rwh] Second App Icon)
      global g_003 ; (003_1)(GUI Object: [run][rwh] Third App Icon)
      global g_004 ; (004_1)(GUI Object: Ok Button)
      global g_005 ; (005_1)(GUI Object: Icon Rotate Left)
      global g_006 ; (006_1)(GUI Object: Icon Rotate Right)
      global g_007 ; (007_1)(GUI Object: Icon Image 4)
      global g_008 ; (008_1)(GUI Object: [key] Alt)
      global g_009 ; (009_1)(GUI Object: [key] Alt Down)
      global g_010 ; (010_1)(GUI Object: [key] Alt Left)
      global g_011 ; (011_1)(GUI Object: [key] Alt Right)
      global g_012 ; (012_1)(GUI Object: [key] Alt Up)
      global g_013 ; (013_1)(GUI Object: [key] Caps Lock)
      global g_014 ; (014_1)(GUI Object: [key] Ctrl Down)
      global g_015 ; (015_1)(GUI Object: [key] Ctrl Left)
      global g_016 ; (016_1)(GUI Object: [key] Ctrl Right)
      global g_017 ; (017_1)(GUI Object: [key] Ctrl Up)
      global g_018 ; (018_1)(GUI Object: [key] Enter)
      global g_019 ; (019_1)(GUI Object: [key] Enter X2)
      global g_020 ; (020_1)(GUI Object: [key] Esc)
      global g_021 ; (021_1)(GUI Object: [key] Esc X2)
      global g_022 ; (022_1)(GUI Object: [key] F1)
      global g_023 ; (023_1)(GUI Object: [key] F2)
      global g_024 ; (024_1)(GUI Object: [key] F3)
      global g_025 ; (025_1)(GUI Object: [key] F4)
      global g_026 ; (026_1)(GUI Object: [key] F5)
      global g_027 ; (027_1)(GUI Object: [key] F6)
      global g_028 ; (028_1)(GUI Object: [key] F7)
      global g_029 ; (029_1)(GUI Object: [key] F8)
      global g_030 ; (030_1)(GUI Object: [key] F9)
      global g_031 ; (031_1)(GUI Object: [key] F10)
      global g_032 ; (032_1)(GUI Object: [key] F11)
      global g_033 ; (033_1)(GUI Object: [key] F12)
      global g_034 ; (034_1)(GUI Object: [key] Numpad 0)
      global g_035 ; (035_1)(GUI Object: [key] Numpad 1)
      global g_036 ; (036_1)(GUI Object: [key] Numpad 2)
      global g_037 ; (037_1)(GUI Object: [key] Numpad 3)
      global g_038 ; (038_1)(GUI Object: [key] Numpad 4)
      global g_039 ; (039_1)(GUI Object: [key] Numpad 5)
      global g_040 ; (040_1)(GUI Object: [key] Numpad 6)
      global g_041 ; (041_1)(GUI Object: [key] Numpad 7)
      global g_042 ; (042_1)(GUI Object: [key] Numpad 8)
      global g_043 ; (043_1)(GUI Object: [key] Numpad 9)
      global g_044 ; (044_1)(GUI Object: [key] Numpad Add)
      global g_045 ; (045_1)(GUI Object: [key] Numpad Divide)
      global g_046 ; (046_1)(GUI Object: [key] Numpad Dot)
      global g_047 ; (047_1)(GUI Object: [key] Numpad Enter)
      global g_048 ; (048_1)(GUI Object: [key] Numpad Multiply)
      global g_049 ; (049_1)(GUI Object: [key] Numpad Subtract)
      global g_050 ; (050_1)(GUI Object: [key] Shift)
      global g_051 ; (051_1)(GUI Object: [key] Shift Down)
      global g_052 ; (052_1)(GUI Object: [key] Shift Left)
      global g_053 ; (053_1)(GUI Object: [key] Shift Right)
      global g_054 ; (054_1)(GUI Object: [key] Shift Up)
      global g_055 ; (055_1)(GUI Object: [key] Tab)
      global g_056 ; (056_1)(GUI Object: [key] Tab X2)
      global g_057 ; (057_1)(GUI Object: [key] Windows Key)
      global g_058 ; (058_1)(GUI Object: [key] Windows Key Down)
      global g_059 ; (059_1)(GUI Object: [key] Windows Key Left)
      global g_060 ; (060_1)(GUI Object: [key] Windows Key Right)
      global g_061 ; (061_1)(GUI Object: [key] Windows Key Up)
      global g_062 ; (062_1)(GUI Object: Cancel)
      global g_063 ; (063_1)(GUI Object: Select Icon Image)
      global g_064 ; (064_1)(GUI Object: Reset Icon Image)
      global g_065 ; (065_1)(GUI Object: <Image Text> Status Bar Description)
      global g_066 ; (066_1)(GUI Object: <Image Text> Text Input)
      global g_067 ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
      global g_068 ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
      global g_069 ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
      global g_070 ; (070_1)(GUI Object: [cpl] Select Control)
      global g_071 ; (071_1)(GUI Object: [url] Select URL)
      global g_072 ; (072_1)(GUI Object: [key] Application Only)
      global g_073 ; (073_1)(GUI Object: [run] As Admin)
      global g_074 ; (074_1)(GUI Object: [key] Ctrl)
      global g_075 ; (075_1)(GUI Object: [key] Delete)
      global g_076 ; (076_1)(GUI Object: [key] End)
      global g_077 ; (077_1)(GUI Object: [key] Home)
      global g_078 ; (078_1)(GUI Object: [key] Insert)
      global g_079 ; (079_1)(GUI Object: [key] Page Down)
      global g_080 ; (080_1)(GUI Object: [key] Page Up)
      global g_081 ; (081_1)(GUI Object: [run][rwh] Select File)
      global g_082 ; (082_1)(GUI Object: [ofl] Select Folder)
      global g_083 ; (083_1)(GUI Object: [ToM] Pum)
      global g_084 ; (084_1)(GUI Object: [ToM] File Url Folder)
      global g_085 ; (085_1)(GUI Object: [key] Select Keyboard)
      global g_086 ; (086_1)(GUI Object: [ToM] Menu Control Key)
      global g_087 ; (087_1)(GUI Object: [mnu] Select Menu)
      global g_088 ; (088_1)(GUI Object: [mnu] App Context Menu 1)
      global g_089 ; (089_1)(GUI Object: [mnu] App Context Menu 2)
      global g_090 ; (090_1)(GUI Object: [mnu] App Context Menu 3)
      global g_091 ; (091_1)(GUI Object: [mnu] App Context Menu 4)
      global g_092 ; (092_1)(GUI Object: [mnu] App Context Menu 5)
      global g_093 ; (093_1)(GUI Object: [mnu] App Context Menu 6)
      global g_094 ; (094_1)(GUI Object: [mnu] App Context Menu 7)
      global g_095 ; (095_1)(GUI Object: [mnu] App Context Menu 8)
      global g_096 ; (096_1)(GUI Object: [mnu] App Context Menu 9)
      global g_097 ; (097_1)(GUI Object: [mnu] App Context Menu 10)
      global g_098 ; (098_1)(GUI Object: [mnu] App Context Menu 11)
      global g_099 ; (099_1)(GUI Object: Web Site Image Link)
      global g_100 ; (100_1)(GUI Object: <Displayed Text> Top 1)
      global g_101 ; (101_1)(GUI Object: Language Flag)
      global g_102 ; (102_1)(GUI Object: Main Display Icon)
      global g_103 ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
      global g_104 ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
      global g_105 ; (105_1)(GUI Object: <Displayed Text> Top 2)
      global g_106 ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
      global g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      global g_108 ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
      global g_109 ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
      global g_110 ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
      global g_111 ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
      global g_112 ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
      global g_113 ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
      global g_114 ; (114_1)(GUI Object: <Displayed Text> Title 1)
      global g_115 ; (115_1)(GUI Object: <Displayed Text> Title 2)
      global g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
      global g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
      global g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
      global g_119 ; (119_1)(Empty)
      global g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
      global g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
      global g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
      global g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      global g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
      global g_125 ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
      global g_126 ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
      global g_127 ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
      global g_128 ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
      global g_129 ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
      global g_130 ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
      global g_131 ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
      global g_132 ; (132_1)(GUI Object: [url] Select Get URL Data)
      global g_133 ; (133_1)(GUI Object: Delete Shortcut)
      global g_134 ; (134_1)(GUI Object: Message Image 1)
      global g_135 ; (135_1)(GUI Object: Message Image 2)
      global g_136 ; (136_1)(GUI Object: Message Image 3)
      global g_137 ; (137_1)(GUI Object: Message Image 4)
      global g_138 ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
      global g_139 ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
      global g_140 ; (140_1)(GUI Object: [mnu] Addon Extra)
      global g_141 ; (141_1)(GUI Object: <Displayed Text> Title 3)
      global g_142 ; (142_1)(GUI Object: HotKey Select Mouse Left)
      global g_143 ; (143_1)(GUI Object: HotKey Select Mouse Right)
      global g_144 ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      global g_145 ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      global g_146 ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      global g_147 ; (147_1)(GUI Object: HotKey Select Mouse X1)
      global g_148 ; (148_1)(GUI Object: HotKey Select Mouse X2)
      global g_149 ; (149_1)(GUI Object: HotKey Windows Key Left)
      global g_150 ; (150_1)(GUI Object: HotKey Windows Key Right)
      global g_151 ; (151_1)(GUI Object: HotKey Ctrl Key)
      global g_152 ; (152_1)(GUI Object: HotKey Alt Key)
      global g_153 ; (153_1)(GUI Object: HotKey Shift Key)
      global g_154 ; (154_1)(GUI Object: [pum] Pum Select Background)
      global g_155 ; (155_1)(GUI Object: [pum] Pum Select Display Text)
      global g_156 ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
      global g_157 ; (157_1)(GUI Object: [pum] Pum Select Settings)
      global g_158 ; (158_1)(GUI Object: [pum] Pum Shortcut)
      global g_159 ; (159_1)(GUI Object: [pum] Select Custom Pum)
      global g_160 ; (160_1)(GUI Object: [pum] Select Application Pum)
      global g_161 ; (161_1)(GUI Object: [pum] Delete Pum)
      global g_162 ; (162_1)(GUI Object: Message Image 5)
      global g_163 ; (163_1)(GUI Object: Message Image 6)
      global g_164 ; (164_1)(GUI Object: Message Image 7)
      global g_165 ; (165_1)(GUI Object: [pum] Backgroung Image Select)
      global g_166 ; (166_1)(GUI Object: [pum] Backgroung Color Select)
      global g_167 ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
      global g_168 ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
      global g_169 ; Var_Number_Error
      global g_170 ; Var_Number_Error
      global g_171 ; Var_Number_Error
      global g_172 ; Var_Number_Error
      global g_173 ; Var_Number_Error
      global g_174 ; Var_Number_Error
      global g_175 ; Var_Number_Error
      global g_176 ; Var_Number_Error
      global g_177 ; Var_Number_Error
      global g_178 ; Var_Number_Error
      global g_179 ; Var_Number_Error
      global g_180 ; Var_Number_Error
      ; -------------------------------------------
    } ; End [SET] global Var(s)
    ; -------------------------------------------
    { ; StartUp Vars
      ; -------------------------------------------
      v_124_3 := DataArray.124.3 ; (124_3)(<Drop Down List> Language: List Box)
      ;
      v_370_1 := DataArray.370.1 ; (370_1)(XML_SC Line Numer)
      ;
      v_363_5  := DataArray.363.5 ; (363_5)(PC Installed Dir)
      ;
      v_365_2  := DataArray.365.2 ; (365_2)(Current User language)
      v_365_4  := DataArray.365.4 ; (365_4)(Language List [Array])
      ;
      ; -------------------------------------------
      if (v_370_1 == 0) ; (370_1)(XML_SC Line Numer)
      {
        v_366_5 := "xxx" ; (366_5)(Script Type)
        DataArray.366.5 := v_366_5 ; (366_5)(Script Type)
        DataArray.133.2 := 0 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        DataArray.133.3 := "" ; (133_3)(Delete Shortcut: Image Path)
        ; (133_1)(GUI Object: Delete Shortcut)
        ; -------------------------------------------
      } ; End (370_1)(XML_SC Line Numer == 0)
      else ; (370_1)(XML_SC Line Numer != 0)
      {
        DataArray := Shortcut_Info(DataArray)
        DataArray.133.2 := 1 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
        DataArray.133.3 := "" ; (133_3)(Delete Shortcut: Image Path)
        v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
        ; (133_1)(GUI Object: Delete Shortcut)
      } ; End (370_1)(XML_SC Line Numer != 0)
    } ; End StartUp Vars
    ; -------------------------------------------
    { ; Set Defaults
      ; -------------------------------------------
      if (v_366_5 == "key" or v_366_5 == "mnu") ; (366_5)(Script Type)
      {
        if (DataArray.72.2 == "") ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        {
          DataArray.72.2 := 2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
        }
      }
      else if (v_366_5 == "url") ; (366_5)(Script Type)
      {
        if (DataArray.307.7 == "") ; (307_7)([url] Use Default Browser [0/1])
        {
          DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
        }
      }
      ; -------------------------------------------
    } ; End Set Defaults
    ; -------------------------------------------
    { ; GUI Define by Monitor Size
      ; -------------------------------------------
      Gui, PopUpMenu:+AlwaysOnTop
      ; -------------------------------------------
      if (A_ScreenHeight > 600) ; (364_2)(Monitor Height [Integer])
      {
        ; -------------------------------------------
        Gui,+AlwaysOnTop
        ; -------------------------------------------
        { ; Messages / (Image 1-7)
          Gui, PopUpMenu:Font, c000000 s14 w700, %GuiFont% ; FONT 14 ("000000" ; Black)
          Gui, PopUpMenu:Add, Picture,                     x40 y207 w70 h70       vg_134                    gl_134, ; (134_1)(GUI Object: Message Image 1)
          Gui, PopUpMenu:Add, Picture,                     x185 y194 w130 h100    vg_135                    gl_135, ; (135_1)(GUI Object: Message Image 2)
          Gui, PopUpMenu:Add, Picture,                     x360 y194 w130 h100    vg_136                    gl_136, ; (136_1)(GUI Object: Message Image 3)
          Gui, PopUpMenu:Add, Picture,                     x10  y295 w480 h270    vg_137                    gl_137, ; (137_1)(GUI Object: Message Image 4)
          Gui, PopUpMenu:Add, Picture,                     x190 y295 w300 h300    vg_162                    ; (162_1)(GUI Object: Message Image 5)
          Gui, PopUpMenu:Add, Picture,                     x10  y295 w160 h150    vg_163                    ; (163_1)(GUI Object: Message Image 6)
          Gui, PopUpMenu:Add, Picture,                     x10  y445 w160 h120    vg_164                    ; (164_1)(GUI Object: Message Image 7)
        } ; End Messages / (Image 1-7)
        ; -------------------------------------------
        { ; Displayed Text / (Top 1)(Top 2)(Bottom 1)(Bottom 2)(Icon Warning Text)(List Text)(Opening Application Path)(Title 1-3)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c199524 s12 w700, %GuiFont% ; FONT 10 ("199524" ; Green)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y126 w480         vg_100, ; (100_1)(GUI Object: <Displayed Text> Top 1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y147 w480         vg_105, ; (105_1)(GUI Object: <Displayed Text> Top 2)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y521 w480         vg_104, ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y548 w480         vg_107, ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s10 w700, %GuiFont% ; FONT 10 ("921297" ; Purple)
          Gui, PopUpMenu:Add, Text, Center                 x321 y576 w169         vg_108, ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
          Gui, PopUpMenu:Add, Text, Center                 x321 y597 w169         vg_109, ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12, %GuiFont% ; FONT 12 ("921297" ; Purple)
          Gui, PopUpMenu:Add, Text, -Wrap                x10  y271 w158           vg_110, ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
          Gui, PopUpMenu:Add, Text, -Wrap                x171 y271 w158           vg_111, ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
          Gui, PopUpMenu:Add, Text, -Wrap                x332 y271 w158           vg_112, ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s12 w700, %GuiFont% ; FONT 10 (Bright Purple b6009e)
          Gui, PopUpMenu:Add, Text, -Wrap                  x10  y271 w480         vg_113, ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c921297 s14 w700, %GuiFont% ; FONT 14 ("921297" ; Purple)
          Gui, PopUpMenu:Add, Text, Center                 x110 y55  w275         vg_114, ; (114_1)(GUI Object: <Displayed Text> Title 1)
          Gui, PopUpMenu:Add, Text, Center                 x110 y79  w275         vg_115, ; (115_1)(GUI Object: <Displayed Text> Title 2)
          Gui, PopUpMenu:Add, Text, Center                 x147 y102 w200         vg_141, ; (141_1)(GUI Object: <Displayed Text> Title 3)
          ; -------------------------------------------
        } ; End Displayed Text / (Top 1)(Top 2)(Bottom 1)(Bottom 2)(Icon Warning Text)(List Text)(Opening Application Path)(Title 1-3)
        ; -------------------------------------------
        { ; Edit Text / (Status Bar Description)([key] Text Input)([url] URL Address)
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont% ; FONT 14 ("000000" ; Black)
          Gui, PopUpMenu:Add, Edit,                        x205 y204 w285 h25     -Tabstop  vg_122,          ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
          Gui, PopUpMenu:Add, Edit,                        x205 y239 w285 h25     vg_123                   gl_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
          Gui, PopUpMenu:Add, Edit,                        x10  y135 w480 h24     vg_131                   gl_131 ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
        } ; End Edit Text / (Status Bar Description)([key] Text Input)([url] URL Address)
        ; -------------------------------------------
        { ; (Common) / (Delete Shortcut)(Web Site Image Link)(Cancel)(Ok Button)
          Gui, PopUpMenu:Add, Picture,                     x390 y55  w100 h25     vg_133                   gl_133, ; (133_1)(GUI Object: Delete Shortcut)
          Gui, PopUpMenu:Add, Picture,                     x10  y670 w480 h20     vg_099                   gl_099, %v_363_5%\img\imgkey\WebAddress.png ; (363_5)(PC Installed Dir)/(099_1)(GUI Object: Web Site Image Link)
          Gui, PopUpMenu:Add, Picture,                     x48  y622 w100 h35     vg_062                   gl_062, ; (062_1)(GUI Object: Cancel)
          Gui, PopUpMenu:Add, Picture,                     x353 y622 w100 h35     vg_004                   gl_004, ; (004_1)(GUI Object: Ok Button)
        } ; End (Common) / (Delete Shortcut)(Web Site Image Link)(Cancel)(Ok Button)
        ; -------------------------------------------
        { ; (Top Menu) (BTS_FileFolder)(Menu Control Key)(Pum)
          Gui, PopUpMenu:Add, Picture,                     x9   y10  w159 h35     vg_084                   gl_084, ; (084_1)(GUI Object: [ToM] File Url Folder)
          Gui, PopUpMenu:Add, Picture,                     x170 y10  w159 h35     vg_086                   gl_086, ; (086_1)(GUI Object: [ToM] Menu Control Key)
          Gui, PopUpMenu:Add, Picture,                     x331 y10  w159 h35     vg_083                   gl_083, ; (083_1)(GUI Object: [ToM] Pum)
        } ; End (Top Menu) (BTS_FileFolder)(Menu Control Key)(Pum)
        ; -------------------------------------------
        { ; (Language) / (Language Flag)(Choose Language Drop Down List)
          Gui, PopUpMenu:Add, Picture,                     x10  y55  w94  h23     vg_101, ; (101_1)(GUI Object: Language Flag)
          Gui, PopUpMenu:Font, c000000 s10 w700, %GuiFont% ; FONT 12 ("000000" ; Black)
          Gui, PopUpMenu:Add, DropDownList,                x10  y81  w94         -Tabstop  vg_124     gl_124,   ; (124_1)(GUI Object: <Drop Down List> Language)
        } ; End (Language) / (Language Flag)(Choose Language Drop Down List)
        ; -------------------------------------------
        { ; (Icon) / (Icon Rotate)(Main Display Icon)(Icon Image 4)(First App Icon)(Second App Icon)(Third App Icon)(Select Icon Image)([Text] Number of Icons)(Reset Icon Image)
          Gui, PopUpMenu:Add, Picture,                     x185 y574 w22  h35     vg_005                   gl_005, ; (005_1)(GUI Object: Icon Rotate Left)
          Gui, PopUpMenu:Add, Picture,                     x210 y574 w80  h80     vg_102                   gl_063, ; (063_1)(GUI Object: Select Icon Image)/(102_1)(GUI Object: Main Display Icon)
          Gui, PopUpMenu:Add, Picture,                     x293 y574 w22  h35     vg_006                   gl_006, ; (006_1)(GUI Object: Icon Rotate Right)
          Gui, PopUpMenu:Add, Picture,                     x321 y574 w40  h40     vg_007                   gl_106, ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])/(007_1)(GUI Object: Icon Image 4)
          Gui, PopUpMenu:Add, Picture,                     x364 y574 w40  h40     vg_001                   gl_001, ; (001_1)(GUI Object: [run][rwh] First App Icon)
          Gui, PopUpMenu:Add, Picture,                     x407 y574 w40  h40     vg_002                   gl_002, ; (002_1)(GUI Object: [run][rwh] Second App Icon)
          Gui, PopUpMenu:Add, Picture,                     x450 y574 w40  h40     vg_003                   gl_003, ; (003_1)(GUI Object: [run][rwh] Third App Icon)
          Gui, PopUpMenu:Font, c921297 s14 w700, %GuiFont% ; FONT 10 ("921297" ; Purple)
          Gui, PopUpMenu:Add, Picture,                     x18  y574 w160 h35     vg_063                   gl_063, ; (063_1)(GUI Object: Select Icon Image)
          Gui, PopUpMenu:Add, Text, BackgroundTrans Center x321 y587 w40      r1  vg_106                   gl_106, ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
          Gui, PopUpMenu:Add, Picture,                     x323 y574 w160 h35     vg_064                   gl_064, ; (064_1)(GUI Object: Reset Icon Image)
        } ; End (Icon) / (Icon Rotate)(Main Display Icon)(Icon Image 4)(First App Icon)(Second App Icon)(Third App Icon)(Select Icon Image)([Text] Number of Icons)(Reset Icon Image)
        ; -------------------------------------------
        { ; (Status Bar Description)
          Gui, PopUpMenu:Add, Picture,                     x10  y204 w185 h25     vg_065, ; (065_1)(GUI Object: <Image Text> Status Bar Description)
        } ; End (Status Bar Description)
        ; -------------------------------------------
        { ; (mnu)(cpl)(key) / (Select) / (Menu)(Control)(Keyboard)
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w130 h25     vg_087                   gl_087, ; (087_1)(GUI Object: [mnu] Select Menu)
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25     vg_070                   gl_070, ; (070_1)(GUI Object: [cpl] Select Control)
          Gui, PopUpMenu:Add, Picture,                     x360 y169 w130 h25     vg_085                   gl_085, ; (085_1)(GUI Object: [key] Select Keyboard)
        } ; End (mnu)(cpl)(key) / (Select) / (Menu)(Control)(Keyboard)
        ; -------------------------------------------
        { ; (cpl) / (Windows Control Menu 1-8)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y239 w58  h25     vg_125                   gl_125, ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
          Gui, PopUpMenu:Add, Picture,                     x70  y239 w58  h25     vg_126                   gl_126, ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
          Gui, PopUpMenu:Add, Picture,                     x130 y239 w58  h25     vg_127                   gl_127, ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
          Gui, PopUpMenu:Add, Picture,                     x190 y239 w58  h25     vg_128                   gl_128, ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
          Gui, PopUpMenu:Add, Picture,                     x250 y239 w58  h25     vg_129                   gl_129, ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
          Gui, PopUpMenu:Add, Picture,                     x310 y239 w58  h25     vg_130                   gl_130, ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
          Gui, PopUpMenu:Add, Picture,                     x370 y239 w58  h25     vg_138                   gl_138, ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
          Gui, PopUpMenu:Add, Picture,                     x430 y239 w58  h25     vg_139                   gl_139, ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
          ; -------------------------------------------
        } ; End (cpl) / (Windows Control Menu 1-8)
        ; -------------------------------------------
        { ; (key)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_072                   gl_072, ; (072_1)(GUI Object: [key] Application Only)
          Gui, PopUpMenu:Add, Picture,                     x10  y239 w185 h25     vg_066, ; (066_1)(GUI Object: <Image Text> Text Input)
          ; -------------------------------------------
          { ; (Down/Up/Left/Right) / (Windows Key)(Shift)(Ctrl)(Alt)
            Gui, PopUpMenu:Add, Picture,                   x254 y274 w23  h23     vg_058                   gl_058, ; (058_1)(GUI Object: [key] Windows Key Down)
            Gui, PopUpMenu:Add, Picture,                   x279 y274 w23  h23     vg_061                   gl_061, ; (061_1)(GUI Object: [key] Windows Key Up)
            Gui, PopUpMenu:Add, Picture,                   x314 y274 w23  h23     vg_051                   gl_051, ; (051_1)(GUI Object: [key] Shift Down)
            Gui, PopUpMenu:Add, Picture,                   x339 y274 w23  h23     vg_054                   gl_054, ; (054_1)(GUI Object: [key] Shift Up)
            Gui, PopUpMenu:Add, Picture,                   x374 y274 w23  h23     vg_014                   gl_014, ; (014_1)(GUI Object: [key] Ctrl Down)
            Gui, PopUpMenu:Add, Picture,                   x399 y274 w23  h23     vg_017                   gl_017, ; (017_1)(GUI Object: [key] Ctrl Up)
            Gui, PopUpMenu:Add, Picture,                   x434 y274 w23  h23     vg_009                   gl_009, ; (009_1)(GUI Object: [key] Alt Down)
            Gui, PopUpMenu:Add, Picture,                   x459 y274 w23  h23     vg_012                   gl_012, ; (012_1)(GUI Object: [key] Alt Up)
            ;
            Gui, PopUpMenu:Add, Picture,                   x254 y326 w23  h23     vg_059                   gl_059, ; (059_1)(GUI Object: [key] Windows Key Left)
            Gui, PopUpMenu:Add, Picture,                   x279 y326 w23  h23     vg_060                   gl_060, ; (060_1)(GUI Object: [key] Windows Key Right)
            Gui, PopUpMenu:Add, Picture,                   x314 y326 w23  h23     vg_052                   gl_052, ; (052_1)(GUI Object: [key] Shift Left)
            Gui, PopUpMenu:Add, Picture,                   x339 y326 w23  h23     vg_053                   gl_053, ; (053_1)(GUI Object: [key] Shift Right)
            Gui, PopUpMenu:Add, Picture,                   x374 y326 w23  h23     vg_015                   gl_015, ; (015_1)(GUI Object: [key] Ctrl Left)
            Gui, PopUpMenu:Add, Picture,                   x399 y326 w23  h23     vg_016                   gl_016, ; (016_1)(GUI Object: [key] Ctrl Right)
            Gui, PopUpMenu:Add, Picture,                   x434 y326 w23  h23     vg_010                   gl_010, ; (010_1)(GUI Object: [key] Alt Left)
            Gui, PopUpMenu:Add, Picture,                   x459 y326 w23  h23     vg_011                   gl_011, ; (011_1)(GUI Object: [key] Alt Right)
          } ; End (Down/Up/Left/Right) / (Windows Key)(Shift)(Ctrl)(Alt)
          ; -------------------------------------------
          { ; (Esc)(Enter)(Tab)(Caps Lock)(Windows Key)(Shift)(Ctrl)(Alt)
            Gui, PopUpMenu:Add, Picture,                   x10  y299 w56  h25     vg_020                   gl_020, ; (020_1)(GUI Object: [key] Esc)
            Gui, PopUpMenu:Add, Picture,                   x70  y299 w56  h25     vg_018                   gl_018, ; (018_1)(GUI Object: [key] Enter)
            Gui, PopUpMenu:Add, Picture,                   x130 y299 w56  h25     vg_055                   gl_055, ; (055_1)(GUI Object: [key] Tab)
            Gui, PopUpMenu:Add, Picture,                   x190 y299 w56  h25     vg_013                   gl_013, ; (013_1)(GUI Object: [key] Caps Lock)
            Gui, PopUpMenu:Add, Picture,                   x250 y299 w56  h25     vg_057                   gl_057, ; (057_1)(GUI Object: [key] Windows Key)
            Gui, PopUpMenu:Add, Picture,                   x310 y299 w56  h25     vg_050                   gl_050, ; (050_1)(GUI Object: [key] Shift)
            Gui, PopUpMenu:Add, Picture,                   x370 y299 w56  h25     vg_074                   gl_074, ; (074_1)(GUI Object: [key] Ctrl)
            Gui, PopUpMenu:Add, Picture,                   x430 y299 w56  h25     vg_008                   gl_008, ; (008_1)(GUI Object: [key] Alt)
          } ; End (Esc)(Enter)(Tab)(Caps Lock)(Windows Key)(Shift)(Ctrl)(Alt)
          ; -------------------------------------------
          { ; (Esc X2)(Enter X2)(Tab X2)
            Gui, PopUpMenu:Add, Picture,                   x10  y326 w56  h23     vg_021                   gl_021, ; (021_1)(GUI Object: [key] Esc X2)
            Gui, PopUpMenu:Add, Picture,                   x70  y326 w56  h23     vg_019                   gl_019, ; (019_1)(GUI Object: [key] Enter X2)
            Gui, PopUpMenu:Add, Picture,                   x130 y326 w56  h23     vg_056                   gl_056, ; (056_1)(GUI Object: [key] Tab X2)
          } ; End (Esc X2)(Enter X2)(Tab X2)
          ; -------------------------------------------
          { ; (Home)(End)(Insert)(Delete)(Page Up)(Page Down)
            Gui, PopUpMenu:Add, Picture,                   x10  y359 w75  h25     vg_077                   gl_077, ; (077_1)(GUI Object: [key] Home)
            Gui, PopUpMenu:Add, Picture,                   x91  y359 w75  h25     vg_076                   gl_076, ; (076_1)(GUI Object: [key] End)
            Gui, PopUpMenu:Add, Picture,                   x172 y359 w75  h25     vg_078                   gl_078, ; (078_1)(GUI Object: [key] Insert)
            Gui, PopUpMenu:Add, Picture,                   x253 y359 w75  h25     vg_075                   gl_075, ; (075_1)(GUI Object: [key] Delete)
            Gui, PopUpMenu:Add, Picture,                   x334 y359 w75  h25     vg_080                   gl_080, ; (080_1)(GUI Object: [key] Page Up)
            Gui, PopUpMenu:Add, Picture,                   x415 y359 w75  h25     vg_079                   gl_079, ; (079_1)(GUI Object: [key] Page Down)
          } ; End (Home)(End)(Insert)(Delete)(Page Up)(Page Down)
          ; -------------------------------------------
          { ; (F 1-12)
            Gui, PopUpMenu:Add, Picture,                   x12  y394 w36  h25     vg_022                   gl_022, ; (022_1)(GUI Object: [key] F1)
            Gui, PopUpMenu:Add, Picture,                   x52  y394 w36  h25     vg_023                   gl_023, ; (023_1)(GUI Object: [key] F2)
            Gui, PopUpMenu:Add, Picture,                   x92  y394 w36  h25     vg_024                   gl_024, ; (024_1)(GUI Object: [key] F3)
            Gui, PopUpMenu:Add, Picture,                   x132 y394 w36  h25     vg_025                   gl_025, ; (025_1)(GUI Object: [key] F4)
            Gui, PopUpMenu:Add, Picture,                   x172 y394 w36  h25     vg_026                   gl_026, ; (026_1)(GUI Object: [key] F5)
            Gui, PopUpMenu:Add, Picture,                   x212 y394 w36  h25     vg_027                   gl_027, ; (027_1)(GUI Object: [key] F6)
            Gui, PopUpMenu:Add, Picture,                   x252 y394 w36  h25     vg_028                   gl_028, ; (028_1)(GUI Object: [key] F7)
            Gui, PopUpMenu:Add, Picture,                   x292 y394 w36  h25     vg_029                   gl_029, ; (029_1)(GUI Object: [key] F8)
            Gui, PopUpMenu:Add, Picture,                   x332 y394 w36  h25     vg_030                   gl_030, ; (030_1)(GUI Object: [key] F9)
            Gui, PopUpMenu:Add, Picture,                   x372 y394 w36  h25     vg_031                   gl_031, ; (031_1)(GUI Object: [key] F10)
            Gui, PopUpMenu:Add, Picture,                   x412 y394 w36  h25     vg_032                   gl_032, ; (032_1)(GUI Object: [key] F11)
            Gui, PopUpMenu:Add, Picture,                   x452 y394 w36  h25     vg_033                   gl_033, ; (033_1)(GUI Object: [key] F12)
          } ; End (F 1-12)
          ; -------------------------------------------
          { ; (Numpad) / (0-9)(Divide)(Multiply)(Add)(Subtract)(Dot)(Enter)
            Gui, PopUpMenu:Add, Picture,                   x158 y429 w185 h25     vg_067, ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
            Gui, PopUpMenu:Add, Picture,                   x12  y464 w44  h25     vg_034                   gl_034, ; (034_1)(GUI Object: [key] Numpad 0)
            Gui, PopUpMenu:Add, Picture,                   x60  y464 w44  h25     vg_035                   gl_035, ; (035_1)(GUI Object: [key] Numpad 1)
            Gui, PopUpMenu:Add, Picture,                   x108 y464 w44  h25     vg_036                   gl_036, ; (036_1)(GUI Object: [key] Numpad 2)
            Gui, PopUpMenu:Add, Picture,                   x156 y464 w44  h25     vg_037                   gl_037, ; (037_1)(GUI Object: [key] Numpad 3)
            Gui, PopUpMenu:Add, Picture,                   x204 y464 w44  h25     vg_038                   gl_038, ; (038_1)(GUI Object: [key] Numpad 4)
            Gui, PopUpMenu:Add, Picture,                   x252 y464 w44  h25     vg_039                   gl_039, ; (039_1)(GUI Object: [key] Numpad 5)
            Gui, PopUpMenu:Add, Picture,                   x300 y464 w44  h25     vg_040                   gl_040, ; (040_1)(GUI Object: [key] Numpad 6)
            Gui, PopUpMenu:Add, Picture,                   x348 y464 w44  h25     vg_041                   gl_041, ; (041_1)(GUI Object: [key] Numpad 7)
            Gui, PopUpMenu:Add, Picture,                   x396 y464 w44  h25     vg_042                   gl_042, ; (042_1)(GUI Object: [key] Numpad 8)
            Gui, PopUpMenu:Add, Picture,                   x444 y464 w44  h25     vg_043                   gl_043, ; (043_1)(GUI Object: [key] Numpad 9)
            Gui, PopUpMenu:Add, Picture,                   x10  y499 w75  h25     vg_045                   gl_045, ; (045_1)(GUI Object: [key] Numpad Divide)
            Gui, PopUpMenu:Add, Picture,                   x91  y499 w75  h25     vg_048                   gl_048, ; (048_1)(GUI Object: [key] Numpad Multiply)
            Gui, PopUpMenu:Add, Picture,                   x172 y499 w75  h25     vg_044                   gl_044, ; (044_1)(GUI Object: [key] Numpad Add)
            Gui, PopUpMenu:Add, Picture,                   x253 y499 w75  h25     vg_049                   gl_049, ; (049_1)(GUI Object: [key] Numpad Subtract)
            Gui, PopUpMenu:Add, Picture,                   x334 y499 w75  h25     vg_046                   gl_046, ; (046_1)(GUI Object: [key] Numpad Dot)
            Gui, PopUpMenu:Add, Picture,                   x415 y499 w75  h25     vg_047                   gl_047, ; (047_1)(GUI Object: [key] Numpad Enter)
          } ; End (Numpad) / (0-9)(Divide)(Multiply)(Add)(Subtract)(Dot)(Enter)
          ; -------------------------------------------
        } ; End (key)
        ; -------------------------------------------
        { ; (mnu) / (Addon Extra)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_140                   gl_140, ; (140_1)(GUI Object: [mnu] Addon Extra)
          ; -------------------------------------------
        } ; End (mnu) / (Addon Extra)
        ; -------------------------------------------
        { ; (cpl)(mnu) / (List) / (Full Across)(List Left 1/3)(Center 1/3)(List Right 1/3)(List Right 2/3)
          ; -------------------------------------------
          ; 100%
          Gui, PopUpMenu:Font, c000000 s12 w700, %GuiFont% ; FONT 8 ("000000" ; Black)
          Gui, PopUpMenu:Add, ListBox,                   x10  y296 w480 r10       vg_116                   gl_116, ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
          ; Here For Tab Selection
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont% ; FONT 8 ("000000" ; Black)
          ; Left 33% 
          Gui, PopUpMenu:Add, ListBox,                   x10  y296 w158 r16       vg_118                   gl_118, ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
          ; -------------------------------------------
          ; Right 66%
          Gui, PopUpMenu:Font, c000000 s10 w700, %GuiFont% ; FONT 8 ("000000" ; Black)
          Gui, PopUpMenu:Add, ListBox,                   x171 y296 w320 r13       vg_117                   gl_117, ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
          ; -------------------------------------------
          Gui, PopUpMenu:Font, c000000 s8 w700, %GuiFont% ; FONT 8 ("000000" ; Black)
          ; Center 33% 
          Gui, PopUpMenu:Add, ListBox,                   x171 y296 w158 r16       vg_120                   gl_120, ; (120_1)(GUI Object: [mnu] List Center 1/3)
          ; Right 33% 
          Gui, PopUpMenu:Add, ListBox,                   x332 y296 w158 r16       vg_121                   gl_121, ; (121_1)(GUI Object: [mnu] List Right 1/3)
          ; -------------------------------------------
        } ; End (cpl)(mnu) / (List) / (Full Across)(List Left 1/3)(Center 1/3)(List Right 1/3)(List Right 2/3)
        ; -------------------------------------------
        { ; (run)(url)(rwh)(ofl) / (Select) / (Select File)(Select URL)(Select Folder)
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w130 h25     vg_081                   gl_081, ; (081_1)(GUI Object: [run][rwh] Select File)
          Gui, PopUpMenu:Add, Picture,                     x185 y169 w130 h25     vg_071                   gl_071, ; (071_1)(GUI Object: [url] Select URL)
          Gui, PopUpMenu:Add, Picture,                     x360 y169 w130 h25     vg_082                   gl_082, ; (082_1)(GUI Object: [ofl] Select Folder)
        } ; End (run)(url)(rwh) / (Select) / (Select File)(Select URL)(Select Folder)
        ; -------------------------------------------
        { ; (rwh)(url) / (url)(Get URL Data) / (run)(As Admin) / (rwh)(url)(Select Open With Application) / (rwh)(url)(Open With App Reset)
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_132 gl_132, ; (132_1)(GUI Object: [url] Select Get URL Data)
          Gui, PopUpMenu:Add, Picture,                     x390 y91  w100 h25     vg_073 gl_073, ; (073_1)(GUI Object: [run] As Admin)
          Gui, PopUpMenu:Add, Picture,                     x10  y237 w30 h30      vg_103, ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
          Gui, PopUpMenu:Add, Picture,                     x50  y239 w280 h25     vg_068 gl_068, ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
          Gui, PopUpMenu:Add, Picture,                     x340 y239 w150 h25     vg_069 gl_069, ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        } ; End (rwh)(url) / (url)(Get URL Data) / (run)(As Admin) / (rwh)(url)(Select Open With Application) / (rwh)(url)(Open With App Reset)
        ; -------------------------------------------
        { ; (pum)
          ; -------------------------------------------
          Gui, PopUpMenu:Add, Picture,                     x10  y249 w158 h25     vg_154 gl_154, ; (154_1)(GUI Object: [pum] Pum Select Background)
          Gui, PopUpMenu:Add, Picture,                     x171 y249 w158 h25     vg_155 gl_155, ; (155_1)(GUI Object: [pum] Pum Select Display Text)
          Gui, PopUpMenu:Add, Picture,                     x332 y249 w158 h25     vg_156 gl_156, ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
          Gui, PopUpMenu:Add, Picture,                     x10  y169 w118 h25     vg_157 gl_157, ; (157_1)(GUI Object: [pum] Pum Select Settings)
          Gui, PopUpMenu:Add, Picture,                     x130 y169 w118 h25     vg_158 gl_158, ; (158_1)(GUI Object: [pum] Pum Shortcut)
          Gui, PopUpMenu:Add, Picture,                     x250 y169 w118 h25     vg_159 gl_159, ; (159_1)(GUI Object: [pum] Select Custom Pum)
          Gui, PopUpMenu:Add, Picture,                     x370 y169 w118 h25     vg_160 gl_160, ; (160_1)(GUI Object: [pum] Select Application Pum)
          Gui, PopUpMenu:Add, Picture,                     x370 y169 w118 h25     vg_161 gl_161, ; (161_1)(GUI Object: [pum] Delete Pum)
          Gui, PopUpMenu:Add, Picture,                     x39  y303 w110 h25     vg_165 gl_165, ; (165_1)(GUI Object: [pum] Backgroung Image Select)
          Gui, PopUpMenu:Add, Picture,                     x39  y338 w110 h25     vg_166 gl_166, ; (166_1)(GUI Object: [pum] Backgroung Color Select)
          Gui, PopUpMenu:Add, Picture,                     x39  y379 w100 h25     vg_167 gl_167, ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
          Gui, PopUpMenu:Add, Picture,                     x39  y413 w100 h25     vg_168 gl_168, ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
          
          
          
          ; -------------------------------------------
        } ; End (pum)
        ; -------------------------------------------
      } ; End (364_2)(Monitor Height [Integer] > 600)
      ; -------------------------------------------
    } ; End GUI Define by Monitor Size
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; App AddOn
      DataArray := mnu_TextAddon_to_MenuArray(DataArray)
      v_302_6 := DataArray.302.6 ; (302_6)([mnu] Menu Size [#])
      { ; GUI Keys
        if (v_302_6 > 0) ; (302_6)([mnu] Menu Size [#])
        {
          if (A_ScreenHeight <= 600) ; (364_2)(Monitor Height [Integer])
          {
            PosX := 185
          }
          else
          {
            PosX := 10
          }
          Num := 88
          ; -------------------------------------------
          Loop %v_302_6% ; (302_6)([mnu] Menu Size [#])
          {
            ; -------------------------------------------
            if (StrLen(Num) == 1)
            {
              Num := "00" Num
            }
            if (StrLen(Num) == 2)
            {
              Num := "0" Num
            }
            ; -------------------------------------------
            if (v_302_6 == 2) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w238 h25 vg_%Num% gl_%Num%
              PosX := PosX + 240 ; 2 px - Width (Img Width 238) (2 * 240 = 480)
            }
            else if (v_302_6 == 3) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w158 h25 vg_%Num% gl_%Num%
              PosX := PosX + 160 ; 2 px - Width (Img Width 158) (3 * 160 = 480)
            }
            else if (v_302_6 == 4) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w118 h25 vg_%Num% gl_%Num%
              PosX := PosX + 120 ; 2 px - Width (Img Width 118) (4 * 120 = 480)
            }
            else if (v_302_6 == 5) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w94 h25 vg_%Num% gl_%Num%
              PosX := PosX + 96 ; 2 px - Width (Img Width 94) (5 * 96 = 480)
            }
            else if (v_302_6 == 6) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w78 h25 vg_%Num% gl_%Num%
              PosX := PosX + 80 ; 2 px - Width (Img Width 78) (6 * 80 = 480)
            }
            else if (v_302_6 == 7) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w67 h25 vg_%Num% gl_%Num%
              PosX := PosX + 69 ; 2 px - Width (Img Width 67) (7 * 69 = 483)
            }
            else if (v_302_6 == 8) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w58 h25 vg_%Num% gl_%Num%
              PosX := PosX + 60 ; 2 px - Width (Img Width 58) (8 * 60 = 480)
            }
            else if (v_302_6 == 9) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w51 h25 vg_%Num% gl_%Num%
              PosX := PosX + 53 ; 2 px - Width (Img Width 51) (9 * 53 = 477)
            }
            else if (v_302_6 == 10) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w46 h25 vg_%Num% gl_%Num%
              PosX := PosX + 48 ; 2 px - Width (Img Width 46) (10 * 48 = 480)
            }
            else if (v_302_6 == 11) ; (302_6)([mnu] Menu Size [#])
            {
              ; Just Adds the GUI Object NOT its value/Image
              Gui, PopUpMenu:Add, Picture, x%PosX% y239 w42 h25 vg_%Num% gl_%Num%
              PosX := PosX + 44 ; 2 px - Width (Img Width 42) (11 * 44 = 484)
            }
            ; -------------------------------------------
            Num := Num + 1
            ; -------------------------------------------
          }
        }
      }
    } ; End App AddOn
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; GUI Show
      ; -------------------------------------------
      { ; Hide Vars
        ; -------------------------------------------
        if (DataArray.116.2 == 1) ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.116.2 := 0 ; (116_2)([cpl][mnu] List Full Across: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
        }
        ; -------------------------------------------
        if (DataArray.117.2 == 1) ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.117.2 := 0 ; (117_2)([cpl][mnu] List Right 2/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
        }
        ; -------------------------------------------
        if (DataArray.118.2 == 1) ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.118.2 := 0 ; (118_2)([cpl][mnu] List Left 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
        }
        ; -------------------------------------------
        if (DataArray.120.2 == 1) ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.120.2 := 0 ; (120_2)([mnu] List Center 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
        }
        ; -------------------------------------------
        if (DataArray.121.2 == 1) ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.121.2 := 0 ; (121_2)([mnu] List Right 1/3: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
        }
        ; -------------------------------------------
        if (DataArray.123.2 == 1) ; (123_2)(<Edit Feild> [key] Text Input: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.123.2 := 0 ; (123_2)(<Edit Feild> [key] Text Input: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        }
        ; -------------------------------------------
        if (DataArray.122.2 == 1) ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
        {
          DataArray.122.2 := 0 ; (122_2)(<Edit Feild> Status Bar Description: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          GuiControl, PopUpMenu:Hide, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
        }
        ; -------------------------------------------
      } ; End Hide Vars
      ; -------------------------------------------
      { ; (365_3)(Language List Number [Integer])
        if (v_365_2 == "de") ; (365_2)(Current User language)
        {
          v_365_3 := 1 ; (365_3)(Language List Number [Integer])
        } ; End (en English)
        else if (v_365_2 == "en") ; (365_2)(Current User language)
        {
          v_365_3 := 2 ; (365_3)(Language List Number [Integer])
        } ; End (fr French)
        else if (v_365_2 == "es") ; (365_2)(Current User language)
        {
          v_365_3 := 3 ; (365_3)(Language List Number [Integer])
        } ; End (de German)
        else if (v_365_2 == "fr") ; (365_2)(Current User language)
        {
          v_365_3 := 4 ; (365_3)(Language List Number [Integer])
        } ; End (it Italian)
        else if (v_365_2 == "it") ; (365_2)(Current User language)
        {
          v_365_3 := 5 ; (365_3)(Language List Number [Integer])
        } ; End (pl Polish)
        else if (v_365_2 == "pl") ; (365_2)(Current User language)
        {
          v_365_3 := 6 ; (365_3)(Language List Number [Integer])
        } ; End (pt Portuguese)
        else if (v_365_2 == "pt") ; (365_2)(Current User language)
        {
          v_365_3 := 7 ; (365_3)(Language List Number [Integer])
        } ; End (ru Russian)
        else if (v_365_2 == "ru") ; (365_2)(Current User language)
        {
          v_365_3 := 8 ; (365_3)(Language List Number [Integer])
        } ; End (es Spanish)
        else if (v_365_2 == "sv") ; (365_2)(Current User language)
        {
          v_365_3 := 9 ; (365_3)(Language List Number [Integer])
        } ; End (sv Swedish)
        else if (v_365_2 == "tr") ; (365_2)(Current User language)
        {
          v_365_3 := 10 ; (365_3)(Language List Number [Integer])
        } ; End (tr Turkish)
      } ; End (365_3)(Language List Number [Integer])
      ; -------------------------------------------
      { ; Language DropDown List & Flag
        ; -------------------------------------------
        GuiControl, PopUpMenu:, g_124, %v_124_3% ; (124_3)(<Drop Down List> Language: List Box)/(124_1)(GUI Object: <Drop Down List> Language)
        GuiControl, PopUpMenu:Choose, g_124, %v_365_3% ; (365_3)(Language List Number [Integer])/(124_1)(GUI Object: <Drop Down List> Language)
        ; -------------------------------------------
        v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
        v_386_9 := DataArray.386.9 ; (386_9)(Language Flag Image [Folder Path])
        ThisImage := v_386_9 "\" v_365_2 ".png" ; (386_9)(Language Flag Image [Folder Path])/(365_2)(Current User language)
        if (DataArray.101.3 != ThisImage) ; (101_3)(Language Flag: Image Path)
        {
          DataArray.101.3 := ThisImage ; (101_3)(Language Flag: Image Path)
          GuiControl, PopUpMenu:, g_101, %ThisImage% ; (101_1)(GUI Object: Language Flag)
          GuiControl, PopUpMenu:MoveDraw, g_101, +w94 +h23 ; (101_1)(GUI Object: Language Flag)
        }
        GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
        ; -------------------------------------------
      } ; End Language DropDown List & Flag
      ; -------------------------------------------
      GuiControl, PopUpMenu:Focus, g_004 ; (004_1)(GUI Object: Ok Button)
      Gui, PopUpMenu:Color, e7d8fe ; Purple
      ; -------------------------------------------
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
      v_384_12 := DataArray.384.12 ; (384_12)(HotKey_Ok [Script File Path])
      Run, *RunAs %v_384_12%,,, Script_v_384_12 ; (384_12)(HotKey_Ok [Script File Path])
      Process, Priority, %Script_v_384_12%, High     ; (384_12)(HotKey_Ok [Script File Path])
      ; -------------------------------------------
      Gui, PopUpMenu:Show, w500 h700, PopUpMenu
      ; -------------------------------------------
      return DataArray
      ; -------------------------------------------
    } ; End GUI Show
    ; -------------------------------------------    
    return DataArray
    ; -------------------------------------------    
  } ; End gui_Shortcut(DataArray) ; > DataArray
  ; -------------------------------------------
  { ; GUI Labels
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    l_001: ; (001_1)(GUI Object: [run][rwh] First App Icon)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        Temp_Icon := DataArray.1.3 ; (001_3)([run][rwh] First App Icon: Image Path)
        DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      }
      ; -------------------------------------------
    }
    return
    l_002: ; (002_1)(GUI Object: [run][rwh] Second App Icon)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        Temp_Icon := DataArray.2.3 ; (002_3)([run][rwh] Second App Icon: Image Path)
        DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      }
      ; -------------------------------------------
    }
    return
    l_003: ; (003_1)(GUI Object: [run][rwh] Third App Icon)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        Temp_Icon := DataArray.3.3 ; (003_3)([run][rwh] Third App Icon: Image Path)
        DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      }
      ; -------------------------------------------
    }
    return
    l_004:  ; (004_1)(GUI Object: Ok Button)
    {
      ; -------------------------------------------
      DataArray := f_004(DataArray) ; (004_1)(GUI Object: Ok Button)
      ; -------------------------------------------
    }
    return
    l_005: ; (005_1)(GUI Object: Icon Rotate Left)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_005(DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
      }
      ; -------------------------------------------
    }
    return
    l_006: ; (006_1)(GUI Object: Icon Rotate Right)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_006(DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
      }
      ; -------------------------------------------
    }
    return
    l_008: ; (008_1)(GUI Object: [key] Alt)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_008(DataArray) ; (008_1)(GUI Object: [key] Alt)
      }
      ; -------------------------------------------
    }
    return
    l_009: ; (009_1)(GUI Object: [key] Alt Down)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_009(DataArray) ; (009_1)(GUI Object: [key] Alt Down)
      }
      ; -------------------------------------------
    }
    return
    l_010: ; (010_1)(GUI Object: [key] Alt Left)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_010(DataArray) ; (010_1)(GUI Object: [key] Alt Left)
      }
      ; -------------------------------------------
    }
    return
    l_011: ; (011_1)(GUI Object: [key] Alt Right)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_011(DataArray) ; (011_1)(GUI Object: [key] Alt Right)
      }
      ; -------------------------------------------
    }
    return
    l_012: ; (012_1)(GUI Object: [key] Alt Up)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_012(DataArray) ; (012_1)(GUI Object: [key] Alt Up)
      }
      ; -------------------------------------------
    }
    return
    l_013: ; (013_1)(GUI Object: [key] Caps Lock)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_013(DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
      }
      ; -------------------------------------------
    }
    return
    l_014: ; (014_1)(GUI Object: [key] Ctrl Down)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_014(DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
      }
      ; -------------------------------------------
    }
    return
    l_015: ; (015_1)(GUI Object: [key] Ctrl Left)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_015(DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
      }
      ; -------------------------------------------
    }
    return
    l_016: ; (016_1)(GUI Object: [key] Ctrl Right)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_016(DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
      }
      ; -------------------------------------------
    }
    return
    l_017: ; (017_1)(GUI Object: [key] Ctrl Up)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_017(DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
      }
      ; -------------------------------------------
    }
    return
    l_018: ; (018_1)(GUI Object: [key] Enter)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_018(DataArray) ; (018_1)(GUI Object: [key] Enter)
      }
      ; -------------------------------------------
    }
    return
    l_019: ; (019_1)(GUI Object: [key] Enter X2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_019(DataArray) ; (019_1)(GUI Object: [key] Enter X2)
      }
      ; -------------------------------------------
    }
    return
    l_020: ; (020_1)(GUI Object: [key] Esc)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_020(DataArray) ; (020_1)(GUI Object: [key] Esc)
      }
      ; -------------------------------------------
    }
    return
    l_021: ; (021_1)(GUI Object: [key] Esc X2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_021(DataArray) ; (021_1)(GUI Object: [key] Esc X2)
      }
      ; -------------------------------------------
    }
    return
    l_022: ; (022_1)(GUI Object: [key] F1)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_022(DataArray) ; (022_1)(GUI Object: [key] F1)
      }
      ; -------------------------------------------
    }
    return
    l_023: ; (023_1)(GUI Object: [key] F2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_023(DataArray) ; (023_1)(GUI Object: [key] F2)
      }
      ; -------------------------------------------
    }
    return
    l_024: ; (024_1)(GUI Object: [key] F3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_024(DataArray) ; (024_1)(GUI Object: [key] F3)
      }
      ; -------------------------------------------
    }
    return
    l_025: ; (025_1)(GUI Object: [key] F4)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_025(DataArray) ; (025_1)(GUI Object: [key] F4)
      }
      ; -------------------------------------------
    }
    return
    l_026: ; (026_1)(GUI Object: [key] F5)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_026(DataArray) ; (026_1)(GUI Object: [key] F5)
      }
      ; -------------------------------------------
    }
    return
    l_027: ; (027_1)(GUI Object: [key] F6)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_027(DataArray) ; (027_1)(GUI Object: [key] F6)
      }
      ; -------------------------------------------
    }
    return
    l_028: ; (028_1)(GUI Object: [key] F7)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_028(DataArray) ; (028_1)(GUI Object: [key] F7)
      }
      ; -------------------------------------------
    }
    return
    l_029: ; (029_1)(GUI Object: [key] F8)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_029(DataArray) ; (029_1)(GUI Object: [key] F8)
      }
      ; -------------------------------------------
    }
    return
    l_030: ; (030_1)(GUI Object: [key] F9)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_030(DataArray) ; (030_1)(GUI Object: [key] F9)
      }
      ; -------------------------------------------
    }
    return
    l_031: ; (031_1)(GUI Object: [key] F10)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_031(DataArray) ; (031_1)(GUI Object: [key] F10)
      }
      ; -------------------------------------------
    }
    return
    l_032: ; (032_1)(GUI Object: [key] F11)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_032(DataArray) ; (032_1)(GUI Object: [key] F11)
      }
      ; -------------------------------------------
    }
    return
    l_033: ; (033_1)(GUI Object: [key] F12)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_033(DataArray) ; (033_1)(GUI Object: [key] F12)
      }
      ; -------------------------------------------
    }
    return
    l_034: ; (034_1)(GUI Object: [key] Numpad 0)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_034(DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
      }
      ; -------------------------------------------
    }
    return
    l_035: ; (035_1)(GUI Object: [key] Numpad 1)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_035(DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
      }
      ; -------------------------------------------
    }
    return
    l_036: ; (036_1)(GUI Object: [key] Numpad 2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_036(DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
      }
      ; -------------------------------------------
    }
    return
    l_037: ; (037_1)(GUI Object: [key] Numpad 3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_037(DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
      }
      ; -------------------------------------------
    }
    return
    l_038: ; (038_1)(GUI Object: [key] Numpad 4)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_038(DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
      }
      ; -------------------------------------------
    }
    return
    l_039: ; (039_1)(GUI Object: [key] Numpad 5)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_039(DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
      }
      ; -------------------------------------------
    }
    return
    l_040: ; (040_1)(GUI Object: [key] Numpad 6)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_040(DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
      }
      ; -------------------------------------------
    }
    return
    l_041: ; (041_1)(GUI Object: [key] Numpad 7)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_041(DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
      }
      ; -------------------------------------------
    }
    return
    l_042: ; (042_1)(GUI Object: [key] Numpad 8)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_042(DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
      }
      ; -------------------------------------------
    }
    return
    l_043: ; (043_1)(GUI Object: [key] Numpad 9)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_043(DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
      }
      ; -------------------------------------------
    }
    return
    l_044: ; (044_1)(GUI Object: [key] Numpad Add)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_044(DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
      }
      ; -------------------------------------------
    }
    return
    l_045: ; (045_1)(GUI Object: [key] Numpad Divide)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_045(DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
      }
      ; -------------------------------------------
    }
    return
    l_046: ; (046_1)(GUI Object: [key] Numpad Dot)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_046(DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
      }
      ; -------------------------------------------
    }
    return
    l_047: ; (047_1)(GUI Object: [key] Numpad Enter)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_047(DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
      }
      ; -------------------------------------------
    }
    return
    l_048: ; (048_1)(GUI Object: [key] Numpad Multiply)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_048(DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
      }
      ; -------------------------------------------
    }
    return
    l_049: ; (049_1)(GUI Object: [key] Numpad Subtract)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_049(DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
      }
      ; -------------------------------------------
    }
    return
    l_050: ; (050_1)(GUI Object: [key] Shift)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_050(DataArray) ; (050_1)(GUI Object: [key] Shift)
      }
      ; -------------------------------------------
    }
    return
    l_051: ; (051_1)(GUI Object: [key] Shift Down)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_051(DataArray) ; (051_1)(GUI Object: [key] Shift Down)
      }
      ; -------------------------------------------
    }
    return
    l_052: ; (052_1)(GUI Object: [key] Shift Left)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_052(DataArray) ; (052_1)(GUI Object: [key] Shift Left)
      }
      ; -------------------------------------------
    }
    return
    l_053: ; (053_1)(GUI Object: [key] Shift Right)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_053(DataArray) ; (053_1)(GUI Object: [key] Shift Right)
      }
      ; -------------------------------------------
    }
    return
    l_054: ; (054_1)(GUI Object: [key] Shift Up)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_054(DataArray) ; (054_1)(GUI Object: [key] Shift Up)
      }
      ; -------------------------------------------
    }
    return
    l_055: ; (055_1)(GUI Object: [key] Tab)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_055(DataArray) ; (055_1)(GUI Object: [key] Tab)
      }
      ; -------------------------------------------
    }
    return
    l_056: ; (056_1)(GUI Object: [key] Tab X2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_056(DataArray) ; (056_1)(GUI Object: [key] Tab X2)
      }
      ; -------------------------------------------
    }
    return
    l_057: ; (057_1)(GUI Object: [key] Windows Key)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_057(DataArray) ; (057_1)(GUI Object: [key] Windows Key)
      }
      ; -------------------------------------------
    }
    return
    l_058: ; (058_1)(GUI Object: [key] Windows Key Down)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_058(DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
      }
      ; -------------------------------------------
    }
    return
    l_059: ; (059_1)(GUI Object: [key] Windows Key Left)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_059(DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
      }
      ; -------------------------------------------
    }
    return
    l_060: ; (060_1)(GUI Object: [key] Windows Key Right)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_060(DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
      }
      ; -------------------------------------------
    }
    return
    l_061: ; (061_1)(GUI Object: [key] Windows Key Up)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_061(DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
      }
      ; -------------------------------------------
    }
    return
    l_062: ; (062_1)(GUI Object: Cancel)
    {
      ; -------------------------------------------
      DataArray := f_062(DataArray) ; (062_1)(GUI Object: Cancel)
      ; -------------------------------------------
    }
    return
    l_063: ; (063_1)(GUI Object: Select Icon Image)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("063", 2, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
          ; -------------------------------------------
          DataArray := f_063(DataArray) ; (063_1)(GUI Object: Select Icon Image)
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("063", 1, 1, DataArray) ; (063_1)(GUI Object: Select Icon Image)
          ; -------------------------------------------
        }
      }
      ; -------------------------------------------
    }
    return
    l_064: ; (064_1)(GUI Object: Reset Icon Image)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("064", 2, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
          ; -------------------------------------------
          DataArray := f_064(DataArray) ; (064_1)(GUI Object: Reset Icon Image)
          SleepTime(100) ; ThisTime, Benchmark
          ; -------------------------------------------
          DataArray := GuiControlImage_PopUpMenu("064", 1, 1, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
          ; -------------------------------------------
        }
      }
      ; -------------------------------------------
    }
    return
    l_068: ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_068(DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
      }
      ; -------------------------------------------
    }
    return
    l_069: ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_069(DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
      }
      ; -------------------------------------------
    }
    return
    l_070: ; (070_1)(GUI Object: [cpl] Select Control)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_070(DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
      }
      ; -------------------------------------------
    }
    return
    l_071: ; (071_1)(GUI Object: [url] Select URL)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_071(DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
      ; -------------------------------------------
    }
    return
    l_072: ; (072_1)(GUI Object: [key] Application Only)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_072(DataArray) ; (072_1)(GUI Object: [key] Application Only)
      }
      ; -------------------------------------------
    }
    return
    l_073: ; (073_1)(GUI Object: [run] As Admin)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_073(DataArray) ; (073_1)(GUI Object: [run] As Admin)
      }
      ; -------------------------------------------
    }
    return
    l_074: ; (074_1)(GUI Object: [key] Ctrl)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_074(DataArray) ; (074_1)(GUI Object: [key] Ctrl)
      }
      ; -------------------------------------------
    }
    return
    l_075: ; (075_1)(GUI Object: [key] Delete)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_075(DataArray) ; (075_1)(GUI Object: [key] Delete)
      }
      ; -------------------------------------------
    }
    return
    l_076: ; (076_1)(GUI Object: [key] End)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_076(DataArray) ; (076_1)(GUI Object: [key] End)
      }
      ; -------------------------------------------
    }
    return
    l_077: ; (077_1)(GUI Object: [key] Home)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_077(DataArray) ; (077_1)(GUI Object: [key] Home)
      }
      ; -------------------------------------------
    }
    return
    l_078: ; (078_1)(GUI Object: [key] Insert)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_078(DataArray) ; (078_1)(GUI Object: [key] Insert)
      }
      ; -------------------------------------------
    }
    return
    l_079: ; (079_1)(GUI Object: [key] Page Down)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_079(DataArray) ; (079_1)(GUI Object: [key] Page Down)
      }
      ; -------------------------------------------
    }
    return
    l_080: ; (080_1)(GUI Object: [key] Page Up)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_080(DataArray) ; (080_1)(GUI Object: [key] Page Up)
      }
      ; -------------------------------------------
    }
    return
    l_081: ; (081_1)(GUI Object: [run][rwh] Select File)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_081(DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
      ; -------------------------------------------
    }
    return
    l_082: ; (082_1)(GUI Object: [ofl] Select Folder)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_082(DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
      ; -------------------------------------------
    }
    return
    l_083: ; (083_1)(GUI Object: [ToM] Pum)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_083(DataArray) ; (083_1)(GUI Object: [ToM] Pum)
      }
      ; -------------------------------------------
    }
    return
    l_084: ; (084_1)(GUI Object: [ToM] File Url Folder)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_084(DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
      }
      ; -------------------------------------------
    }
    return
    l_085: ; (085_1)(GUI Object: [key] Select Keyboard)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_085(DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
      }
      ; -------------------------------------------
    }
    return
    l_086: ; (086_1)(GUI Object: [ToM] Menu Control Key)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_086(DataArray) ; (086_1)(GUI Object: [ToM] Menu Control Key)
      }
      ; -------------------------------------------
    }
    return
    l_087: ; (087_1)(GUI Object: [mnu] Select Menu)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_087(DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
      }
      ; -------------------------------------------
    }
    return
    l_088: ; (088_1)(GUI Object: [mnu] App Context Menu 1)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_088(DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
      }
      ; -------------------------------------------
    }
    return
    l_089: ; (089_1)(GUI Object: [mnu] App Context Menu 2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_089(DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
      }
      ; -------------------------------------------
    }
    return
    l_090: ; (090_1)(GUI Object: [mnu] App Context Menu 3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_090(DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
      }
      ; -------------------------------------------
    }
    return
    l_091: ; (091_1)(GUI Object: [mnu] App Context Menu 4)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_091(DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
      }
      ; -------------------------------------------
    }
    return
    l_092: ; (092_1)(GUI Object: [mnu] App Context Menu 5)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_092(DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
      }
      ; -------------------------------------------
    }
    return
    l_093: ; (093_1)(GUI Object: [mnu] App Context Menu 6)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_093(DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
      }
      ; -------------------------------------------
    }
    return
    l_094: ; (094_1)(GUI Object: [mnu] App Context Menu 7)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_094(DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
      }
      ; -------------------------------------------
    }
    return
    l_095: ; (095_1)(GUI Object: [mnu] App Context Menu 8)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_095(DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
      }
      ; -------------------------------------------
    }
    return
    l_096: ; (096_1)(GUI Object: [mnu] App Context Menu 9)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_096(DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
      }
      ; -------------------------------------------
    }
    return
    l_097: ; (097_1)(GUI Object: [mnu] App Context Menu 10)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_097(DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
      }
      ; -------------------------------------------
    }
    return
    l_098: ; (098_1)(GUI Object: [mnu] App Context Menu 11)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_098(DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
      }
      ; -------------------------------------------
    }
    return
    l_099: ; (099_1)(GUI Object: Web Site Image Link)
    {
      ; -------------------------------------------
      DataArray := f_099(DataArray) ; (099_1)(GUI Object: Web Site Image Link)
      ; -------------------------------------------
    }
    return
    l_106: ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_106(DataArray) ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
      }
      ; -------------------------------------------
    }
    return
    l_116: ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_116(DataArray) ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
      }
      ; -------------------------------------------
    }
    return
    l_117: ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_117(DataArray) ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
      }
      ; -------------------------------------------
    }
    return
    l_118: ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_118(DataArray) ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
      }
      ; -------------------------------------------
    }
    return ; ------------------------------------------- 
    l_120: ; (120_1)(GUI Object: [mnu] List Center 1/3)
    {
      ; -------------------------------------------
      DataArray := f_120(DataArray) ; (120_1)(GUI Object: [mnu] List Center 1/3)
      ; -------------------------------------------
    }
    return ; ------------------------------------------- 
    l_121: ; (121_1)(GUI Object: [mnu] List Right 1/3)
    {
      ; -------------------------------------------
      DataArray := f_121(DataArray) ; (121_1)(GUI Object: [mnu] List Right 1/3)
      ; -------------------------------------------
    }
    return ; ------------------------------------------- 
    l_123: ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        ; -------------------------------------------
        DataArray := f_123(DataArray) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    return
    l_124: ; (124_1)(GUI Object: <Drop Down List> Language)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        ; -------------------------------------------
        DataArray.365.5 := DataArray.365.2 ; (365_5)(Old User language)/(365_2)(Current User language)
        ; -------------------------------------------
        DataArray := f_124(DataArray) ; (124_1)(GUI Object: <Drop Down List> Language)
        ; -------------------------------------------
        { ; Tray Icon Menu
          ; -------------------------------------------
          { ; (365_5)(Old User language)
            ; -------------------------------------------
            if (DataArray.365.5 == "de") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+0048}{U+006F}{U+0074}{U+0020}{U+004B}{U+0065}{U+0079}{U+0020}{U+00C4}{U+006E}{U+0064}{U+0065}{U+0072}{U+006E}")
              Old_MenuText_Exit := Unicode_To_String("{U+0042}{U+0065}{U+0065}{U+006E}{U+0064}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "en") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := "Change Hot Key"
              Old_MenuText_Exit := "Exit PopUpMenu"
            }
            else if (DataArray.365.5 == "es") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0072}{U+0020}{U+0074}{U+0065}{U+0063}{U+006C}{U+0061}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0063}{U+0063}{U+0065}{U+0073}{U+006F}{U+0020}{U+0072}{U+00E1}{U+0070}{U+0069}{U+0064}{U+006F}")
              Old_MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+006C}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "fr") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+0043}{U+0068}{U+0061}{U+006E}{U+0067}{U+0065}{U+0072}{U+0020}{U+004C}{U+0061}{U+0020}{U+0054}{U+006F}{U+0075}{U+0063}{U+0068}{U+0065}{U+0020}{U+0044}{U+0065}{U+0020}{U+0052}{U+0061}{U+0063}{U+0063}{U+006F}{U+0075}{U+0072}{U+0063}{U+0069}")
              Old_MenuText_Exit := Unicode_To_String("{U+0051}{U+0075}{U+0069}{U+0074}{U+0074}{U+0065}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "it") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0020}{U+0054}{U+0061}{U+0073}{U+0074}{U+006F}{U+0020}{U+0044}{U+0069}{U+0020}{U+0053}{U+0063}{U+0065}{U+006C}{U+0074}{U+0061}{U+0020}{U+0052}{U+0061}{U+0070}{U+0069}{U+0064}{U+0061}")
              Old_MenuText_Exit := Unicode_To_String("{U+0045}{U+0073}{U+0063}{U+0069}{U+0020}{U+0064}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "pl") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+005A}{U+006D}{U+0069}{U+0065}{U+0144}{U+0020}{U+006B}{U+006C}{U+0061}{U+0077}{U+0069}{U+0073}{U+007A}{U+0020}{U+0067}{U+006F}{U+0072}{U+0105}{U+0063}{U+0061}")
              Old_MenuText_Exit := Unicode_To_String("{U+0057}{U+0079}{U+006A}{U+0064}{U+017A}{U+0020}{U+007A}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "pt") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+}{U+006C}{U+0074}{U+0065}{U+0072}{U+0061}{U+0072}{U+0020}{U+0063}{U+0068}{U+0061}{U+0076}{U+0065}{U+0020}{U+0071}{U+0075}{U+0065}{U+006E}{U+0074}{U+0065}")
              Old_MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "ru") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+0418}{U+0437}{U+043C}{U+0435}{U+043D}{U+0438}{U+0442}{U+044C}{U+0020}{U+0413}{U+043E}{U+0440}{U+044F}{U+0447}{U+0443}{U+044E}{U+0020}{U+041A}{U+043B}{U+0430}{U+0432}{U+0438}{U+0448}{U+0443}")
              Old_MenuText_Exit := Unicode_To_String("{U+0412}{U+044B}{U+0445}{U+043E}{U+0434}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "sv") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+00C4}{U+006E}{U+0064}{U+0072}{U+0061}{U+0020}{U+0068}{U+0065}{U+0074}{U+0061}{U+0020}{U+006E}{U+0079}{U+0063}{U+006B}{U+0065}{U+006C}{U+006E}")
              Old_MenuText_Exit := Unicode_To_String("{U+}{U+0076}{U+0073}{U+006C}{U+0075}{U+0074}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.5 == "tr") ; (365_5)(Old User language)
            {
              Old_MenuText_HotKey := Unicode_To_String("{U+004B}{U+0131}{U+0073}{U+0061}{U+0079}{U+006F}{U+006C}{U+0020}{U+0054}{U+0075}{U+015F}{U+0075}{U+006E}{U+0075}{U+0020}{U+0044}{U+0065}{U+011F}{U+0069}{U+015F}{U+0074}{U+0069}{U+0072}")
              Old_MenuText_Exit := Unicode_To_String("{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}{U+0027}{U+0064}{U+0065}{U+006E}{U+0020}{U+00E7}{U+0131}{U+006B}")
            }
            ; -------------------------------------------
          } ; (365_5)(Old User language)
          ; -------------------------------------------
          { ; (365_2)(Current User language)
            ; -------------------------------------------
            if (DataArray.365.2 == "de") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+0048}{U+006F}{U+0074}{U+0020}{U+004B}{U+0065}{U+0079}{U+0020}{U+00C4}{U+006E}{U+0064}{U+0065}{U+0072}{U+006E}")
              MenuText_Exit := Unicode_To_String("{U+0042}{U+0065}{U+0065}{U+006E}{U+0064}{U+0065}{U+006E}{U+0020}{U+0053}{U+0069}{U+0065}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "en") ; (365_2)(Current User language)
            {
              MenuText_HotKey := "Change Hot Key"
              MenuText_Exit := "Exit PopUpMenu"
            }
            else if (DataArray.365.2 == "es") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0072}{U+0020}{U+0074}{U+0065}{U+0063}{U+006C}{U+0061}{U+0020}{U+0064}{U+0065}{U+0020}{U+0061}{U+0063}{U+0063}{U+0065}{U+0073}{U+006F}{U+0020}{U+0072}{U+00E1}{U+0070}{U+0069}{U+0064}{U+006F}")
              MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+006C}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "fr") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+0043}{U+0068}{U+0061}{U+006E}{U+0067}{U+0065}{U+0072}{U+0020}{U+004C}{U+0061}{U+0020}{U+0054}{U+006F}{U+0075}{U+0063}{U+0068}{U+0065}{U+0020}{U+0044}{U+0065}{U+0020}{U+0052}{U+0061}{U+0063}{U+0063}{U+006F}{U+0075}{U+0072}{U+0063}{U+0069}")
              MenuText_Exit := Unicode_To_String("{U+0051}{U+0075}{U+0069}{U+0074}{U+0074}{U+0065}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "it") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+0043}{U+0061}{U+006D}{U+0062}{U+0069}{U+0061}{U+0020}{U+0054}{U+0061}{U+0073}{U+0074}{U+006F}{U+0020}{U+0044}{U+0069}{U+0020}{U+0053}{U+0063}{U+0065}{U+006C}{U+0074}{U+0061}{U+0020}{U+0052}{U+0061}{U+0070}{U+0069}{U+0064}{U+0061}")
              MenuText_Exit := Unicode_To_String("{U+0045}{U+0073}{U+0063}{U+0069}{U+0020}{U+0064}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "pl") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+005A}{U+006D}{U+0069}{U+0065}{U+0144}{U+0020}{U+006B}{U+006C}{U+0061}{U+0077}{U+0069}{U+0073}{U+007A}{U+0020}{U+0067}{U+006F}{U+0072}{U+0105}{U+0063}{U+0061}")
              MenuText_Exit := Unicode_To_String("{U+0057}{U+0079}{U+006A}{U+0064}{U+017A}{U+0020}{U+007A}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "pt") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+}{U+006C}{U+0074}{U+0065}{U+0072}{U+0061}{U+0072}{U+0020}{U+0063}{U+0068}{U+0061}{U+0076}{U+0065}{U+0020}{U+0071}{U+0075}{U+0065}{U+006E}{U+0074}{U+0065}")
              MenuText_Exit := Unicode_To_String("{U+0053}{U+0061}{U+0069}{U+0072}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "ru") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+0418}{U+0437}{U+043C}{U+0435}{U+043D}{U+0438}{U+0442}{U+044C}{U+0020}{U+0413}{U+043E}{U+0440}{U+044F}{U+0447}{U+0443}{U+044E}{U+0020}{U+041A}{U+043B}{U+0430}{U+0432}{U+0438}{U+0448}{U+0443}")
              MenuText_Exit := Unicode_To_String("{U+0412}{U+044B}{U+0445}{U+043E}{U+0434}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "sv") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+00C4}{U+006E}{U+0064}{U+0072}{U+0061}{U+0020}{U+0068}{U+0065}{U+0074}{U+0061}{U+0020}{U+006E}{U+0079}{U+0063}{U+006B}{U+0065}{U+006C}{U+006E}")
              MenuText_Exit := Unicode_To_String("{U+}{U+0076}{U+0073}{U+006C}{U+0075}{U+0074}{U+0061}{U+0020}{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}")
            }
            else if (DataArray.365.2 == "tr") ; (365_2)(Current User language)
            {
              MenuText_HotKey := Unicode_To_String("{U+004B}{U+0131}{U+0073}{U+0061}{U+0079}{U+006F}{U+006C}{U+0020}{U+0054}{U+0075}{U+015F}{U+0075}{U+006E}{U+0075}{U+0020}{U+0044}{U+0065}{U+011F}{U+0069}{U+015F}{U+0074}{U+0069}{U+0072}")
              MenuText_Exit := Unicode_To_String("{U+0050}{U+006F}{U+0070}{U+0055}{U+0070}{U+004D}{U+0065}{U+006E}{U+0075}{U+0027}{U+0064}{U+0065}{U+006E}{U+0020}{U+00E7}{U+0131}{U+006B}")
            }
            ; -------------------------------------------
          } ; (365_2)(Current User language)
          ; -------------------------------------------
          Menu, Tray, Rename, %Old_MenuText_HotKey%, %MenuText_HotKey%
          Menu, Tray, Rename, %Old_MenuText_Exit%, %MenuText_Exit%
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
    }
    return
    l_125: ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_125(DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
      }
      ; -------------------------------------------
    }
    return
    l_126: ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_126(DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
      }
      ; -------------------------------------------
    }
    return
    l_127: ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_127(DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
      }
      ; -------------------------------------------
    }
    return
    l_128: ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_128(DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
      }
      ; -------------------------------------------
    }
    return
    l_129: ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_129(DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
      }
      ; -------------------------------------------
    }
    return
    l_130: ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_130(DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
      }
      ; -------------------------------------------
    }
    return
    l_131: ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        ; -------------------------------------------
        DataArray := f_131(DataArray) ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    return
    l_132: ; (132_1)(GUI Object: [url] Select Get URL Data)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_132(DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
      }
      ; -------------------------------------------
    }
    return
    l_133: ; (133_1)(GUI Object: Delete Shortcut)
    {
      ; -------------------------------------------
      DataArray := f_133(DataArray) ; (133_1)(GUI Object: Delete Shortcut)
      ; -------------------------------------------
    }
    return
    l_134: ; (134_1)(GUI Object: Message Image 1)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_134(DataArray) ; (134_1)(GUI Object: Message Image 1)
      }
      ; -------------------------------------------
    }
    return
    l_135: ; (135_1)(GUI Object: Message Image 2)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_135(DataArray) ; (135_1)(GUI Object: Message Image 2)
      }
      ; -------------------------------------------
    }
    return
    l_136: ; (136_1)(GUI Object: Message Image 3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_136(DataArray) ; (136_1)(GUI Object: Message Image 3)
      }
      ; -------------------------------------------
    }
    return
    l_137: ; (137_1)(GUI Object: Message Image 4)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_137(DataArray) ; (137_1)(GUI Object: Message Image 4)
      }
      ; -------------------------------------------
    }
    return
    l_138: ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_138(DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
      }
      ; -------------------------------------------
    }
    return
    l_139: ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_139(DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
      }
      ; -------------------------------------------
    }
    return
    l_140: ; (140_1)(GUI Object: [mnu] Addon Extra)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_140(DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
      }
      ; -------------------------------------------
    }
    return
    l_154: ; (154_1)(GUI Object: [pum] Pum Select Background)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_154(DataArray) ; (154_1)(GUI Object: [pum] Pum Select Background)
      }
      ; -------------------------------------------
    }
    l_155: ; (155_1)(GUI Object: [pum] Pum Select Display Text)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_155(DataArray) ; (155_1)(GUI Object: [pum] Pum Select Display Text)
      }
      ; -------------------------------------------
    }
    return
    l_156: ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_156(DataArray) ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
      }
      ; -------------------------------------------
    }
    return
    l_157: ; (157_1)(GUI Object: [pum] Pum Select Settings)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_157(DataArray) ; (157_1)(GUI Object: [pum] Pum Select Settings)
      }
      ; -------------------------------------------
    }
    return
    l_158: ; (158_1)(GUI Object: [pum] Pum Shortcut)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_158(DataArray) ; (158_1)(GUI Object: [pum] Pum Shortcut)
      }
      ; -------------------------------------------
    }
    return
    l_159: ; (159_1)(GUI Object: [pum] Select Custom Pum)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_159(DataArray) ; (159_1)(GUI Object: [pum] Select Custom Pum)
      }
      ; -------------------------------------------
    }
    return
    l_160: ; (160_1)(GUI Object: [pum] Select Application Pum)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_160(DataArray) ; (160_1)(GUI Object: [pum] Select Application Pum)
      }
      ; -------------------------------------------
    }
    return
    l_161: ; (161_1)(GUI Object: [pum] Delete Pum)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_161(DataArray) ; (161_1)(GUI Object: [pum] Delete Pum)
      }
      ; -------------------------------------------
    }
    return
    l_165: ; (165_1)(GUI Object: [pum] Backgroung Image Select)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_165(DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
      }
      ; -------------------------------------------
    }
    return
    l_166: ; (166_1)(GUI Object: [pum] Backgroung Color Select)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_166(DataArray) ; (166_1)(GUI Object: [pum] Backgroung Color Select)
      }
      ; -------------------------------------------
    }
    return
    l_167: ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_167(DataArray) ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
      }
      ; -------------------------------------------
    }
    return
    l_168: ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray := f_168(DataArray) ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
      }
      ; -------------------------------------------
    }
    return
    
    
    
    
    
    
    
    
    
    
    
    GuiClose: ; (062_1)(GUI Object: Cancel)
    {
      ; -------------------------------------------
      DataArray := f_062(DataArray) ; (062_1)(GUI Object: Cancel)
      ; -------------------------------------------
    }
    return
    Label_BTS_PumNewDelete:
    {
      ; -------------------------------------------
      
      ; -------------------------------------------
    }
    return
    Label_BTS_PumConfig:
    {
      ; -------------------------------------------
      
      ; -------------------------------------------
    }
    return
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End Labels
  ; ------------------------------------------
} ; End gui_Shortcut
; -------------------------------------------
{ ; #Include Lib Folder
  ; -------------------------------------------
  #Include %A_AppDataCommon%\PopUpMenu_PUM\system\Benchmark.ahk
  ; -------------------------------------------
  #Include %A_ScriptDir%\_S1_C.ahk
  #Include %A_ScriptDir%\_S2_H.ahk
  #Include %A_ScriptDir%\_S3_S.ahk
  #Include %A_ScriptDir%\Application_Request.ahk
  #Include %A_ScriptDir%\Array_Add.ahk
  #Include %A_ScriptDir%\Array_From_File.ahk
  #Include %A_ScriptDir%\Array_From_String.ahk
  #Include %A_ScriptDir%\Array_Item_Exist.ahk
  #Include %A_ScriptDir%\Array_Item_Is_In_Mult.ahk
  #Include %A_ScriptDir%\Array_Item_Position.ahk
  #Include %A_ScriptDir%\Array_Replace_Item.ahk
  #Include %A_ScriptDir%\Array_Reverse.ahk
  #Include %A_ScriptDir%\Array_Subtract.ahk
  #Include %A_ScriptDir%\Array_To_File.ahk
  #Include %A_ScriptDir%\Array_to_ListBox.ahk
  #Include %A_ScriptDir%\Connect_Check.ahk
  #Include %A_ScriptDir%\Convert_ResizeToBmp.ahk
  #Include %A_ScriptDir%\Convert_ChopToBmp.ahk
  #Include %A_ScriptDir%\Convert_ToIco.ahk
  #Include %A_ScriptDir%\cpl_TextFile_to_Array.ahk
  #Include %A_ScriptDir%\DataArray_Set.ahk
  #Include %A_ScriptDir%\Default_Application.ahk
  #Include %A_ScriptDir%\Default_Browser.ahk
  #Include %A_ScriptDir%\Download_File.ahk
  #Include %A_ScriptDir%\Existing_Shortcut.ahk
  #Include %A_ScriptDir%\Extract_Icons_From_File.ahk
  #Include %A_ScriptDir%\Find_Windows_Public_Folder.ahk
  #Include %A_ScriptDir%\f_004.ahk ; (004_1)(GUI Object: Ok Button)
  #Include %A_ScriptDir%\f_005.ahk ; (005_1)(GUI Object: Icon Rotate Left)
  #Include %A_ScriptDir%\f_006.ahk ; (006_1)(GUI Object: Icon Rotate Right)
  #Include %A_ScriptDir%\f_008.ahk ; (008_1)(GUI Object: [key] Alt)
  #Include %A_ScriptDir%\f_009.ahk ; (009_1)(GUI Object: [key] Alt Down)
  #Include %A_ScriptDir%\f_010.ahk ; (010_1)(GUI Object: [key] Alt Left)
  #Include %A_ScriptDir%\f_011.ahk ; (011_1)(GUI Object: [key] Alt Right)
  #Include %A_ScriptDir%\f_012.ahk ; (012_1)(GUI Object: [key] Alt Up)
  #Include %A_ScriptDir%\f_013.ahk ; (013_1)(GUI Object: [key] Caps Lock)
  #Include %A_ScriptDir%\f_014.ahk ; (014_1)(GUI Object: [key] Ctrl Down)
  #Include %A_ScriptDir%\f_015.ahk ; (015_1)(GUI Object: [key] Ctrl Left)
  #Include %A_ScriptDir%\f_016.ahk ; (016_1)(GUI Object: [key] Ctrl Right)
  #Include %A_ScriptDir%\f_017.ahk ; (017_1)(GUI Object: [key] Ctrl Up)
  #Include %A_ScriptDir%\f_018.ahk ; (018_1)(GUI Object: [key] Enter)
  #Include %A_ScriptDir%\f_019.ahk ; (019_1)(GUI Object: [key] Enter X2)
  #Include %A_ScriptDir%\f_020.ahk ; (020_1)(GUI Object: [key] Esc)
  #Include %A_ScriptDir%\f_021.ahk ; (021_1)(GUI Object: [key] Esc X2)
  #Include %A_ScriptDir%\f_022.ahk ; (022_1)(GUI Object: [key] F1)
  #Include %A_ScriptDir%\f_023.ahk ; (023_1)(GUI Object: [key] F2)
  #Include %A_ScriptDir%\f_024.ahk ; (024_1)(GUI Object: [key] F3)
  #Include %A_ScriptDir%\f_025.ahk ; (025_1)(GUI Object: [key] F4)
  #Include %A_ScriptDir%\f_026.ahk ; (026_1)(GUI Object: [key] F5)
  #Include %A_ScriptDir%\f_027.ahk ; (027_1)(GUI Object: [key] F6)
  #Include %A_ScriptDir%\f_028.ahk ; (028_1)(GUI Object: [key] F7)
  #Include %A_ScriptDir%\f_029.ahk ; (029_1)(GUI Object: [key] F8)
  #Include %A_ScriptDir%\f_030.ahk ; (030_1)(GUI Object: [key] F9)
  #Include %A_ScriptDir%\f_031.ahk ; (031_1)(GUI Object: [key] F10)
  #Include %A_ScriptDir%\f_032.ahk ; (032_1)(GUI Object: [key] F11)
  #Include %A_ScriptDir%\f_033.ahk ; (033_1)(GUI Object: [key] F12)
  #Include %A_ScriptDir%\f_034.ahk ; (034_1)(GUI Object: [key] Numpad 0)
  #Include %A_ScriptDir%\f_035.ahk ; (035_1)(GUI Object: [key] Numpad 1)
  #Include %A_ScriptDir%\f_036.ahk ; (036_1)(GUI Object: [key] Numpad 2)
  #Include %A_ScriptDir%\f_037.ahk ; (037_1)(GUI Object: [key] Numpad 3)
  #Include %A_ScriptDir%\f_038.ahk ; (038_1)(GUI Object: [key] Numpad 4)
  #Include %A_ScriptDir%\f_039.ahk ; (039_1)(GUI Object: [key] Numpad 5)
  #Include %A_ScriptDir%\f_040.ahk ; (040_1)(GUI Object: [key] Numpad 6)
  #Include %A_ScriptDir%\f_041.ahk ; (041_1)(GUI Object: [key] Numpad 7)
  #Include %A_ScriptDir%\f_042.ahk ; (042_1)(GUI Object: [key] Numpad 8)
  #Include %A_ScriptDir%\f_043.ahk ; (043_1)(GUI Object: [key] Numpad 9)
  #Include %A_ScriptDir%\f_044.ahk ; (044_1)(GUI Object: [key] Numpad Add)
  #Include %A_ScriptDir%\f_045.ahk ; (045_1)(GUI Object: [key] Numpad Divide)
  #Include %A_ScriptDir%\f_046.ahk ; (046_1)(GUI Object: [key] Numpad Dot)
  #Include %A_ScriptDir%\f_047.ahk ; (047_1)(GUI Object: [key] Numpad Enter)
  #Include %A_ScriptDir%\f_048.ahk ; (048_1)(GUI Object: [key] Numpad Multiply)
  #Include %A_ScriptDir%\f_049.ahk ; (049_1)(GUI Object: [key] Numpad Subtract)
  #Include %A_ScriptDir%\f_050.ahk ; (050_1)(GUI Object: [key] Shift)
  #Include %A_ScriptDir%\f_051.ahk ; (051_1)(GUI Object: [key] Shift Down)
  #Include %A_ScriptDir%\f_052.ahk ; (052_1)(GUI Object: [key] Shift Left)
  #Include %A_ScriptDir%\f_053.ahk ; (053_1)(GUI Object: [key] Shift Right)
  #Include %A_ScriptDir%\f_054.ahk ; (054_1)(GUI Object: [key] Shift Up)
  #Include %A_ScriptDir%\f_055.ahk ; (055_1)(GUI Object: [key] Tab)
  #Include %A_ScriptDir%\f_056.ahk ; (056_1)(GUI Object: [key] Tab X2)
  #Include %A_ScriptDir%\f_057.ahk ; (057_1)(GUI Object: [key] Windows Key)
  #Include %A_ScriptDir%\f_058.ahk ; (058_1)(GUI Object: [key] Windows Key Down)
  #Include %A_ScriptDir%\f_059.ahk ; (059_1)(GUI Object: [key] Windows Key Left)
  #Include %A_ScriptDir%\f_060.ahk ; (060_1)(GUI Object: [key] Windows Key Right)
  #Include %A_ScriptDir%\f_061.ahk ; (061_1)(GUI Object: [key] Windows Key Up)
  #Include %A_ScriptDir%\f_062.ahk ; (062_1)(GUI Object: Cancel)
  #Include %A_ScriptDir%\f_063.ahk ; (063_1)(GUI Object: Select Icon Image)
  #Include %A_ScriptDir%\f_064.ahk ; (064_1)(GUI Object: Reset Icon Image)
  #Include %A_ScriptDir%\f_068.ahk ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
  #Include %A_ScriptDir%\f_069.ahk ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
  #Include %A_ScriptDir%\f_070.ahk ; (070_1)(GUI Object: [cpl] Select Control)
  #Include %A_ScriptDir%\f_071.ahk ; (071_1)(GUI Object: [url] Select URL)
  #Include %A_ScriptDir%\f_072.ahk ; (072_1)(GUI Object: [key] Application Only)
  #Include %A_ScriptDir%\f_073.ahk ; (073_1)(GUI Object: [run] As Admin)
  #Include %A_ScriptDir%\f_074.ahk ; (074_1)(GUI Object: [key] Ctrl)
  #Include %A_ScriptDir%\f_075.ahk ; (075_1)(GUI Object: [key] Delete)
  #Include %A_ScriptDir%\f_076.ahk ; (076_1)(GUI Object: [key] End)
  #Include %A_ScriptDir%\f_077.ahk ; (077_1)(GUI Object: [key] Home)
  #Include %A_ScriptDir%\f_078.ahk ; (078_1)(GUI Object: [key] Insert)
  #Include %A_ScriptDir%\f_079.ahk ; (079_1)(GUI Object: [key] Page Down)
  #Include %A_ScriptDir%\f_080.ahk ; (080_1)(GUI Object: [key] Page Up)
  #Include %A_ScriptDir%\f_081.ahk ; (081_1)(GUI Object: [run][rwh] Select File)
  #Include %A_ScriptDir%\f_082.ahk ; (082_1)(GUI Object: [ofl] Select Folder)
  #Include %A_ScriptDir%\f_083.ahk ; (083_1)(GUI Object: [ToM] Pum)
  #Include %A_ScriptDir%\f_084.ahk ; (084_1)(GUI Object: [ToM] File Url Folder)
  #Include %A_ScriptDir%\f_085.ahk ; (085_1)(GUI Object: [key] Select Keyboard)
  #Include %A_ScriptDir%\f_086.ahk ; (086_1)(GUI Object: [ToM] Menu Control Key)
  #Include %A_ScriptDir%\f_087.ahk ; (087_1)(GUI Object: [mnu] Select Menu)
  #Include %A_ScriptDir%\f_088.ahk ; (088_1)(GUI Object: [mnu] App Context Menu 1)
  #Include %A_ScriptDir%\f_089.ahk ; (089_1)(GUI Object: [mnu] App Context Menu 2)
  #Include %A_ScriptDir%\f_090.ahk ; (090_1)(GUI Object: [mnu] App Context Menu 3)
  #Include %A_ScriptDir%\f_091.ahk ; (091_1)(GUI Object: [mnu] App Context Menu 4)
  #Include %A_ScriptDir%\f_092.ahk ; (092_1)(GUI Object: [mnu] App Context Menu 5)
  #Include %A_ScriptDir%\f_093.ahk ; (093_1)(GUI Object: [mnu] App Context Menu 6)
  #Include %A_ScriptDir%\f_094.ahk ; (094_1)(GUI Object: [mnu] App Context Menu 7)
  #Include %A_ScriptDir%\f_095.ahk ; (095_1)(GUI Object: [mnu] App Context Menu 8)
  #Include %A_ScriptDir%\f_096.ahk ; (096_1)(GUI Object: [mnu] App Context Menu 9)
  #Include %A_ScriptDir%\f_097.ahk ; (097_1)(GUI Object: [mnu] App Context Menu 10)
  #Include %A_ScriptDir%\f_098.ahk ; (098_1)(GUI Object: [mnu] App Context Menu 11)
  #Include %A_ScriptDir%\f_099.ahk ; (099_1)(GUI Object: Web Site Image Link)
  #Include %A_ScriptDir%\f_102.ahk ; (102_1)(GUI Object: Main Display Icon)
  #Include %A_ScriptDir%\f_106.ahk ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
  #Include %A_ScriptDir%\f_116.ahk ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
  #Include %A_ScriptDir%\f_117.ahk ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
  #Include %A_ScriptDir%\f_118.ahk ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
  #Include %A_ScriptDir%\f_120.ahk ; (120_1)(GUI Object: [mnu] List Center 1/3)
  #Include %A_ScriptDir%\f_121.ahk ; (121_1)(GUI Object: [mnu] List Right 1/3)
  #Include %A_ScriptDir%\f_123.ahk ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
  #Include %A_ScriptDir%\f_124.ahk ; (124_1)(GUI Object: <Drop Down List> Language)
  #Include %A_ScriptDir%\f_125.ahk ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
  #Include %A_ScriptDir%\f_126.ahk ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
  #Include %A_ScriptDir%\f_127.ahk ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
  #Include %A_ScriptDir%\f_128.ahk ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
  #Include %A_ScriptDir%\f_129.ahk ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
  #Include %A_ScriptDir%\f_130.ahk ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
  #Include %A_ScriptDir%\f_131.ahk ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
  #Include %A_ScriptDir%\f_132.ahk ; (132_1)(GUI Object: [url] Select Get URL Data)
  #Include %A_ScriptDir%\f_133.ahk ; (133_1)(GUI Object: Delete Shortcut)
  #Include %A_ScriptDir%\f_134.ahk ; (134_1)(GUI Object: Message Image 1)
  #Include %A_ScriptDir%\f_135.ahk ; (135_1)(GUI Object: Message Image 2)
  #Include %A_ScriptDir%\f_136.ahk ; (136_1)(GUI Object: Message Image 3)
  #Include %A_ScriptDir%\f_137.ahk ; (137_1)(GUI Object: Message Image 4)
  #Include %A_ScriptDir%\f_138.ahk ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
  #Include %A_ScriptDir%\f_139.ahk ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
  #Include %A_ScriptDir%\f_140.ahk ; (140_1)(GUI Object: [mnu] Addon Extra)
  
  
  
  #Include %A_ScriptDir%\f_154.ahk ; (154_1)(GUI Object: [pum] Pum Select Background)
  #Include %A_ScriptDir%\f_155.ahk ; (155_1)(GUI Object: [pum] Pum Select Display Text)
  #Include %A_ScriptDir%\f_156.ahk ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
  #Include %A_ScriptDir%\f_157.ahk ; (157_1)(GUI Object: [pum] Pum Select Settings)
  #Include %A_ScriptDir%\f_158.ahk ; (158_1)(GUI Object: [pum] Pum Shortcut)
  #Include %A_ScriptDir%\f_159.ahk ; (159_1)(GUI Object: [pum] Select Custom Pum)
  #Include %A_ScriptDir%\f_160.ahk ; (160_1)(GUI Object: [pum] Select Application Pum)
  #Include %A_ScriptDir%\f_161.ahk ; (161_1)(GUI Object: [pum] Delete Pum)
  #Include %A_ScriptDir%\f_165.ahk ; (165_1)(GUI Object: [pum] Backgroung Image Select)
  #Include %A_ScriptDir%\f_166.ahk ; (166_1)(GUI Object: [pum] Backgroung Color Select)
  #Include %A_ScriptDir%\f_167.ahk ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
  #Include %A_ScriptDir%\f_168.ahk ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
  
  
  #Include %A_ScriptDir%\F_UnZip.ahk
  #Include %A_ScriptDir%\Function_Flow.ahk
  #Include %A_ScriptDir%\Function_Msg.ahk
  #Include %A_ScriptDir%\Find_Windows_Public_Folder.ahk
  #Include %A_ScriptDir%\GetActiveBrowserURL.ahk
  #Include %A_ScriptDir%\GetAddressBar.ahk
  #Include %A_ScriptDir%\GetBrowserURL_ACC.ahk
  #Include %A_ScriptDir%\GetBrowserURL_DDE.ahk
  #Include %A_ScriptDir%\GetSelected_ListNumber.ahk
  #Include %A_ScriptDir%\GuiControlImage_PopUpMenu.ahk
  #Include %A_ScriptDir%\GuiControlImage_HotKeySelect.ahk
  #Include %A_ScriptDir%\Gui_Text_Width.ahk
  #Include %A_ScriptDir%\HotKey_Cancel.ahk
  #Include %A_ScriptDir%\HotKey_Check_Selected.ahk
  #Include %A_ScriptDir%\Hotkey_gui.ahk
  #Include %A_ScriptDir%\HotKey_Ok.ahk
  #Include %A_ScriptDir%\HotKey_Select_Key.ahk
  #Include %A_ScriptDir%\HotKey_Text_Display_Language.ahk
  #Include %A_ScriptDir%\HotKey_UnSelect_Key.ahk
  #Include %A_ScriptDir%\HotKey_Validate.ahk
  #Include %A_ScriptDir%\IsURL.ahk
  #Include %A_ScriptDir%\Is_Script_Running.ahk
  #Include %A_ScriptDir%\KeyArray_Display.ahk
  #Include %A_ScriptDir%\KeyArray_KeyIsIn.ahk
  #Include %A_ScriptDir%\KeyArray_Numbers.ahk
  #Include %A_ScriptDir%\KeyArray_SelectKey.ahk
  #Include %A_ScriptDir%\KeyArray_Shortcut.ahk
  #Include %A_ScriptDir%\KeyArray_Validate.ahk
  #Include %A_ScriptDir%\mnu_TextAddon_to_MenuArray.ahk
  #Include %A_ScriptDir%\Mouse_IsIn_Window.ahk
  #Include %A_ScriptDir%\Product_ID.ahk
  #Include %A_ScriptDir%\Pum_Close.ahk
  #Include %A_ScriptDir%\Pum_Run.ahk
  #Include %A_ScriptDir%\Reset_Vars.ahk
  #Include %A_ScriptDir%\Script_Close.ahk
  #Include %A_ScriptDir%\Send_Email.ahk
  #Include %A_ScriptDir%\Shortcut_Config.ahk
  #Include %A_ScriptDir%\Shortcut_Info.ahk
  #Include %A_ScriptDir%\SleepTime.ahk
  #Include %A_ScriptDir%\Splash_Script.ahk
  ;~ #Include %A_ScriptDir%\StartUp.ahk
  #Include %A_ScriptDir%\String_Reverse.ahk
  #Include %A_ScriptDir%\String_To_Unicode.ahk
  #Include %A_ScriptDir%\Text_Adjust_PopUpMenu.ahk
  #Include %A_ScriptDir%\Text_Adjust_HotKeySelect.ahk
  #Include %A_ScriptDir%\Text_File.ahk
  #Include %A_ScriptDir%\Unicode_In_String.ahk
  #Include %A_ScriptDir%\Unicode_to_String.ahk
  #Include %A_ScriptDir%\url_Acc_Children.ahk
  #Include %A_ScriptDir%\url_Acc_Init.ahk
  #Include %A_ScriptDir%\url_Acc_ObjectFromWindow.ahk
  #Include %A_ScriptDir%\url_Acc_Query.ahk
  #Include %A_ScriptDir%\url_Get_PageIcon.ahk
  #Include %A_ScriptDir%\url_Get_PageIcon_Title.ahk
  #Include %A_ScriptDir%\url_Get_URL_Address.ahk
  #Include %A_ScriptDir%\url_HtmlCode_to_Text.ahk
  ; -------------------------------------------
} ; End #Include Lib Folder
; -------------------------------------------
