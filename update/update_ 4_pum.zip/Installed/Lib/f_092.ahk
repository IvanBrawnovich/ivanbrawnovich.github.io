﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_092(DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_092", DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
  ; -------------------------------------------
  if (DataArray.92.2 == 1) ; (092_2)([mnu] App Context Menu 5: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    { ; Select/UnSelect
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("140", 1, 1, DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("088", 1, 1, DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
      DataArray := GuiControlImage_PopUpMenu("089", 1, 1, DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
      DataArray := GuiControlImage_PopUpMenu("090", 1, 1, DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
      DataArray := GuiControlImage_PopUpMenu("091", 1, 1, DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
      DataArray := GuiControlImage_PopUpMenu("092", 2, 1, DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
      DataArray := GuiControlImage_PopUpMenu("093", 1, 1, DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
      DataArray := GuiControlImage_PopUpMenu("094", 1, 1, DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
      DataArray := GuiControlImage_PopUpMenu("095", 1, 1, DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
      DataArray := GuiControlImage_PopUpMenu("096", 1, 1, DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
      DataArray := GuiControlImage_PopUpMenu("097", 1, 1, DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
      DataArray := GuiControlImage_PopUpMenu("098", 1, 1, DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
      ; -------------------------------------------
    } ; End Select/UnSelect
    ; -------------------------------------------
    { ; [MenuArrayNum]
      ; -------------------------------------------
      DataArray.302.2 := 5 ; (302_2)([mnu] Menu Number #_X_X_[X])
      DataArray.302.3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
      DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
      DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      ; -------------------------------------------
    } ; End [MenuArrayNum]
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
