﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Script_Close(ThisScript)
{
  while (Is_Script_Running(ThisScript) > 0)
  {
    DetectHiddenWindows, On
    WinClose, %ThisScript% ahk_class AutoHotkey
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\Lib"
    }
    Disable_Wait := Script_Dir "\Disable_Wait.ahk"
    RunWait, %Disable_Wait%
    DetectHiddenWindows, On
    WinClose, %Disable_Wait% ahk_class AutoHotkey
  }
}
