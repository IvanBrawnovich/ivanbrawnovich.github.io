﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_136(DataArray) ; (136_1)(GUI Object: Message Image 3)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_136", DataArray) ; (136_1)(GUI Object: Message Image 3)
  ; -------------------------------------------
  if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(Script Type)
  {
    DataArray := f_085(DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
  }
  else if (DataArray.366.5 ==  "run_rwh_url_ofl") ; (366_5)(Script Type)
  {
    DataArray := f_082(DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
  }
  return DataArray
  ; -------------------------------------------
}
