﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Extra Icons
; -------------------------------------------
f_106(DataArray) ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_106", DataArray) ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  v_368_4 := DataArray.368.4 ; (368_4)(This Application Icons Folder [Extracted])
  ; -------------------------------------------
  { ; Language Set DialogText [SET] DialogText := "PUM - Shortcut Icon"
    ; -------------------------------------------
    if (v_365_2 == "en") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Shortcut Icon"
    } ; End (en English)
    else if (v_365_2 == "fr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Icône de raccourci"
    } ; End (fr French)
    else if (v_365_2 == "de") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Shortcut-Symbol"
    } ; End (de German)
    else if (v_365_2 == "it") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Icone Scorciatoia"
    } ; End (it Italian)
    else if (v_365_2 == "pl") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Ikona skrótu"
    } ; End (pl Polish)
    else if (v_365_2 == "pt") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Ícone de atalho"
    } ; End (pt Portuguese)
    else if (v_365_2 == "ru") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Контекстное Значок"
    } ; End (ru Russian)
    else if (v_365_2 == "es") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Icono de acceso directo"
    } ; End (es Spanish)
    else if (v_365_2 == "sv") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Genvägsikonen"
    } ; End (sv Swedish)
    else if (v_365_2 == "tr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Kısayol Simgesi"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End Language Set DialogText [SET] DialogText := "PUM - Shortcut Icon"
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  FileSelectFile, ThisFile, 3, %v_368_4%, %DialogText% ; (368_4)(This Application Icons Folder [Extracted])
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if ThisFile
  {
    ; -------------------------------------------
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, ThisFile , , , ThisExt
    StringLower, ThisExt, ThisExt
    ; -------------------------------------------
    if (ThisExt == "ico")
    {
      ; -------------------------------------------
      DataArray := f_102(ThisFile, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      ; -------------------------------------------
    } ; End (ThisExt == "ico")
    ; -------------------------------------------
  } ; End if ThisFile
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
