﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_133(DataArray) ; (133_1)(GUI Object: Delete Shortcut)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_133", DataArray) ; (133_1)(GUI Object: Delete Shortcut)
  ; -------------------------------------------
  if (DataArray.133.2 == 1) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("133", 2, 1, DataArray) ; (133_1)(GUI Object: Delete Shortcut)
    ; -------------------------------------------
    GuiControl, PopUpMenu:Disable, g_131 ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    GuiControl, PopUpMenu:Disable, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    GuiControl, PopUpMenu:Disable, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    GuiControl, PopUpMenu:Disable, g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
    GuiControl, PopUpMenu:Disable, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
    GuiControl, PopUpMenu:Disable, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
    GuiControl, PopUpMenu:Disable, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
    GuiControl, PopUpMenu:Disable, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
    GuiControl, PopUpMenu:Disable, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
    ; -------------------------------------------
  }
  else if (DataArray.133.2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("133", 1, 1, DataArray) ; (133_1)(GUI Object: Delete Shortcut)
    ; -------------------------------------------
    GuiControl, PopUpMenu:Enable, g_131 ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    GuiControl, PopUpMenu:Enable, g_122 ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    GuiControl, PopUpMenu:Enable, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    GuiControl, PopUpMenu:Enable, g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
    GuiControl, PopUpMenu:Enable, g_116 ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
    GuiControl, PopUpMenu:Enable, g_117 ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
    GuiControl, PopUpMenu:Enable, g_118 ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
    GuiControl, PopUpMenu:Enable, g_120 ; (120_1)(GUI Object: [mnu] List Center 1/3)
    GuiControl, PopUpMenu:Enable, g_121 ; (121_1)(GUI Object: [mnu] List Right 1/3)
    ; -------------------------------------------
  }
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray) 
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  if (DataArray.133.2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    DataArray := GuiControlImage_PopUpMenu("004", 1, 1, DataArray) ; (004_1)(GUI Object: Ok Button)
  }
  return DataArray
  ; -------------------------------------------
} ; End L_BTS_DeleteShortcut(DataArray) ; > DataArray
