﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Unicode_In_String(ItemValue) ; "(U_Code)XXXX(U_Code)" > ItemValue
{
  ; -------------------------------------------
  while (InStr(ItemValue, "(U_Code)") > 0)
  {
    Pos_1 := InStr(ItemValue, "(U_Code)")
    Pos_2 := InStr(ItemValue, "(U_Code)", , , 2)
    Cod_1 := SubStr(ItemValue, Pos_1 + 8, (Pos_2 - Pos_1) - 8)
    Uni_1 := "{U+" Cod_1 "}"
    Str_1 := Unicode_To_String(Uni_1) ; "{U+xxxx}" > String
    ItemValue := StrReplace(ItemValue, "(U_Code)" Cod_1 "(U_Code)", Str_1)
  }
  ; -------------------------------------------
  return ItemValue
  ; -------------------------------------------
}
; -------------------------------------------
