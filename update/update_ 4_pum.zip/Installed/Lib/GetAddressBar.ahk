﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
GetAddressBar(accObj)
{
  try if ((accObj.accRole(0) == 42) and IsURL(accObj.accValue(0)))
  {
    return accObj
  }
  try if ((accObj.accRole(0) == 42) and IsURL("http://" accObj.accValue(0))) ; Modern browsers omit "http://"
  {
    return accObj
  }
  for nChild, accChild in url_Acc_Children(accObj)
  {
    if IsObject(accAddressBar := GetAddressBar(accChild))
    {
      return accAddressBar
    }
  }
}
