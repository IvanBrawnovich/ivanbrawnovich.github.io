﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Shortcut_Config(DataArray) ; > DataArray
{
  { ; Start Up Vars
    ; -------------------------------------------
    v_133_2 := DataArray.133.2 ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
    ; -------------------------------------------
    ; Common Make\Change\Delete
    ;
    v_361_3  := DataArray.361.3 ; (361_3)(Pum Factored Width [pixels])
    v_361_4  := DataArray.361.4 ; (361_4)(Pum Factored Height [pixels])
    v_361_5  := DataArray.361.5 ; (361_5)(Pum Actual Window Width [pixels])
    v_361_6  := DataArray.361.6 ; (361_6)(Pum Actual Window Height [pixels])
    v_361_8  := DataArray.361.8 ; (361_8)(Pum [Specific Folder Path])
    v_361_9  := DataArray.361.9 ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
    v_361_10 := DataArray.361.10 ; (361_10)(Pum toolbox0.xml [Array])
    ;
    v_362_2  := DataArray.362.2 ; (362_2)([XML][Line 3] Pum Display Name in TitleBar)
    v_362_3  := DataArray.362.3 ; (362_3)([XML][Line 3] Pum Total Height (Y) Rows)
    v_362_4  := DataArray.362.4 ; (362_4)([XML][Line 3] Pum Total Width (X) Columns)
    
    v_362_7  := DataArray.362.7 ; (362_7)([XML][Line 3] Pum stayontop [Always -1])
    v_362_8 := DataArray.362.8 ; (362_8)([XML][Line 5] Titlebar visible [-1 On / 0 Off])
    v_362_9 := DataArray.362.9  ; (362_9)([XML][Line 5] Titlebar height [4 - 32])
    v_362_10 := DataArray.362.10 ; (362_10)([XML][Line 7] Ststusbar visible [-1 On / 0 Off])
    v_362_11 := DataArray.362.11 ; (362_11)([XML][Line 7] Ststusbar height [4 - 32])
    v_362_31 := DataArray.362.31 ; (362_31)([XML][Line 20] Background filename [BMP Full Path])
    ;
    ; -------------------------------------------
    ; Change
    v_370_9  := DataArray.370.9 ; (370_9)(XML_SC_L2 Old Script [Full File Path])
    v_370_10 := DataArray.370.10 ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
    ; -------------------------------------------
    ; Make\Change
    ;
    v_102_3  := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
    ;
    v_122_3  := DataArray.122.3 ; (122_3)(<Edit Feild> Status Bar Description: Value)
    ;
    v_366_5  := DataArray.366.5 ; (366_5)(Script Type)
    ;
    v_370_2  := DataArray.370.2 ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)
    v_370_3  := DataArray.370.3 ; (370_3)(XML_SC_L1 [Y-Row][Grid Positon)
    v_370_4  := DataArray.370.4 ; (370_4)(XML_SC_L1 [TextColor])
    v_370_5  := DataArray.370.5 ; (370_5)(XML_SC_L1 [TextAlign])
    v_370_6  := DataArray.370.6 ; (370_6)(XML_SC_L1 [ParaAlign])
    v_370_7  := DataArray.370.7 ; (370_7)(XML_SC_L1 [Type])
    ;
    v_386_10 := DataArray.386.10 ; (386_10)(All Pums Icon cache [Folder Path])
    ; -------------------------------------------
    ; Change\Delete
    v_370_1 := DataArray.370.1 ; (370_1)(XML_SC Line Numer)
    ; -------------------------------------------
  } ; End Start Up Vars  
  ; -------------------------------------------
  { ; Modify Vars
    ; -------------------------------------------
    ; Center Pum
    ; -------------------------------------------
    v_362_5 := Ceil((A_ScreenWidth - v_361_5) / 2) ; (362_5)([XML][Line 3] Pum Window Position (X) Left)/(361_5)(Pum Actual Window Width [pixels])
    v_362_6 := Ceil((A_ScreenHeight - v_361_6) / 2)  ; (362_6)([XML][Line 3] Pum Window Position (Y) Top)/(361_6)(Pum Actual Window Height [pixels])
    ; -------------------------------------------
  } ; End Modify Vars
  ; -------------------------------------------
  { ; Var Defaults [PUM Config]
    ; -------------------------------------------
    v_362_7 := "-1" ; (362_7)([XML][Line 3] Pum stayontop [Always -1])
    ; (362_7)([XML][Line 3] Pum stayontop [Always -1])
    ; -------------------------------------------
    v_362_12 := "-1" ; (362_12)([XML][Line 7] Ststusbar hint [Always -1])
    v_362_13 := "0" ; (362_13)([XML][Line 9] Displaymode type [Always 0])
    v_362_18 := "0" ; (362_18)([XML][Line 13] Border spacing [Always 0])
    v_362_19 := "0" ; (362_19)([XML][Line 13] Border type [Always 0])
    v_362_23 := "0" ; (362_23)([XML][Line 15] Font shadowtype [Always 0])
    v_362_29 := "0" ; (362_29)([XML][Line 19] Background effect [Always 0])
    ; -------------------------------------------
  } ; End Var Defaults [PUM Config]
  ; -------------------------------------------
  { ; Var Defaults [Shortcut]
    ; -------------------------------------------
    v_370_5 := 0 ; (370_5)(XML_SC_L1 [TextAlign])
    v_370_6 := 2 ; (370_6)(XML_SC_L1 [ParaAlign])
    v_370_7 := 0 ; (370_7)(XML_SC_L1 [Type])
    if (v_370_4 == "") ; (370_4)(XML_SC_L1 [TextColor])
    {
      v_370_4 := "16777215" ; (370_4)(XML_SC_L1 [TextColor])
    }
    ; -------------------------------------------
  } ; End Var Defaults [Shortcut]
  ; -------------------------------------------
  if (v_133_2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    { ; Start Up Vars
      ; -------------------------------------------
      FormatTime, TimeRightNow , , yyyyMMddHHmmss
      ThisYear := SubStr(TimeRightNow, 1, 4)
      ThisMonth := SubStr(TimeRightNow, 5, 2)
      ThisDay := SubStr(TimeRightNow, 7, 2)
      ThisHour := SubStr(TimeRightNow, 9, 2)
      ThisMinute := SubStr(TimeRightNow, 11, 2)
      ThisSecond := SubStr(TimeRightNow, 13, 2)
      TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (v_366_5 == "cpl") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
      ; Script_Line_2 := "#_#_(#)"            (cpl) %(365_2)%_cpl_%(300_2)%_%(300_3)%_(%(300_4)%) "XXX_XXX_(XXX)"
      ; Script_Line_3 := ""                   (cpl) *** EMPTY ***
      ; Script_Line_4 := ""                   (cpl) *** EMPTY ***
      ; Script_Line_5 := ""                   (cpl) *** EMPTY ***
      ; Script_Line_6 := ""                   (cpl) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
      ;
      ; ------------------------------------------- Var_1
      if (DataArray.300.3 > 0) ; (300_3)([cpl] Menu Number X_#_[X])
      {
        Var_1 := "Var_1 := """ DataArray.300.2 "_" DataArray.300.3 "_(" DataArray.300.4 ")""" ; (300_2)([cpl] Menu Number #_X_[X])/(300_3)([cpl] Menu Number X_#_[X])/(300_4)([cpl] Menu Number X_X_[#])
      }
      else
      {
        Var_1 := "Var_1 := """ DataArray.300.2 "_(" DataArray.300.4 ")""" ; (300_2)([cpl] Menu Number #_X_[X])/(300_4)([cpl] Menu Number X_X_[#])
      }
      ; ------------------------------------------- Var_2
      Var_2 := "Var_2 := """""
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """""
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """""
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (cpl)
    ; -------------------------------------------
    else if (v_366_5 == "key") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
      ; Script_Line_2 := 1/2                  (key) (072_2)
      ; Script_Line_3 := ["[Key]", "~X~"]     (key) (301_8)
      ; Script_Line_4 := "App Class"          (key) (301_5)
      ; Script_Line_5 := "App Process"        (key) (301_6)
      ; Script_Line_6 := ""                   (key) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
      ;
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := " DataArray.72.2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      ; ------------------------------------------- Var_2
      v_301_8 := DataArray.301.8 ; (301_8)([key] KeyArray_Shortcut [Array])
      v_301_8_Len := v_301_8.MaxIndex() ; (301_8)([key] KeyArray_Shortcut [Array])
      Var_2 := "Var_2 := ["""
      for Index, ThisItem in v_301_8 ; (301_8)([key] KeyArray_Shortcut [Array])
      {
        if (Index < v_301_8_Len) ; (301_8)([key] KeyArray_Shortcut [Array])
        {
          Var_2 := Var_2 ThisItem """, """
        }
        else
        {
          Var_2 := Var_2 ThisItem  """]"
        }
      }
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """ DataArray.301.5 """" ; (301_5)([key][mnu] [Line 4] Application Only Class)
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """ DataArray.301.6 """" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (key)
    ; -------------------------------------------
    else if (v_366_5 == "mnu") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
      ; Script_Line_2 := 2                    (mnu) (072_2) (Always Selected = 2)
      ; Script_Line_3 := "#_#_#_(#)"          (mnu) %(302_2)%_%(302_3)%_%(302_4)%_(%(302_5)%) "XXX_XXX_XXX_(XXX)"
      ; Script_Line_4 := "App Class"          (mnu) (301_5)
      ; Script_Line_5 := "App Process"        (mnu) (301_6)
      ; Script_Line_6 := "Lang"               (mnu) (365_2)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
      ;
      v_301_5 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)/(301_5)([key][mnu] [Line 4] Application Only Class)
      v_301_6 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := 2"
      ; ------------------------------------------- Var_2
      if (DataArray.302.3 > 0) ; (302_3)([mnu] Menu Number X_#_X_[X])
      {
        if (DataArray.302.4 > 0) ; (302_4)([mnu] Menu Number X_X_#_[X])
        {
          Var_2 := "Var_2 := """ DataArray.302.2 "_" DataArray.302.3 "_" DataArray.302.4 "_(" DataArray.302.5 ")""" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_4)([mnu] Menu Number X_X_#_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
        }
        else
        {
          Var_2 := "Var_2 := """ DataArray.302.2 "_" DataArray.302.3 "_(" DataArray.302.5 ")""" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
        }
      }
      else
      {
        Var_2 := "Var_2 := """ DataArray.302.2 "_(" DataArray.302.5 ")""" ; (302_2)([mnu] Menu Number #_X_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
      }
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """ v_301_5 """" ; (301_5)([key][mnu] [Line 4] Application Only Class)
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """ v_301_6 """" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """ DataArray.365.2 """" ; (365_2)(Current User language)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (mnu)
    ; -------------------------------------------
    else if (v_366_5 == "ofl") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
      ; Script_Line_2 := ""                   (ofl) *** EMPTY ***
      ; Script_Line_3 := "D:\Pictures"        (ofl) (303_2)
      ; Script_Line_4 := ""                   (ofl) *** EMPTY ***
      ; Script_Line_5 := ""                   (ofl) *** EMPTY ***
      ; Script_Line_6 := ""                   (ofl) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
      ;
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := """""
      ; ------------------------------------------- Var_2
      Var_2 := "Var_2 := """ DataArray.303.2 """" ; (303_2)([ofl] Folder Path)
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """""
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """""
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (ofl)
    ; -------------------------------------------
    else if (v_366_5 == "run") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
      ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      ; Script_Line_3 := "E:\Application.exe" (run) (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      ; Script_Line_4 := ""                   (run) *** EMPTY ***
      ; Script_Line_5 := ""                   (run) *** EMPTY ***
      ; Script_Line_6 := ""                   (run) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
      ;
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := " DataArray.73.2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      ; ------------------------------------------- Var_2
      Var_2 := "Var_2 := """ DataArray.305.4 """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """""
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """""
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (run)
    ; -------------------------------------------
    else if (v_366_5 == "rwh") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
      ; Script_Line_2 := 1/2                  (run) (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      ; Script_Line_3 := "E:\FilePath.EXT"    (rwh) (305_4)([File Name] [File Ext] [File Path])
      ; Script_Line_4 := "C:\Application.exe" (rwh) (305_5)(Selected Opening Application [Full File Path])
      ; Script_Line_5 := ""                   (rwh) *** EMPTY ***
      ; Script_Line_6 := ""                   (rwh) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
      ;
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := " DataArray.73.2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
      ; ------------------------------------------- Var_2
      Var_2 := "Var_2 := """ DataArray.305.4 """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """ DataArray.305.5 """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """""
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (rwh)
    ; -------------------------------------------
    else if (v_366_5 == "url") ; (366_5)(Script Type)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
      ; Script_Line_2 := 0/1                  (url) (307_7)([url] Use Default Browser [0/1])
      ; Script_Line_3 := "https://Site.com/"  (url) (307_2)([url] Current URL)
      ; Script_Line_4 := "C:\Browser.exe"     (url) (307_5)([url] Opening Browser [Full File Path])
      ; Script_Line_5 := ""                   (url) *** EMPTY ***
      ; Script_Line_6 := ""                   (url) *** EMPTY ***
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
      ;
      ; ------------------------------------------- Var_1
      Var_1 := "Var_1 := " DataArray.307.7 ; (307_7)([url] Use Default Browser [0/1])
      ; ------------------------------------------- Var_2
      Var_2 := "Var_2 := """ DataArray.307.2 """" ; (307_2)([url] Current URL)
      ; ------------------------------------------- Var_3
      Var_3 := "Var_3 := """ DataArray.307.5 """" ; (307_5)([url] Selected Opening Browser [Full File Path])
      ; ------------------------------------------- Var_4
      Var_4 := "Var_4 := """""
      ; ------------------------------------------- Var_5
      Var_5 := "Var_5 := """""
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (url)
    ; -------------------------------------------
    { ; XML_Line_3 <toolbox name="PopUpMenu - Desktop" rows="11" columns="15" left="150" top="100" stayontop="-1" >
      ; -------------------------------------------
      ; <toolbox name="PopUpMenu - Desktop" rows="11" columns="15" left="150" top="100" stayontop="-1" >
      ; -------------------------------------------
      XML_Line_3 := "<toolbox name=""" v_362_2 """ rows=""" v_362_3 """ columns=""" v_362_4 """ left=""" v_362_5  """ top=""" v_362_6  """ stayontop=""" v_362_7 """ >" ; (362_2)([XML][Line 3] Pum Display Name in TitleBar)/(362_3)([XML][Line 3] Pum Total Height (Y) Rows)/(362_4)([XML][Line 3] Pum Total Width (X) Columns)/(362_5)([XML][Line 3] Pum Window Position (X) Left)/(362_6)([XML][Line 3] Pum Window Position (Y) Top)/(362_7)([XML][Line 3] Pum stayontop [Always -1])
      ; -------------------------------------------
    } ; End XML_Line_3
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; XML_SC_Line_1 <shortcut row="1" column="1" textcolor="16777215" textalign="0" paraalign="0" type="0" >
      ; -------------------------------------------
      ; {Space 4} <shortcut row="1" column="1" textcolor="16777215" textalign="0" paraalign="0" type="0" >
      ; -------------------------------------------
      ; Center the Pum
      v_362_5 := Ceil((A_ScreenWidth - v_361_5) / 2) ; (362_5)([XML][Line 3] Pum Window Position (X) Left)/(361_5)(Pum Actual Window Width [pixels])
      v_362_6 := Ceil((A_ScreenHeight - v_361_6) / 2)  ; (362_6)([XML][Line 3] Pum Window Position (Y) Top)/(361_6)(Pum Actual Window Height [pixels])
      ; -------------------------------------------
      XML_SC_Line_1 := "    <shortcut row=""" v_370_2 """ column=""" v_370_3 """ textcolor=""" v_370_4 """ textalign=""" v_370_5  """ paraalign=""" v_370_6  """ type=""" v_370_7 """ >" ; (370_2)(XML_SC_L1 [X-Column][Grid Positon)/(370_3)(XML_SC_L1 [Y-Row][Grid Positon)/(370_4)(XML_SC_L1 [TextColor])/(370_5)(XML_SC_L1 [TextAlign])/(370_6)(XML_SC_L1 [ParaAlign])/(370_7)(XML_SC_L1 [Type])
      ; -------------------------------------------
    } ; End XML_SC_Line_1
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; XML_SC_Line_2 <filename>ahk\key-20191128111115.ahk</filename>
      ; -------------------------------------------
      ; {Space 6}   <filename>ahk\key-20191128111115.ahk</filename>
      ; -------------------------------------------
      SC_Script := "ahk\" v_366_5 "-" TimeRightNow ".ahk" ; (366_5)(Script Type)
      ; -------------------------------------------
      XML_SC_Line_2 := "      <filename>" SC_Script "</filename>"
      ; -------------------------------------------
    } ; End XML_SC_Line_2
    ; -------------------------------------------  
    { ; XML_SC_Line_3 <openwith></openwith> (Always)
      ; -------------------------------------------
      ; {Space 6}   <openwith></openwith>
      ; -------------------------------------------
      XML_SC_Line_3 := "      <openwith></openwith>"
      ; -------------------------------------------
    } ; End XML_SC_Line_3 (Alway This) (No Change)
    ; -------------------------------------------  
    { ; XML_SC_Line_4 <startin></startin> (Always)
      ; -------------------------------------------
      ; {Space 6}   <startin></startin>
      ; -------------------------------------------
      XML_SC_Line_4 := "      <startin></startin>"
      ; -------------------------------------------
    } ; End XML_SC_Line_4 (Alway This) (No Change)
    ; -------------------------------------------  
    { ; XML_SC_Line_5 <consolebuffer hintastitle="0" override="0" rows="0" cols="0" /> (Always)
      ; -------------------------------------------
      ; {Space 6}   <consolebuffer hintastitle="0" override="0" rows="0" cols="0" />
      ; -------------------------------------------
      XML_SC_Line_5 := "      <consolebuffer hintastitle=""0"" override=""0"" rows=""0"" cols=""0"" />"
      ; -------------------------------------------
    } ; End XML_SC_Line_5 (Alway This) (No Change)
    ; -------------------------------------------  
    { ; XML_SC_Line_6 <hint>Shortcut Description</hint>
      ; -------------------------------------------
      ; {Space 6}   <hint>Shortcut Description</hint>
      ; -------------------------------------------
      XML_SC_Line_6 := "      <hint>" v_122_3 "</hint>" ; (122_3)(<Edit Feild> Status Bar Description: Value)
      ; -------------------------------------------
    } ; End XML_SC_Line_6
    ; -------------------------------------------  
    { ; XML_SC_Line_7 <overlaytext></overlaytext> (Always)
      ; -------------------------------------------
      ; {Space 6}   <overlaytext></overlaytext>
      ; -------------------------------------------
      XML_SC_Line_7 := "      <overlaytext></overlaytext>"
      ; -------------------------------------------
    } ; End XML_SC_Line_7 (Alway This) (No Change)
    ; -------------------------------------------  
    { ; XML_SC_Line_8 <icon name="C:\ProgramData\PopUpMenu_PUM\cache\20191128111115.ico" index="0" />
      ; -------------------------------------------
      ; {Space 6}   <icon name="C:\ProgramData\PopUpMenu_PUM\cache\20191128111115.ico" index="0" />
      ; -------------------------------------------
      ThisIcon := v_386_10 "\" TimeRightNow ".ico" ; (386_10)(All Pums Icon cache [Folder Path])
      FileCopy, %v_102_3%, %ThisIcon%, 1 ; (102_3)(Main Display Icon: Image Path)
      ; -------------------------------------------
      XML_SC_Line_8 := "      <icon name=""" ThisIcon """ index=""0"" />"
      ; -------------------------------------------
    } ; End XML_SC_Line_8
    ; -------------------------------------------  
    { ; XML_SC_Line_9 <statistics executions="0" since="15-Feb-21 3:49:05 PM" />
      ; -------------------------------------------
      ; {Space 6}   <statistics executions="0" since="15-Feb-21 3:49:05 PM" />
      ; -------------------------------------------
      { ; Get Time Right Now [SET] ThisTime
        ; -------------------------------------------
        { ; Month Number to Abbreviation
          ; -------------------------------------------
          if (ThisMonth == "01")
          {
            ThisMonth := "Jan"
          }
          else if (ThisMonth == "02")
          {
            ThisMonth := "Feb"
          }
          else if (ThisMonth == "03")
          {
            ThisMonth := "Mar"
          }
          else if (ThisMonth == "04")
          {
            ThisMonth := "Apr"
          }
          else if (ThisMonth == "05")
          {
            ThisMonth := "May"
          }
          else if (ThisMonth == "06")
          {
            ThisMonth := "Jun"
          }
          else if (ThisMonth == "07")
          {
            ThisMonth := "Jul"
          }
          else if (ThisMonth == "08")
          {
            ThisMonth := "Aug"
          }
          else if (ThisMonth == "09")
          {
            ThisMonth := "Sep"
          }
          else if (ThisMonth == "10")
          {
            ThisMonth := "Oct"
          }
          else if (ThisMonth == "11")
          {
            ThisMonth := "Nov"
          }
          else if (ThisMonth == "12")
          {
            ThisMonth := "Dec"
          }
          ; -------------------------------------------
        } ; End Month Number to Abbreviation
        ; -------------------------------------------
        if (ThisHour > 12)
        {
          AmPm := "PM"
          ThisHour := ThisHour - 12
          if (SubStr(ThisHour, 1, 1) == "0")
          {
            ThisHour := SubStr(ThisHour, 2, 1)
          }
        }
        else
        {
          AmPm := "AM"
        }
        ThisYear := SubStr(ThisYear, 3, 2)
        ThisTime := ThisDay "-" ThisMonth "-" ThisYear " " ThisHour ":" ThisMinute ":" ThisSecond " " AmPm
        ; -------------------------------------------
      } ; End Get Time Right Now [SET] ThisTime
      ; -------------------------------------------
      XML_SC_Line_9 := "      <statistics executions=""0"" since=""" ThisTime """ />"
      ; -------------------------------------------
    } ; End XML_SC_Line_9
    ; -------------------------------------------
    { ; XML_SC_Line_10 </shortcut>(Always)
      ; -------------------------------------------
      ; {Space 4} </shortcut>
      ; -------------------------------------------
      XML_SC_Line_10 := "    </shortcut>"
      ; -------------------------------------------
    } ; End XML_SC_Line_10 (Alway This) (No Change)
    ; -------------------------------------------
    { ; Make New Script
      ; -------------------------------------------
      Script_Array := []
      Script_Array.1 := "#NoTrayIcon"
      Script_Array.2 := Var_1
      Script_Array.3 := Var_2
      Script_Array.4 := Var_3
      Script_Array.5 := Var_4
      Script_Array.6 := Var_5
      Script_Array.7 := "F_Shortcut(""" v_366_5 """, Var_1, Var_2, Var_3, Var_4, Var_5)" ; (366_5)(Script Type)
      Script_Array.8 := "ExitApp"
      ; -------------------------------------------
      XML_ScriptName := "ahk\" v_366_5 "-" TimeRightNow ".ahk" ; (366_5)(Script Type)
      v_370_8 := v_361_8 "\" XML_ScriptName ; (370_8)(XML_SC_L2 Script [Full File Path])/(361_8)(Pum [Specific Folder Path])
      if FileExist(v_370_8) ; (370_8)(XML_SC_L2 Script [Full File Path])
      {
        FileDelete, %v_370_8% ; (370_8)(XML_SC_L2 Script [Full File Path])
      }
      for Index, ThisLine in Script_Array
      {
        FileAppend, %ThisLine%`n, %v_370_8%, UTF-8 ; (370_8)(XML_SC_L2 Script [Full File Path])
      } ; End Make New Script
      ; -------------------------------------------
    }
    ; -------------------------------------------
    { ; Write New (Pum toolbox0.xml [Array])
      ; -------------------------------------------
      { ; Center the Pum
        ; -------------------------------------------
        v_361_10.RemoveAt(3) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(3, XML_Line_3) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
      } ; End ; Center the Pum
      ; -------------------------------------------
      if (v_370_1 == 0) ; (370_1)(XML_SC Line Numer)
      {
        ; -------------------------------------------
        ; Make New Shortcut
        ; -------------------------------------------
        LineNum := 25
        v_361_10.InsertAt(LineNum, XML_SC_Line_1) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_2) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_3) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_4) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_5) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_6) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_7) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_8) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_9) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.InsertAt(LineNum, XML_SC_Line_10) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        v_361_10.InsertAt(35, "") ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
      } ; End (DoThis == "Make") ; Write New Shortcut to XML
      else ; Change Existing Shortcut
      {
        ; -------------------------------------------
        ; Change Existing Shortcut
        ; -------------------------------------------
        LineNum := v_370_1 ; (370_1)(XML_SC Line Numer)
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_1) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_2) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_3) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_4) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_5) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_6) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_7) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_8) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_9) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
        LineNum := LineNum + 1
        v_361_10.RemoveAt(LineNum) ; (361_10)(Pum toolbox0.xml [Array])
        v_361_10.InsertAt(LineNum, XML_SC_Line_10) ; (361_10)(Pum toolbox0.xml [Array])
        ; -------------------------------------------
      } ; End (DoThis == "Change") ; Change Shortcut in XML
      ; -------------------------------------------
    } ; End Write New (Pum toolbox0.xml [Array])
    ; -------------------------------------------
  } ; End (DoThis == "Make" or DoThis == "Change")
  ; -------------------------------------------
  else if (v_133_2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    ; Delete Shortcut
    ; -------------------------------------------
    Loop 11
    {
      v_361_10.RemoveAt(v_370_1) ; (361_10)(Pum toolbox0.xml [Array])/(370_1)(XML_SC Line Numer)
    }
    ; -------------------------------------------
  } ; End Delete Shortcut
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; -------------------------------------------
  if (v_370_1 > 0 or v_133_2 == 2) ; (370_1)(XML_SC Line Numer)/(133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
  {
    ; ------------------------------------------- 
    ; (Delete) (Old Script File)
    FileDelete, %v_370_9% ; (370_9)(XML_SC_L2 Old Script [Full File Path])
    ; -------------------------------------------
    ;(Delete) (Old Icon) (PopUpMenu_PUM\cache)
    FileDelete, %v_370_10% ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
    ; ------------------------------------------- (Delete) (Old Icon) (This Pum Name\iconcache)
    iconcache_Path := v_361_8 "\iconcache\*.ico" ; (361_8)(Pum [Specific Folder Path])
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_370_10, , , , Old_Icon_Name ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
    Loop Files, %iconcache_Path%, R  ; Recurse into subfolders.
    {
      This_Icon := A_LoopFileFullPath
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, This_Icon, , , , This_Icon_Name ; FileName ; C__ProgramData_PopUpMenu_PUM_cache_20191128111115.ico,0_(64).ico
      if (InStr(This_Icon_Name, Old_Icon_Name) > 0)
      {
        FileDelete, %This_Icon% ; C__ProgramData_PopUpMenu_PUM_cache_20191128110637.ico,0_(64).ico
        break
      }
    } ; End Loop Files, %iconcache_Path%, R
    ; -------------------------------------------
  } ; End (DoThis == "Change" or DoThis == "Delete") ; (Delete) (Script & Icons)
  ; -------------------------------------------
  { ; Write New XML
    ; -------------------------------------------
    Bmp_Images := v_361_8 "\settings\*.bmp" ; (361_8)(Pum [Specific Folder Path])
    ; -------------------------------------------
    { ; Create (Up to 3) Backup(s) of Xml
      ; -------------------------------------------
      ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, v_361_9, , Folder_PumSettings
      Folder_PumSettingsBak := Folder_PumSettings "\Backup"
      if !FileExist(Folder_PumSettingsBak)
      {
        FileCreateDir, %Folder_PumSettingsBak%
      }
      File_PumXmlBak_1 := Folder_PumSettingsBak "\(Backup_1)_toolbox0.xml"
      File_PumXmlBak_2 := Folder_PumSettingsBak "\(Backup_2)_toolbox0.xml"
      File_PumXmlBak_3 := Folder_PumSettingsBak "\(Backup_3)_toolbox0.xml"
      ; -------------------------------------------
      ; FileCopy, SourcePattern, DestPattern , Overwrite
      ; -------------------------------------------
      if FileExist(File_PumXmlBak_3)
      {
        FileDelete, %File_PumXmlBak_3%
        FileCopy, %File_PumXmlBak_2%, %File_PumXmlBak_3% , 1
        FileCopy, %File_PumXmlBak_1%, %File_PumXmlBak_2% , 1
      }
      else if FileExist(File_PumXmlBak_2)
      {
        FileCopy, %File_PumXmlBak_2%, %File_PumXmlBak_3% , 1
        FileCopy, %File_PumXmlBak_1%, %File_PumXmlBak_2% , 1
      }
      else if FileExist(File_PumXmlBak_1)
      {
        FileCopy, %File_PumXmlBak_1%, %File_PumXmlBak_2% , 1
        FileDelete, %File_PumXmlBak_1%
      }
      ; -------------------------------------------
      FileCopy, %v_361_9%, %File_PumXmlBak_1%, 1
      ; -------------------------------------------
    } ; End Create a Backup of Xml OverWrite Old Backup
    ; -------------------------------------------
    FileDelete, %v_361_9% ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
    FileDelete, %Bmp_Images% ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
    ; -------------------------------------------
    for Index, ThisLine in v_361_10 ; (361_10)(Pum toolbox0.xml [Array])
    {
      FileAppend, %ThisLine%`n, %v_361_9% ; (361_9)(Pum toolbox0.xml File Path [Full File Path])
    }
    ; -------------------------------------------
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\Lib"
    }
    ; -------------------------------------------
    Disable_Persistent := Script_Dir "\Disable_Persistent.ahk"
    Disable_Gui        := Script_Dir "\Disable_Gui.ahk"
    Disable_KeyGui     := Script_Dir "\Disable_KeyGui.ahk"
    Disable_KeyGui     := Script_Dir "\Disable_KeyPum.ahk"
    ; -------------------------------------------
    Gui, PopUpMenu:Destroy
    ; -------------------------------------------
    Script_Close(Disable_Persistent)
    Script_Close(Disable_Gui)
    Script_Close(Disable_KeyGui)
    Script_Close(Disable_KeyPum)
    ; -------------------------------------------
    ; -------------------------------------------
    Pc_TxtFile_ActiveApp  := A_AppDataCommon "\PopUpMenu_PUM\system\Active_App.txt"
    FileDelete, %Pc_TxtFile_ActiveApp%
    ; -------------------------------------------
    WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    IfInString, PumProcess, pum_
    {
      Process, Close, %PumProcess%
    } ; End IfInString, PumProcess, pum_
    ; -------------------------------------------
    Folder_Pum := StrReplace(Folder_PumSettings, "\settings", "")
    Pum_Executable := Folder_Pum "\" PumProcess
    Script_Dir := A_ScriptDir
    if (InStr(Script_Dir, "\Lib") == 0)
    {
      Script_Dir := Script_Dir "\Lib"
    }
    Disable_KeyPum := Script_Dir "\Disable_KeyPum.ahk"
    ; -------------------------------------------
    Run, %Pum_Executable%,,, S_Pum_Executable
    Process, Priority, %S_Pum_Executable%, High
    WinHide, ahk_class TfrmToolbox
    WinSet, AlwaysOnTop, On, ahk_class TfrmToolbox
    ; -------------------------------------------
    while !WinExist("ahk_class TfrmToolbox")
    {
    }
    ; -------------------------------------------
    while (Is_Script_Running(Disable_KeyPum) == 0)
    {
      Run, %Disable_KeyPum%
      Sleep, 100
    }
    ; -------------------------------------------
  } ; End Write New XML
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Shortcut_Make(DataArray)
