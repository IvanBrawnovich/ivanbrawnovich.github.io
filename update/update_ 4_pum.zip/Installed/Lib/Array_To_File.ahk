﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_To_File(This_Array, File_Path) ; This_Array, File_Path > File_Path_Exist [0/1]
{
  if FileExist(File_Path)
  {
    FileDelete, %File_Path%
  }
  for This_Item_Num, This_Line in This_Array
  {
    FileAppend, %This_Line%`n, %File_Path%, UTF-8
  }
  if FileExist(File_Path)
  {
    File_Path_Exist := 1
  }
  else
  {
    File_Path_Exist := 0
  }
  return File_Path_Exist
}
