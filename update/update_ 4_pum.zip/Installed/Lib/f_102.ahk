﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Copies Icon to A_AppDataCommon "\PopUpMenu_PUM\tempicon
f_102(ThisIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_102", DataArray) ; (102_1)(GUI Object: Main Display Icon)
  ; -------------------------------------------
  v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
  v_386_2 := DataArray.386.2 ; (386_2)(Temporary Icon [System Folder Path])
  v_370_10 := DataArray.370.10 ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
  ; -------------------------------------------
  Current_Icon := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
  ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ThisIcon, , , , Temp_Icon
  Temp_Icon := v_386_2 "\" Temp_Icon ".ico" ; (386_2)(Temporary Icon [System Folder Path])
  ; -------------------------------------------
  if FileExist(ThisIcon)
  {
    ; -------------------------------------------
    if (Temp_Icon != ThisIcon) ; (102_3)(Main Display Icon: Image Path)
    {
      FileCopy, %ThisIcon%, %Temp_Icon%, 1 ; (102_3)(Main Display Icon: Image Path)
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (Temp_Icon != Current_Icon)
  {
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_102, %Temp_Icon% ; (102_1)(GUI Object: Main Display Icon)
    GuiControl, PopUpMenu:Move, g_102, w80 h80 ; (102_1)(GUI Object: Main Display Icon)
    ; -------------------------------------------
    ; Done Twice Here Because the Image is Pixelated if I don't
    GuiControl, PopUpMenu:, g_102, %Temp_Icon% ; (102_1)(GUI Object: Main Display Icon)
    GuiControl, PopUpMenu:Move, g_102, w80 h80 ; (102_1)(GUI Object: Main Display Icon)
    ; -------------------------------------------
    GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
    ; -------------------------------------------
  }
  DataArray.102.3 := Temp_Icon ; (102_3)(Main Display Icon: Image Path)
  ; -------------------------------------------
  
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
