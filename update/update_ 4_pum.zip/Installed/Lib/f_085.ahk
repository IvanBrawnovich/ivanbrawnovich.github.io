﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_085(DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_085", DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
  ; -------------------------------------------
  v_085_2 := DataArray.85.2 ; (085_2)([key] Select Keyboard: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_085_2 == 1) ; (085_2)([key] Select Keyboard: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "key" ; (366_5)(Script Type)
    ; -------------------------------------------
    v_367_2  := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    ; -------------------------------------------
    if (v_367_2 != "Windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    {
      ; -------------------------------------------
      v_302_7 := DataArray.302.7 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      if (v_302_7 == 1) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      {
        DataArray := GuiControlImage_PopUpMenu("087", 1, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
      }
      else if (v_302_7 == 0) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      {
        DataArray := GuiControlImage_PopUpMenu("087", 3, 1, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("137", 0, 0, DataArray) ; (137_1)(GUI Object: Message Image 4)
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("070", 1, 1, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
    DataArray := GuiControlImage_PopUpMenu("085", 2, 1, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
