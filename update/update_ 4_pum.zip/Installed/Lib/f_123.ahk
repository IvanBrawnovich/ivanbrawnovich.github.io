﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_123(DataArray) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_123", DataArray) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
  ; -------------------------------------------
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  ; -------------------------------------------
  if (v_366_5 == "key") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    Gui, PopUpMenu:Submit, NoHide
    ; Edit Var Current Value
    Pre_Key := DataArray.123.3 ; (123_3)(<Edit Feild> [key] Text Input: Value)
    v_301_2   := DataArray.301.2 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    ; Edit Feild Current Value
    GuiControlGet, v_123, PopUpMenu:, g_123 ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ; -------------------------------------------
    if (v_123 != "") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    {
      if (Pre_Key != "") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      {
        PreArrayKey := "~" Pre_Key "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        ArrayKey := "~" v_123 "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        v_301_2 := Array_Replace_Item(v_301_2, PreArrayKey, ArrayKey) ; (301_2)([key] KeyArray_Numbers [Array])
      }
      else
      {
        ArrayKey := "~" v_123 "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        v_301_2 := Array_Add(v_301_2, ArrayKey, "End") ; (301_2)([key] KeyArray_Numbers [Array])
      }
    } ; (123)_(---)(Edit Text Input)_(2)Select_(3)Value
    else ; (123)(Edit Text Input) is Empty
    {
      if (Pre_Key != "") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      {
        PreArrayKey := "~" Pre_Key "~" ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        v_301_2 := Array_Subtract(v_301_2, PreArrayKey, 0) ; (301_2)([key] KeyArray_Numbers [Array])
      }
    } ; End (123)(Edit Text Input) is Empty
    ; -------------------------------------------
    DataArray.301.2 := v_301_2 ; (301_2)([key] KeyArray_Numbers [Array])
    DataArray.123.3 := v_123 ; (123_3)(<Edit Feild> [key] Text Input: Value)/(123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ; -------------------------------------------
    DataArray := KeyArray_Display(DataArray) ; > DataArray
    DataArray := KeyArray_Shortcut(DataArray) ; > DataArray
    DataArray := KeyArray_Validate(DataArray)
    ; (105_1)(GUI Object: <Displayed Text> Top 2)/(141_1)(GUI Object: <Displayed Text> Title 3)
    LimitedArray := [["v_105_1"], ["v_141_1"]] ; (105_1)(GUI Object: <Displayed Text> Top 2)/(141_1)(GUI Object: <Displayed Text> Title 3)
    DataArray.363.9 := LimitedArray ; (363_9)(Limited DataArray)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
    Send, {End}
    ; -------------------------------------------
  } ; (366_5)(Script Type) (key)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; (123)_(---)(Edit Text Input)_(2)Select_(3)Value
