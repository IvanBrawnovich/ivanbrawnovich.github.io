﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
HotKey_Select_Key(ThisKey, DataArray)
{
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_142") ; (142_1)(GUI Object: HotKey Select Mouse Left)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := v_369_2 "LButton" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
      ; (Other Mouse Keys)(No Keys Selected)
      if (HotKey_Check_Selected([142, 143, 144, 145, 146, 147, 148], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)/(144_1)(GUI Object: HotKey Select Mouse Middle)/(145_1)(GUI Object: HotKey Select Mouse Wheel Up)/(146_1)(GUI Object: HotKey Select Mouse Wheel Down)/(147_1)(GUI Object: HotKey Select Mouse X1)/(148_1)(GUI Object: HotKey Select Mouse X2)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 3, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      else
      {
        ; -------------------------------------------
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
        ; -------------------------------------------
        { ; Control Keys
          ; -------------------------------------------
          if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
          }
          if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
          }
          if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
          }
          ; -------------------------------------------
        } ; End Control Keys
        ; -------------------------------------------
        { ; Windows Key
          ; -------------------------------------------
          if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
            DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          ; -------------------------------------------
        } ; End Windows Key
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
  } ; (142) (HotKey Select Mouse Left)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_143") ; (143_1)(GUI Object: HotKey Select Mouse Right)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "RButton" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
      ; (Other Mouse Keys)(No Keys Selected)
      if (HotKey_Check_Selected([142, 143, 144, 145, 146, 147, 148], DataArray) == 0) ; (142_3)(HotKey Select Mouse Left: Image Path)/(143_1)(GUI Object: HotKey Select Mouse Right)/(144_1)(GUI Object: HotKey Select Mouse Middle)/(145_1)(GUI Object: HotKey Select Mouse Wheel Up)/(146_1)(GUI Object: HotKey Select Mouse Wheel Down)/(147_1)(GUI Object: HotKey Select Mouse X1)/(148_1)(GUI Object: HotKey Select Mouse X2)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 3, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      else
      {
        ; -------------------------------------------
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
        ; -------------------------------------------
        { ; Control Keys
          ; -------------------------------------------
          if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
          }
          if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
          }
          if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
          }
          ; -------------------------------------------
        } ; End Control Keys
        ; -------------------------------------------
        { ; Windows Key
          ; -------------------------------------------
          if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
          {
            DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
            DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
          }
          ; -------------------------------------------
        } ; End Windows Key
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
  } ; (143) (HotKey Select Mouse Right)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_144") ; (144_1)(GUI Object: HotKey Select Mouse Middle)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "MButton" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("144", 2, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
    { ; Control Keys
      ; -------------------------------------------
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End Control Keys
    ; -------------------------------------------
    { ; Windows Key
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End Windows Key
    ; -------------------------------------------
  } ; (144) (HotKey Select Mouse Middle)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_145") ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "WheelUp" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("145", 2, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
    { ; Control Keys
      ; -------------------------------------------
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End Control Keys
    ; -------------------------------------------
    { ; Windows Key
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End Windows Key
    ; -------------------------------------------
  } ; (145) (HotKey Select Mouse Wheel Up)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_146") ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "WheelDown" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("146", 2, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
    { ; Control Keys
      ; -------------------------------------------
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End Control Keys
    ; -------------------------------------------
    { ; Windows Key
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End Windows Key
    ; -------------------------------------------
  } ; (146) (HotKey Select Mouse Wheel Down)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_147") ; (147_1)(GUI Object: HotKey Select Mouse X1)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "XButton1" ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton2", "") ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("147", 2, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("148", 1, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; -------------------------------------------
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
    { ; Control Keys
      ; -------------------------------------------
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End Control Keys
    ; -------------------------------------------
    { ; Windows Key
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End Windows Key
    ; -------------------------------------------
  } ; (147) (HotKey Select Mouse X1)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_148") ; (148_1)(GUI Object: HotKey Select Mouse X2)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    { ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
      v_369_2 := StrReplace(v_369_2, "LButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "RButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "MButton", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelUp", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "WheelDown", "") ; (369_2)(Current User Hotkey)
      v_369_2 := StrReplace(v_369_2, "XButton1", "") ; (369_2)(Current User Hotkey)
      v_369_2 := v_369_2 "XButton2" ; (369_2)(Current User Hotkey)
      DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      ; -------------------------------------------
    } ; (369_2)(Current User Hotkey)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    { ; Mouse Button (Toggle)
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("142", 1, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      DataArray := GuiControlImage_HotKeySelect("143", 1, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      DataArray := GuiControlImage_HotKeySelect("144", 1, 0, DataArray) ; (144_1)(GUI Object: HotKey Select Mouse Middle)
      DataArray := GuiControlImage_HotKeySelect("145", 1, 0, DataArray) ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)
      DataArray := GuiControlImage_HotKeySelect("146", 1, 0, DataArray) ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)
      DataArray := GuiControlImage_HotKeySelect("147", 1, 0, DataArray) ; (147_1)(GUI Object: HotKey Select Mouse X1)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("148", 2, 0, DataArray) ; (148_1)(GUI Object: HotKey Select Mouse X2)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; -------------------------------------------
    } ; End Mouse Button (Toggle)
    ; -------------------------------------------
    { ; Control Keys
      ; -------------------------------------------
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End Control Keys
    ; -------------------------------------------
    { ; Windows Key
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End Windows Key
    ; -------------------------------------------
  } ; (148) (HotKey Select Mouse X2)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_149") ; (149_1)(GUI Object: HotKey Windows Key Left)
  {
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "LWin" ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -------------------------------------------
      DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
      DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      ; -------------------------------------------
    }
    ; -------------------------------------------
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "#" v_369_2 ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
      DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.142.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 3) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End ; (Other than Windows Left/Right Keys) (One or More Selected)
    ; -------------------------------------------
  } ; (149) (HotKey Windows Key Left)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_150") ; (150_1)(GUI Object: HotKey Windows Key Right)
  {
    ; -------------------------------------------
    ; (Other Than_149_150)(Windows Key)(No Keys Selected)
    if (HotKey_Check_Selected([149, 150], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "LWin" ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
      DataArray := GuiControlImage_HotKeySelect("150", 1, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "#" v_369_2 ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
      DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.142.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 3) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
    } ; End ; (Other than Windows Left/Right Keys) (One or More Selected)
    ; -------------------------------------------
  } ; (150) (HotKey Windows Key Right)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_151") ; (151_1)(GUI Object: HotKey Ctrl Key)
  {
    ; -------------------------------------------
    ; (Other Than_151)(Ctrl Key)(No Keys Selected)
    if (HotKey_Check_Selected([151], DataArray) == 0) ; (151_3)(HotKey Ctrl Key: Image Path)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "^" ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("151", 3, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        ; (Mouse Keys) (No Keys Selected)
        if (HotKey_Check_Selected([149, 150, 151, 152, 153], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)/(151_1)(GUI Object: HotKey Ctrl Key)/(152_1)(GUI Object: HotKey Alt Key)/(153_1)(GUI Object: HotKey Shift Key)
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
          v_369_2 := v_369_2 "Ctrl" ; (369_2)(Current User Hotkey)
        }
        else
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#^") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#^") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "LButton", "^LButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RButton", "^RButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "MButton", "^MButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelUp", "^WheelUp") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelDown", "^WheelDown") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton1", "^XButton1") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton2", "^XButton2") ; (369_2)(Current User Hotkey)
        }
        ; -------------------------------------------
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.142.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      ; -------------------------------------------
      if (DataArray.143.2 == 3) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      ; -------------------------------------------
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      ; -------------------------------------------
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End (NOT Ctrl) (One or More Selected)
    ; -------------------------------------------
  } ; (151) (HotKey Ctrl Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_152") ; (152_1)(GUI Object: HotKey Alt Key)
  {
    ; -------------------------------------------
    ; (Other Than_152)(Alt Key)(No Keys Selected)
    if (HotKey_Check_Selected([152], DataArray) == 0) ; (152_3)(HotKey Alt Key: Image Path)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "!" ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("152", 3, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        ; (Mouse Keys) (No Keys Selected)
        if (HotKey_Check_Selected([149, 150, 151, 152, 153], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)/(151_1)(GUI Object: HotKey Ctrl Key)/(152_1)(GUI Object: HotKey Alt Key)/(153_1)(GUI Object: HotKey Shift Key)
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Shift", "+") ; (369_2)(Current User Hotkey)
          v_369_2 := v_369_2 "Alt" ; (369_2)(Current User Hotkey)
        }
        else
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#!") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#!") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "LButton", "!LButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RButton", "!RButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "MButton", "!MButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelUp", "!WheelUp") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelDown", "!WheelDown") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton1", "!XButton1") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton2", "!XButton2") ; (369_2)(Current User Hotkey)
        }
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.142.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 3) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.153.2 == 3) ; (153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      }
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------s
    } ; End (Other Than Alt Key) (One or More Selected)
    ; -------------------------------------------
  } ; (152) (HotKey Alt Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (ThisKey == "v_153") ; (153_1)(GUI Object: HotKey Shift Key)
  {
    ; -------------------------------------------
    ; (Other Than_153)(Shift Key)(No Keys Selected)
    if (HotKey_Check_Selected([153], DataArray) == 0) ; (153_3)(HotKey Shift Key: Image Path)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
        v_369_2 := "+" ; (369_2)(Current User Hotkey)
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("153", 3, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    else
    {
      ; -------------------------------------------
      v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      { ; (369_2)(Current User Hotkey)
        ; -------------------------------------------
        ; (Mouse Keys) (No Keys Selected)
        if (HotKey_Check_Selected([149, 150, 151, 152, 153], DataArray) == 0) ; (149_3)(HotKey Windows Key Left: Image Path)/(150_1)(GUI Object: HotKey Windows Key Right)/(151_1)(GUI Object: HotKey Ctrl Key)/(152_1)(GUI Object: HotKey Alt Key)/(153_1)(GUI Object: HotKey Shift Key)
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Ctrl", "^") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "Alt", "!") ; (369_2)(Current User Hotkey)
          v_369_2 := v_369_2 "Shift" ; (369_2)(Current User Hotkey)
        }
        else ; Mouse Key is Selected
        {
          v_369_2 := StrReplace(v_369_2, "LWin", "#+") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RWin", "#+") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "LButton", "+LButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "RButton", "+RButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "MButton", "+MButton") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelUp", "+WheelUp") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "WheelDown", "+WheelDown") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton1", "+XButton1") ; (369_2)(Current User Hotkey)
          v_369_2 := StrReplace(v_369_2, "XButton2", "+XButton2") ; (369_2)(Current User Hotkey)
        }
        DataArray.369.2 := v_369_2 ; (369_2)(Current User Hotkey)
      } ; (369_2)(Current User Hotkey)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := GuiControlImage_HotKeySelect("153", 2, 1, DataArray) ; (153_1)(GUI Object: HotKey Shift Key)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (DataArray.142.2 == 3) ; (142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("142", 2, 0, DataArray) ; (142_1)(GUI Object: HotKey Select Mouse Left)
      }
      if (DataArray.143.2 == 3) ; (143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("143", 2, 0, DataArray) ; (143_1)(GUI Object: HotKey Select Mouse Right)
      }
      if (DataArray.151.2 == 3) ; (151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("151", 2, 1, DataArray) ; (151_1)(GUI Object: HotKey Ctrl Key)
      }
      if (DataArray.152.2 == 3) ; (152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("152", 2, 1, DataArray) ; (152_1)(GUI Object: HotKey Alt Key)
      }
      ; -------------------------------------------
      if (DataArray.149.2 == 2 or DataArray.150.2 == 2) ; (149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)/(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      {
        DataArray := GuiControlImage_HotKeySelect("149", 2, 0, DataArray) ; (149_1)(GUI Object: HotKey Windows Key Left)
        DataArray := GuiControlImage_HotKeySelect("150", 2, 0, DataArray) ; (150_1)(GUI Object: HotKey Windows Key Right)
      }
      ; -------------------------------------------
    } ; End (Other Than Shift Key) (One or More Selected)
    ; -------------------------------------------
  } ; (152) (HotKey Shift Key)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
