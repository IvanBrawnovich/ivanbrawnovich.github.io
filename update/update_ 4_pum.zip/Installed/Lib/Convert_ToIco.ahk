﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Allowed Transparency
; no  > jpeg jpg iff jps mpo pcx pxr pbm sct tga 
; yes > tif tiff gif png
; -------------------------------------------
Convert_ToIco(DataArray)
{
  ; -------------------------------------------
  v_102_3 := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
  v_386_2 := DataArray.386.2 ; (386_2)(Temporary Icon [System Folder Path])
  ; -------------------------------------------
  Any_IcoFile := v_386_2 "\*.Ico" ; (386_2)(Temporary Icon [System Folder Path])
  ; -------------------------------------------
  if FileExist(Any_IcoFile)
  {
    FileDelete, %Any_IcoFile%
  }
  ; -------------------------------------------
  if v_102_3 ; (102_3)(Main Display Icon: Image Path)
  {
    ; -------------------------------------------
    v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
    ; -------------------------------------------
    ; SplitPath,  ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_102_3, , , , ImgName ; (102_3)(Main Display Icon: Image Path)
    ; -------------------------------------------
    NewImg := v_386_2 "\" ImgName ".ico" ; (386_2)(Temporary Icon [System Folder Path])
    ; -------------------------------------------
    ; (383_2)([Image Convert] magick.exe [Support Program File Path])
    ; (102_3)(Main Display Icon: Image Path)
    ; -------------------------------------------
    RunThis := v_383_2 " convert """ v_102_3 """ -define icon:auto-resize=64,48,32,16 """ NewImg """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
    DataArray.102.3 := NewImg ; (102_3)(Main Display Icon: Image Path)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("506", 0) ; (506_1)(Splash Info Script File: Converting Image)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_102, %NewImg% ; (102_1)(GUI Object: Main Display Icon)
    GuiControl, PopUpMenu:MoveDraw, g_102, +w80 +h80 ; (102_1)(GUI Object: Main Display Icon)
    GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  Splash_Script("Off", 0)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
