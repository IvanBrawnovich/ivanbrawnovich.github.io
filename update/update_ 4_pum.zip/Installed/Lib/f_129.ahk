﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_129(DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_129", DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
  ; -------------------------------------------
  if (DataArray.129.2 == 1) ; (129_2)([cpl] Windows Control Menu 5: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    { ; Select/UnSelect
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("125", 1, 0, DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
      DataArray := GuiControlImage_PopUpMenu("126", 1, 0, DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
      DataArray := GuiControlImage_PopUpMenu("127", 1, 0, DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
      DataArray := GuiControlImage_PopUpMenu("128", 1, 0, DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
      DataArray := GuiControlImage_PopUpMenu("129", 2, 0, DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
      DataArray := GuiControlImage_PopUpMenu("130", 1, 0, DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
      DataArray := GuiControlImage_PopUpMenu("138", 1, 0, DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
      DataArray := GuiControlImage_PopUpMenu("139", 1, 0, DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
      ; -------------------------------------------
    } ; End Select/UnSelect
    ; -------------------------------------------
    { ; [StartUpVars]
      DataArray.300.2 := 5 ; (300_2)([cpl] Menu Number #_X_[X])
      DataArray.300.3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
      DataArray.300.4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
    } ; End [StartUpVars]
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
