﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_160(DataArray) ; (160_1)(GUI Object: [pum] Select Application Pum)
{
  ; -------------------------------------------
  v_160_2 := DataArray.160.2 ; (160_2)([pum] Select Application Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_160_2 == "") ; (160_2)([pum] Select Application Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_160_2 := 1 ; (160_2)([pum] Select Application Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_160_2 == 1) ; (160_2)([pum] Select Application Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumApp" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
