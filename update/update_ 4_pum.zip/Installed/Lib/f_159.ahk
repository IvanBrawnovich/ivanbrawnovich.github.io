﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_159(DataArray) ; (159_1)(GUI Object: [pum] Select Custom Pum)
{
  ; -------------------------------------------
  v_159_2 := DataArray.159.2 ; (159_2)([pum] Select Custom Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_159_2 == "") ; (159_2)([pum] Select Custom Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_159_2 := 1 ; (159_2)([pum] Select Custom Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_159_2 == 1) ; (159_2)([pum] Select Custom Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumCus" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
