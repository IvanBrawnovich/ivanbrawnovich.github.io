﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
DownloadFile(ThisUrl, ThisFile) ; > File Downloaded OK
{
  ; -------------------------------------------
  URLDownloadToFile, %ThisUrl%, %ThisFile%
  ; -------------------------------------------
  if (ErrorLevel == 0)
  {
    ; -------------------------------------------
    if FileExist(ThisFile)
    {
      FileReadLine, LineOne, %ThisFile%, 1 ; Number of the Last Update that was ran
      if (InStr(LineOne, "DOCTYPE") > 0)
      {
        FileOK := 0
      }
      else if (InStr(LineOne, "html") > 0)
      {
        FileOK := 0
      }
      else
      {
        FileOK := 1
      }
    } ; End FileExist(ThisFile)
    else
    {
      FileOK := 0
    } ; End !FileExist(ThisFile)
  } ; End (ErrorLevel == 0)
  else
  {
    FileOK := 0
  } ; End (ErrorLevel != 0)
  ; -------------------------------------------
  if (FileOK == 0)
  {
    FileDelete, %ThisFile%
  }
  ; -------------------------------------------
  return FileOK
  ; -------------------------------------------
} ; End StarUp_DownloadFile(ThisUrl, ThisFile) ; > File Downloaded OK
