﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
String_To_Unicode(This_String, DataArray) ; > {U+0443}{U+0441}{U+0441}
{
  ; -------------------------------------------
  v_387_1 := DataArray.387.1 ; (387_1)(Unicode Array)
  ; -------------------------------------------
  LoopNum := StrLen(This_String)
  This_Unicode := ""
  Num := 0
  Loop %LoopNum%
  {
    ; -------------------------------------------
    Num := Num + 1
    ; -------------------------------------------
    This_Chr := SubStr(This_String, Num, 1)
    ; -------------------------------------------
    for Index, Item_Array in v_387_1 ; (387_1)(Unicode Array)
    {
      Check_Character := Item_Array.1
      if (Check_Character == This_Chr)
      {
        This_Unicode := This_Unicode Item_Array.2
        break
      }
    }
  } ; End Loop %LoopNum%
  ; -------------------------------------------
  return This_Unicode
  ; -------------------------------------------
}
