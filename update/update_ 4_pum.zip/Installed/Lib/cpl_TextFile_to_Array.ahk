﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; (341_1)([cpl] de German Menu Array Addon)_(341_2)([cpl] de German Menu Array de_cpl)
; (342_1)([cpl] en English Menu Array Addon)_(342_2)([cpl] en English Menu Array en_cpl)
; (343_1)([cpl] es Spanish Menu Array Addon)_(343_2)([cpl] es Spanish Menu Array es_cpl)
; (344_1)([cpl] fr French Menu Array Addon)_(344_2)([cpl] fr French Menu Array fr_cpl)
; (345_1)([cpl] it Italian Menu Array Addon)_(345_2)([cpl] it Italian Menu Array it_cpl)
; (346_1)([cpl] pl Polish Menu Array Addon)_(346_2)([cpl] pl Polish Menu Array pl_cpl)
; (347_1)([cpl] pt Portuguese Menu Array Addon)_(347_2)([cpl] pt Portuguese Menu Array pt_cpl)
; (348_1)([cpl] ru Russian Menu Array Addon)_(348_2)([cpl] ru Russian Menu Array ru_cpl)
; (349_1)([cpl] sv Swedish Menu Array Addon)_(349_2)([cpl] sv Swedish Menu Array sv_cpl)
; (350_1)([cpl] tr Turkish Menu Array Addon)_(350_2)([cpl] tr Turkish Menu Array tr_cpl)
; -------------------------------------------
cpl_TextFile_to_Array(DataArray) ; > DataArray
{
  ; -------------------------------------------
  DataArray := Function_Flow("cpl_TextFile_to_Array", DataArray)
  ; -------------------------------------------
  ThisNum := 0
  Loop 10
  {
    ThisNum := ThisNum + 1
    ; -------------------------------------------
    cplFile := DataArray[340][ThisNum] ; (340_1-10)(Text Menu [cpl])
    ; -------------------------------------------
    cplArray := ""
    ; -------------------------------------------
    if FileExist(cplFile)
    {
      ; -------------------------------------------
      LineNum := 0
      ; -------------------------------------------
      ThisTime := A_TickCount
      BreakTime := ThisTime + 3000
      ; -------------------------------------------
      Loop ; Infinite Loop
      {
        ; -------------------------------------------
        ThisTime := A_TickCount
        if (BreakTime == ThisTime)
        {
          break
        }
        ; -------------------------------------------
        LineNum := LineNum + 1
        ; -------------------------------------------
        FileReadLine, MenuArray, %cplFile%, LineNum
        ; -------------------------------------------
        ThisLen := StrLen(MenuArray)
        if (ThisLen == 0 or !MenuArray)
        {
          break
        } ; End !MenuArray
        else
        {
          MenuArray  := StrSplit(MenuArray, "|", "")
          cplArray := Array_Add(cplArray, MenuArray, "End")
        } ; End else
        ; -------------------------------------------
        MenuArray := ""
        ; -------------------------------------------
      } ; End Infinite Loop [SET] cplArray
      ; -------------------------------------------
      VarNum := 340 + ThisNum
      DataArray[VarNum] := cplArray
      ;~ DataArray[VarNum][1] := cplArray
      ; -------------------------------------------
    } ; End if FileExist(cplFile)
    ; -------------------------------------------
  } ; End Loop 10
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; v_(341-350)_1 := DataArray.(341-350).1
  ; v_(341-350)_1.1.1 = Menu Name
  ; v_(341-350)_1.1.2 = Menu Content
  ; (342_1)([cpl] en English Menu Array en_cpl)
  ; (342_1)([cpl] en English Menu Array en_cpl)
  ; (342_1)([cpl] en English Menu Array en_cpl)
  
  ; (342_1)([cpl] en English Menu Array en_cpl)
  ; 
  ;~ ToolTip, %Msg%, 0, 0
  ;~ Msg := ""
  
  
  
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  return DataArray
  ; -------------------------------------------
}
