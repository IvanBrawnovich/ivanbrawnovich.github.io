﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
url_Acc_Children(Acc)
{
  if ComObjType(Acc,"Name") != "IAccessible"
  {
    ErrorLevel := "Invalid IAccessible Object"
  }
  else
  {
    url_Acc_Init(), cChildren:=Acc.accChildCount, Children:=[]
    if DllCall("oleacc\AccessibleChildren", "Ptr",ComObjValue(Acc), "Int",0, "Int",cChildren, "Ptr",VarSetCapacity(varChildren,cChildren*(8+2*A_PtrSize),0)*0+&varChildren, "Int*",cChildren)=0
    {
      Loop %cChildren%
      {
        i:=(A_Index-1)*(A_PtrSize*2+8)+8, child:=NumGet(varChildren,i), Children.Insert(NumGet(varChildren,i-8)=9?url_Acc_Query(child):child), NumGet(varChildren,i-8)=9?ObjRelease(child):
      }
      return Children.MaxIndex()?Children:
    }
    else
    {
      ErrorLevel := "AccessibleChildren DllCall Failed"
    }
  }
}
