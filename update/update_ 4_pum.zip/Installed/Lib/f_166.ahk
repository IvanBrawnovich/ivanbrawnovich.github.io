﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_166(DataArray) ; (166_1)(GUI Object: [pum] Backgroung Color Select)
{
  ; -------------------------------------------
  v_166_2 := DataArray.166.2 ; (166_2)([pum] Backgroung Color Select: [0]Hide/[1]Nor/[2]Sel)
  ; -------------------------------------------
  if (v_166_2 == "") ; (166_2)([pum] Backgroung Color Select: [0]Hide/[1]Nor/[2]Sel)
  {
    v_166_2 := 1 ; (166_2)([pum] Backgroung Color Select: [0]Hide/[1]Nor/[2]Sel)
  }
  ; -------------------------------------------
  if (v_166_2 == 1) ; (166_2)([pum] Backgroung Color Select: [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumBG_pumCol" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
