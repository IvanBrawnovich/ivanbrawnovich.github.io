﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_154(DataArray) ; (154_1)(GUI Object: [pum] Pum Select Background)
{
  ; -------------------------------------------
  v_154_2 := DataArray.154.2 ; (154_2)([pum] Pum Select Background: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_154_2 == "") ; (154_2)([pum] Pum Select Background: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_154_2 := 1 ; (154_2)([pum] Pum Select Background: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_154_2 == 1) ; (154_2)([pum] Pum Select Background: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumBG" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
