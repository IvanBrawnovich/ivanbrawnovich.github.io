﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_060(DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_060", DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("060", DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
