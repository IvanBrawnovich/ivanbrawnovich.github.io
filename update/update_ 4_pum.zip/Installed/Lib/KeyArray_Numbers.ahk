﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
KeyArray_Numbers(DataArray) ; > DataArray
{
  ; -------------------------------------------
  DataArray := Function_Flow("KeyArray_Numbers", DataArray)
  ; -------------------------------------------
  ; Creates
  ; (301_2)([key] KeyArray_Numbers [Array])
  ; From
  ; (301_8)([key] KeyArray_Keystroke [Array] for Shortcut)
  ; -------------------------------------------
  v_301_8 := DataArray.301.8 ; (301_8)([key] KeyArray_Shortcut [Array])
  ; -------------------------------------------
  Ckeck_Array := v_301_8.1 ; (301_8)([key] KeyArray_Shortcut [Array])
  ; -------------------------------------------
  if (Ckeck_Array != "") ; Make Sure (301_8)([key] KeyArray_Keystroke for Shortcut) Has Key's in it
  {
    ; -------------------------------------------
    v_301_2 := "" ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
    for Index, This_KeyStroke in v_301_8 ; (301_8)([key] KeyArray_Shortcut [Array])
    {
      ; -------------------------------------------
      if (SubStr(This_KeyStroke, 1, 1) == "~") ; User Written Text
      {
        v_301_2 := Array_Add(v_301_2, This_KeyStroke, "End") ; (301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt]") ; (008)
      {
        v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt Down]") ; (008)(009)
      {
        v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(009)", "End") ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Alt Up]") ; (008)(012)
      {
        v_301_2 := Array_Add(v_301_2, "(008)", "End") ; (008_1)(GUI Object: [key] Alt)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt]") ; (010)
      {
        v_301_2 := Array_Add(v_301_2, "(010)", "End") ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt Down]") ; (010)(009)
      {
        v_301_2 := Array_Add(v_301_2, "(010)", "End") ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(009)", "End") ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LAlt Up]") ; (010)(012)
      {
        v_301_2 := Array_Add(v_301_2, "(010)", "End") ; (010_1)(GUI Object: [key] Alt Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt]") ; (011)
      {
        v_301_2 := Array_Add(v_301_2, "(011)", "End") ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt Down]") ; (011)(009)
      {
        v_301_2 := Array_Add(v_301_2, "(011)", "End") ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(009)", "End") ; (009_1)(GUI Object: [key] Alt Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RAlt Up]") ; (011)(012)
      {
        v_301_2 := Array_Add(v_301_2, "(011)", "End") ; (011_1)(GUI Object: [key] Alt Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(012)", "End") ; (012_1)(GUI Object: [key] Alt Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[CapsLock]") ; (013)
      {
        v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl]") ; (015)
      {
        v_301_2 := Array_Add(v_301_2, "(015)", "End") ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl Down]") ; (015)(014)
      {
        v_301_2 := Array_Add(v_301_2, "(015)", "End") ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(014)", "End") ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LCtrl Up]") ; (015)(017)
      {
        v_301_2 := Array_Add(v_301_2, "(015)", "End") ; (015_1)(GUI Object: [key] Ctrl Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl]") ; (016)
      {
        v_301_2 := Array_Add(v_301_2, "(016)", "End") ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl Down]") ; (016)(014)
      {
        v_301_2 := Array_Add(v_301_2, "(016)", "End") ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(014)", "End") ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RCtrl Up]") ; (016)(017)
      {
        v_301_2 := Array_Add(v_301_2, "(016)", "End") ; (016_1)(GUI Object: [key] Ctrl Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Enter]") ; (018) / X2 (019)
      {
        v_301_2 := Array_Add(v_301_2, "(018)", "End") ; (018_1)(GUI Object: [key] Enter)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Esc]") ; (020) / X2 (021)
      {
        v_301_2 := Array_Add(v_301_2, "(020)", "End") ; (020_1)(GUI Object: [key] Esc)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F1]") ; (022)
      {
        v_301_2 := Array_Add(v_301_2, "(022)", "End") ; (022_1)(GUI Object: [key] F1)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F2]") ; (023)
      {
        v_301_2 := Array_Add(v_301_2, "(023)", "End") ; (023_1)(GUI Object: [key] F2)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F3]") ; (024)
      {
        v_301_2 := Array_Add(v_301_2, "(024)", "End") ; (024_1)(GUI Object: [key] F3)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F4]") ; (025)
      {
        v_301_2 := Array_Add(v_301_2, "(025)", "End") ; (025_1)(GUI Object: [key] F4)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F5]") ; (026)
      {
        v_301_2 := Array_Add(v_301_2, "(026)", "End") ; (026_1)(GUI Object: [key] F5)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F6]") ; (027)
      {
        v_301_2 := Array_Add(v_301_2, "(027)", "End") ; (027_1)(GUI Object: [key] F6)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F7]") ; (028)
      {
        v_301_2 := Array_Add(v_301_2, "(028)", "End") ; (028_1)(GUI Object: [key] F7)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F8]") ; (029)
      {
        v_301_2 := Array_Add(v_301_2, "(029)", "End") ; (029_1)(GUI Object: [key] F8)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F9]") ; (030)
      {
        v_301_2 := Array_Add(v_301_2, "(030)", "End") ; (030_1)(GUI Object: [key] F9)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F10]") ; (031)
      {
        v_301_2 := Array_Add(v_301_2, "(031)", "End") ; (031_1)(GUI Object: [key] F10)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F11]") ; (032)
      {
        v_301_2 := Array_Add(v_301_2, "(032)", "End") ; (032_1)(GUI Object: [key] F11)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[F12]") ; (033)
      {
        v_301_2 := Array_Add(v_301_2, "(033)", "End") ; (033_1)(GUI Object: [key] F12)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad0]") ; (034)
      {
        v_301_2 := Array_Add(v_301_2, "(034)", "End") ; (034_1)(GUI Object: [key] Numpad 0)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad1]") ; (035)
      {
        v_301_2 := Array_Add(v_301_2, "(035)", "End") ; (035_1)(GUI Object: [key] Numpad 1)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad2]") ; (036)
      {
        v_301_2 := Array_Add(v_301_2, "(036)", "End") ; (036_1)(GUI Object: [key] Numpad 2)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad3]") ; (037)
      {
        v_301_2 := Array_Add(v_301_2, "(037)", "End") ; (037_1)(GUI Object: [key] Numpad 3)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad4]") ; (038)
      {
        v_301_2 := Array_Add(v_301_2, "(038)", "End") ; (038_1)(GUI Object: [key] Numpad 4)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad5]") ; (039)
      {
        v_301_2 := Array_Add(v_301_2, "(039)", "End") ; (039_1)(GUI Object: [key] Numpad 5)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad6]") ; (040)
      {
        v_301_2 := Array_Add(v_301_2, "(040)", "End") ; (040_1)(GUI Object: [key] Numpad 6)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad7]") ; (041)
      {
        v_301_2 := Array_Add(v_301_2, "(041)", "End") ; (041_1)(GUI Object: [key] Numpad 7)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad8]") ; (042)
      {
        v_301_2 := Array_Add(v_301_2, "(042)", "End") ; (042_1)(GUI Object: [key] Numpad 8)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Numpad9]") ; (043)
      {
        v_301_2 := Array_Add(v_301_2, "(043)", "End") ; (043_1)(GUI Object: [key] Numpad 9)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadAdd]") ; (044)
      {
        v_301_2 := Array_Add(v_301_2, "(044)", "End") ; (044_1)(GUI Object: [key] Numpad Add)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadDiv]") ; (045)
      {
        v_301_2 := Array_Add(v_301_2, "(045)", "End") ; (045_1)(GUI Object: [key] Numpad Divide)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadDot]") ; (046)
      {
        v_301_2 := Array_Add(v_301_2, "(046)", "End") ; (046_1)(GUI Object: [key] Numpad Dot)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadEnter]") ; (047)
      {
        v_301_2 := Array_Add(v_301_2, "(047)", "End") ; (047_1)(GUI Object: [key] Numpad Enter)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadMult]") ; (048)
      {
        v_301_2 := Array_Add(v_301_2, "(048)", "End") ; (048_1)(GUI Object: [key] Numpad Multiply)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[NumpadSub]") ; (049)
      {
        v_301_2 := Array_Add(v_301_2, "(049)", "End") ; (049_1)(GUI Object: [key] Numpad Subtract)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift]") ; (050)
      {
        v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift Down]") ; (050)(051)
      {
        v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(051)", "End") ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Shift Up]") ; (050)(054)
      {
        v_301_2 := Array_Add(v_301_2, "(050)", "End") ; (050_1)(GUI Object: [key] Shift)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift]") ; (052)
      {
        v_301_2 := Array_Add(v_301_2, "(052)", "End") ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift Down]") ; (052)(051)
      {
        v_301_2 := Array_Add(v_301_2, "(052)", "End") ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(051)", "End") ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LShift Up]") ; (052)(054)
      {
        v_301_2 := Array_Add(v_301_2, "(052)", "End") ; (052_1)(GUI Object: [key] Shift Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift]") ; (053)
      {
        v_301_2 := Array_Add(v_301_2, "(053)", "End") ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift Down]") ; (053)(051)
      {
        v_301_2 := Array_Add(v_301_2, "(053)", "End") ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(051)", "End") ; (051_1)(GUI Object: [key] Shift Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RShift Up]") ; (053)(054)
      {
        v_301_2 := Array_Add(v_301_2, "(053)", "End") ; (053_1)(GUI Object: [key] Shift Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(054)", "End") ; (054_1)(GUI Object: [key] Shift Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Tab]") ; (055) / 2X (056)
      {
        v_301_2 := Array_Add(v_301_2, "(055)", "End") ; (055_1)(GUI Object: [key] Tab)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win]") ; (057)
      {
        v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win Down]") ; (057)(058)
      {
        v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(058)", "End") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Win Up]") ; (057)(061)
      {
        v_301_2 := Array_Add(v_301_2, "(057)", "End") ; (057_1)(GUI Object: [key] Windows Key)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(058)", "End") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin]") ; (059)
      {
        v_301_2 := Array_Add(v_301_2, "(059)", "End") ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin Down]") ; (059)(058)
      {
        v_301_2 := Array_Add(v_301_2, "(059)", "End") ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(058)", "End") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[LWin Up]") ; (059)(061)
      {
        v_301_2 := Array_Add(v_301_2, "(059)", "End") ; (059_1)(GUI Object: [key] Windows Key Left)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(061)", "End") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin]") ; (060)
      {
        v_301_2 := Array_Add(v_301_2, "(060)", "End") ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin Down]") ; (060)(058)
      {
        v_301_2 := Array_Add(v_301_2, "(060)", "End") ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(058)", "End") ; (058_1)(GUI Object: [key] Windows Key Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[RWin Up]") ; (060)(061)
      {
        v_301_2 := Array_Add(v_301_2, "(060)", "End") ; (060_1)(GUI Object: [key] Windows Key Right)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(061)", "End") ; (061_1)(GUI Object: [key] Windows Key Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl]") ; (074)
      {
        v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl Down]") ; (074)(014)
      {
        v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(014)", "End") ; (014_1)(GUI Object: [key] Ctrl Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Ctrl Up]") ; (074)(017)
      {
        v_301_2 := Array_Add(v_301_2, "(074)", "End") ; (074_1)(GUI Object: [key] Ctrl)/(301_2)([key] KeyArray_Numbers [Array])
        v_301_2 := Array_Add(v_301_2, "(017)", "End") ; (017_1)(GUI Object: [key] Ctrl Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Delete]") ; (075)
      {
        v_301_2 := Array_Add(v_301_2, "(075)", "End") ; (075_1)(GUI Object: [key] Delete)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[End]") ; (076)
      {
        v_301_2 := Array_Add(v_301_2, "(076)", "End") ; (076_1)(GUI Object: [key] End)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Home]") ; (077)
      {
        v_301_2 := Array_Add(v_301_2, "(077)", "End") ; (077_1)(GUI Object: [key] Home)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[Insert]") ; (078)
      {
        v_301_2 := Array_Add(v_301_2, "(078)", "End") ; (078_1)(GUI Object: [key] Insert)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[PgDn]") ; (079)
      {
        v_301_2 := Array_Add(v_301_2, "(079)", "End") ; (079_1)(GUI Object: [key] Page Down)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
      else if (This_KeyStroke == "[PgUp]") ; (080)
      {
        v_301_2 := Array_Add(v_301_2, "(080)", "End") ; (080_1)(GUI Object: [key] Page Up)/(301_2)([key] KeyArray_Numbers [Array])
      }
      ; -------------------------------------------
    } ; (301_8)([key] KeyArray_Keystroke for Shortcut)
    ; -------------------------------------------
    DataArray.301.2 := v_301_2 ; (301_2)([key] KeyArray_Numbers [Array])
    ; -------------------------------------------
  } ; End (Ckeck_Array != "") ; Make Sure (301_2)([key] KeyArray_Numbers) Has Key's in it
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Key_Array_Numbers(DataArray) ; > DataArray
