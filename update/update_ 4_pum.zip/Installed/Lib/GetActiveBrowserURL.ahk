﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  GetActiveBrowserURL
GetActiveBrowserURL(sExe, sClass)
{
/*
;"InternetExplorer" or "IE" - for Internet Explorer
;"Firefox" - for Firefox (or its portable version)
;"Opera" - for Opera
;"Opera@USB" - for Opera@USB
;"GoogleChrome" - for Google Chrome (or its portable version)
Safari (macOS)
Konqueror (Linux) 
Lynx (Unix)
Internet Explorer (Replaced by Microsoftedge)
Iridium
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe iridium.exe)
Avant
(ahk_class TAFfrmClient.UnicodeClass) ***
(ahk_exe avantvw.exe)
Brave
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe Brave.exe)
Chrome
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe chrome.exe)
Firefox
(ahk_class MozillaWindowClass) ***
(ahk_exe firefox.exe)
Iridium
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe iridium.exe)
Kingpin
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe Kingpin Private Browser.exe)
Maxthon
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe Maxthon.exe)
Opera
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe opera.exe)
SlimBrowser
(ahk_class FlashPeakWindowClass) ***
(ahk_exe slimbrowser.exe)
Slimjet
(ahk_class Slimjet_WidgetWin_1) ***
(ahk_exe slimjet.exe)
Tor
(Fake: Uses Default)
(Fake: Uses Default)
UC
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe UCBrowser.exe)
Vivaldi
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe vivaldi.exe)
Yandex
(ahk_class YandexBrowser_WidgetWin_1)
(ahk_exe browser.exe)
Microsoftedge
(ahk_class Chrome_WidgetWin_1) ***
(ahk_exe msedge.exe)
*/
  ModernBrowsers := "ApplicationFrameWindow,Chrome_WidgetWin_0,Chrome_WidgetWin_1,Maxthon3Cls_MainFrm,MozillaWindowClass,Slimjet_WidgetWin_1,TAFfrmClient.UnicodeClass,FlashPeakWindowClass,YandexBrowser_WidgetWin_1"
  LegacyBrowsers := "IEFrame,OperaWindowClass"
  if sClass in % ModernBrowsers
  {
    return GetBrowserURL_ACC(sExe, sClass)
  }
  else if sClass in % LegacyBrowsers
  {
    return GetBrowserURL_DDE(sExe, sClass)
  }
  else
  {
    return ""
  }
}
