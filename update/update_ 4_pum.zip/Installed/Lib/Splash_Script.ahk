﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Dark Purple 
; Winset, TransColor, 573694
; -------------------------------------------
Splash_Script(ImgNum, Sleep_Time) ; ImgNum ("Off"/Number), Sleep_Time > Nothing
{
  ; -------------------------------------------
  { ; [GET] User Language
    ; -------------------------------------------
    Lang_File := A_AppData "\PopUpMenu_PUM\system\Language.txt" ; (381_2)(User Language Text File [User Text File Path])
    if FileExist(Lang_File) ; (381_2)(User Language Text File [User Text File Path])
    {
      FileReadLINE, ThisLang, %Lang_File%, 1 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      if (ThisLang == "") ; (365_2)(Current User language)
      {
        FileDelete, %Lang_File% ; (381_2)(User Language Text File [User Text File Path])
        ThisLang := "en" ; (365_2)(Current User language)
        FileAppend, %ThisLang%`n, %Lang_File%, UTF-8 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
      }
    }
    else
    {
      ThisLang := "en" ; (365_2)(Current User language)
      FileAppend, %ThisLang%`n, %Lang_File%, UTF-8 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
    }
    ; -------------------------------------------
  } ; End [GET] User Language
  ; -------------------------------------------
  if (ImgNum == "Off")
  {
    ; -------------------------------------------
    ; Closes Any Splash Image
    ; Does Not Need DataArray
    ; -------------------------------------------
    if (Sleep_Time > 0)
    {
      Sleep, %Sleep_Time%
    }
    ; -------------------------------------------
    SplashImage, Off
    ; -------------------------------------------
    Splash_500 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_501 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_502 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_503 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_504 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_505 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_506 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_507 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_508 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_509 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_510 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_" ThisLang ".ahk" ; (365_2)(Current User language)
    Splash_511 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_" ThisLang ".ahk" ; (365_2)(Current User language)
    ; -------------------------------------------
    
    
    
    Script_Close(Splash_500)
    Script_Close(Splash_501)
    Script_Close(Splash_502)
    Script_Close(Splash_503)
    Script_Close(Splash_504)
    Script_Close(Splash_505)
    Script_Close(Splash_506)
    Script_Close(Splash_507)
    Script_Close(Splash_508)
    Script_Close(Splash_509)
    Script_Close(Splash_510)
    Script_Close(Splash_511)
    
    
    
    
    
    ;~ Loop 2
    ;~ {
      ;~ DetectHiddenWindows, On
      ;~ WinClose, %Splash_500% ahk_class AutoHotkey
      ;~ WinClose, %Splash_501% ahk_class AutoHotkey
      ;~ WinClose, %Splash_502% ahk_class AutoHotkey
      ;~ WinClose, %Splash_503% ahk_class AutoHotkey
      ;~ WinClose, %Splash_504% ahk_class AutoHotkey
      ;~ WinClose, %Splash_505% ahk_class AutoHotkey
      ;~ WinClose, %Splash_506% ahk_class AutoHotkey
      ;~ WinClose, %Splash_507% ahk_class AutoHotkey
      ;~ WinClose, %Splash_508% ahk_class AutoHotkey
      ;~ WinClose, %Splash_509% ahk_class AutoHotkey
      ;~ WinClose, %Splash_510% ahk_class AutoHotkey
      ;~ WinClose, %Splash_511% ahk_class AutoHotkey
      ;~ Sleep, 100
    ;~ } ; End Loop Images
    
    
    
    
    
    ; -------------------------------------------
  }
  else
  {
    ; -------------------------------------------
    ThisSplash := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\" ImgNum "_" ThisLang ".ahk" ; (365_2)(Current User language)
    ; -------------------------------------------
    if (SubStr(ImgNum, 1, 1) == "4")
    {
      SplashImage, %ThisSplash%, b
      if (Sleep_Time > 0)
      {
        Sleep, %Sleep_Time%
        SplashImage, Off
      }
    }
    else
    {
      ; -------------------------------------------
      Run, %ThisSplash%,,, ThisSplash ; (384_8)(Launcher [Script File Path])
      Process, Priority, %ThisSplash%, High ; (384_8)(Launcher [Script File Path])
      ; -------------------------------------------
      if (Sleep_Time > 0)
      {
        Script_Close(ThisSplash)
        
        ; -------------------------------------------
        Sleep, %Sleep_Time%
        ; -------------------------------------------
        Splash_500_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_de.ahk" ; (365_2)(Current User language)
        Splash_500_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_en.ahk" ; (365_2)(Current User language)
        Splash_500_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_es.ahk" ; (365_2)(Current User language)
        Splash_500_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_fr.ahk" ; (365_2)(Current User language)
        Splash_500_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_it.ahk" ; (365_2)(Current User language)
        Splash_500_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_pl.ahk" ; (365_2)(Current User language)
        Splash_500_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_pt.ahk" ; (365_2)(Current User language)
        Splash_500_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_ru.ahk" ; (365_2)(Current User language)
        Splash_500_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_sv.ahk" ; (365_2)(Current User language)
        Splash_500_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_tr.ahk" ; (365_2)(Current User language)
        
        Splash_501_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_de.ahk" ; (365_2)(Current User language)
        Splash_501_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_en.ahk" ; (365_2)(Current User language)
        Splash_501_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_es.ahk" ; (365_2)(Current User language)
        Splash_501_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_fr.ahk" ; (365_2)(Current User language)
        Splash_501_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_it.ahk" ; (365_2)(Current User language)
        Splash_501_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_pl.ahk" ; (365_2)(Current User language)
        Splash_501_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_pt.ahk" ; (365_2)(Current User language)
        Splash_501_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_ru.ahk" ; (365_2)(Current User language)
        Splash_501_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_sv.ahk" ; (365_2)(Current User language)
        Splash_501_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_tr.ahk" ; (365_2)(Current User language)
        
        Splash_502_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_de.ahk" ; (365_2)(Current User language)
        Splash_502_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_en.ahk" ; (365_2)(Current User language)
        Splash_502_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_es.ahk" ; (365_2)(Current User language)
        Splash_502_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_fr.ahk" ; (365_2)(Current User language)
        Splash_502_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_it.ahk" ; (365_2)(Current User language)
        Splash_502_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_pl.ahk" ; (365_2)(Current User language)
        Splash_502_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_pt.ahk" ; (365_2)(Current User language)
        Splash_502_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_ru.ahk" ; (365_2)(Current User language)
        Splash_502_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_sv.ahk" ; (365_2)(Current User language)
        Splash_502_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_tr.ahk" ; (365_2)(Current User language)
        
        Splash_503_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_de.ahk" ; (365_2)(Current User language)
        Splash_503_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_en.ahk" ; (365_2)(Current User language)
        Splash_503_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_es.ahk" ; (365_2)(Current User language)
        Splash_503_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_fr.ahk" ; (365_2)(Current User language)
        Splash_503_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_it.ahk" ; (365_2)(Current User language)
        Splash_503_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_pl.ahk" ; (365_2)(Current User language)
        Splash_503_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_pt.ahk" ; (365_2)(Current User language)
        Splash_503_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_ru.ahk" ; (365_2)(Current User language)
        Splash_503_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_sv.ahk" ; (365_2)(Current User language)
        Splash_503_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_tr.ahk" ; (365_2)(Current User language)
        
        Splash_504_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_de.ahk" ; (365_2)(Current User language)
        Splash_504_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_en.ahk" ; (365_2)(Current User language)
        Splash_504_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_es.ahk" ; (365_2)(Current User language)
        Splash_504_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_fr.ahk" ; (365_2)(Current User language)
        Splash_504_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_it.ahk" ; (365_2)(Current User language)
        Splash_504_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_pl.ahk" ; (365_2)(Current User language)
        Splash_504_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_pt.ahk" ; (365_2)(Current User language)
        Splash_504_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_ru.ahk" ; (365_2)(Current User language)
        Splash_504_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_sv.ahk" ; (365_2)(Current User language)
        Splash_504_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_tr.ahk" ; (365_2)(Current User language)
        
        Splash_505_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_de.ahk" ; (365_2)(Current User language)
        Splash_505_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_en.ahk" ; (365_2)(Current User language)
        Splash_505_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_es.ahk" ; (365_2)(Current User language)
        Splash_505_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_fr.ahk" ; (365_2)(Current User language)
        Splash_505_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_it.ahk" ; (365_2)(Current User language)
        Splash_505_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_pl.ahk" ; (365_2)(Current User language)
        Splash_505_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_pt.ahk" ; (365_2)(Current User language)
        Splash_505_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_ru.ahk" ; (365_2)(Current User language)
        Splash_505_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_sv.ahk" ; (365_2)(Current User language)
        Splash_505_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_tr.ahk" ; (365_2)(Current User language)
        
        Splash_506_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_de.ahk" ; (365_2)(Current User language)
        Splash_506_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_en.ahk" ; (365_2)(Current User language)
        Splash_506_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_es.ahk" ; (365_2)(Current User language)
        Splash_506_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_fr.ahk" ; (365_2)(Current User language)
        Splash_506_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_it.ahk" ; (365_2)(Current User language)
        Splash_506_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_pl.ahk" ; (365_2)(Current User language)
        Splash_506_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_pt.ahk" ; (365_2)(Current User language)
        Splash_506_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_ru.ahk" ; (365_2)(Current User language)
        Splash_506_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_sv.ahk" ; (365_2)(Current User language)
        Splash_506_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_tr.ahk" ; (365_2)(Current User language)
        
        Splash_507_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_de.ahk" ; (365_2)(Current User language)
        Splash_507_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_en.ahk" ; (365_2)(Current User language)
        Splash_507_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_es.ahk" ; (365_2)(Current User language)
        Splash_507_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_fr.ahk" ; (365_2)(Current User language)
        Splash_507_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_it.ahk" ; (365_2)(Current User language)
        Splash_507_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_pl.ahk" ; (365_2)(Current User language)
        Splash_507_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_pt.ahk" ; (365_2)(Current User language)
        Splash_507_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_ru.ahk" ; (365_2)(Current User language)
        Splash_507_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_sv.ahk" ; (365_2)(Current User language)
        Splash_507_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_tr.ahk" ; (365_2)(Current User language)
        
        Splash_508_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_de.ahk" ; (365_2)(Current User language)
        Splash_508_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_en.ahk" ; (365_2)(Current User language)
        Splash_508_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_es.ahk" ; (365_2)(Current User language)
        Splash_508_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_fr.ahk" ; (365_2)(Current User language)
        Splash_508_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_it.ahk" ; (365_2)(Current User language)
        Splash_508_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_pl.ahk" ; (365_2)(Current User language)
        Splash_508_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_pt.ahk" ; (365_2)(Current User language)
        Splash_508_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_ru.ahk" ; (365_2)(Current User language)
        Splash_508_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_sv.ahk" ; (365_2)(Current User language)
        Splash_508_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_tr.ahk" ; (365_2)(Current User language)
        
        Splash_509_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_de.ahk" ; (365_2)(Current User language)
        Splash_509_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_en.ahk" ; (365_2)(Current User language)
        Splash_509_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_es.ahk" ; (365_2)(Current User language)
        Splash_509_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_fr.ahk" ; (365_2)(Current User language)
        Splash_509_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_it.ahk" ; (365_2)(Current User language)
        Splash_509_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_pl.ahk" ; (365_2)(Current User language)
        Splash_509_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_pt.ahk" ; (365_2)(Current User language)
        Splash_509_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_ru.ahk" ; (365_2)(Current User language)
        Splash_509_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_sv.ahk" ; (365_2)(Current User language)
        Splash_509_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_tr.ahk" ; (365_2)(Current User language)
        
        Splash_510_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_de.ahk" ; (365_2)(Current User language)
        Splash_510_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_en.ahk" ; (365_2)(Current User language)
        Splash_510_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_es.ahk" ; (365_2)(Current User language)
        Splash_510_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_fr.ahk" ; (365_2)(Current User language)
        Splash_510_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_it.ahk" ; (365_2)(Current User language)
        Splash_510_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_pl.ahk" ; (365_2)(Current User language)
        Splash_510_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_pt.ahk" ; (365_2)(Current User language)
        Splash_510_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_ru.ahk" ; (365_2)(Current User language)
        Splash_510_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_sv.ahk" ; (365_2)(Current User language)
        Splash_510_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_tr.ahk" ; (365_2)(Current User language)
        
        Splash_511_1 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_de.ahk" ; (365_2)(Current User language)
        Splash_511_2 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_en.ahk" ; (365_2)(Current User language)
        Splash_511_3 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_es.ahk" ; (365_2)(Current User language)
        Splash_511_4 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_fr.ahk" ; (365_2)(Current User language)
        Splash_511_5 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_it.ahk" ; (365_2)(Current User language)
        Splash_511_6 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_pl.ahk" ; (365_2)(Current User language)
        Splash_511_7 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_pt.ahk" ; (365_2)(Current User language)
        Splash_511_8 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_ru.ahk" ; (365_2)(Current User language)
        Splash_511_9 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_sv.ahk" ; (365_2)(Current User language)
        Splash_511_0 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_tr.ahk" ; (365_2)(Current User language)
        
        Script_Close(Splash_500_1)
        Script_Close(Splash_500_2)
        Script_Close(Splash_500_3)
        Script_Close(Splash_500_4)
        Script_Close(Splash_500_5)
        Script_Close(Splash_500_6)
        Script_Close(Splash_500_7)
        Script_Close(Splash_500_8)
        Script_Close(Splash_500_9)
        Script_Close(Splash_500_0)
        
        Script_Close(Splash_501_1)
        Script_Close(Splash_501_2)
        Script_Close(Splash_501_3)
        Script_Close(Splash_501_4)
        Script_Close(Splash_501_5)
        Script_Close(Splash_501_6)
        Script_Close(Splash_501_7)
        Script_Close(Splash_501_8)
        Script_Close(Splash_501_9)
        Script_Close(Splash_501_0)
        
        Script_Close(Splash_502_1)
        Script_Close(Splash_502_2)
        Script_Close(Splash_502_3)
        Script_Close(Splash_502_4)
        Script_Close(Splash_502_5)
        Script_Close(Splash_502_6)
        Script_Close(Splash_502_7)
        Script_Close(Splash_502_8)
        Script_Close(Splash_502_9)
        Script_Close(Splash_502_0)
        
        Script_Close(Splash_503_1)
        Script_Close(Splash_503_2)
        Script_Close(Splash_503_3)
        Script_Close(Splash_503_4)
        Script_Close(Splash_503_5)
        Script_Close(Splash_503_6)
        Script_Close(Splash_503_7)
        Script_Close(Splash_503_8)
        Script_Close(Splash_503_9)
        Script_Close(Splash_503_0)
        
        Script_Close(Splash_504_1)
        Script_Close(Splash_504_2)
        Script_Close(Splash_504_3)
        Script_Close(Splash_504_4)
        Script_Close(Splash_504_5)
        Script_Close(Splash_504_6)
        Script_Close(Splash_504_7)
        Script_Close(Splash_504_8)
        Script_Close(Splash_504_9)
        Script_Close(Splash_504_0)
        
        Script_Close(Splash_505_1)
        Script_Close(Splash_505_2)
        Script_Close(Splash_505_3)
        Script_Close(Splash_505_4)
        Script_Close(Splash_505_5)
        Script_Close(Splash_505_6)
        Script_Close(Splash_505_7)
        Script_Close(Splash_505_8)
        Script_Close(Splash_505_9)
        Script_Close(Splash_505_0)
        
        Script_Close(Splash_506_1)
        Script_Close(Splash_506_2)
        Script_Close(Splash_506_3)
        Script_Close(Splash_506_4)
        Script_Close(Splash_506_5)
        Script_Close(Splash_506_6)
        Script_Close(Splash_506_7)
        Script_Close(Splash_506_8)
        Script_Close(Splash_506_9)
        Script_Close(Splash_506_0)
        
        Script_Close(Splash_507_1)
        Script_Close(Splash_507_2)
        Script_Close(Splash_507_3)
        Script_Close(Splash_507_4)
        Script_Close(Splash_507_5)
        Script_Close(Splash_507_6)
        Script_Close(Splash_507_7)
        Script_Close(Splash_507_8)
        Script_Close(Splash_507_9)
        Script_Close(Splash_507_0)
        
        Script_Close(Splash_508_1)
        Script_Close(Splash_508_2)
        Script_Close(Splash_508_3)
        Script_Close(Splash_508_4)
        Script_Close(Splash_508_5)
        Script_Close(Splash_508_6)
        Script_Close(Splash_508_7)
        Script_Close(Splash_508_8)
        Script_Close(Splash_508_9)
        Script_Close(Splash_508_0)
        
        Script_Close(Splash_509_1)
        Script_Close(Splash_509_2)
        Script_Close(Splash_509_3)
        Script_Close(Splash_509_4)
        Script_Close(Splash_509_5)
        Script_Close(Splash_509_6)
        Script_Close(Splash_509_7)
        Script_Close(Splash_509_8)
        Script_Close(Splash_509_9)
        Script_Close(Splash_509_0)
        
        Script_Close(Splash_510_1)
        Script_Close(Splash_510_2)
        Script_Close(Splash_510_3)
        Script_Close(Splash_510_4)
        Script_Close(Splash_510_5)
        Script_Close(Splash_510_6)
        Script_Close(Splash_510_7)
        Script_Close(Splash_510_8)
        Script_Close(Splash_510_9)
        Script_Close(Splash_510_0)
        
        Script_Close(Splash_511_1)
        Script_Close(Splash_511_2)
        Script_Close(Splash_511_3)
        Script_Close(Splash_511_4)
        Script_Close(Splash_511_5)
        Script_Close(Splash_511_6)
        Script_Close(Splash_511_7)
        Script_Close(Splash_511_8)
        Script_Close(Splash_511_9)
        Script_Close(Splash_511_0)

        
        
        
        
        
        
        
        
        
        ;~ Splash_500 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\500_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_501 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\501_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_502 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\502_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_503 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\503_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_504 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\504_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_505 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\505_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_506 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\506_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_507 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\507_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_508 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\508_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_509 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\509_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_510 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\510_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ Splash_511 := A_AppDataCommon "\PopUpMenu_PUM\splash\ahk\511_" ThisLang ".ahk" ; (365_2)(Current User language)
        ;~ ; -------------------------------------------
        ;~ Script_Close(Splash_500)
        ;~ Script_Close(Splash_501)
        ;~ Script_Close(Splash_502)
        ;~ Script_Close(Splash_503)
        ;~ Script_Close(Splash_504)
        ;~ Script_Close(Splash_505)
        ;~ Script_Close(Splash_506)
        ;~ Script_Close(Splash_507)
        ;~ Script_Close(Splash_508)
        ;~ Script_Close(Splash_509)
        ;~ Script_Close(Splash_510)
        ;~ Script_Close(Splash_511)
        
        
        ;~ Loop 2
        ;~ {
          ;~ DetectHiddenWindows, On
          ;~ WinClose, %Splash_500% ahk_class AutoHotkey
          ;~ WinClose, %Splash_501% ahk_class AutoHotkey
          ;~ WinClose, %Splash_502% ahk_class AutoHotkey
          ;~ WinClose, %Splash_503% ahk_class AutoHotkey
          ;~ WinClose, %Splash_504% ahk_class AutoHotkey
          ;~ WinClose, %Splash_505% ahk_class AutoHotkey
          ;~ WinClose, %Splash_506% ahk_class AutoHotkey
          ;~ WinClose, %Splash_507% ahk_class AutoHotkey
          ;~ WinClose, %Splash_508% ahk_class AutoHotkey
          ;~ WinClose, %Splash_509% ahk_class AutoHotkey
          ;~ WinClose, %Splash_510% ahk_class AutoHotkey
          ;~ WinClose, %Splash_511% ahk_class AutoHotkey
        ;~ }
        
        
        
      }
    }
  }
} ; End Splash_Script(ImgNum, Sleep_Time)
