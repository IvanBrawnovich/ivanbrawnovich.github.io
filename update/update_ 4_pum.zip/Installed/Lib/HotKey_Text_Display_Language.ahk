﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HotKey_Text_Display_Language(DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("HotKey_Text_Display_Language", DataArray)
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; (231_1)(HotKey User Hot Key)
  ; (231_2)(User Hotkey)
  ; (231_3)(User Hotkey File)
  ; (231_4)(Displayed KeyStroke)/(Choose a Keystroke)
  ; (231_5)(No Keystroke Selected)
  ; (231_6)(This is a good Keystroke)
  ; (231_7)(This keystroke is not good)
  v_369_2 := DataArray.369.2 ; (369_2)(Current User Hotkey)
  v_369_4 := "" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
  ; -------------------------------------------
  if (v_365_2 == "de") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Kein Tastenanschlag ausgewählt" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Dies ist ein guter Tastenanschlag" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Dieser Tastenanschlag ist nicht gut" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Wählen Sie einen Tastenanschlag" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Windows Schlüssel" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Linker Windows Schlüssel" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rechter Windows Schlüssel" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Linke Maustaste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rechte Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mittlere Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Maus-Rad nach oben" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mausrad nach unten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Maus X1 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Maus X2 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Linke Maustaste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rechte Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mittlere Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus-Rad nach oben" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mausrad nach unten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X1 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X2 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Linke Maustaste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rechte Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mittlere Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus-Rad nach oben" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mausrad nach unten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X1 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X2 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Strg" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Umsch" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Linke Maustaste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rechte Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mittlere Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus-Rad nach oben" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mausrad nach unten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X1 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X2 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Linke Maustaste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rechte Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mittlere Maus-Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus-Rad nach oben" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mausrad nach unten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X1 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maus X2 Taste" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; (365_2)(Current User language)
  if (v_365_2 == "en") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "No Keystroke Selected" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "This is a good Keystroke" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "This keystroke is not good" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Choose a Keystroke" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    } ; (231_2)(User Hotkey)
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Windows Key" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          
          
          
          v_369_4 := "Left Windows Key" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Right Windows Key" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Left Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Right Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Middle Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mouse Wheel Up" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mouse Wheel Down" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mouse X1 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mouse X2 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Left Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Right Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Middle Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Up" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Down" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X1 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X2 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Left Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Right Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Middle Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Up" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Down" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X1 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X2 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Left Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Right Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Middle Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Up" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Down" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X1 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X2 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Left Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Right Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Middle Mouse Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Up" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse Wheel Down" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X1 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mouse X2 Button" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "es") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Sin pulsación de tecla seleccionada" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Esta es una buena pulsación de teclas" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Esta pulsación de tecla no es buena" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Elija una pulsación de tecla" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Clave Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Tecla de Windows izquierda" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Tecla de Windows derecha" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botón izquierdo del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botón derecho del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botón central del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rueda del ratón hacia arriba" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rueda del ratón hacia abajo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botón Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botón Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón izquierdo del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón derecho del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón central del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia arriba" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia abajo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón izquierdo del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón derecho del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón central del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia arriba" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia abajo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mayús" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón izquierdo del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón derecho del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón central del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia arriba" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia abajo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón izquierdo del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón derecho del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón central del ratón" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia arriba" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rueda del ratón hacia abajo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botón Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "fr") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Aucune frappe sélectionnée" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "C'est une bonne frappe" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Cette frappe n'est pas bonne" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Choisissez une frappe" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Clé Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Touche Windows gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Touche Windows droite" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Bouton souris gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Bouton Droit De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Bouton Milieu De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Roue de souris vers le haut" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Roue de souris vers le bas" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Souris X1 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Souris X2 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton souris gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Droit De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Milieu De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le haut" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le bas" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X1 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X2 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton souris gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Droit De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Milieu De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le haut" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le bas" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X1 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X2 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maj" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton souris gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Droit De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Milieu De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le haut" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le bas" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X1 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X2 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton souris gauche" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Droit De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Bouton Milieu De La Souris" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le haut" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roue de souris vers le bas" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X1 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Souris X2 Bouton" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "it") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Nessuna sequenza di tasti selezionata" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Questa è una buona sequenza di tasti" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Questa sequenza di tasti non è buona" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Scegli una sequenza di tasti" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Chiave Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Tasto Windows sinistro" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Tasto Windows Destro" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Pulsante sinistro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Pulsante destro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Pulsante centrale del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rotellina del mouse verso l'alto" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Rotellina del mouse verso il basso" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Pulsante Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Pulsante Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante sinistro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante destro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante centrale del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso l'alto" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso il basso" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante sinistro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante destro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante centrale del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso l'alto" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso il basso" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Maiusc" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante sinistro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante destro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante centrale del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso l'alto" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso il basso" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante sinistro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante destro del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante centrale del mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso l'alto" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Rotellina del mouse verso il basso" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Pulsante Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "pl") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Nie wybrano naciśnięcia klawisza" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "To jest dobre naciśnięcie klawisza" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "To naciśnięcie klawisza nie jest dobre" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Wybierz naciśnięcie klawisza" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Klucz Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Lewy klawisz Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Prawy Klawisz Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Lewy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Prawy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Środkowy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Kółko myszy w górę" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Kółko myszy w dół" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Przycisk Myszy X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Przycisk Myszy X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Lewy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Prawy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Środkowy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w górę" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w dół" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Lewy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Prawy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Środkowy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w górę" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w dół" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Lewy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Prawy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Środkowy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w górę" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w dół" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Lewy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Prawy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Środkowy Przycisk Myszy" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w górę" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kółko myszy w dół" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Przycisk Myszy X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "pt") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Sem teclas selecionadas" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Este é um bom toque de tecla" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Este toque de tecla não é bom." ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Escolha uma tecla" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Chave Do Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Chave Esquerda Do Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Chave Direita Do Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botão esquerdo do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botão direito do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botão do meio do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Roda do mouse para cima" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Roda do mouse para baixo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botão Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Botão Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão esquerdo do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão direito do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão do meio do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para cima" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para baixo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão esquerdo do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão direito do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão do meio do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para cima" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para baixo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão esquerdo do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão direito do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão do meio do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para cima" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para baixo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão esquerdo do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão direito do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão do meio do mouse" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para cima" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Roda do mouse para baixo" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Botão Mouse X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "ru") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Нажатие клавиши не выбрано" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Это хорошее нажатие клавиши" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Это нажатие клавиши не хорошо" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Выберите нажатие клавиши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ключ Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Левая клавиша Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Правая клавиша Windows" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Левая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Правая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Средняя кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Колесо мыши вверх" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Колесо мыши вниз" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Кнопка мыши X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Кнопка мыши X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Левая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Правая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Средняя кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вверх" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вниз" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Левая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Правая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Средняя кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вверх" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вниз" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Shift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Левая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Правая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Средняя кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вверх" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вниз" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Левая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Правая кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Средняя кнопка мыши" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вверх" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Колесо мыши вниз" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X1" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Кнопка мыши X2" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  if (v_365_2 == "sv") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Ingen tangenttryckning vald" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Det här är en bra tangenttryckning" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Denna tangenttryckning är inte bra" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Välj ett tangenttryck" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Windows-tangenten" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Vänster Windows-tangent" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Höger Windows-tangent" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Vänster musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Höger musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mitten musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mushjulet uppåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mushjulet nedåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mus X1-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Mus X2-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Vänster musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Höger musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mitten musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet uppåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet nedåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X1-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X2-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Vänster musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Höger musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mitten musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet uppåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet nedåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X1-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X2-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Ctrl" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Alt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Skift" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Vänster musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Höger musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mitten musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet uppåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet nedåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X1-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X2-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Vänster musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Höger musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mitten musknapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet uppåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mushjulet nedåt" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X1-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Mus X2-knapp" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------    
  }
  if (v_365_2 == "tr") ; (365_2)(Current User language)
  {
    ; -------------------------------------------
    v_369_5 := "Tuş Vuruşu Seçilmedi" ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
    v_369_6 := "Bu iyi bir Tuş vuruşu" ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
    v_369_7 := "Bu tuş vuruşu iyi değil" ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
    ; -------------------------------------------
    if (v_369_2 == "") ; (369_2)(Current User Hotkey)
    {
      ; -------------------------------------------
      v_369_4 := "Bir Tuş Vuruşu Seçin" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      { ; First
        if (SubStr(v_369_2, 1, 1) == "#") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Windows Tuşu" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "LWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Sol Windows Tuşu" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 4) == "RWin") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Sağ Windows Tuşu" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Sol Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Sağ Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Orta Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Fare Tekerleği Yukarı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Fare Tekerleği Aşağı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Fare X1 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 1, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := "Fare X2 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
      } ; End First
      ; -------------------------------------------
      { ; Second
        ; -------------------------------------------
        if (SubStr(v_369_2, 2, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sol Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sağ Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Orta Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Yukarı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Aşağı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X1 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 2, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X2 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Second
      ; -------------------------------------------
      { ; Third
        ; -------------------------------------------
        if (SubStr(v_369_2, 3, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sol Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sağ Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Orta Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Yukarı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Aşağı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X1 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 3, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X2 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Third
      ; -------------------------------------------
      { ; Forth
        ; -------------------------------------------
        if (SubStr(v_369_2, 4, 1) == "^") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "!") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 1) == "+") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 4) == "Ctrl") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Kontrol" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 3) == "Alt") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sçnk" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 5) == "Shift") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Üst" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sol Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sağ Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Orta Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Yukarı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Aşağı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X1 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 4, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X2 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Forth
      ; -------------------------------------------
      { ; Fifth
        ; -------------------------------------------
        if (SubStr(v_369_2, 5, 7) == "LButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sol Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "RButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Sağ Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "MButton") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Orta Fare Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 7) == "WheelUp") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Yukarı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 9) == "WheelDown") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare Tekerleği Aşağı" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton1") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X1 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        if (SubStr(v_369_2, 5, 8) == "XButton2") ; (369_2)(Current User Hotkey)
        {
          v_369_4 := v_369_4 " + Fare X2 Düğmesi" ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
        }
        ; -------------------------------------------
      } ; End Fifth
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  DataArray.369.4 := v_369_4 ; (369_4)(Hotkey <Displayed Text> KeyStroke/Choose a Keystroke)
  DataArray.369.5 := v_369_5 ; (369_5)(Hotkey <Displayed Text> No Keystroke Selected)
  DataArray.369.6 := v_369_6 ; (369_6)(Hotkey <Displayed Text> This is a good Keystroke)
  DataArray.369.7 := v_369_7 ; (369_7)(Hotkey <Displayed Text> This keystroke is not good)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
