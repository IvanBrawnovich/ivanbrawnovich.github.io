﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_116(DataArray) ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
{
  ; -------------------------------------------
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  DataArray := GetSelected_ListNumber("g_116", v_366_5, DataArray) ; (366_5)(Script Type)/(116_1)(GUI Object: [cpl][mnu] List Full Across)
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
