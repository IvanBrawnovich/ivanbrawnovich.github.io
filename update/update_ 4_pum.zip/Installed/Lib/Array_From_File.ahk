﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_From_File(FilePath) ; > Array
{
  ReturnArray := []
  Loop, Read, %FilePath%
  {
    ReturnArray.Push(A_LoopReadLine)
  } ; End Loop, Read, %FilePath%
  return ReturnArray
}
