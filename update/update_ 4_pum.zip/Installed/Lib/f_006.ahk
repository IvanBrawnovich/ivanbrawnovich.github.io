﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_006(DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_006", DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
  ; -------------------------------------------
  v_102_3 := DataArray.102.3 ; (102_3)(Main Display Icon: Image Path)
  v_383_2 := DataArray.383.2 ; (383_2)([Image Convert] magick.exe [Support Program File Path])
  ; -------------------------------------------
  ; This will be displayed only if the Image is a Ico
  ; -------------------------------------------
  if (DataArray.4.2 == 1) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
  {
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("006", 2, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
    ; -------------------------------------------
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_102_3, , , ThisExt ; (102_3)(Main Display Icon: Image Path)
    StringLower, ThisExt, ThisExt
    ; -------------------------------------------
    ; Rotate Ico
    if (ThisExt == "ico")
    {
      RunThis := v_383_2 " """ v_102_3 """ -rotate 90 """ v_102_3 """" ; (383_2)([Image Convert] magick.exe [Support Program File Path])/(102_3)(Main Display Icon: Image Path)
      RunWait, %RunThis%, , Hide
      GuiControl, PopUpMenu:, g_102, %v_102_3% ; (102_3)(Main Display Icon: Image Path)/(102_1)(GUI Object: Main Display Icon)
      GuiControl, PopUpMenu:MoveDraw, g_102, +w80 +h80 ; (102_1)(GUI Object: Main Display Icon)
      GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
    } ; End if (ThisExt == "ico")
    ; -------------------------------------------
    DataArray := GuiControlImage_PopUpMenu("006", 1, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
    ; -------------------------------------------
  } ; End if OK (IsEnabled == 1)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; (006)_(---)(Icon Rotate Right)_(2)Select_(3)Image
