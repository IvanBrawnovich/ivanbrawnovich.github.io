﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
/*
Add at Start
DataArray.450 := "" ; (450_1)(Last Function [Array])
Add at End
Function_Msg(SleepTime, DataArray) ; (450)Function Array /  SleepTime, DataArray > Nothing
*/
; -------------------------------------------
Function_Flow(This_Function, DataArray)
{
  ; -------------------------------------------
  FlowArray := DataArray.450 ; (450_1)(Last Function [Array])
  if !FlowArray
  {
    FlowArray := []
  }
  if (This_Function != "GuiControl_Image")
  {
    FlowArray.Push(This_Function)
  }
  DataArray.450 := FlowArray ; (450_1)(Last Function [Array])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
return
