﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_079(DataArray) ; (079_1)(GUI Object: [key] Page Down)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_079", DataArray) ; (079_1)(GUI Object: [key] Page Down)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("079", DataArray) ; (079_1)(GUI Object: [key] Page Down)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
