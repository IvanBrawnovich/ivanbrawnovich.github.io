﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_155(DataArray) ; (155_1)(GUI Object: [pum] Pum Select Display Text)
{
  ; -------------------------------------------
  v_155_2 := DataArray.155.2 ; (155_2)([pum] Pum Select Display Text: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_155_2 == "") ; (155_2)([pum] Pum Select Display Text: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_155_2 := 1 ; (155_2)([pum] Pum Select Display Text: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_155_2 == 1) ; (155_2)([pum] Pum Select Display Text: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumDis" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
