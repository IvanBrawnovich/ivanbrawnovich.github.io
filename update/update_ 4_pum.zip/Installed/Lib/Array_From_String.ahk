﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_From_String(LoopNum, ThisString, LookForThis) ; LoopNum (Number Search for LookForThis), ThisString, LookForThis > Array
{
  ; return ReturnArray
  ; This is a Array, from a string (a toolbox0.xml Config line string)
  ReturnArray := []
  CountPos := 1
  Loop %LoopNum%
  {
    If (CountPos == 1)
    {
      StringGetPos, FoundPos, ThisString, %LookForThis%
      NewStartPos := FoundPos+2
      ThisString := SubStr(ThisString, NewStartPos)
      StringGetPos, FoundPos, ThisString, %LookForThis%
      NewString := SubStr(ThisString, 1, FoundPos)
    } ; End (CountPos == 1)
    else
    {
      StringGetPos, FoundPos, ThisString, %LookForThis%
      NewStartPos := FoundPos+2
      ThisString := SubStr(ThisString, NewStartPos)
      StringGetPos, FoundPos, ThisString, %LookForThis%
      NewStartPos := FoundPos+2
      ThisString := SubStr(ThisString, NewStartPos)
      StringGetPos, FoundPos, ThisString, %LookForThis%
      NewString := SubStr(ThisString, 1, FoundPos)
    } ; End else
    ReturnArray[CountPos] := NewString
    CountPos := CountPos+1
  } ; End Loop %LoopNum%
  return ReturnArray
}
