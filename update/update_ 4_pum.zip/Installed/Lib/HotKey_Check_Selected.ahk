﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
HotKey_Check_Selected(SubArray, DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("HotKey_Check_Selected", DataArray)
  ; -------------------------------------------
  ; (142_1)(GUI Object: HotKey Select Mouse Left)_(142_2)(HotKey Select Mouse Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(142_3)(HotKey Select Mouse Left: Image Path)
  ; (143_1)(GUI Object: HotKey Select Mouse Right)_(143_2)(HotKey Select Mouse Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(143_3)(HotKey Select Mouse Right: Image Path)
  ; (144_1)(GUI Object: HotKey Select Mouse Middle)_(144_2)(HotKey Select Mouse Mouse Middle: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(144_3)(HotKey Select Mouse Mouse Middle: Image Path)
  ; (145_1)(GUI Object: HotKey Select Mouse Wheel Up)_(145_2)(HotKey Select Mouse Wheel Up: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(145_3)(HotKey Select Mouse Wheel Up: Image Path)
  ; (146_1)(GUI Object: HotKey Select Mouse Wheel Down)_(146_2)(HotKey Select Mouse Wheel Down: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(146_3)(HotKey Select Mouse Wheel Down: Image Path)
  ; (147_1)(GUI Object: HotKey Select Mouse X1)_(147_2)(HotKey Select Mouse X1: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(147_3)(HotKey Select Mouse X1: Image Path)
  ; (148_1)(GUI Object: HotKey Select Mouse X2)_(148_2)(HotKey Select Mouse X2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(148_3)(HotKey Select Mouse X2: Image Path)
  ; (149_1)(GUI Object: HotKey Windows Key Left)_(149_2)(HotKey Windows Key Left: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(149_3)(HotKey Windows Key Left: Image Path)
  ; (150_1)(GUI Object: HotKey Windows Key Right)_(150_2)(HotKey Windows Key Right: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(150_3)(HotKey Windows Key Right: Image Path)
  ; (151_1)(GUI Object: HotKey Ctrl Key)_(151_2)(HotKey Ctrl Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(151_3)(HotKey Ctrl Key: Image Path)
  ; (152_1)(GUI Object: HotKey Alt Key)_(152_2)(HotKey Alt Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(152_3)(HotKey Alt Key: Image Path)
  ; (153_1)(GUI Object: HotKey Shift Key)_(153_2)(HotKey Shift Key: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)_(153_3)(HotKey Shift Key: Image Path)
  ; -------------------------------------------
  VarNumArray := [142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153]
  SubArrayLen := SubArray.MaxIndex()
  for Index, CheckKey in VarNumArray
  {
    Num := 0
    AddToArray := 1
    Loop %SubArrayLen%
    {
      Num := Num + 1
      if (CheckKey == SubArray[Num])
      {
        AddToArray := 0
      }
    }
    if (AddToArray == 1)
    {
      VarArray := Array_Add(VarArray, CheckKey, "End")
    }
  }
  ; -------------------------------------------
  IsSelected := 0
  ; -------------------------------------------
  for Index, VarNum in VarArray
  {
    SelectType := DataArray[VarNum][2]
    if (SelectType == 2 or SelectType == 3)
    {
      IsSelected := 1
      break
    } ; End (SelectType == 2 or SelectType == 3)
  }
  ; -------------------------------------------
  return IsSelected
  ; -------------------------------------------
}
