﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Time_Check(TimeMsg, DataArray) ; TimeType = ("0"/"End"), TimeMsg > DataArray
{
  ; -------------------------------------------
  if (TimeMsg == "End")
  {
    ; -------------------------------------------
    TimeArray := DataArray.200 ; (200_1)(End GUI Object)
    TimeArray_LastTime := TimeArray.1.1
    ; -------------------------------------------
    for Index, This_TimeArray in TimeArray
    {
      This_TimeArray_Time := This_TimeArray.1
      This_TimeArray_Time := This_TimeArray_Time - TimeArray_LastTime
      This_TimeArray_Msg := This_TimeArray.2
      if (Index == 1)
      {
        Msg := Msg This_TimeArray_Msg "`n"
      }
      else
      {
        Msg := Msg This_TimeArray_Msg " = " This_TimeArray_Time "`n"
      }
      TimeArray_LastTime := This_TimeArray.1
    }
    ; -------------------------------------------
    Msg := Msg "`n"
    ; -------------------------------------------
    TimeArray_StartTime := TimeArray.1.1
    TimeArray_EndTime := A_TickCount - TimeArray_StartTime
    ; -------------------------------------------
    Msg := Msg "End Time = " TimeArray_EndTime "`n"
    Tooltip, %Msg%, 0, 0
    Msg := ""
    DataArray.200 := "" ; (200_1)(End GUI Object)
  }
  else
  {
    ; -------------------------------------------
    TimeArray := DataArray.200 ; (200_1)(End GUI Object)
    ; -------------------------------------------
    TimeArray_ThisTime  := A_TickCount
    This_TimeArray := [TimeArray_ThisTime, TimeMsg]
    TimeArray := Array_Add(TimeArray, This_TimeArray, "End") ; ThisArray, AddThis, ThisPos > ThisArray
    DataArray.200 := TimeArray ; (200_1)(End GUI Object)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
