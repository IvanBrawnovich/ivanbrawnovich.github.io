﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Icon Image
; -------------------------------------------
f_063(DataArray) ; (063_1)(GUI Object: Select Icon Image)
{
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
  ; -------------------------------------------
  PicturesDir := Find_Windows_Public_Folder("Pictures", 0)
  ; -------------------------------------------
  { ; Language Set DialogText [SET] DialogText := "PUM - Select Shortcut Image"
    ; -------------------------------------------
    if (v_365_2 == "de") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Shortcut Bild auswählen"
    } ; End (de German)
    ; -------------------------------------------
    else if (v_365_2 == "en") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Select Shortcut Image"
    } ; End (en English)
    ; -------------------------------------------
    else if (v_365_2 == "es") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Seleccionar imagen de acceso directo"
    } ; End (es Spanish)
    ; -------------------------------------------
    else if (v_365_2 == "fr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Sélectionnez Shortcut Image"
    } ; End (fr French)
    ; -------------------------------------------
    else if (v_365_2 == "it") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Seleziona immagine di scelta rapida"
    } ; End (it Italian)
    ; -------------------------------------------
    else if (v_365_2 == "pl") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Wybierz obraz skrótu"
    } ; End (pl Polish)
    ; -------------------------------------------
    else if (v_365_2 == "pt") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Selecione imagem de atalho"
    } ; End (pt Portuguese)
    ; -------------------------------------------
    else if (v_365_2 == "ru") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Выберите изображение ярлыка"
    } ; End (ru Russian)
    ; -------------------------------------------
    else if (v_365_2 == "sv") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Välj genvägsbild"
    } ; End (sv Swedish)
    ; -------------------------------------------
    else if (v_365_2 == "tr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Kısayol Görüntüsünü Seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End Language Set DialogText
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  FileSelectFile, ThisFile, 3, %PicturesDir%, %DialogText%, Icons Documents (*.ico; *.svg; *.gif; *.bmp; *.jpeg; *.jpg; *.png; *.webp; *.tiff; *.tif; *.exe)
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if ThisFile
  {
    ; -------------------------------------------
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, ThisFile , NameIco, , ThisExt
    StringLower, ThisExt, ThisExt
    ; -------------------------------------------
    if (ThisExt == "ico") ; Selected ThisFile is a Ico
    {
      ; -------------------------------------------
      ; Selected ThisFile is a Ico
      ; -------------------------------------------
      DataArray := f_102(ThisFile, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
      GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
    } ; End if (ThisExt == "ico")
    ; -------------------------------------------
    else if (NameIco != "PopUpMenu.png" && ThisExt == "svg" or ThisExt == "gif" or ThisExt == "bmp" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "webp" or ThisExt == "tiff" or ThisExt == "tif")
    {
      ; -------------------------------------------
      ; Selected ThisFile is a Image
      ; -------------------------------------------
      DataArray.102.3 := ThisFile ; (102_3)(Main Display Icon: Image Path)
      ; -------------------------------------------
      ; (368_3)(Convert Image To Icon) = 1 | Convert to ico
      ; (368_3)(Convert Image To Icon) = 0 | Convert to for Pum Background Image
      ; -------------------------------------------
      DataArray := Convert_ToIco(DataArray) ; this Function runs f _ 102
      ; -------------------------------------------
    } ; End else if (NameIco != "PopUpMenu.png" && ThisExt == "svg" or ThisExt == "gif" or ThisExt == "bmp" or ThisExt == "jpeg" or ThisExt == "jpg" or ThisExt == "png" or ThisExt == "webp" or ThisExt == "tiff" or ThisExt == "tif")
    ; -------------------------------------------
    else if(ThisExt == "exe")
    {
      ; -------------------------------------------
      DataArray.307.2 := ThisFile ; (307_2)([url] Current URL)
      DataArray.102.3 := "" ; (102_3)(Main Display Icon: Image Path)
      DataArray := Extract_Icons_From_File(DataArray)
      ; -------------------------------------------
    } ; End (ThisExt == "exe")
    ; -------------------------------------------
  } ; End if ThisFile
  ; -------------------------------------------        
  return DataArray
  ; -------------------------------------------
}
