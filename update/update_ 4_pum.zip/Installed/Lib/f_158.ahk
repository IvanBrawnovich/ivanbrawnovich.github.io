﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_158(DataArray) ; (158_1)(GUI Object: [pum] Pum Shortcut)
{
  ; -------------------------------------------
  v_158_2 := DataArray.158.2 ; (158_2)([pum] Pum Shortcut: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_158_2 == "") ; (158_2)([pum] Pum Shortcut: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_158_2 := 1 ; (158_2)([pum] Pum Shortcut: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_158_2 == 1) ; (158_2)([pum] Pum Shortcut: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSho" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
