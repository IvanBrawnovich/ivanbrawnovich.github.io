﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_168(DataArray) ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
{
  ; -------------------------------------------
  v_168_2 := DataArray.168.2 ; (168_2)([pum] Backgroung Image Chop: [0]Hide/[1]Nor/[2]Sel)
  ; -------------------------------------------
  if (v_168_2 == "") ; (168_2)([pum] Backgroung Image Chop: [0]Hide/[1]Nor/[2]Sel)
  {
    v_168_2 := 1 ; (168_2)([pum] Backgroung Image Chop: [0]Hide/[1]Nor/[2]Sel)
  }
  ; -------------------------------------------
  if (v_168_2 == 1) ; (168_2)([pum] Backgroung Image Chop: [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumBG_pumImg_pumCho" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
