﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_083(DataArray) ; (083_1)(GUI Object: [ToM] Pum)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_083", DataArray) ; (083_1)(GUI Object: [ToM] Pum)
  ; -------------------------------------------
  v_083_2 := DataArray.83.2 ; (083_2)([ToM] Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  if (v_083_2 == 1) ; (083_2)([ToM] Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum" ; (366_5)(Script Type)
    ; -------------------------------------------
    { ; Quick Select/UnSelect
      ; -------------------------------------------
      DataArray := GuiControlImage_PopUpMenu("084", 1, 1, DataArray) ; (084_1)(GUI Object: [ToM] File Url Folder)
      DataArray := GuiControlImage_PopUpMenu("086", 1, 1, DataArray) ; (086_1)(GUI Object: [ToM] Menu Control Key)
      DataArray := GuiControlImage_PopUpMenu("083", 2, 1, DataArray) ; (083_1)(GUI Object: [ToM] Pum)
      ; -------------------------------------------
    } ; End Quick Select/UnSelect
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
  } ; (083_2)([ToM] Pum: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
