﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Reset_Vars(DataArray) ; > DataArray
{
  ; -------------------------------------------
  if (DataArray.361.17 == 0) ; (361_17)(LButton Was Clicked [0/1])
  {
    Num := 1
    while (Num < 165)
    {
      if (Num != 124)
      {
        DataArray[Num][2] := ""
        DataArray[Num][3] := ""
      }
      Num := Num + 1
    }
  }
  ; -------------------------------------------
  ; 
  DataArray.300.2 := 0 ; (300_2)([cpl] Menu Number #_X_[X])
  DataArray.300.3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
  DataArray.300.4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
  ;
  DataArray.301.2 := "" ; (301_2)([key] KeyArray_Numbers [Array])
  DataArray.301.7 := "" ; (301_7)([key] KeyArray_Display [String] [by Lang])
  DataArray.301.8 := "" ; (301_8)([key] KeyArray_Shortcut [Array])
  ;
  DataArray.302.2 := 0 ; (302_2)([mnu] Menu Number #_X_X_[X])
  DataArray.302.3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
  DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
  DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
  DataArray.302.6 := 0 ; (302_6)([mnu] Menu Size [#])
  ;
  DataArray.307.2 := "" ; (307_2)([url] Current URL)
  DataArray.307.8 := "" ; (307_8)([url] Previous URL)
  ;
  DataArray.361.10 := "" ; (361_10)(Pum toolbox0.xml [Array])
  DataArray.361.15 := "" ; (361_15)(Pum Folder Name  [NO Path][NO (pum_)][NO Ext])
  ;
  DataArray.366.5  := "" ; (366_5)(Script Type)
  ;
  DataArray.370.4  := "" ; (370_4)(XML_SC_L1 [TextColor])
  DataArray.370.5  := "" ; (370_5)(XML_SC_L1 [TextAlign])
  DataArray.370.6  := "" ; (370_6)(XML_SC_L1 [ParaAlign])
  DataArray.370.7  := "" ; (370_7)(XML_SC_L1 [Type])
  DataArray.370.8  := "" ; (370_8)(XML_SC_L2 Script [Full File Path])
  DataArray.370.9  := "" ; (370_9)(XML_SC_L2 Old Script [Full File Path])
  DataArray.370.10 := "" ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
  ; -------------------------------------------    
  return DataArray
  ; -------------------------------------------
} ; End Reset_Vars(DataArray) ; > DataArray
