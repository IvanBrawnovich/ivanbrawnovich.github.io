﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_167(DataArray) ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
{
  ; -------------------------------------------
  v_167_2 := DataArray.167.2 ; (167_2)([pum] Backgroung Image Fit: [0]Hide/[1]Nor/[2]Sel)
  ; -------------------------------------------
  if (v_167_2 == "") ; (167_2)([pum] Backgroung Image Fit: [0]Hide/[1]Nor/[2]Sel)
  {
    v_167_2 := 1 ; (167_2)([pum] Backgroung Image Fit: [0]Hide/[1]Nor/[2]Sel)
  }
  ; -------------------------------------------
  if (v_167_2 == 1) ; (167_2)([pum] Backgroung Image Fit: [0]Hide/[1]Nor/[2]Sel)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumBG_pumImg_pumFit" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
