﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Pum_Close() ; > Nothing
{
  ; -------------------------------------------
  Script_Dir := A_ScriptDir
  if (InStr(Script_Dir, "\Lib") == 0)
  {
    Script_Dir := Script_Dir "\Lib"
  }
  Disable_Persistent := Script_Dir "\Disable_Persistent.ahk"
  Disable_Gui        := Script_Dir "\Disable_Gui.ahk"
  Disable_KeyGui     := Script_Dir "\Disable_KeyGui.ahk"
  ; -------------------------------------------
  if WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; Keep Shortcut Gui Active
  {
    ; -------------------------------------------
    Gui, PopUpMenu:Destroy
    ; -------------------------------------------
    Script_Close(Disable_Persistent)
    Script_Close(Disable_Gui)
    Script_Close(Disable_KeyGui)
    Run, %Disable_KeyPum%
    ; -------------------------------------------
    WinSet, Enable ,, ahk_class TfrmToolbox
    WinSet, AlwaysOnTop, On, ahk_class TfrmToolbox
    ; -------------------------------------------
  }
  else if WinExist("ahk_class TfrmToolbox") ; Close Any PUM
  {
    ; -------------------------------------------
    Pc_TxtFile_ActiveApp  := A_AppDataCommon "\PopUpMenu_PUM\system\Active_App.txt"
    FileDelete, %Pc_TxtFile_ActiveApp%
    ; -------------------------------------------
    WinGet, PumProcess, ProcessName, ahk_class TfrmToolbox
    ; -------------------------------------------
    IfInString, PumProcess, pum_
    {
      Process, Close, %PumProcess%
    } ; End IfInString, PumProcess, pum_
  } ; End WinExist("ahk_class TfrmToolbox") 
} ; End Pum_Close`
