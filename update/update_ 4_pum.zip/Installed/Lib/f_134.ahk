﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_134(DataArray) ; (134_1)(GUI Object: Message Image 1)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_134", DataArray) ; (134_1)(GUI Object: Message Image 1)
  ; -------------------------------------------
  ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
  ; -------------------------------------------
  if (DataArray.366.6 != 17)  ; (366_6)(This Script Error [Integer])
  {
    if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(Script Type)
    {
      DataArray := f_087(DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
    }
    else if (DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(Script Type)
    {
      DataArray := f_081(DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
    }
  } ; End [ScriptError == 17]
  return DataArray
  ; -------------------------------------------
}
