﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; Select Open With Application
; -------------------------------------------
f_068(DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_068", DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
    ; -------------------------------------------
    v_305_4 := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    v_305_6 := DataArray.305.6 ; (305_6)([rwh] Default Application [Full File Path])
    v_307_6 := DataArray.307.6 ; (307_6)([url] Default Browser [Full File Path])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  { ; Select File Start In Folder
    InstalledPrograms := A_ProgramsCommon ; Common Start Menu
    IfNotExist, %InstalledPrograms%
    {
      InstalledPrograms := A_Programs ; User Spicifc Start Menu
      IfNotExist, %InstalledPrograms%
      {
        InstalledPrograms := A_ProgramFiles ; Installed Programs Directory
        IfNotExist, %InstalledPrograms%
        {
          InstalledPrograms := A_WinDir
        } ; End IfNotExist, %InstalledPrograms%
      } ; End IfNotExist, %InstalledPrograms%
    } ; End IfNotExist, %InstalledPrograms%
  } ; End Select File Start In Folder
  ; -------------------------------------------
  { ; Language Set DialogText [SET] DialogText := "PUM - Application to Open this File"
    ; -------------------------------------------
    if (v_365_2 == "de") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Anwendung zum Öffnen dieser Datei"
    } ; End (de German)
    ; -------------------------------------------
    else if (v_365_2 == "en") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Application to Open this File"
    } ; End (en English)
    ; -------------------------------------------
    else if (v_365_2 == "es") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Aplicación para abrir este archivo"
    } ; End (es Spanish)
    ; -------------------------------------------
    else if (v_365_2 == "fr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Application pour ouvrir ce fichier"
    } ; End (fr French)
    ; -------------------------------------------
    else if (v_365_2 == "it") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Applicazione per aprire questo file"
    } ; End (it Italian)
    ; -------------------------------------------
    else if (v_365_2 == "pl") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Aplikacja do otwarcia tego pliku"
    } ; End (pl Polish)
    ; -------------------------------------------
    else if (v_365_2 == "pt") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Aplicativo para abrir este arquivo"
    } ; End (pt Portuguese)
    ; -------------------------------------------
    else if (v_365_2 == "ru") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Приложение для открытия этого файла"
    } ; End (ru Russian)
    ; -------------------------------------------
    else if (v_365_2 == "sv") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Program för att öppna den här filen"
    } ; End (sv Swedish)
    ; -------------------------------------------
    else if (v_365_2 == "tr") ; (365_2)(Current User language)
    {
      DialogText := "PUM - Bu Dosyayı Açmak İçin Başvuru"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End Language Set DialogText [SET] DialogText := "PUM - Application to Open this File"
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  FileSelectFile, ThisSelected, 3, %InstalledPrograms%, %DialogText%, ; (305_5)(Selected Opening Application [Full File Path])
  ; -------------------------------------------
  if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , A
    WinSet, AlwaysOnTop, On, ahk_id %Gui_Id%
    ; -------------------------------------------
  }
  ; -------------------------------------------
  IfInString, ThisSelected, %A_ScriptDir% ; (305_5)(Selected Opening Application [Full File Path])
  {
    ThisSelected := ""
  } ; End IfInString, ThisFile, %A_ScriptDir%
  ; -------------------------------------------
  if ThisSelected ; (305_5)(Selected Opening Application [Full File Path])
  {
    ; -------------------------------------------
    ; (Value) (Modify)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, ThisSelected, , , FileExt ; (305_5)(Selected Opening Application [Full File Path])
    StringLower, FileExt, FileExt
    ; -------------------------------------------
    if (FileExt == "lnk")
    {
      FileGetShortcut, %ThisSelected%, ThisSelected ; (305_5)(Selected Opening Application [Full File Path])
    }
    ; -------------------------------------------
    if (FileExt == "exe")
    {
      if (DataArray.366.5 == "rwh") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        v_305_5 := ThisSelected ; (305_5)([rwh] Selected Opening Application [Full File Path])
        DataArray.305.5 := v_305_5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
        ; -------------------------------------------
        if (v_305_5 == v_305_6) ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_6)([rwh] Default Application [Full File Path])
        {
          ; 1 = Is Use Default
          DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
        }
        else
        {
          ; 0 = DO NOT Use Default
          DataArray.305.8 := 0 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
        }
      }
      ; -------------------------------------------
      else if (DataArray.366.5 == "url") ; (366_5)(Script Type)
      {
        ; -------------------------------------------
        v_307_5 := ThisSelected ; (307_5)([url] Selected Opening Browser [Full File Path])
        DataArray.307.5 := v_307_5 ; (307_5)([url] Selected Opening Browser [Full File Path])
        ; -------------------------------------------
        if (v_307_5 == v_307_6) ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_6)([url] Default Browser [Full File Path])
        {
          ; 1 = Is Use Default
          DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
        }
        else
        {
          ; 0 = DO NOT Use Default
          DataArray.307.7 := 0 ; (307_7)([url] Use Default Browser [0/1])
        }
      }
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
    }
    else
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; (430_1)(Splash Error File: Not a Application)
      ; (430_1)(Splash Error Image File: Not a Application)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    }
    ; -------------------------------------------
  } ; End if ThisFile
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
