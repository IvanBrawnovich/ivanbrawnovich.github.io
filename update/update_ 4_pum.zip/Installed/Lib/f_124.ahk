﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_124(DataArray) ; (124_1)(GUI Object: <Drop Down List> Language)
{
  ; -------------------------------------------
  v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
  v_381_2 := DataArray.381.2 ; (381_2)(User Language Text File [User Text File Path])
  v_386_9 := DataArray.386.9 ; (386_9)(Language Flag Image [Folder Path])
  ; -------------------------------------------
  GuiControlGet, v_124, PopUpMenu:, g_124 ; (124_1)(GUI Object: <Drop Down List> Language)
  LangListBox := DataArray.124.3 ; (124_3)(<Drop Down List> Language: List Box)
  LangArray  := StrSplit(LangListBox, "|", "")
  LangArray.RemoveAt(1)
  ; -------------------------------------------
  v_365_4 := DataArray.365.4 ; (365_4)(Language List [Array])
  for Index, This_Lang in LangArray
  {
    if (This_Lang == v_124) ; (124_1)(GUI Object: <Drop Down List> Language)
    {
      v_365_2 := v_365_4[Index] ; (365_2)(Current User language)/(365_4)(Language List [Array])
      v_365_3 := Index ; (365_3)(Language List Number [Integer])
    }
  }
  DataArray.365.2 := v_365_2 ; (365_2)(Current User language)
  DataArray.365.3 := v_365_3 ; (365_3)(Language List Number [Integer])
  ; -------------------------------------------
  ThisImage := v_386_9 "\" v_365_2 ".png" ; (386_9)(Language Flag Image [Folder Path])/(365_2)(Current User language)
  if (DataArray.101.3 != ThisImage) ; (101_3)(Language Flag: Image Path)
  {
    DataArray.101.3 := ThisImage ; (101_3)(Language Flag: Image Path)
    GuiControl, PopUpMenu:, g_101, %ThisImage% ; (101_1)(GUI Object: Language Flag)
    GuiControl, PopUpMenu:MoveDraw, g_101, +w94 +h23 ; (101_1)(GUI Object: Language Flag)
    GuiControl, PopUpMenu:Show, g_102 ; (102_1)(GUI Object: Main Display Icon)
  }
  ; -------------------------------------------
  if FileExist(v_381_2) ; (381_2)(User Language Text File [User Text File Path])
  {
    FileDelete, %v_381_2% ; (381_2)(User Language Text File [User Text File Path])
  } ; (370_7)(User Language Text File)
  FileAppend, %v_365_2%`n, %v_381_2%, UTF-8 ; (365_2)(Current User language)/(381_2)(User Language Text File [User Text File Path])
  ; -------------------------------------------
  if (v_366_5 == "key") ; (366_5)(Script Type)
  {
    if (DataArray.301.2.1 != "") ; (301_2)([key] KeyArray_Numbers [Array])
    {
      ; -------------------------------------------
      ; Creates
      ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Display(DataArray) ; > DataArray
      DataArray.451.1 := "123" ; (451_1)(Error Fix Skip This Var)
      ; -------------------------------------------
    }
  }
  ; -------------------------------------------
  GuiControl, PopUpMenu:Choose, g_124, %v_365_3% ; (365_3)(Language List Number [Integer])/(124_1)(GUI Object: <Drop Down List> Language)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
