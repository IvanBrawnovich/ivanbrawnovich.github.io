﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_016(DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_016", DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("016", DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
