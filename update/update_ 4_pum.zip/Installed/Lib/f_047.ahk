﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_047(DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_047", DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("047", DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
