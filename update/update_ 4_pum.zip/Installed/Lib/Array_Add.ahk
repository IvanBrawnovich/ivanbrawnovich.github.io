﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Array_Add(ThisArray, AddThis, ThisPos) ; ThisArray, AddThis, ThisPos > ThisArray
{
  ; -------------------------------------------
  if !ThisPos
  {
    ThisPos := "End"
  }
  ; -------------------------------------------
  if AddThis
  {
    CheckThis := ThisArray[1]
    if CheckThis
    {
      if (ThisPos == "End")
      {
        ThisArray.Push(AddThis) ; Adds (AddThis) to End
      }
      else
      {
        if (ThisPos == 0)
        {
          ThisPos := 1
        }
        ThisArray.InsertAt(ThisPos, AddThis) ; Adds (AddThis) at (ThisPos)
      }
    } ; End if CheckThis
    else
    {
      ThisArray := []
      ThisArray[1] := AddThis
    } ; End else
  } ; End if AddThis
  return ThisArray
}
