﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
/*
All Images (Except WebAddress.png)
(xxx)_#_xx.png
(xxx) = DataArray Number
# = (1 = Normal, Enable, Default) (2 = Selected, Reset Default) (3 = Warning, Disabled)
; -------------------------------------------
SelectType = 0
(GuiControl, PopUpMenu:Hide, g_%GuiVarNum%)
SelectType = 1,2,3
(GuiControl, PopUpMenu:, g_%GuiVarNum%, %VarNum%)
(GuiControl, PopUpMenu:Show, g_%GuiVarNum%)
*/
; -------------------------------------------
GuiControlImage_PopUpMenu(VarNum, SelectType, HasLanguage, DataArray) ; > DataArray
{
  ; -------------------------------------------
  DataArray := Function_Flow("GuiControl_Image", DataArray)
  ; -------------------------------------------
  if (VarNum != "" or SelectType != "" or HasLanguage != "")
  {
    ; -------------------------------------------
    GuiVarNum := VarNum
    GuiVarNum := StrReplace(GuiVarNum, "_cpl", "")
    GuiVarNum := StrReplace(GuiVarNum, "_key", "")
    GuiVarNum := StrReplace(GuiVarNum, "_mnu", "")
    GuiVarNum := StrReplace(GuiVarNum, "_ofl", "")
    GuiVarNum := StrReplace(GuiVarNum, "_run", "")
    GuiVarNum := StrReplace(GuiVarNum, "_rwh", "")
    GuiVarNum := StrReplace(GuiVarNum, "_url", "")
    GuiVarNum := StrReplace(GuiVarNum, "_pum", "")
    ; -------------------------------------------
    DataVarNum := GuiVarNum
    ; -------------------------------------------
    if (SubStr(DataVarNum, 1, 1) == "0") ; 00# Remove 0's
    {
      DataVarNum := SubStr(DataVarNum, 2)
    }
    if (SubStr(DataVarNum, 1, 1) == "0") ; 0# Remove 0's
    {
      DataVarNum := SubStr(DataVarNum, 2)
    }
    ; -------------------------------------------
    DataArray[DataVarNum][2] := SelectType ; [SET] DataArray to SelectType
    ; -------------------------------------------
    if (SelectType == 0)
    {
      DataArray[DataVarNum][3] := ""
      GuiControl, PopUpMenu:Hide, g_%GuiVarNum%
    }
    else if (SelectType == 1 or SelectType == 2 or SelectType == 3)
    {
      ; -------------------------------------------
      v_363_5 := DataArray.363.5 ; (363_5)(PC Installed Dir)
      v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
      v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      v_386_3 := DataArray.386.3 ; (386_3)(Addons [System Folder Path])
      v_302_6 := DataArray.302.6 ; (302_6)([mnu] Menu Size [#])
      ; -------------------------------------------
      ; (140_1)(GUI Object: [mnu] Addon Extra)
      if (DataVarNum == 140)
      {
        ; -------------------------------------------
        VarValue := v_386_3 "\" v_367_2 "\(" VarNum ")_" SelectType "_" v_365_2 ".png" ; (386_3)(Addons [System Folder Path])/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(365_2)(Current User language)
        ; -------------------------------------------
      }
      ; (088)-(098)([mnu] App Context Menu 1-11)
      else if (DataVarNum == 88 or DataVarNum == 89 or DataVarNum == 90 or DataVarNum == 91 or DataVarNum == 92 or DataVarNum == 93 or DataVarNum == 94 or DataVarNum == 95 or DataVarNum == 96 or DataVarNum == 97 or DataVarNum == 98)
      {
        ; -------------------------------------------
        VarValue := v_386_3 "\" v_367_2 "\" v_365_2 "\img\(" VarNum ")_" SelectType "_" v_302_6 "_" v_365_2 ".png" ; (386_3)(Addons [System Folder Path])/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(302_6)([mnu] Menu Size [#])/(365_2)(Current User language)
        ; -------------------------------------------
      } ; End (088)-(098)([mnu] App Context Menu 1-11)
      ; -------------------------------------------
      else if (HasLanguage == 0)
      {
        ; -------------------------------------------
        VarValue := v_363_5 "\img\imgkey\(" VarNum ")_" SelectType ".png" ; (363_5)(PC Installed Dir)
        ; -------------------------------------------
      }
      else if (HasLanguage == 1)
      {
        ; -------------------------------------------
        VarValue := v_363_5 "\img\imgkey\(" VarNum ")_" SelectType "_" v_365_2 ".png" ; (363_5)(PC Installed Dir)/(365_2)(Current User language)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      CurrentValue := DataArray[DataVarNum][3]
      if (CurrentValue == "")
      {
        ChangeValue := 1
      }
      else if (CurrentValue != VarValue)
      {
        ChangeValue := 1
      }
      ; -------------------------------------------
      if FileExist(VarValue)
      {
        if (ChangeValue == 1)
        {
          DataArray[DataVarNum][3] := VarValue
          GuiControl, PopUpMenu:, g_%GuiVarNum%, %VarValue%
        }
      }
      GuiControl, PopUpMenu:Show, g_%GuiVarNum%
      ; -------------------------------------------
    } ; End (SelectType == 1 or SelectType == 2 or SelectType == 3)
  } ; End (VarNum != "" or SelectType != "" or HasLanguage != "")
  else
  {
    ; -------------------------------------------
    if (VarNum == "")
    {
      Msg := Msg "VarNum is Blank`n"
    }
    else if (SelectType == "")
    {
      Msg := Msg "SelectType is Blank`n"
    }
    else if (HasLanguage == "")
    {
      Msg := Msg "HasLanguage is Blank`n"
    }
    MsgBox, 262144, , %Msg% , 3
    Msg := ""
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
      
