﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Unicode_To_String(ThisCode) ; "{U+xxxx}" > String
{
  ; -------------------------------------------
  Return_String := ""
  ; -------------------------------------------
  Num := 1
  Pos_S := InStr(ThisCode, "{" , , , Num)
  while (Pos_S > 0)
  {
    Pos_E := InStr(ThisCode, "}" , , , Num)
    Pos_Len := Pos_E - Pos_S
    Pos_Len := Pos_Len + 1
    Single_Code := SubStr(ThisCode, Pos_S, Pos_Len)
    Code_Array := Array_Add(Code_Array, Single_Code, ThisPos) ; ThisArray, AddThis, ThisPos > ThisArray
    Num := Num + 1
    Pos_S := InStr(ThisCode, "{" , , , Num)
  }
  ThisArrayLen := Code_Array.MaxIndex()
  for Index, Single_Code in Code_Array
  {
    New_StrLen := StrLen(Single_Code)
    Loop, % StrLen(Single_Code) / New_StrLen
    {
    	vNum := "0x" SubStr(Single_Code, A_Index*New_StrLen-4, 4), Return_String .= Chr(vNum)
    }
  }
  return Return_String
}
