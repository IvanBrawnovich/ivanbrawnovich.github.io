﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_069(DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_069", DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
  ; -------------------------------------------
  v_069_2 := DataArray.69.2 ; (069_2)([rwh][url] Open With App Reset: Select [0]Hide/[1]Default/[2]Reset Default)
  ; -------------------------------------------
  if (v_069_2 == 2) ; (069_2)([rwh][url] Open With App Reset: Select [0]Hide/[1]Default/[2]Reset Default)
  {
    ; -------------------------------------------
    ; Reset to Default
    ; -------------------------------------------
    if (DataArray.366.5 == "rwh") ; (366_5)(Script Type)
    {
      ; -------------------------------------------
      ; 1 = Is Use Default
      DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
      DataArray.305.5 := DataArray.305.6 ; (305_5)([rwh] Selected Opening Application [Full File Path])/(305_6)([rwh] Default Application [Full File Path])
      ; -------------------------------------------
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (rwh)
    else if (DataArray.366.5 == "url") ; (366_5)(Script Type)
    {
      ; -------------------------------------------
      ; 1 = Is Use Default
      DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
      DataArray.307.5 := DataArray.307.6 ; (307_5)([url] Selected Opening Browser [Full File Path])/(307_6)([url] Default Browser [Full File Path])
      ; -------------------------------------------
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (url)
    ; -------------------------------------------
  } ; End (069_2) = 2
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
