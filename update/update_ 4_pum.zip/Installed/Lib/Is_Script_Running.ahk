﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Is_Script_Running(ScriptPath)
{
  ; -------------------------------------------
  ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ScriptPath, , ,  , ThisScript
  ; -------------------------------------------
  
  ScriptRunning := 0
  DetectHiddenWindows, On
  WinGet, ahk_list, List, ahk_class AutoHotkey
  ; -------------------------------------------
  Loop % ahk_list
  {
    ; -------------------------------------------
    WinGetTitle, ahk_win, % "ahk_id" ahk_list%A_Index%
    RegExMatch(ahk_win,"^.*?\.ahk",m)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, m, AhkName
    StringLower, AhkName, AhkName
    ; -------------------------------------------
    Check_AhkName := AhkName
    Check_AhkName := StrReplace(Check_AhkName, ".ahk", "")
    StringLower, ThisScript, ThisScript
    StringLower, Check_AhkName, Check_AhkName
    if (Check_AhkName == ThisScript)
    {
      ScriptRunning := ScriptRunning + 1
      break
    } ; End (AhkName == ThisScript)
    ; -------------------------------------------
  } ; End Loop % ahk_list
  ; -------------------------------------------
  return ScriptRunning
}
