﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
Send_Email(Email_Subject, Email_Body, AttachFile)
{
  ; -------------------------------------------
  pmsg := ComObjCreate("CDO.Message")
  ; -------------------------------------------
  pmsg.From := """PopUpMenu AutoHotKey"" <popupmenu_autohotkey@yahoo.com>"
  ;~ pmsg.From := """PopUpMenu AutoHotKey"" <popupmenu_autohotkesdSdADADSDy@yahoo.com>"
  pmsg.To   := "popupmenu@yahoo.com"
  ; -------------------------------------------
  pmsg.BCC  := ""
  pmsg.CC   := ""
  ; -------------------------------------------
  pmsg.Subject  := Email_Subject
  pmsg.TextBody := Email_Body
  sAttach       := AttachFile
  ; -------------------------------------------
  fields := Object()
  ; -------------------------------------------
  fields.smtpserver            := "smtp.mail.yahoo.com" ; specify your SMTP server
  fields.smtpserverport        := 465 ; 25
  fields.smtpusessl            := True ; True (otherwise it will Lock Up)
  fields.sendusing             := 2   ; cdoSendUsingPort
  fields.smtpauthenticate      := 1   ; cdoBasic
  ; -------------------------------------------
  ;~ fields.sendusername          := "popupmenu@yahoo.com"
  ;~ fields.sendpassword          := "vdkp fywf zhbd ivix" ; popupmenu@yahoo.com
  ; -------------------------------------------
  fields.sendusername          := "popupmenu_autohotkey@yahoo.com"
  fields.sendpassword          := "wtre wgpy tmlo hhwn" ; popupmenu_autohotkey@yahoo.com
  ; -------------------------------------------
  
  fields.smtpconnectiontimeout := 60
  schema := "http://schemas.microsoft.com/cdo/configuration/"
  ; -------------------------------------------
  pfld := pmsg.Configuration.Fields
  
  ; -------------------------------------------
  for field,value in fields
  {
    pfld.Item(schema . field) := value
  }
  ; -------------------------------------------
  pfld.Update()
  ; -------------------------------------------
  Loop, Parse, AttachFile, |, %A_Space%%A_Tab%
  {
    pmsg.AddAttachment(A_LoopField)
  }
  ; -------------------------------------------
  pmsg.Send()
  ; -------------------------------------------
  if (ErrorLevel != 0)
  {
    Return_Value := 0
  }
  else
  {
    Return_Value := 1
  }
  ; -------------------------------------------
  return Return_Value
}
