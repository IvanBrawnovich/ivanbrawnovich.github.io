﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
/*
  LimitedArray := [["v_072_1"], ["v_141_1"]] ; (072_1)(GUI Object: [key] Application Only)/(141_1)(GUI Object: <Displayed Text> Title 3)
  DataArray.363.9 := LimitedArray ; (363_9)(Limited DataArray)
*/
_S2_H(DataArray)
{
  ; -------------------------------------------
  /*
  FontColor := "199524" ; (Green)
  FontColor := "a30404" ; (Red)
  FontColor := "000000" ; (Black)
  FontColor := "921297" ; (Purple)
  */
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  { ; Start Up Vars
    ; -------------------------------------------
    v_302_6 := DataArray.302.6 ; (302_6)([mnu] Menu Size [#])
    v_370_8 := DataArray.370.8 ; (370_8)(XML_SC_L2 Script [Full File Path])
    v_366_6 := DataArray.366.6 ; (366_6)(This Script Error [Integer])
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    v_367_3 := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; (363_9)(Limited DataArray)
  ; -------------------------------------------
  LimitedArray := DataArray.363.9 ; (363_9)(Limited DataArray)
  if (LimitedArray == "")
  {
    LimitedArray := DataArray
  }
  ; -------------------------------------------
  for Index, ThisItem in LimitedArray
  {
    ; -------------------------------------------
    ThisItem := ThisItem.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (ThisItem == "GuiVarEnd")
    {
      break
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_001_1") ; (001_1)(GUI Object: [run][rwh] First App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("001", 0, 0, DataArray) ; (001_1)(GUI Object: [run][rwh] First App Icon)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("001", 0, 0, DataArray) ; (001_1)(GUI Object: [run][rwh] First App Icon)
      }
    } ; (001_1)(GUI Object: [run][rwh] First App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_002_1") ; (002_1)(GUI Object: [run][rwh] Second App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("002", 0, 0, DataArray) ; (002_1)(GUI Object: [run][rwh] Second App Icon)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("002", 0, 0, DataArray) ; (002_1)(GUI Object: [run][rwh] Second App Icon)
      }
    } ; (002_1)(GUI Object: [run][rwh] Second App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_003_1") ; (003_1)(GUI Object: [run][rwh] Third App Icon)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("003", 0, 0, DataArray) ; (003_1)(GUI Object: [run][rwh] Third App Icon)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("003", 0, 0, DataArray) ; (003_1)(GUI Object: [run][rwh] Third App Icon)
      }
    } ; (003_1)(GUI Object: [run][rwh] Third App Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_005_1") ; (005_1)(GUI Object: Icon Rotate Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (DataArray.4.2 == 3) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("005", 0, 0, DataArray) ; (005_1)(GUI Object: Icon Rotate Left)
      }      
    } ; (005_1)(GUI Object: Icon Rotate Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_006_1") ; (006_1)(GUI Object: Icon Rotate Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (DataArray.4.2 == 3) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("006", 0, 0, DataArray) ; (006_1)(GUI Object: Icon Rotate Right)
      }
    } ; (006_1)(GUI Object: Icon Rotate Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_007_1") ; (007_1)(GUI Object: Icon Image 4)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("007", 0, 0, DataArray) ; (007_1)(GUI Object: Icon Image 4)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("007", 0, 0, DataArray) ; (007_1)(GUI Object: Icon Image 4)
      }
    } ; (007_1)(GUI Object: Icon Image 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_008_1") ; (008_1)(GUI Object: [key] Alt)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("008", 0, 0, DataArray) ; (008_1)(GUI Object: [key] Alt)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("008", 0, 0, DataArray) ; (008_1)(GUI Object: [key] Alt)
      }
    } ; (008_1)(GUI Object: [key] Alt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_009_1") ; (009_1)(GUI Object: [key] Alt Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("009", 0, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("009", 0, 0, DataArray) ; (009_1)(GUI Object: [key] Alt Down)
      }
    } ; (009_1)(GUI Object: [key] Alt Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_010_1") ; (010_1)(GUI Object: [key] Alt Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("010", 0, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("010", 0, 0, DataArray) ; (010_1)(GUI Object: [key] Alt Left)
      }
    } ; (010_1)(GUI Object: [key] Alt Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_011_1") ; (011_1)(GUI Object: [key] Alt Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("011", 0, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("011", 0, 0, DataArray) ; (011_1)(GUI Object: [key] Alt Right)
      }
    } ; (011_1)(GUI Object: [key] Alt Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_012_1") ; (012_1)(GUI Object: [key] Alt Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("012", 0, 0, DataArray) ; (012_1)(GUI Object: [key] Alt Up)
      }
    } ; (012_1)(GUI Object: [key] Alt Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_013_1") ; (013_1)(GUI Object: [key] Caps Lock)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("013", 0, 0, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("013", 0, 0, DataArray) ; (013_1)(GUI Object: [key] Caps Lock)
      }
    } ; (013_1)(GUI Object: [key] Caps Lock)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_014_1") ; (014_1)(GUI Object: [key] Ctrl Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("014", 0, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("014", 0, 0, DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
      }
    } ; (014_1)(GUI Object: [key] Ctrl Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_015_1") ; (015_1)(GUI Object: [key] Ctrl Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("015", 0, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("015", 0, 0, DataArray) ; (015_1)(GUI Object: [key] Ctrl Left)
      }
    } ; (015_1)(GUI Object: [key] Ctrl Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_016_1") ; (016_1)(GUI Object: [key] Ctrl Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("016", 0, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("016", 0, 0, DataArray) ; (016_1)(GUI Object: [key] Ctrl Right)
      }
    } ; (016_1)(GUI Object: [key] Ctrl Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_017_1") ; (017_1)(GUI Object: [key] Ctrl Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("017", 0, 0, DataArray) ; (017_1)(GUI Object: [key] Ctrl Up)
      }
    } ; (017_1)(GUI Object: [key] Ctrl Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_018_1") ; (018_1)(GUI Object: [key] Enter)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("018", 0, 0, DataArray) ; (018_1)(GUI Object: [key] Enter)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("018", 0, 0, DataArray) ; (018_1)(GUI Object: [key] Enter)
      }
    } ; (018_1)(GUI Object: [key] Enter)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_019_1") ; (019_1)(GUI Object: [key] Enter X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("019", 0, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("019", 0, 0, DataArray) ; (019_1)(GUI Object: [key] Enter X2)
      }
    } ; (019_1)(GUI Object: [key] Enter X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_020_1") ; (020_1)(GUI Object: [key] Esc)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("020", 0, 0, DataArray) ; (020_1)(GUI Object: [key] Esc)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("020", 0, 0, DataArray) ; (020_1)(GUI Object: [key] Esc)
      }
    } ; (020_1)(GUI Object: [key] Esc)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_021_1") ; (021_1)(GUI Object: [key] Esc X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("021", 0, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("021", 0, 0, DataArray) ; (021_1)(GUI Object: [key] Esc X2)
      }
    } ; (021_1)(GUI Object: [key] Esc X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_022_1") ; (022_1)(GUI Object: [key] F1)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("022", 0, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("022", 0, 0, DataArray) ; (022_1)(GUI Object: [key] F1)
      }
    } ; (022_1)(GUI Object: [key] F1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_023_1") ; (023_1)(GUI Object: [key] F2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("023", 0, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("023", 0, 0, DataArray) ; (023_1)(GUI Object: [key] F2)
      }
    } ; (023_1)(GUI Object: [key] F2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_024_1") ; (024_1)(GUI Object: [key] F3)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("024", 0, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("024", 0, 0, DataArray) ; (024_1)(GUI Object: [key] F3)
      }
    } ; (024_1)(GUI Object: [key] F3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_025_1") ; (025_1)(GUI Object: [key] F4)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("025", 0, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("025", 0, 0, DataArray) ; (025_1)(GUI Object: [key] F4)
      }
    } ; (025_1)(GUI Object: [key] F4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_026_1") ; (026_1)(GUI Object: [key] F5)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("026", 0, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("026", 0, 0, DataArray) ; (026_1)(GUI Object: [key] F5)
      }
    } ; (026_1)(GUI Object: [key] F5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_027_1") ; (027_1)(GUI Object: [key] F6)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("027", 0, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("027", 0, 0, DataArray) ; (027_1)(GUI Object: [key] F6)
      }
    } ; (027_1)(GUI Object: [key] F6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_028_1") ; (028_1)(GUI Object: [key] F7)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("028", 0, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("028", 0, 0, DataArray) ; (028_1)(GUI Object: [key] F7)
      }
    } ; (028_1)(GUI Object: [key] F7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_029_1") ; (029_1)(GUI Object: [key] F8)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("029", 0, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("029", 0, 0, DataArray) ; (029_1)(GUI Object: [key] F8)
      }
    } ; (029_1)(GUI Object: [key] F8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_030_1") ; (030_1)(GUI Object: [key] F9)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("030", 0, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("030", 0, 0, DataArray) ; (030_1)(GUI Object: [key] F9)
      }
    } ; (030_1)(GUI Object: [key] F9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_031_1") ; (031_1)(GUI Object: [key] F10)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("031", 0, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("031", 0, 0, DataArray) ; (031_1)(GUI Object: [key] F10)
      }
    } ; (031_1)(GUI Object: [key] F10)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_032_1") ; (032_1)(GUI Object: [key] F11)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("032", 0, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("032", 0, 0, DataArray) ; (032_1)(GUI Object: [key] F11)
      }
    } ; (032_1)(GUI Object: [key] F11)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_033_1") ; (033_1)(GUI Object: [key] F12)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("033", 0, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("033", 0, 0, DataArray) ; (033_1)(GUI Object: [key] F12)
      }
    } ; (033_1)(GUI Object: [key] F12)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_034_1") ; (034_1)(GUI Object: [key] Numpad 0)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("034", 0, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("034", 0, 0, DataArray) ; (034_1)(GUI Object: [key] Numpad 0)
      }
    } ; (034_1)(GUI Object: [key] Numpad 0)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_035_1") ; (035_1)(GUI Object: [key] Numpad 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("035", 0, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("035", 0, 0, DataArray) ; (035_1)(GUI Object: [key] Numpad 1)
      }
    } ; (035_1)(GUI Object: [key] Numpad 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_036_1") ; (036_1)(GUI Object: [key] Numpad 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("036", 0, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("036", 0, 0, DataArray) ; (036_1)(GUI Object: [key] Numpad 2)
      }
    } ; (036_1)(GUI Object: [key] Numpad 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_037_1") ; (037_1)(GUI Object: [key] Numpad 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("037", 0, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("037", 0, 0, DataArray) ; (037_1)(GUI Object: [key] Numpad 3)
      }
    } ; (037_1)(GUI Object: [key] Numpad 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_038_1") ; (038_1)(GUI Object: [key] Numpad 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("038", 0, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("038", 0, 0, DataArray) ; (038_1)(GUI Object: [key] Numpad 4)
      }
    } ; (038_1)(GUI Object: [key] Numpad 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_039_1") ; (039_1)(GUI Object: [key] Numpad 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("039", 0, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("039", 0, 0, DataArray) ; (039_1)(GUI Object: [key] Numpad 5)
      }
    } ; (039_1)(GUI Object: [key] Numpad 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_040_1") ; (040_1)(GUI Object: [key] Numpad 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("040", 0, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("040", 0, 0, DataArray) ; (040_1)(GUI Object: [key] Numpad 6)
      }
    } ; (040_1)(GUI Object: [key] Numpad 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_041_1") ; (041_1)(GUI Object: [key] Numpad 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("041", 0, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("041", 0, 0, DataArray) ; (041_1)(GUI Object: [key] Numpad 7)
      }
    } ; (041_1)(GUI Object: [key] Numpad 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_042_1") ; (042_1)(GUI Object: [key] Numpad 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("042", 0, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("042", 0, 0, DataArray) ; (042_1)(GUI Object: [key] Numpad 8)
      }
    } ; (042_1)(GUI Object: [key] Numpad 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_043_1") ; (043_1)(GUI Object: [key] Numpad 9)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("043", 0, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("043", 0, 0, DataArray) ; (043_1)(GUI Object: [key] Numpad 9)
      }
    } ; (043_1)(GUI Object: [key] Numpad 9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_044_1") ; (044_1)(GUI Object: [key] Numpad Add)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("044", 0, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("044", 0, 0, DataArray) ; (044_1)(GUI Object: [key] Numpad Add)
      }
    } ; (044_1)(GUI Object: [key] Numpad Add)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_045_1") ; (045_1)(GUI Object: [key] Numpad Divide)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("045", 0, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("045", 0, 0, DataArray) ; (045_1)(GUI Object: [key] Numpad Divide)
      }
    } ; (045_1)(GUI Object: [key] Numpad Divide)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_046_1") ; (046_1)(GUI Object: [key] Numpad Dot)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("046", 0, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("046", 0, 0, DataArray) ; (046_1)(GUI Object: [key] Numpad Dot)
      }
    } ; (046_1)(GUI Object: [key] Numpad Dot)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_047_1") ; (047_1)(GUI Object: [key] Numpad Enter)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("047", 0, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("047", 0, 0, DataArray) ; (047_1)(GUI Object: [key] Numpad Enter)
      }
    } ; (047_1)(GUI Object: [key] Numpad Enter)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_048_1") ; (048_1)(GUI Object: [key] Numpad Multiply)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("048", 0, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("048", 0, 0, DataArray) ; (048_1)(GUI Object: [key] Numpad Multiply)
      }
    } ; (048_1)(GUI Object: [key] Numpad Multiply)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_049_1") ; (049_1)(GUI Object: [key] Numpad Subtract)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("049", 0, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("049", 0, 0, DataArray) ; (049_1)(GUI Object: [key] Numpad Subtract)
      }
    } ; (049_1)(GUI Object: [key] Numpad Subtract)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_050_1") ; (050_1)(GUI Object: [key] Shift)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("050", 0, 0, DataArray) ; (050_1)(GUI Object: [key] Shift)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("050", 0, 0, DataArray) ; (050_1)(GUI Object: [key] Shift)
      }
    } ; (050_1)(GUI Object: [key] Shift)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_051_1") ; (051_1)(GUI Object: [key] Shift Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("051", 0, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("051", 0, 0, DataArray) ; (051_1)(GUI Object: [key] Shift Down)
      }
    } ; (051_1)(GUI Object: [key] Shift Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_052_1") ; (052_1)(GUI Object: [key] Shift Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("052", 0, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("052", 0, 0, DataArray) ; (052_1)(GUI Object: [key] Shift Left)
      }
    } ; (052_1)(GUI Object: [key] Shift Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_053_1") ; (053_1)(GUI Object: [key] Shift Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("053", 0, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("053", 0, 0, DataArray) ; (053_1)(GUI Object: [key] Shift Right)
      }
    } ; (053_1)(GUI Object: [key] Shift Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_054_1") ; (054_1)(GUI Object: [key] Shift Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("054", 0, 0, DataArray) ; (054_1)(GUI Object: [key] Shift Up)
      }
    } ; (054_1)(GUI Object: [key] Shift Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_055_1") ; (055_1)(GUI Object: [key] Tab)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("055", 0, 0, DataArray) ; (055_1)(GUI Object: [key] Tab)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("055", 0, 0, DataArray) ; (055_1)(GUI Object: [key] Tab)
      }
    } ; (055_1)(GUI Object: [key] Tab)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_056_1") ; (056_1)(GUI Object: [key] Tab X2)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("056", 0, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("056", 0, 0, DataArray) ; (056_1)(GUI Object: [key] Tab X2)
      }
    } ; (056_1)(GUI Object: [key] Tab X2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_057_1") ; (057_1)(GUI Object: [key] Windows Key)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("057", 0, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("057", 0, 0, DataArray) ; (057_1)(GUI Object: [key] Windows Key)
      }
      ; -------------------------------------------
    } ; (057_1)(GUI Object: [key] Windows Key)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_058_1") ; (058_1)(GUI Object: [key] Windows Key Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("058", 0, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("058", 0, 0, DataArray) ; (058_1)(GUI Object: [key] Windows Key Down)
      }
    } ; (058_1)(GUI Object: [key] Windows Key Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_059_1") ; (059_1)(GUI Object: [key] Windows Key Left)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("059", 0, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("059", 0, 0, DataArray) ; (059_1)(GUI Object: [key] Windows Key Left)
      }
    } ; (059_1)(GUI Object: [key] Windows Key Left)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_060_1") ; (060_1)(GUI Object: [key] Windows Key Right)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("060", 0, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("060", 0, 0, DataArray) ; (060_1)(GUI Object: [key] Windows Key Right)
      }
    } ; (060_1)(GUI Object: [key] Windows Key Right)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_061_1") ; (061_1)(GUI Object: [key] Windows Key Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("061", 0, 0, DataArray) ; (061_1)(GUI Object: [key] Windows Key Up)
      }
    } ; (061_1)(GUI Object: [key] Windows Key Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_063_1") ; (063_1)(GUI Object: Select Icon Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (DataArray.4.2 == 3) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          DataArray := GuiControlImage_PopUpMenu("063", 0, 0, DataArray) ; (063_1)(GUI Object: Select Icon Image)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("063", 0, 0, DataArray) ; (063_1)(GUI Object: Select Icon Image)
      }
    } ; (063_1)(GUI Object: Select Icon Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_064_1") ; (064_1)(GUI Object: Reset Icon Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (DataArray.4.2 == 3) ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        {
          DataArray := GuiControlImage_PopUpMenu("064", 0, 0, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("064", 0, 0, DataArray) ; (064_1)(GUI Object: Reset Icon Image)
      }
    } ; (064_1)(GUI Object: Reset Icon Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_065_1") ; (065_1)(GUI Object: <Image Text> Status Bar Description)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key" && v_366_5 != "ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("065", 0, 0, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("065", 0, 0, DataArray) ; (065_1)(GUI Object: <Image Text> Status Bar Description)
      }
    } ; (065_1)(GUI Object: <Image Text> Status Bar Description)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_066_1") ; (066_1)(GUI Object: <Image Text> Text Input)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("066", 0, 0, DataArray) ; (066_1)(GUI Object: <Image Text> Text Input)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("066", 0, 0, DataArray) ; (066_1)(GUI Object: <Image Text> Text Input)
      }
    } ; (066_1)(GUI Object: <Image Text> Text Input)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_067_1") ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("067", 0, 0, DataArray) ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("067", 0, 0, DataArray) ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
      }
    } ; (067_1)(GUI Object: [key] <Image Text> Numeric Keypad)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_068_1") ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("068", 0, 0, DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("068", 0, 0, DataArray) ; (068_1)(GUI Object: [rwh][url] Select Open With Browser/Application)
      }
    } ; (068_1)(GUI Object: [rwh][url] Select Open With Application)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_069_1") ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("069", 0, 0, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("069", 0, 0, DataArray) ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
      }
    } ; (069_1)(GUI Object: [rwh][url] Open With App Reset)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_070_1") ; (070_1)(GUI Object: [cpl] Select Control)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if (v_366_5 != "mnu_cpl_key" && v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("070", 0, 0, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("070", 0, 0, DataArray) ; (070_1)(GUI Object: [cpl] Select Control)
      }
    } ; (070_1)(GUI Object: [cpl] Select Control)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_071_1") ; (071_1)(GUI Object: [url] Select URL)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if (v_366_5 != "run_rwh_url_ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url" && v_366_5 != "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("071", 0, 0, DataArray) ; (071_1)(GUI Object: [url] Select URL)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("071", 0, 0, DataArray) ; (071_1)(GUI Object: [url] Select URL)
      }
    } ; (071_1)(GUI Object: [ruf] Select URL)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_072_1") ; (072_1)(GUI Object: [key] Application Only)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("072", 0, 0, DataArray) ; (072_1)(GUI Object: [key] Application Only)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("072", 0, 0, DataArray) ; (072_1)(GUI Object: [key] Application Only)
      }
    } ; (072_1)(GUI Object: [key] Application Only)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_073_1") ; (073_1)(GUI Object: [run] As Admin)
    {
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("073", 0, 0, DataArray) ; (073_1)(GUI Object: [run] As Admin)
        }
      }
      else
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("073", 0, 0, DataArray) ; (073_1)(GUI Object: [run] As Admin)
        }
      }
    } ; (073_1)(GUI Object: [run][rwh] As Admin)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_074_1") ; (074_1)(GUI Object: [key] Ctrl)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("074", 0, 0, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("074", 0, 0, DataArray) ; (074_1)(GUI Object: [key] Ctrl)
      }
    } ; (074_1)(GUI Object: [key] Ctrl)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_075_1") ; (075_1)(GUI Object: [key] Delete)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("075", 0, 0, DataArray) ; (075_1)(GUI Object: [key] Delete)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("075", 0, 0, DataArray) ; (075_1)(GUI Object: [key] Delete)
      }
    } ; (075_1)(GUI Object: [key] Delete)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_076_1") ; (076_1)(GUI Object: [key] End)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("076", 0, 0, DataArray) ; (076_1)(GUI Object: [key] End)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("076", 0, 0, DataArray) ; (076_1)(GUI Object: [key] End)
      }
    } ; (076_1)(GUI Object: [key] End)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_077_1") ; (077_1)(GUI Object: [key] Home)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("077", 0, 0, DataArray) ; (077_1)(GUI Object: [key] Home)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("077", 0, 0, DataArray) ; (077_1)(GUI Object: [key] Home)
      }
    } ; (077_1)(GUI Object: [key] Home)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_078_1") ; (078_1)(GUI Object: [key] Insert)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("078", 0, 0, DataArray) ; (078_1)(GUI Object: [key] Insert)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("078", 0, 0, DataArray) ; (078_1)(GUI Object: [key] Insert)
      }
    } ; (078_1)(GUI Object: [key] Insert)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_079_1") ; (079_1)(GUI Object: [key] Page Down)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("079", 0, 0, DataArray) ; (079_1)(GUI Object: [key] Page Down)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("079", 0, 0, DataArray) ; (079_1)(GUI Object: [key] Page Down)
      }
    } ; (079_1)(GUI Object: [key] Page Down)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_080_1") ; (080_1)(GUI Object: [key] Page Up)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("080", 0, 0, DataArray) ; (080_1)(GUI Object: [key] Page Up)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("080", 0, 0, DataArray) ; (080_1)(GUI Object: [key] Page Up)
      }
    } ; (080_1)(GUI Object: [key] Page Up)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_081_1") ; (081_1)(GUI Object: [run][rwh] Select File)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if (v_366_5 != "run_rwh_url_ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url" && v_366_5 != "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("081", 0, 0, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("081", 0, 0, DataArray) ; (081_1)(GUI Object: [run][rwh] Select File)
      }
    } ; (081_1)(GUI Object: [run][rwh] Select File)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_082_1") ; (082_1)(GUI Object: [ofl] Select Folder)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; [ScriptError == 19] (url)(No Internet Connection)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 6 or v_366_6 == 8 or v_366_6 == 15 or v_366_6 == 18 or v_366_6 == 19 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if (v_366_5 != "run_rwh_url_ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url" && v_366_5 != "ofl") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("082", 0, 0, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("082", 0, 0, DataArray) ; (082_1)(GUI Object: [ofl] Select Folder)
      }
    } ; (082_1)(GUI Object: [ofl] Select Folder)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_085_1") ; (085_1)(GUI Object: [key] Select Keyboard)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError == 20] (ActiveProcess = "Windows")
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17 or v_366_6 == 20) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if (v_366_5 != "mnu_cpl_key" && v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key") ; (366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("085", 0, 0, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("085", 0, 0, DataArray) ; (085_1)(GUI Object: [key] Select Keyboard)
      }
    } ; (085_1)(GUI Object: [key] Select Keyboard)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_087_1") ; (087_1)(GUI Object: [mnu] Select Menu)
    {
      ; -------------------------------------------
      if (v_367_3 != "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
      {
        ; -------------------------------------------
        ; [ScriptError == 3] (Invalid KeyStroke)
        ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
        ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
        ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
        ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
        ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
        ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
        ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 5 or v_366_6 == 7 or v_366_6 == 9 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 12 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          if (v_366_5 != "mnu_cpl_key" && v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key") ; (366_5)(Script Type)/(366_5)(Script Type)
          {
            DataArray := GuiControlImage_PopUpMenu("087", 0, 0, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("087", 0, 0, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("087", 0, 0, DataArray) ; (087_1)(GUI Object: [mnu] Select Menu)
      }
    } ; (087_1)(GUI Object: [mnu] Select Menu)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_088_1") ; (088_1)(GUI Object: [mnu] App Context Menu 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 1) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("088", 0, 0, DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("088", 0, 0, DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("088", 0, 0, DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("088", 0, 0, DataArray) ; (088_1)(GUI Object: [mnu] App Context Menu 1)
      }
    } ; (088_1)(GUI Object: [mnu] App Context Menu 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_089_1") ; (089_1)(GUI Object: [mnu] App Context Menu 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 2) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("089", 0, 0, DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("089", 0, 0, DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("089", 0, 0, DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("089", 0, 0, DataArray) ; (089_1)(GUI Object: [mnu] App Context Menu 2)
      }
    } ; (089_1)(GUI Object: [mnu] App Context Menu 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_090_1") ; (090_1)(GUI Object: [mnu] App Context Menu 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 3) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("090", 0, 0, DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("090", 0, 0, DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("090", 0, 0, DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("090", 0, 0, DataArray) ; (090_1)(GUI Object: [mnu] App Context Menu 3)
      }
    } ; (090_1)(GUI Object: [mnu] App Context Menu 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_091_1") ; (091_1)(GUI Object: [mnu] App Context Menu 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 4) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("091", 0, 0, DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("091", 0, 0, DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("091", 0, 0, DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("091", 0, 0, DataArray) ; (091_1)(GUI Object: [mnu] App Context Menu 4)
      }
    } ; (091_1)(GUI Object: [mnu] App Context Menu 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_092_1") ; (092_1)(GUI Object: [mnu] App Context Menu 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 5) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("092", 0, 0, DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("092", 0, 0, DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("092", 0, 0, DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("092", 0, 0, DataArray) ; (092_1)(GUI Object: [mnu] App Context Menu 5)
      }
    } ; (092_1)(GUI Object: [mnu] App Context Menu 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_093_1") ; (093_1)(GUI Object: [mnu] App Context Menu 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 6) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("093", 0, 0, DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("093", 0, 0, DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("093", 0, 0, DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("093", 0, 0, DataArray) ; (093_1)(GUI Object: [mnu] App Context Menu 6)
      }
    } ; (093_1)(GUI Object: [mnu] App Context Menu 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_094_1") ; (094_1)(GUI Object: [mnu] App Context Menu 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 7) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("094", 0, 0, DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("094", 0, 0, DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("094", 0, 0, DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("094", 0, 0, DataArray) ; (094_1)(GUI Object: [mnu] App Context Menu 7)
      }
    } ; (094_1)(GUI Object: [mnu] App Context Menu 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_095_1") ; (095_1)(GUI Object: [mnu] App Context Menu 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 8) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("095", 0, 0, DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("095", 0, 0, DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("095", 0, 0, DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("095", 0, 0, DataArray) ; (095_1)(GUI Object: [mnu] App Context Menu 8)
      }
    } ; (095_1)(GUI Object: [mnu] App Context Menu 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_096_1") ; (096_1)(GUI Object: [mnu] App Context Menu 9)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 9) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("096", 0, 0, DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("096", 0, 0, DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("096", 0, 0, DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("096", 0, 0, DataArray) ; (096_1)(GUI Object: [mnu] App Context Menu 9)
      }
    } ; (096_1)(GUI Object: [mnu] App Context Menu 9)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_097_1") ; (097_1)(GUI Object: [mnu] App Context Menu 10)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 10) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("097", 0, 0, DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("097", 0, 0, DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("097", 0, 0, DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("097", 0, 0, DataArray) ; (097_1)(GUI Object: [mnu] App Context Menu 10)
      }
    } ; (097_1)(GUI Object: [mnu] App Context Menu 10)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_098_1") ; (098_1)(GUI Object: [mnu] App Context Menu 11)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 11) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("098", 0, 0, DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("098", 0, 0, DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("098", 0, 0, DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("098", 0, 0, DataArray) ; (098_1)(GUI Object: [mnu] App Context Menu 11)
      }
    } ; (098_1)(GUI Object: [mnu] App Context Menu 11)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_100_1") ; (100_1)(GUI Object: <Displayed Text> Top 1)
    {
      if (v_366_5 != "mnu") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("100", 0, 0, DataArray) ; (100_1)(GUI Object: <Displayed Text> Top 1)
      }
    } ; (100_1)(GUI Object: <Displayed Text> Top 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_102_1") ; (102_1)(GUI Object: Main Display Icon)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Application Target [exe] File Not Found)
      ; [ScriptError == 2] (rwh)(No Application to Open File)
      ; [ScriptError == 3] (key)(Invalid KeyStroke)
      ; [ScriptError == 6] (ofl)(Folder Not Found)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key" && v_366_5 != "ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("102", 0, 0, DataArray) ; (102_1)(GUI Object: Main Display Icon)
      }
    } ; (102_1)(GUI Object: Main Display Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_103_1") ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("103", 0, 0, DataArray) ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("103", 0, 0, DataArray) ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
      }
    } ; (103_1)(GUI Object: [rwh][url] Opening Application Image)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_104_1") ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("104", 0, 0, DataArray) ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
      }
    } ; (104_1)(GUI Object: <Displayed Text> Bottom 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_105_1") ; (105_1)(GUI Object: <Displayed Text> Top 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key" && v_366_5 != "ofl" && v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("105", 0, 0, DataArray) ; (105_1)(GUI Object: <Displayed Text> Top 2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("105", 0, 0, DataArray) ; (105_1)(GUI Object: <Displayed Text> Top 2)
      }
    } ; (105_1)(GUI Object: <Displayed Text> Top 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_106_1") ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("106", 0, 0, DataArray) ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("106", 0, 0, DataArray) ; (106_1)(GUI Object: [rwh][run] <Displayed Text> Number of Icons [Open Folder Select])
      }
    } ; (106_1)(GUI Object: [rwh][run] [Text] Number of Icons [Open Folder Select])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_107_1") ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh" ) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("107", 0, 0, DataArray) ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
      }
    } ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_108_1") ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh" ) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("108", 0, 0, DataArray) ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("108", 0, 0, DataArray) ; (108_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Top)
      }
    } ; (108_1)(GUI Object: [rwh][run] Icon Warning Text Top)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_109_1") ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
    {
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "run" && v_366_5 != "rwh" ) ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("109", 0, 0, DataArray) ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("109", 0, 0, DataArray) ; (109_1)(GUI Object: [rwh][run] <Displayed Text> Icon Warning Bottom)
      }
    } ; (109_1)(GUI Object: [rwh][run] Icon Warning Text Bottom)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_110_1") ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10 or v_366_6 == 11) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl" && v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("110", 0, 0, DataArray) ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("110", 0, 0, DataArray) ; (110_1)(GUI Object: [cpl][mnu] <Displayed Text> Left List)[cpl]
      }
    } ; (110_1)(GUI Object: [cpl][mnu] Left List Text)[cpl]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_111_1") ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10 or v_366_6 == 11) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl" && v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("111", 0, 0, DataArray) ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("111", 0, 0, DataArray) ; (111_1)(GUI Object: [cpl][mnu] <Displayed Text> Center List)
      }
    } ; (111_1)(GUI Object: [cpl][mnu] Center List Text)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_112_1") ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("112", 0, 0, DataArray) ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("112", 0, 0, DataArray) ; (112_1)(GUI Object: [mnu] <Displayed Text> Right List)
      }
    } ; (112_1)(GUI Object: [mnu] Right List Text)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_113_1") ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
    {
      ; -------------------------------------------
      ; [ScriptError == 2] (No Application to Open File)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 2) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("113", 0, 0, DataArray) ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("113", 0, 0, DataArray) ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
      }
    } ; (113_1)(GUI Object: <Displayed Text> Opening Application Path)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_116_1") ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10 or v_366_6 == 11) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl" && v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("116", 0, 0, DataArray) ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("116", 0, 0, DataArray) ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
      }
    } ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_117_1") ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10 or v_366_6 == 11) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl" && v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("117", 0, 0, DataArray) ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("117", 0, 0, DataArray) ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
      }
    } ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_118_1") ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10 or v_366_6 == 11) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl" && v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("118", 0, 0, DataArray) ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("118", 0, 0, DataArray) ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
      }
    } ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_120_1") ; (120_1)(GUI Object: [mnu] List Center 1/3)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("120", 0, 0, DataArray) ; (120_1)(GUI Object: [mnu] List Center 1/3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("120", 0, 0, DataArray) ; (120_1)(GUI Object: [mnu] List Center 1/3)
      }
    } ; (120_1)(GUI Object: [mnu] List Center 1/3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_121_1") ; (121_1)(GUI Object: [mnu] List Right 1/3)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("121", 0, 0, DataArray) ; (121_1)(GUI Object: [mnu] List Right 1/3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("121", 0, 0, DataArray) ; (121_1)(GUI Object: [mnu] List Right 1/3)
      }
    } ; (121_1)(GUI Object: [mnu] List Right 1/3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_122_1") ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    {
      ; -------------------------------------------
      ; [ScriptError == 1] (Target File Not Found)
      ; [ScriptError == 2] (No Application to Open File)
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 6] (Folder Not Found)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 10 or v_366_6 == 11 or v_366_6 == 13 or v_366_6 == 14 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "mnu" && v_366_5 != "cpl" && v_366_5 != "key" && v_366_5 != "ofl" && v_366_5 != "run" && v_366_5 != "rwh" && v_366_5 != "url") ; (366_5)(Script Type)/(366_5)(Script Type)/(366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("122", 0, 0, DataArray) ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("122", 0, 0, DataArray) ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
      }
    } ; (122_1)(GUI Object: <Edit Feild> Status Bar Description)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_123_1") ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    {
      ; -------------------------------------------
      ; [ScriptError == 3] (Invalid KeyStroke)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 3 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "key") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("123", 0, 0, DataArray) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("123", 0, 0, DataArray) ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
      }
    } ; (123_1)(GUI Object: <Edit Feild> [key] Text Input)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_125_1") ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("125", 0, 0, DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("125", 0, 0, DataArray) ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
      }
    } ; (125_1)(GUI Object: [cpl] Windows Control Menu 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_126_1") ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("126", 0, 0, DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("126", 0, 0, DataArray) ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
      }
    } ; (126_1)(GUI Object: [cpl] Windows Control Menu 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_127_1") ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("127", 0, 0, DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("127", 0, 0, DataArray) ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
      }
    } ; (127_1)(GUI Object: [cpl] Windows Control Menu 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_128_1") ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("128", 0, 0, DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("128", 0, 0, DataArray) ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
      }
    } ; (128_1)(GUI Object: [cpl] Windows Control Menu 4)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_129_1") ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("129", 0, 0, DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("129", 0, 0, DataArray) ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
      }
    } ; (129_1)(GUI Object: [cpl] Windows Control Menu 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_130_1") ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("130", 0, 0, DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("130", 0, 0, DataArray) ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
      }
    } ; (130_1)(GUI Object: [cpl] Windows Control Menu 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_131_1") ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (367_1)(Active Process Info)_(367_2)(Active Process Name)_(367_3)(Active Process Name With Ext)_(367_4)(Active Process Class)_(367_5)(Active Process Title)_(367_6)(Active Process Full Path)_(367_7)(Active Process Version)
      ; -------------------------------------------
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("131", 0, 0, DataArray) ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("131", 0, 0, DataArray) ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
      }
    } ; (131_1)(GUI Object: <Edit Feild> [url] URL Address)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_132_1") ; (132_1)(GUI Object: [url] Select Get URL Data)
    {
      ; -------------------------------------------
      ; [ScriptError == 15] (No Error)(url)(No Selected URL)
      ; [ScriptError == 18] (url)(Source Not Found)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 15 or v_366_6 == 18) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "url") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("132", 0, 0, DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("132", 0, 0, DataArray) ; (132_1)(GUI Object: [url] Select Get URL Data)
      }
    } ; (132_1)(GUI Object: [url] Select Get URL Data)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_133_1") ; (133_1)(GUI Object: Delete Shortcut)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (v_370_8 == "") ; (370_8)(XML_SC_L2 Script [Full File Path])
      {
        ; (133_1)(GUI Object: Delete Shortcut)
      }
      else if (v_366_5 == "xxx" or v_366_5 == "mnu_cpl_key" or v_366_5 == "run_rwh_url_ofl") ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("133", 0, 0, DataArray) ; (133_1)(GUI Object: Delete Shortcut)
      }
    } ; (133_1)(GUI Object: Delete Shortcut)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_134_1") ; (134_1)(GUI Object: Message Image 1)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; -------------------------------------------
      if (v_366_6 != 5 && v_366_6 != 7 && v_366_6 != 8 && v_366_6 != 12 && v_366_6 != 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        DataArray := GuiControlImage_PopUpMenu("134", 0, 0, DataArray) ; (134_1)(GUI Object: Message Image 1)
      }
    } ; (134_1)(GUI Object: Message Image 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_135_1") ; (135_1)(GUI Object: Message Image 2)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; -------------------------------------------
      if (v_366_6 != 5 && v_366_6 != 7 && v_366_6 != 8 && v_366_6 != 12 && v_366_6 != 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        DataArray := GuiControlImage_PopUpMenu("135", 0, 0, DataArray) ; (135_1)(GUI Object: Message Image 2)
      }
    } ; (135_1)(GUI Object: Message Image 2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_136_1") ; (136_1)(GUI Object: Message Image 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
      ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; -------------------------------------------
      if (v_366_6 != 5 && v_366_6 != 7 && v_366_6 != 8 && v_366_6 != 12 && v_366_6 != 17) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
      {
        DataArray := GuiControlImage_PopUpMenu("136", 0, 0, DataArray) ; (136_1)(GUI Object: Message Image 3)
      }
    } ; (136_1)(GUI Object: Message Image 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_138_1") ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("138", 0, 0, DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("138", 0, 0, DataArray) ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
      }
    } ; (138_1)(GUI Object: [cpl] Windows Control Menu 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_139_1") ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
    {
      ; -------------------------------------------
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 11 or v_366_6 == 14) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 != "cpl") ; (366_5)(Script Type)
        {
          DataArray := GuiControlImage_PopUpMenu("139", 0, 0, DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("139", 0, 0, DataArray) ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
      }
    } ; (139_1)(GUI Object: [cpl] Windows Control Menu 8)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_140_1") ; (140_1)(GUI Object: [mnu] Addon Extra)
    {
      ; -------------------------------------------
      ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (v_366_6 == 0 or v_366_6 == 9 or v_366_6 == 10) ; (366_6)(This Script Error [Integer])
      {
        if (v_366_5 == "mnu") ; (366_5)(Script Type)
        {
          if (v_302_6 >= 1) ; (302_6)([mnu] Menu Size [#])
          {
            if (v_367_3 == "Windows") ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
            {
              DataArray := GuiControlImage_PopUpMenu("140", 0, 0, DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
            }
          }
          else
          {
            DataArray := GuiControlImage_PopUpMenu("140", 0, 0, DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
          }
        }
        else
        {
          DataArray := GuiControlImage_PopUpMenu("140", 0, 0, DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
        }
      }
      else
      {
        DataArray := GuiControlImage_PopUpMenu("140", 0, 0, DataArray) ; (140_1)(GUI Object: [mnu] Addon Extra)
      }
    } ; (140_1)(GUI Object: [mnu] Addon Extra)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_141_1") ; (141_1)(GUI Object: <Displayed Text> Title 3)
    {
      ; -------------------------------------------
      ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        DataArray := GuiControlImage_PopUpMenu("141", 0, 0, DataArray) ; (141_1)(GUI Object: <Displayed Text> Title 3)
      }
    } ; (141_1)(GUI Object: <Displayed Text> Title 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_154_1") ; (154_1)(GUI Object: [pum] Pum Select Background)
    {
      if (InStr(v_366_5, "pumSet") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("154", 0, 0, DataArray) ; (154_1)(GUI Object: [pum] Pum Select Background)
      }
    } ; (154_1)(GUI Object: [pum] Pum Select Background)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_155_1") ; (155_1)(GUI Object: [pum] Pum Select Display Text)
    {
      if (InStr(v_366_5, "pumSet") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("155", 0, 0, DataArray) ; (155_1)(GUI Object: [pum] Pum Select Display Text)
      }
    } ; (155_1)(GUI Object: [pum] Pum Select Shortcut Description Text)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_156_1") ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
    {
      if (InStr(v_366_5, "pumSet") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("156", 0, 0, DataArray) ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
      }
    } ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_157_1") ; (157_1)(GUI Object: [pum] Pum Select Settings)
    {
      if (InStr(v_366_5, "pum") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("157", 0, 0, DataArray) ; (157_1)(GUI Object: [pum] Pum Select Settings)
      }
    } ; (157_1)(GUI Object: [pum] Pum Select Settings)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_158_1") ; (158_1)(GUI Object: [pum] Pum Shortcut)
    {
      if (InStr(v_366_5, "pum") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("158", 0, 0, DataArray) ; (158_1)(GUI Object: [pum] Pum Shortcut)
      }
    } ; (158_1)(GUI Object: [pum] Pum Shortcut)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_159_1") ; (159_1)(GUI Object: [pum] Select Custom Pum)
    {
      if (InStr(v_366_5, "pum") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("159", 0, 0, DataArray) ; (159_1)(GUI Object: [pum] Select Custom Pum)
      }
    } ; (159_1)(GUI Object: [pum] Select Custom Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_160_1") ; (160_1)(GUI Object: [pum] Select Application Pum)
    {
      if (InStr(v_366_5, "pum") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("160", 0, 0, DataArray) ; (160_1)(GUI Object: [pum] Select Application Pum)
      }
    } ; (160_1)(GUI Object: [pum] Select Application Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_161_1") ; (161_1)(GUI Object: [pum] Delete Pum)
    {
      if (InStr(v_366_5, "pum") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("161", 0, 0, DataArray) ; (161_1)(GUI Object: [pum] Delete Pum)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_162_1") ; (162_1)(GUI Object: Message Image 5)
    {
      if (InStr(v_366_5, "pumImg") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("162", 0, 0, DataArray) ; (162_1)(GUI Object: Message Image 5)
      }
    } ; (162_1)(GUI Object: Message Image 5)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_163_1") ; (163_1)(GUI Object: Message Image 6)
    {
      ; (366_5)(Script Type)
      ;~ {
        DataArray := GuiControlImage_PopUpMenu("163", 0, 0, DataArray) ; (163_1)(GUI Object: Message Image 6)
      ;~ }
    } ; (163_1)(GUI Object: Message Image 6)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_164_1") ; (164_1)(GUI Object: Message Image 7)
    {
      ; (366_5)(Script Type)
      ;~ {
        DataArray := GuiControlImage_PopUpMenu("164", 0, 0, DataArray) ; (164_1)(GUI Object: Message Image 7)
      ;~ }
    } ; (164_1)(GUI Object: Message Image 7)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_165_1") ; (165_1)(GUI Object: [pum] Backgroung Image Select)
    {
      if (InStr(v_366_5, "pumBG") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("165", 0, 0, DataArray) ; (165_1)(GUI Object: [pum] Backgroung Image Select)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_166_1") ; (166_1)(GUI Object: [pum] Backgroung Color Select)
    {
      if (InStr(v_366_5, "pumBG") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("166", 0, 0, DataArray) ; (166_1)(GUI Object: [pum] Backgroung Color Select)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_167_1") ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
    {
      if (InStr(v_366_5, "pumImg") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("167", 0, 0, DataArray) ; (167_1)(GUI Object: [pum] Backgroung Image Fit)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_168_1") ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
    {
      if (InStr(v_366_5, "pumImg") == 0) ; (366_5)(Script Type)
      {
        DataArray := GuiControlImage_PopUpMenu("168", 0, 0, DataArray) ; (168_1)(GUI Object: [pum] Backgroung Image Chop)
      }
    } ; (161_1)(GUI Object: [pum] Delete Pum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
