﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_156(DataArray) ; (156_1)(GUI Object: [pum] Pum Select Dimensions)
{
  ; -------------------------------------------
  v_156_2 := DataArray.156.2 ; (156_2)([pum] Pum Select Dimensions: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_156_2 == "") ; (156_2)([pum] Pum Select Dimensions: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_156_2 := 1 ; (156_2)([pum] Pum Select Dimensions: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_156_2 == 1) ; (156_2)([pum] Pum Select Dimensions: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet_pumDim" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
