﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_064(DataArray) ; (064_1)(GUI Object: Reset Icon Image)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_064", DataArray) ; (064_1)(GUI Object: Reset Icon Image)
  ; -------------------------------------------
  Temp_Icon := ""
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    v_370_10 := DataArray.370.10 ; (370_10)(XML_SC_L8 Old Icon [Full File Path])
    v_386_7 := DataArray.386.7 ; (386_7)(Default Script Type Icon [Folder Path])
    ; -------------------------------------------
    v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    v_367_3 := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
    StringLower, ActiveProcess, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    ; ------------------------------------------- (cpl)
    v_386_8 := DataArray.386.8 ; (386_8)(Windows Control Icon [Folder Path])
    v_300_2 := DataArray.300.2 ; (300_2)([cpl] Menu Number #_X_[X])
    v_300_3 := DataArray.300.3 ; (300_3)([cpl] Menu Number X_#_[X])
    v_300_4 := DataArray.300.4 ; (300_4)([cpl] Menu Number X_X_[#])
    ; ------------------------------------------- (mnu)
    v_386_3 := DataArray.386.3 ; (386_3)(Addons [System Folder Path])
    v_302_2 := DataArray.302.2 ; (302_2)([mnu] Menu Number #_X_X_[X])
    v_302_3 := DataArray.302.3 ; (302_3)([mnu] Menu Number X_#_X_[X])
    v_302_4 := DataArray.302.4 ; (302_4)([mnu] Menu Number X_X_#_[X])
    v_302_5 := DataArray.302.5 ; (302_5)([mnu] Menu Number X_X_X_[#])
    ; ------------------------------------------- (run)
    v_305_4 := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    ; -------------------------------------------
    v_305_5 := DataArray.305.5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
    v_305_6 := DataArray.305.6 ; (305_6)([rwh] Default Application [Full File Path])
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  if (v_366_5 == "key" or v_366_5 == "ofl") ; (366_5)(Script Type)
  {
    Temp_Icon := v_386_7 "\" v_366_5 ".ico" ; (386_7)(Default Script Type Icon [Folder Path])/(366_5)(Script Type)
    DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
  } ; (366_5)(Script Type)
  ; -------------------------------------------
  else if (v_366_5 == "cpl") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    if (v_300_3 > 0) ; (300_3)([cpl] Menu Number X_#_[X])
    {
      Temp_Icon := v_386_8 "\" v_300_2 "_" v_300_3 "_(" v_300_4 ").ico" ; (386_8)(Windows Control Icon [Folder Path])/(300_2)([cpl] Menu Number #_X_[X])/(300_3)([cpl] Menu Number X_#_[X])/(300_4)([cpl] Menu Number X_X_[#])
    }
    else if (v_300_3 == 0) ; (300_3)([cpl] Menu Number X_#_[X])
    {
      Temp_Icon := v_386_8 "\" v_300_2 "_(" v_300_4 ").ico" ; (386_8)(Windows Control Icon [Folder Path])/(300_2)([cpl] Menu Number #_X_[X])/(300_4)([cpl] Menu Number X_X_[#])
    }
    DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
  } ; (366_5)(Script Type) (cpl)
  ; -------------------------------------------
  else if (v_366_5 == "mnu") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    if v_302_3 ; (302_3)([mnu] Menu Number X_#_X_[X])
    {
      if v_302_4 ; (302_4)([mnu] Menu Number X_X_#_[X])
      {
        Temp_Icon := v_386_3 "\" ActiveProcess "\ico\" v_302_2 "_" v_302_3 "_" v_302_4 "_(" v_302_5 ").ico" ; (386_3)(Addons [System Folder Path])/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_4)([mnu] Menu Number X_X_#_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
      } ; (302_4)([mnu] Menu Number X_X_#_[X])
      else
      {
        Temp_Icon := v_386_3 "\" ActiveProcess "\ico\" v_302_2 "_" v_302_3 "_(" v_302_5 ").ico" ; (386_3)(Addons [System Folder Path])/(302_2)([mnu] Menu Number #_X_X_[X])/(302_3)([mnu] Menu Number X_#_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
      } ; END else
    } ; (302_3)([mnu] Menu Number X_#_X_[X])
    else
    {
      Temp_Icon := v_386_3 "\" ActiveProcess "\ico\" v_302_2 "_(" v_302_5 ").ico" ; (386_3)(Addons [System Folder Path])/(302_2)([mnu] Menu Number #_X_X_[X])/(302_5)([mnu] Menu Number X_X_X_[#])
    }
    DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
  } ; (366_5)(Script Type) (mnu)
  ; -------------------------------------------
  else if (v_366_5 == "url") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
    GuiControlGet, v_131_3, PopUpMenu:, g_131 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
    ; -------------------------------------------
    if (v_307_2 != "") ; (307_2)([url] Current URL)
    {
      if (v_131_3 == "" or v_307_2 != v_131_3) ; (307_2)([url] Current URL)/(131_3)(<Edit Feild> [url] URL Address: Value)
      {
        DataArray.131.3 := v_307_2 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(307_2)([url] Current URL)
        v_131_3 := v_307_2 ; (131_3)(<Edit Feild> [url] URL Address: Value)/(307_2)([url] Current URL)
        GuiControl, PopUpMenu:, g_131, %v_131_3% ; (131_3)(<Edit Feild> [url] URL Address: Value)/(131_1)(GUI Object: <Edit Feild> [url] URL Address)
        DataArray := url_Get_PageIcon(DataArray)
      }
      else
      {
        DataArray := url_Get_PageIcon(DataArray)
      }
    }
    else
    {
      Temp_Icon := v_386_7 "\" v_366_5 ".ico" ; (386_7)(Default Script Type Icon [Folder Path])/(366_5)(Script Type)
      DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
  } ; (366_5)(Script Type) (url)
  ; -------------------------------------------
  else if (v_366_5 == "run") ; (366_5)(Script Type)
  {
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, v_305_4, , , , ThisApp ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    TempIcon := v_386_1 "\" ThisApp "\" ThisApp "_0.ico" ; (386_1)(Extracted Application Icons [System Folder Path])
    if !FileExist(TempIcon)
    {
      DataArray := Extract_Icons_From_File(DataArray)
    }
    else
    {
      DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
  } ; (366_5)(Script Type) (run)
  ; -------------------------------------------
  else if (v_366_5 == "rwh") ; (366_5)(Script Type)
  {
    if FileExist(v_305_5) ; (305_5)([rwh] Selected Opening Application [Full File Path])
    {
      SplitPath, v_305_5, , , , ThisApp ; (305_5)([rwh] Selected Opening Application [Full File Path])
      TempIcon := v_386_1 "\" ThisApp "\" ThisApp "_0.ico" ; (386_1)(Extracted Application Icons [System Folder Path])
    }
    else if FileExist(v_305_6) ; (305_6)([rwh] Default Application [Full File Path])
    {
      SplitPath, v_305_6, , , , ThisApp ; (305_6)([rwh] Default Application [Full File Path])
      TempIcon := v_386_1 "\" ThisApp "\" ThisApp "_0.ico" ; (386_1)(Extracted Application Icons [System Folder Path])
      DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
    if !FileExist(TempIcon)
    {
      DataArray := Extract_Icons_From_File(DataArray)
    }
    else
    {
      DataArray := f_102(TempIcon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
  } ; (366_5)(Script Type) (rwh)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (v_366_5 != "url" && v_366_5 != "run" && v_366_5 != "rwh") ; (366_5)(Script Type)
  {
    if FileExist(Temp_Icon)
    {
      DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
    else
    {
      Temp_Icon := v_386_7 "\Missing.png" ; (386_7)(Default Script Type Icon [Folder Path])
      DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(GUI Object: Main Display Icon)
    }
  } ; (366_5)(Script Type) != (url) && != (run) && != (rwh)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (v_366_5 != "mnu") ; (366_5)(Script Type)
  {
    DataArray.107.2 := 0 ; (107_2)(<Displayed Text> Bottom 2: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    GuiControl, PopUpMenu:Hide, g_107 ; (107_1)(GUI Object: <Displayed Text> Bottom 2)
  } ; (366_5)(Script Type) != (mnu)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
  
