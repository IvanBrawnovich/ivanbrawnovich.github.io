﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_157(DataArray) ; (157_1)(GUI Object: [pum] Pum Select Settings)
{
  ; -------------------------------------------
  v_157_2 := DataArray.157.2 ; (157_2)([pum] Pum Select Settings: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  ; -------------------------------------------
  if (v_157_2 == "") ; (157_2)([pum] Pum Select Settings: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    v_157_2 := 1 ; (157_2)([pum] Pum Select Settings: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  }
  ; -------------------------------------------
  if (v_157_2 == 1) ; (157_2)([pum] Pum Select Settings: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumSet" ; (366_5)(Script Type)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
