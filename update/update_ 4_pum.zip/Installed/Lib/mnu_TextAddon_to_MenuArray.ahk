﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
mnu_TextAddon_to_MenuArray(DataArray)
{
  ; -------------------------------------------
  v_302_6 := 0 ; (302_6)([mnu] Menu Size [#])
  v_365_4 := DataArray.365.4 ; (365_4)(Language List [Array])
  ; -------------------------------------------
  v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  v_367_3 := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
  v_386_3 := DataArray.386.3 ; (386_3)(Addons [System Folder Path])
  StringLower, ActiveProcess, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
  ; -------------------------------------------
  for ThisNum, v_365_2 in v_365_4 ; (365_2)(Current User language)/(365_4)(Language List [Array])
  {
    ; -------------------------------------------
    ; (370_16)(Addons [Folder Path])
    ; (367_2)(Active Process Name)
    ; (365_2)(Current User language)
    ;
    ; (367_2)(Active Process Name)/(365_2)(Current User language)
    ; (367_2)(Active Process Name)
    ; (365_2)(Current User language)
    ThisAddon := v_386_3 "\" ActiveProcess "\" v_365_2 "\addon_" ActiveProcess "_" v_365_2 ".txt" ; (386_3)(Addons [System Folder Path])/(365_2)(Current User language)
    AllMenuArray := ""
    ; -------------------------------------------
    if FileExist(ThisAddon) ; AddOn Exist / [SET] ThisAddon(ThisFile), AllMenuArray
    {
      ; -------------------------------------------
      LineNum := 1
      FileReadLine, MenuName, %ThisAddon%, LineNum
      MenuName := StrReplace(MenuName, A_Space, "")
      LineNum := LineNum + 1 ; 2
      FileReadLine, MenuArray, %ThisAddon%, LineNum
      ; -------------------------------------------
      MenuArray  := StrSplit(MenuArray, "|", "")
      v_302_6 := MenuArray.MaxIndex() ; (302_6)([mnu] Menu Size [#])
      AllMenuArrayItem := [MenuName, MenuArray]
      MenuName  := ""
      MenuArray := ""
      AllMenuArray  := Array_Add(AllMenuArray, AllMenuArrayItem, "End")
      ; -------------------------------------------
      LineNum   := LineNum + 1 ; 3
      ; -------------------------------------------
      ThisTime := A_TickCount
      BreakTime := ThisTime + 3000
      ; -------------------------------------------
      Loop ; Infinite Loop
      {
        ; -------------------------------------------
        ThisTime := A_TickCount
        if (BreakTime == ThisTime)
        {
          break
        }
        ; -------------------------------------------
        MenuArray  := ""
        MenuName  := ""
        ComArray  := ""
        TxtArray  := ""
        EndOfFile := ""
        ; -------------------------------------------
        FileReadLine, MenuName, %ThisAddon%, LineNum
        ; -------------------------------------------
        ThisLen := StrLen(MenuName)
        if (ThisLen == 0 or !MenuName)
        {
          break
        }
        ; -------------------------------------------
        MenuName := StrReplace(MenuName, A_Space, "")
        LineNum   := LineNum + 1 ; 5
        FileReadLine, ComArray, %ThisAddon%, LineNum
        LineNum   := LineNum + 1 ; 6
        FileReadLine, TxtArray, %ThisAddon%, LineNum
        LineNum   := LineNum + 1 ; 7
        FileReadLine, EndOfFile, %ThisAddon%, LineNum
        ; -------------------------------------------
        ComArray  := StrSplit(ComArray, "|", "")
        TxtArray  := StrSplit(TxtArray, "|", "")
        ; -------------------------------------------
        for Index, ThisItem in ComArray
        {
          ; -------------------------------------------
          Decription := TxtArray[Index]
          ItemArray := [ThisItem, Decription]
          MenuArray := Array_Add(MenuArray, ItemArray, "End")
          MenuName := StrReplace(MenuName, A_Space, "")
          ; -------------------------------------------
        } ; End for Index, ThisItem in ComArray
        ; -------------------------------------------
        AllMenuArrayItem := [MenuName, MenuArray]
        AllMenuArray := Array_Add(AllMenuArray, AllMenuArrayItem, "End")
        ; -------------------------------------------        
        MenuName := ""
        ; -------------------------------------------
      } ; End Infinite Loop [SET] AllMenuArray
      ; -------------------------------------------
    } ; End FileExist(ThisFile)
    ; -------------------------------------------
    { ; (321)-(330) (2)(AllMenuArray = %lang%_MenuArray) / (3)(Addon Installed [1/0]
      if (v_365_2 == "de") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.321.2 := AllMenuArray ; (321_2)([mnu] de German Menu Array de_MenuArray)
          DataArray.321.3 := 1 ; (321_3)([mnu] de German Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.321.3 := 0 ; (321_3)([mnu] de German Addon Installed [1/0])
        }
      } ; End (de German)
      else if (v_365_2 == "en") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.322.2 := AllMenuArray ; (322_2)([mnu] en English Menu Array en_MenuArray)
          DataArray.322.3 := 1 ; (322_3)([mnu] en English Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.322.3 := 0 ; (322_3)([mnu] en English Addon Installed [1/0])
        }
      } ; End (en English)
      else if (v_365_2 == "es") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.323.2 := AllMenuArray ; (323_2)([mnu] es Spanish Menu Array es_MenuArray)
          DataArray.323.3 := 1 ; (323_3)([mnu] es Spanish Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.323.3 := 0 ; (323_3)([mnu] es Spanish Addon Installed [1/0])
        }
      } ; End (es Spanish)
      else if (v_365_2 == "fr") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.324.2 := AllMenuArray ; (324_2)([mnu] fr French Menu Array fr_MenuArray)
          DataArray.324.3 := 1 ; (324_3)([mnu] fr French Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.324.3 := 0 ; (324_3)([mnu] fr French Addon Installed [1/0])
        }
      } ; End (fr French)
      else if (v_365_2 == "it") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.325.2 := AllMenuArray ; (325_2)([mnu] it Italian Menu Array it_MenuArray)
          DataArray.325.3 := 1 ; (325_3)([mnu] it Italian Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.325.3 := 0 ; (325_3)([mnu] it Italian Addon Installed [1/0])
        }
      } ; End (it Italian)
      else if (v_365_2 == "pl") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.326.2 := AllMenuArray ; (326_2)([mnu] pl Polish Menu Array pl_MenuArray)
          DataArray.326.3 := 1 ; (326_3)([mnu] pl Polish Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.326.3 := 0 ; (326_3)([mnu] pl Polish Addon Installed [1/0])
        }
      } ; End (pl Polish)
      else if (v_365_2 == "pt") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.327.2 := AllMenuArray ; (327_2)([mnu] pt Portuguese Menu Array pt_MenuArray)
          DataArray.327.3 := 1 ; (327_3)([mnu] pt Portuguese Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.327.3 := 0 ; (327_3)([mnu] pt Portuguese Addon Installed [1/0])
        }
      } ; End (pt Portuguese)
      else if (v_365_2 == "ru") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.328.2 := AllMenuArray ; (328_2)([mnu] ru Russian Menu Array ru_MenuArray)
          DataArray.328.3 := 1 ; (328_3)([mnu] ru Russian Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.328.3 := 0 ; (328_3)([mnu] ru Russian Addon Installed [1/0])
        }
      } ; End (ru Russian)
      else if (v_365_2 == "sv") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.329.2 := AllMenuArray ; (329_2)([mnu] sv Swedish Menu Array sv_MenuArray)
          DataArray.329.3 := 1 ; (329_3)([mnu] sv Swedish Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.329.3 := 0 ; (329_3)([mnu] sv Swedish Addon Installed [1/0])
        }
      } ; End (sv Swedish)
      else if (v_365_2 == "tr") ; (365_2)(Current User language)
      {
        if AllMenuArray
        {
          DataArray.330.2 := AllMenuArray ; (330_2)([mnu] tr Turkish Menu Array tr_MenuArray)
          DataArray.330.3 := 1 ; (330_3)([mnu] tr Turkish Addon Installed [1/0])
        } ; End if AllMenuArray
        else
        {
          DataArray.330.3 := 0 ; (330_3)([mnu] tr Turkish Addon Installed [1/0])
        }
      } ; End (tr Turkish)
    }
    ; -------------------------------------------
  } ; (365_4)(Language List [Array])
  ; -------------------------------------------
  DataArray.302.6 := v_302_6 ; (302_6)([mnu] Menu Size [#])
  ; -------------------------------------------
  return DataArray
}
