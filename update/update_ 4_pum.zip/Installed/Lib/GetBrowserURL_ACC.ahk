﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  (url) GetBrowserURL_ACC
GetBrowserURL_ACC(sExe, sClass)
{
  global nWindow, accAddressBar
  if (nWindow != WinExist("ahk_class " sClass)) ; reuses accAddressBar if it's the same window
  {
    ;~ nWindow := WinExist("ahk_class " sClass)
    nWindow := WinExist("ahk_exe " sExe)
    accAddressBar := GetAddressBar(url_Acc_ObjectFromWindow(nWindow))
  }
  try sURL := accAddressBar.accValue(0)
  if (sURL == "")
  {
    WinGet, nWindows, List, % "ahk_class " sClass ; In case of a nested browser window as in the old CoolNovo (TO DO: check if still needed)
    if (nWindows > 1)
    {
      accAddressBar := GetAddressBar(url_Acc_ObjectFromWindow(nWindows2))
      try sURL := accAddressBar.accValue(0)
    }
  }
  if ((sURL != "") and (SubStr(sURL, 1, 4) != "http")) ; Modern browsers omit "http://"
  {
    sURL := "http://" sURL
  }
  if (sURL == "")
  {
    nWindow := -1 ; Don't remember the window if there is no URL
  }
  return sURL
}
