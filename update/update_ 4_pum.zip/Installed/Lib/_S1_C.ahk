﻿; [ScriptError == 1] (Application Target [exe] File Not Found)
; [ScriptError == 2] (rwh)(No Application to Open File)
; [ScriptError == 3] (key)(Invalid KeyStroke)
; [ScriptError == 4] (Enpty Icon Grid Selected)
; [ScriptError == 5] (mnu)(Addon Not Installed)(Addon is Available)
; [ScriptError == 6] (ofl)(Folder Not Found)
; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
; [ScriptError == 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
; [ScriptError == 15] (No Error)(url)(No Selected URL)
; [ScriptError == 16] *********************************
; [ScriptError == 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
; [ScriptError == 18] (url)(Source Not Found)
; [ScriptError == 19] (url)(No Internet Connection)
; [ScriptError == 20] (ActiveProcess = "Windows")
; [ScriptError == 21] (url)(Previous URL Does Not Match Current URL)
; -------------------------------------------
/*
  ; -------------------------------------------
  FontColor := "199524" ; (Green)
  FontColor := "a30404" ; (Red)
  FontColor := "000000" ; (Black)
  FontColor := "921297" ; (Purple)
  FontColor := "040e47" ; (Dark Blue) As Admin Color
  ; -------------------------------------------
*/
; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#Include E:\Installed\(_PUM_)\Lib\Time_Check.ahk
; -------------------------------------------
_S1_C(DataArray)
{
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  v_384_1 := DataArray.384.1
  Run, %v_384_1%
  while (Is_Script_Running(v_384_1) == 0)
  {
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  { ; Set Defaults
    ; -------------------------------------------
    if (v_366_5 == "key" or v_366_5 == "mnu") ; (366_5)(Script Type)
    {
      if (DataArray.72.2 == "") ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      {
        DataArray.72.2 := 2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      }
    }
    else if (v_366_5 == "url") ; (366_5)(Script Type)
    {
      if (DataArray.307.7 == "") ; (307_7)([url] Use Default Browser [0/1])
      {
        DataArray.307.7 := 1 ; (307_7)([url] Use Default Browser [0/1])
      }
    }
    ; -------------------------------------------
  } ; End Set Defaults
  ; -------------------------------------------
  { ; Start Up Vars
    ; -------------------------------------------
    v_366_6 := 0 ; (366_6)(This Script Error [Integer])
    ; -------------------------------------------
    v_072_2 := DataArray.72.2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    ;
    v_300_2 := DataArray.300.2 ; (300_2)([cpl] Menu Number #_X_[X])
    v_300_4 := DataArray.300.4 ; (300_4)([cpl] Menu Number X_X_[#])
    ;
    v_301_3 := DataArray.301.3 ; (301_3)([key] KeyArray is Valid [1/3])
    v_301_6 := DataArray.301.6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
    ;
    v_302_2 := DataArray.302.2 ; (302_2)([mnu] Menu Number #_X_X_[X])
    v_302_5 := DataArray.302.5 ; (302_5)([mnu] Menu Number X_X_X_[#])
    ;
    v_303_2 := DataArray.303.2 ; (303_2)([ofl] Folder Path)
    ;
    v_305_4 := DataArray.305.4 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
    v_305_5 := DataArray.305.5 ; (305_5)([rwh] Selected Opening Application [Full File Path])
    v_305_10 := DataArray.305.10 ; (305_10)([run] Selected File [File Ext] WithOut [.])
    ;
    v_307_2 := DataArray.307.2 ; (307_2)([url] Current URL)
    v_307_3 := DataArray.307.3 ; (307_3)([url] Source URL Downloaded Ok [0/1])
    v_307_8 := DataArray.307.8 ; (307_8)([url] Previous URL)
    ;
    if (v_307_8 == "") ; (307_8)([url] Previous URL)
    {
      v_307_8 := v_307_2 ; (307_8)([url] Previous URL)/(307_2)([url] Current URL)
      DataArray.307.8 := v_307_8 ; (307_8)([url] Previous URL)
    }
    ;
    v_321_3 := DataArray.321.3 ; (321_3)([mnu] de German Addon Installed [1/0])
    v_322_3 := DataArray.322.3 ; (322_3)([mnu] en English Addon Installed [1/0])
    v_323_3 := DataArray.323.3 ; (323_3)([mnu] es Spanish Addon Installed [1/0])
    v_324_3 := DataArray.324.3 ; (324_3)([mnu] fr French Addon Installed [1/0])
    v_325_3 := DataArray.325.3 ; (325_3)([mnu] it Italian Addon Installed [1/0])
    v_326_3 := DataArray.326.3 ; (326_3)([mnu] pl Polish Addon Installed [1/0])
    v_327_3 := DataArray.327.3 ; (327_3)([mnu] pt Portuguese Addon Installed [1/0])
    v_328_3 := DataArray.328.3 ; (328_3)([mnu] ru Russian Addon Installed [1/0])
    v_329_3 := DataArray.329.3 ; (329_3)([mnu] sv Swedish Addon Installed [1/0])
    v_330_3 := DataArray.330.3 ; (330_3)([mnu] tr Turkish Addon Installed [1/0])
    ;
    v_370_8 := DataArray.370.8 ; (370_8)(XML_SC_L2 Script [Full File Path])
    ;
    v_365_2 := DataArray.365.2 ; (365_2)(Current User language)
    v_366_5 := DataArray.366.5 ; (366_5)(Script Type)
    ;
    v_367_2 := DataArray.367.2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
    v_367_3 := DataArray.367.3 ; (367_3)([Line 2] Active Process [File Name] [File Ext] / [NO Path])
    v_367_4 := DataArray.367.4 ; (367_4)([Line 3] Active Process Class)
    ;
    v_380_2 := DataArray.380.2 ; (380_2)(Application Request [System Text File Path])
    v_380_7 := DataArray.380.7 ; (380_7)(Current Addons [Text File Downloaded] [System Text File Path])
    ;
    v_385_1 := DataArray.385.1 ; (385_1)(Current Addons [current_addons.txt] [Downloaded Text File] [PopUpMenu URL Address])
    ; -------------------------------------------
    v_004_2 := 1 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    ; -------------------------------------------
    v_366_6 := 0 ; (366_6)(This Script Error [Integer])
    ; -------------------------------------------
    v_366_3 := 1 ; (366_3)(First Run [0/1])
    ; (366_3)(First Run [1/0])
    ; This is Here Because of
    ; ; (123)(GUI Object: <Edit Feild> [key] Text Input)
    ; Uses Gui, Submit, NoHide
    ; Which causes script to load twice
    ; See gui_Shortcut.ahk
    ; -------------------------------------------
  } ; End Start Up Vars
  ; -------------------------------------------
  { ; Check for Script Error
    ; -------------------------------------------
    if (v_366_5 == "xxx" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      ; [ScriptError == 4] (Enpty Icon Grid Selected)
      ; -------------------------------------------
      v_366_6 := 4 ; (366_6)(This Script Error [Integer])
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (xxx)
    ; -------------------------------------------
    if (v_366_5 == "run_rwh_url_ofl" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      ; [ScriptError == 8] (No Error)(run_rwh_url_ofl)(Country Image)
      ; -------------------------------------------
      v_366_6 := 8 ; (366_6)(This Script Error [Integer])
      v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (run_rwh_url_ofl)
    ; -------------------------------------------
    if (v_366_5 == "mnu_cpl_key" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      v_302_7 := 0 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      ; -------------------------------------------
      { ; (302_1)(ScriptType [mnu])_(302_2)([mnu] Menu Item #_X_X_[X])_(302_3)([mnu] Menu Item X_#_X_[X])_(302_4)([mnu] Menu Item X_X_#_[X])_(302_5)([mnu] Menu Item X_X_X_[#])_(302_6)([mnu] Menu Size [#])_(302_7)([mnu] Active Process Has a Addon Installed [1/0])
        ; -------------------------------------------
        if (v_365_2 == "de" && V_321_3 == 1) ; (365_2)(Current User language)/(321_3)([mnu] de German Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "en" && V_322_3 == 1) ; (365_2)(Current User language)/(322_3)([mnu] en English Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "es" && v_323_3 == 1) ; (365_2)(Current User language)/(323_3)([mnu] es Spanish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "fr" && v_324_3 == 1) ; (365_2)(Current User language)/(324_3)([mnu] fr French Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "it" && v_325_3 == 1) ; (365_2)(Current User language)/(325_3)([mnu] it Italian Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "pl" && v_326_3 == 1) ; (365_2)(Current User language)/(326_3)([mnu] pl Polish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "pt" && v_327_3 == 1) ; (365_2)(Current User language)/(327_3)([mnu] pt Portuguese Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "ru" && v_328_3 == 1) ; (365_2)(Current User language)/(328_3)([mnu] ru Russian Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "sv" && v_329_3 == 1) ; (365_2)(Current User language)/(329_3)([mnu] sv Swedish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "tr" && v_330_3 == 1) ; (365_2)(Current User language)/(330_3)([mnu] tr Turkish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      DataArray.302.7 := v_302_7 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      ; -------------------------------------------
      if (v_302_7 == 0) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      {
        if (v_367_2 == "Windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
        {
          ; -------------------------------------------
          ; [ScriptError == 20] (ActiveProcess = "Windows")
          ; -------------------------------------------
          v_366_6 := 20 ; (366_6)(This Script Error [Integer])
          v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          if FileExist(v_380_7) ; (380_7)(Current Addons [Text File Downloaded] [System Text File Path])
          {
            ; -------------------------------------------
            Current_Addon_Array := Array_From_File(v_380_7) ; (380_7)(Current Addons [Text File Downloaded] [System Text File Path])
            Check_App_Addon := v_367_2 "_" v_365_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(365_2)(Current User language)
            StringLower, Check_App_Addon, Check_App_Addon
            ; -------------------------------------------
            for Index, This_Addon in Current_Addon_Array
            {
              StringLower, This_Addon, This_Addon
              ; -------------------------------------------
              if (This_Addon == Check_App_Addon)
              {
                ; -------------------------------------------
                ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
                ; -------------------------------------------
                v_366_6 := 5 ; (366_6)(This Script Error [Integer])
                v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
                ; -------------------------------------------
                break
                ; -------------------------------------------
              }
            }
          }
          ; -------------------------------------------
          ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
          ; -------------------------------------------
          if (v_366_6 != 5) ; (366_6)(This Script Error [Integer])
          {
            ; -------------------------------------------
            StringLower, Check_App_Addon, Check_App_Addon
            ; -------------------------------------------
            HasRequested := 0
            ; -------------------------------------------
            if FileExist(v_380_2) ; (380_2)(Application Request [System Text File Path])
            {
              ; -------------------------------------------
              AppArray := Array_From_File(v_380_2) ; (380_2)(Application Request [System Text File Path])
              for Index, CheckApp in AppArray
              {
                ; -------------------------------------------
                StringLower, CheckApp, CheckApp
                ; -------------------------------------------
                if (CheckApp == Check_App_Addon)
                {
                  HasRequested := 1
                  break
                } ; End (CheckApp == AppRequest)
              } ; End for Index, CheckApp in AppArray
              ; -------------------------------------------
            } ; (380_2)(Application Request [System Text File Path])
            ; -------------------------------------------
            if (HasRequested == 0)
            {
              ; -------------------------------------------
              ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
              ; -------------------------------------------
              v_366_6 := 17 ; (366_6)(This Script Error [Integer])
              v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
              ; -------------------------------------------
            }
            else if (HasRequested == 1)
            {
              ; -------------------------------------------
              ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
              ; -------------------------------------------
              v_366_6 := 12 ; (366_6)(This Script Error [Integer])
              v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
              ; -------------------------------------------
            }
          }
        }
      }
      ; -------------------------------------------
      else if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError == 7] (No Error)(mnu_cpl_key)(Country Image)
        ; -------------------------------------------
        v_366_6 := 7 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
    } ; End (366_5)(Script Type) (mnu_cpl_key)
    ; -------------------------------------------
    if (v_366_5 == "mnu" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      v_302_7 := 0 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      ; -------------------------------------------
      { ; (302_7)([mnu] Active Process Has a Addon Installed [1/0])
        ; -------------------------------------------
        if (v_365_2 == "de" && V_321_3 == 1) ; (365_2)(Current User language)/(321_3)([mnu] de German Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "en" && V_322_3 == 1) ; (365_2)(Current User language)/(322_3)([mnu] en English Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "es" && v_323_3 == 1) ; (365_2)(Current User language)/(323_3)([mnu] es Spanish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "fr" && v_324_3 == 1) ; (365_2)(Current User language)/(324_3)([mnu] fr French Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "it" && v_325_3 == 1) ; (365_2)(Current User language)/(325_3)([mnu] it Italian Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "pl" && v_326_3 == 1) ; (365_2)(Current User language)/(326_3)([mnu] pl Polish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "pt" && v_327_3 == 1) ; (365_2)(Current User language)/(327_3)([mnu] pt Portuguese Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "ru" && v_328_3 == 1) ; (365_2)(Current User language)/(328_3)([mnu] ru Russian Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "sv" && v_329_3 == 1) ; (365_2)(Current User language)/(329_3)([mnu] sv Swedish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
        else if (v_365_2 == "tr" && v_330_3 == 1) ; (365_2)(Current User language)/(330_3)([mnu] tr Turkish Addon Installed [1/0])
        {
          v_302_7 := 1 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
        }
        ; -------------------------------------------
      } ; (302_7)([mnu] Active Process Has a Addon Installed [1/0])
      ; -------------------------------------------
      DataArray.302.7 := v_302_7 ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      ; -------------------------------------------
      if (v_302_7 == 0) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      {
        ; -------------------------------------------
        if FileExist(v_380_7) ; (380_7)(Current Addons [Text File Downloaded] [System Text File Path])
        {
          ; -------------------------------------------
          Current_Addon_Array := Array_From_File(v_380_7) ; (380_7)(Current Addons [Text File Downloaded] [System Text File Path])
          Check_App_Addon := v_367_2 "_" v_365_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])/(365_2)(Current User language)
          StringLower, Check_App_Addon, Check_App_Addon
          ; -------------------------------------------
          for Index, This_Addon in Current_Addon_Array
          {
            StringLower, This_Addon, This_Addon
            ; -------------------------------------------
            if (This_Addon == Check_App_Addon)
            {
              ; -------------------------------------------
              ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
              ; -------------------------------------------
              v_366_6 := 5 ; (366_6)(This Script Error [Integer])
              v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
              ; -------------------------------------------
              break
              ; -------------------------------------------
            }
          }
        }
        ; -------------------------------------------
        ; [ScriptError == 5] (Addon Not Installed)(Addon is Available)
        ; -------------------------------------------
        if (v_366_6 != 5) ; (366_6)(This Script Error [Integer])
        {
          ; -------------------------------------------
          StringLower, Check_App_Addon, Check_App_Addon
          ; -------------------------------------------
          HasRequested := 0
          ; -------------------------------------------
          if FileExist(v_380_2) ; (380_2)(Application Request [System Text File Path])
          {
            ; -------------------------------------------
            AppArray := Array_From_File(v_380_2) ; (380_2)(Application Request [System Text File Path])
            for Index, CheckApp in AppArray
            {
              ; -------------------------------------------
              StringLower, CheckApp, CheckApp
              ; -------------------------------------------
              if (CheckApp == Check_App_Addon)
              {
                HasRequested := 1
                break
              } ; End (CheckApp == AppRequest)
            } ; End for Index, CheckApp in AppArray
            ; -------------------------------------------
          } ; (380_2)(Application Request [System Text File Path])
          ; -------------------------------------------
          if (HasRequested == 0)
          {
            ; -------------------------------------------
            ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
            ; -------------------------------------------
            v_366_6 := 17 ; (366_6)(This Script Error [Integer])
            v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            ; -------------------------------------------
          }
          else if (HasRequested == 1)
          {
            ; -------------------------------------------
            ; [ScriptError == 12] (Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
            ; -------------------------------------------
            v_366_6 := 12 ; (366_6)(This Script Error [Integer])
            v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            ; -------------------------------------------
          }
        }
      }
      ; -------------------------------------------
      else if (v_302_7 == 1) ; (302_7)([mnu] Active Process Has a Addon Installed [0/1])
      {
        ; -------------------------------------------
        if !v_302_2 ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          v_302_2 := 0 ; (302_2)([mnu] Menu Number #_X_X_[X])
        }
        ; -------------------------------------------
        if (v_302_2 == 0) ; (302_2)([mnu] Menu Number #_X_X_[X])
        {
          ; -------------------------------------------
          ; [ScriptError == 9] (No Error)(mnu)(Menu Bar Item Not Selected)
          ; -------------------------------------------
          v_366_6 := 9 ; (366_6)(This Script Error [Integer])
          v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else
        {
          ; -------------------------------------------
          if !v_302_5 ; (302_5)([mnu] Menu Number X_X_X_[#])
          {
            v_302_5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
          }
          ; -------------------------------------------
          if (v_302_5 == 0) ; (302_5)([mnu] Menu Number X_X_X_[#])
          {
            ; -------------------------------------------
            ; [ScriptError == 10] (No Error)(mnu)(Menu Bar Item Is Selected)(List Item Not Selected)
            ; -------------------------------------------
            v_366_6 := 10 ; (366_6)(This Script Error [Integer])
            v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            ; -------------------------------------------
          }
        }
      }
    } ; End (366_5)(Script Type) (mnu)
    ; -------------------------------------------
    if (v_366_5 == "cpl" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      if !v_300_2 ; (300_2)([cpl] Menu Number #_X_[X])
      {
        v_300_2 := 0 ; (300_2)([cpl] Menu Number #_X_[X])
      }
      ; -------------------------------------------
      if (v_300_2 == 0) ; (300_2)([cpl] Menu Number #_X_[X])
      {
        ; -------------------------------------------
        ; [ScriptError == 14] (No Error)(cpl)(Menu Bar Item Not Selected)
        ; -------------------------------------------
        v_366_6 := 14 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        if !v_300_4 ; (300_4)([cpl] Menu Number X_X_[#])
        {
          v_300_4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
        }
        ; -------------------------------------------
        if (v_300_4 == 0) ; (300_4)([cpl] Menu Number X_X_[#])
        {
          ; -------------------------------------------
          ; [ScriptError == 11] (No Error)(cpl)(Menu Bar Item Is Selected)(List Item Not Selected)
          ; -------------------------------------------
          v_366_6 := 11 ; (366_6)(This Script Error [Integer])
          v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
          ; -------------------------------------------
        }
      }
    } ; End (366_5)(Script Type) (cpl)
    ; -------------------------------------------
    if (v_366_5 == "ofl" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      if !FileExist(v_303_2) ; (303_2)([ofl] Folder Path)
      {
        ; -------------------------------------------
        ; [ScriptError == 6] (Folder Not Found)
        ; -------------------------------------------
        v_366_6 := 6 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (ofl)
    ; -------------------------------------------
    if (v_366_5 == "run" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      if !FileExist(v_305_4) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      {
        ; -------------------------------------------
        ; [ScriptError == 1] (Target File Not Found)
        ; -------------------------------------------
        v_366_6 := 1 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (run)
    ; -------------------------------------------
    if (v_366_5 == "rwh" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      if !FileExist(v_305_4) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
      {
        ; -------------------------------------------
        ; [ScriptError == 1] (Target File Not Found)
        ; -------------------------------------------
        v_366_6 := 1 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        ; Get the Default Application that open the Extension
        DefaultApp := Default_Application(v_305_10) ; (305_10)([run] Selected File [File Ext] WithOut [.])
        ; -------------------------------------------
        if FileExist(v_305_5) ; (305_5)([rwh] Selected Opening Application [Full File Path])
        {
          if (DefaultApp == "OpenWith.exe" or DefaultApp == "NoDefault")
          {
            DataArray.305.6 := v_305_5 ; (305_6)([rwh] Default Application [Full File Path])/(305_5)([rwh] Selected Opening Application [Full File Path])
          }
          else if !FileExist(DefaultApp)
          {
            DataArray.305.6 := v_305_5 ; (305_6)([rwh] Default Application [Full File Path])/(305_5)([rwh] Selected Opening Application [Full File Path])
          }
          else
          {
            DataArray.305.6 := DefaultApp ; (305_6)([rwh] Default Application [Full File Path])
          }
          ; -------------------------------------------
          if (DataArray.305.6 == v_305_5) ; (305_6)([rwh] Default Application [Full File Path])/(305_5)([rwh] Selected Opening Application [Full File Path])
          {
            DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
          }
          else
          {
            DataArray.305.8 := 0 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
          }
        } ; End (305_5)([rwh] Selected Opening Application [Full File Path]) (Exist)
        else
        {
          if (DefaultApp == "OpenWith.exe" or DefaultApp == "NoDefault")
          {
            ; -------------------------------------------
            ; [ScriptError == 2] (No Application to Open File)
            ; -------------------------------------------
            v_366_6 := 2 ; (366_6)(This Script Error [Integer])
            v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            ; -------------------------------------------
            DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
            DataArray.305.5 := "" ; (305_5)([rwh] Selected Opening Application [Full File Path])
            DataArray.305.6 := "" ; (305_6)([rwh] Default Application [Full File Path])
            ; -------------------------------------------
          }
          else if !FileExist(DefaultApp)
          {
            ; -------------------------------------------
            ; [ScriptError == 2] (No Application to Open File)
            ; -------------------------------------------
            v_366_6 := 2 ; (366_6)(This Script Error [Integer])
            v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
            ; -------------------------------------------
            DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
            DataArray.305.5 := "" ; (305_5)([rwh] Selected Opening Application [Full File Path])
            DataArray.305.6 := "" ; (305_6)([rwh] Default Application [Full File Path])
            ; -------------------------------------------
          }
          else
          {
            DataArray.305.8 := 1 ; (305_8)([rwh] Use Default Application to Open This File [0/1])
            DataArray.305.5 := DefaultApp ; (305_5)([rwh] Selected Opening Application [Full File Path])
            DataArray.305.6 := DefaultApp ; (305_6)([rwh] Default Application [Full File Path])
          }
        }
      }
    } ; End (366_5)(Script Type) (rwh)
    ; -------------------------------------------
    if (v_366_5 == "key" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      DataArray := KeyArray_Validate(DataArray)
      v_301_3 := DataArray.301.3 ; (301_3)([key] KeyArray is Valid [1/3])
      ; -------------------------------------------
      if (v_301_3 == 3) ; (301_3)([key] KeyArray is Valid [1/3])
      {
        ; -------------------------------------------
        ; (key)
        ; (141)(Decriptive Title Text 3) = "Invalid Keystroke"
        ; -------------------------------------------
        v_366_6 := 3 ; (366_6)(This Script Error [Integer])
        v_004_2 := 3 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (v_366_6 == 0) ; (366_6)(This Script Error [Integer])
      {
        ; -------------------------------------------
        StringLower, ActiveProcess, v_367_2 ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
        StringLower, AppOnlyProcess, v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
        ; -------------------------------------------
        if v_301_6 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])
        {
          if (v_072_2 == 2) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
          {
            if (AppOnlyProcess != ActiveProcess) ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
            {
              ; -------------------------------------------
              ; (141)(Decriptive Title Text 3) = "Changing Application"
              ; -------------------------------------------
              v_366_6 := 13 ; (366_6)(This Script Error [Integer])
              ; -------------------------------------------
            }
          }
        }
      }
    } ; End (366_5)(Script Type) (key)
    ; -------------------------------------------
    if (v_366_5 == "url" && v_366_6 == 0) ; (366_5)(Script Type)/(366_6)(This Script Error [Integer])
    {
      ; -------------------------------------------
      Check_v_307_2 := StrReplace(v_307_2, "http://", "") ; (307_2)([url] Current URL)
      Check_v_307_2 := StrReplace(v_307_2, "https://", "") ; (307_2)([url] Current URL)
      Check_v_307_2 := StrReplace(v_307_2, "ftp://", "") ; (307_2)([url] Current URL)
      Check_v_307_2 := StrReplace(v_307_2, A_Space, "") ; (307_2)([url] Current URL)
      ; -------------------------------------------
      if (Connect_Check(flag=0x40) == 0)
      {
        ; -------------------------------------------
        ; [ScriptError == 19] (url)(No Internet Connection)
        ; -------------------------------------------
        v_366_6 := 19 ; (366_6)(This Script Error [Integer])
        ; -------------------------------------------
      }
      else if (Check_v_307_2 == "") ; (307_2)([url] Current URL)
      {
        ; -------------------------------------------
        DataArray.307.8 := v_307_2 ; (307_8)([url] Previous URL)/(307_2)([url] Current URL)
        ; -------------------------------------------
        ; [ScriptError == 15] (No Error)(url)(No Selected URL)
        ; -------------------------------------------
        v_366_6 := 15 ; (366_6)(This Script Error [Integer])
        ; -------------------------------------------
      }
      else if (v_307_2 != v_307_8) ; (307_2)([url] Current URL)/(307_8)([url] Previous URL)
      {
        ; -------------------------------------------
        ; [ScriptError == 21] (url)(Previous URL Does Not Match Current URL)
        ; -------------------------------------------
        v_366_6 := 21 ; (366_6)(This Script Error [Integer])
        ; -------------------------------------------
      }
      else if (v_307_3 == 0) ; (307_3)([url] Source URL Downloaded Ok [0/1])
      {
        ; -------------------------------------------
        ; [ScriptError == 18] (url)(Source Not Found)
        ; -------------------------------------------
        v_366_6 := 18 ; (366_6)(This Script Error [Integer])
        ; -------------------------------------------
      }
      ; -------------------------------------------
    } ; End (366_5)(Script Type) (url)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; -------------------------------------------
    ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
    ; -------------------------------------------
    if (v_366_6 == 0 or v_366_6 == 13) ; (366_6)(This Script Error [Integer])
    {
      v_004_2 := 1 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    ; -------------------------------------------
    ; (366_3)(First Run [1/0])
    ; This is Here Because of
    ; ; (123)(GUI Object: <Edit Feild> [key] Text Input)
    ; Uses Gui, Submit, NoHide
    ; Which causes script to load twice
    ; See gui_Shortcut.ahk
    DataArray.366.3 := v_366_3 ; (366_3)(First Run [0/1])
    ; -------------------------------------------
    if (DataArray.133.2 != 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
    {
      DataArray.4.2 := v_004_2 ; (004_2)(Ok Button: Select [0]Hide/[1]Nor/[3]Dis)
    }
    DataArray.366.6 := v_366_6 ; (366_6)(This Script Error [Integer])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; -------------------------------------------
    ; [ScriptError == 1] (Application Target [exe] File Not Found)
    ; [ScriptError == 2] (rwh)(No Application to Open File)
    ; [ScriptError == 3] (key)(Invalid KeyStroke)
    ; [ScriptError == 6] (ofl)(Folder Not Found)
    ; [ScriptError == 13] (No Error)(key)(Changing Application)(AppOnly = 1)
    ; [ScriptError == 18] (url)(Source Not Found)
    ; [ScriptError == 19] (url)(No Internet Connection)
    ; -------------------------------------------
    if (DataArray.133.2 == 2) ; (133_2)(Delete Shortcut: Select [0]Hide/[1]Nor/[2]Sel)
    {
      Gui, PopUpMenu:Color, ba556f ; Red
    }
    else if (v_366_6 == 1 or v_366_6 == 2 or v_366_6 == 3 or v_366_6 == 6 or v_366_6 == 13 or v_366_6 == 18 or v_366_6 == 19) ; (366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])/(366_6)(This Script Error [Integer])
    {
      Gui, PopUpMenu:Color, fed8ed ; Light Read
    }
    else
    {
      Gui, PopUpMenu:Color, e7d8fe ; Purple
    }
    ; -------------------------------------------
    
    
    ;~ Msg := Msg "(366_5)(Script Type)`n"
    ;~ Msg := Msg DataArray.366.5 "`n`n"
    
    ;~ Msg := Msg "(366_6)(This Script Error [Integer])`n"
    ;~ Msg := Msg DataArray.366.6 "`n`n"
    
    ;~ Tooltip, %Msg%, -500, 500
    ;~ Msg := ""
    
    
    
    
  } ; End Check for Script Error
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
