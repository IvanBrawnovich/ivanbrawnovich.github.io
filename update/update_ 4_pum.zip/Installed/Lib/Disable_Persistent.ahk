﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
#SingleInstance, force
#NoTrayIcon
; -------------------------------------------
; This File Must be Ran AsAdmin
; -------------------------------------------
Disable_ScriptClose(ThisScript)
{
  while (Disable_IsScriptRun(ThisScript) > 0)
  {
    DetectHiddenWindows, On
    WinClose, %ThisScript% ahk_class AutoHotkey
  }
} ; End Disable_ScriptClose(ThisScript)
; -------------------------------------------
Disable_IsScriptRun(ScriptPath)
{
  ; -------------------------------------------
  ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
  SplitPath, ScriptPath, , ,  , ThisScript
  ; -------------------------------------------
  ScriptRunning := 0
  DetectHiddenWindows, On
  WinGet, ahk_list, List, ahk_class AutoHotkey
  ; -------------------------------------------
  Loop % ahk_list
  {
    ; -------------------------------------------
    WinGetTitle, ahk_win, % "ahk_id" ahk_list%A_Index%
    RegExMatch(ahk_win,"^.*?\.ahk",m)
    ; SplitPath, ThisFilePath, FileNameExt, Folder, Ext, FileName, DriveLetter
    SplitPath, m, AhkName
    StringLower, AhkName, AhkName
    ; -------------------------------------------
    Check_AhkName := AhkName
    Check_AhkName := StrReplace(Check_AhkName, ".ahk", "")
    StringLower, ThisScript, ThisScript
    StringLower, Check_AhkName, Check_AhkName
    if (Check_AhkName == ThisScript)
    {
      ScriptRunning := ScriptRunning + 1
      break
    } ; End (AhkName == ThisScript)
    ; -------------------------------------------
  } ; End Loop % ahk_list
  ; -------------------------------------------
  return ScriptRunning
} ; End Disable_IsScriptRun(ScriptPath)
; -------------------------------------------
Disable_KeyPum := A_ScriptDir "\Disable_KeyPum.ahk"
Disable_KeyGui := A_ScriptDir "\Disable_KeyGui.ahk"
Disable_KeyDia := A_ScriptDir "\Disable_KeyDia.ahk"
Disable_KeySelect := A_ScriptDir "\Disable_KeySelect.ahk"
Disable_Run := A_ScriptDir "\Disable_Run.ahk"
Disable_Ofl := A_ScriptDir "\Disable_Ofl.ahk"
Disable_Gui := A_ScriptDir "\Disable_Gui.ahk"
Disable_Wait := A_ScriptDir "\Disable_Wait.ahk"

Disable_ScriptClose(Disable_KeySelect)
; -------------------------------------------
/*
Stay in Window Works with 
Loop Above
Hotkey
Nothing Works With
Hotkey Above
Loop
*/
Loop
{
  ; -------------------------------------------
  SetTitleMatchMode, 1
  ; -------------------------------------------
  Disable_ScriptClose(Disable_Wait)
  ; -------------------------------------------
  if (Disable_IsScriptRun(Disable_KeyPum) > 0) ; (Off) Disable_KeyPum
  {
    Disable_ScriptClose(Disable_KeyPum)
  }
  ; -------------------------------------------
  if WinExist("Browse For Folder" . "ahk_class #32770") ; (Run) Disable_KeyDia / Disable_Ofl
  {
    ; -------------------------------------------
    SetTitleMatchMode, 1
    WinGet, Ofl_Id, ID , Browse For Folder ahk_class #32770
    WinActivate, ahk_id %Ofl_Id%
    WinGetTitle, Ofl_Title, ahk_id %Ofl_Id%
    WinGetClass, Ofl_Class, ahk_id %Ofl_Id%
    WinSet, AlwaysOnTop, On, ahk_id %Ofl_Id%
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Gui) > 0) ; (Off) Disable_Gui
    {
      Disable_ScriptClose(Disable_Gui)
    }
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Run) > 0) ; (Off) Disable_Run
    {
      Disable_ScriptClose(Disable_Run)
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_KeyGui) == 0)
    {
      Run, %Disable_KeyGui%
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_Ofl) == 0)
    {
      Run, *RunAs %Disable_Ofl%
      RunWait, %Disable_Wait%
      Disable_ScriptClose(Disable_Wait)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
  else if WinExist("PUM -" . "ahk_class #32770") ; (Run) Disable_KeyDia / Disable_Run
  {
    ; -------------------------------------------
    SetTitleMatchMode, 1
    WinGet, Run_Id, ID , PUM - ahk_class #32770
    WinActivate, ahk_id %Run_Id%
    WinGetTitle, Run_Title, ahk_id %Run_Id%
    WinGetClass, Run_Class, ahk_id %Run_Id%
    WinSet, AlwaysOnTop, On, ahk_id %Run_Id%
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Gui) > 0) ; (Off) Disable_Gui
    {
      Disable_ScriptClose(Disable_Gui)
    }
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Ofl) > 0) ; (Off) Disable_Ofl
    {
      Disable_ScriptClose(Disable_Ofl)
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_KeyGui) == 0)
    {
      Run, %Disable_KeyGui%
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_Run) == 0)
    {
      Run, *RunAs %Disable_Run%
      RunWait, %Disable_Wait%
      Disable_ScriptClose(Disable_Wait)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
  else if WinActive("PopUpMenu" . "ahk_class AutoHotkeyGUI") ; (Run) Disable_KeyGui / Disable_Gui
  {
   ; -------------------------------------------
    SetTitleMatchMode, 1
    WinGet, Gui_Id, ID , PopUpMenu ahk_class AutoHotkeyGUI
    WinActivate, ahk_id %Gui_Id%
    WinGetTitle, Gui_Title, ahk_id %Gui_Id%
    WinGetClass, Gui_Class, ahk_id %Gui_Id%
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Run) > 0) ; (Off) Disable_Run
    {
      Disable_ScriptClose(Disable_Run)
    }
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_Ofl) > 0) ; (Off) Disable_Ofl
    {
      Disable_ScriptClose(Disable_Ofl)
    }
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_KeyGui) == 0)
    {
      Run, %Disable_KeyGui%
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Disable_IsScriptRun(Disable_Gui) == 0)
    {
      Run, *RunAs %Disable_Gui%
      RunWait, %Disable_Wait%
      Disable_ScriptClose(Disable_Wait)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
  }
  ; -------------------------------------------
  if !WinExist("PopUpMenu" . "ahk_class AutoHotkeyGUI")
  {
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_KeySelect) > 0) ; (Off) Disable_KeyGui
    {
      Disable_ScriptClose(Disable_KeySelect)
    }
    ; -------------------------------------------
    if (Disable_IsScriptRun(Disable_KeyGui) > 0) ; (Off) Disable_KeyGui
    {
      Disable_ScriptClose(Disable_KeyGui)
    }
    ; -------------------------------------------
    ExitApp
  }
} ; End Loop
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
