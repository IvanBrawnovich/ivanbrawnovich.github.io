﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
GetSelected_ListNumber(GuiList, ThisType, DataArray)
{
  ; -------------------------------------------
  DataArray := Function_Flow("GetSelected_ListNumber", DataArray)
  ; -------------------------------------------
  GuiControlGet, SelectedItem, PopUpMenu:, %GuiList% ; [SET] SelectedItem (String)
  ; -------------------------------------------
  if (InStr(SelectedItem, "-----------") == 0)
  {
    ; -------------------------------------------
    DataArray.366.4 := 0 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    ListVarNum := SubStr(GuiList, 3)
    ; -------------------------------------------
    { ; [SET] SelectedNum
      ThisListBox := DataArray[ListVarNum][3]
      ThisListBox := StrSplit(ThisListBox, "|", "|")
      Num := 0
      for Index, ThisItem in ThisListBox
      {
        if (ThisItem == SelectedItem)
        {
          IfInString, SelectedItem, >
          {
            IsSub := 1
          }
          else
          {
            IsSub := 0
          }
          SelectedNum := Num
          break
        } ; End (ThisItem == SelectedItem)
        else
        {
          Num := Num + 1
        } ; End else
      } ; End for Index, ThisItem in ThisListBox
    } ; End [SET] SelectedNum
    ; -------------------------------------------
    { ; [UPDATE] SelectedNum > (MenuArrayNum2 / MenuArrayNum3 / MenuArrayNumSel) / (cplNum2 / cplNumSel)
      ; -------------------------------------------
      if (GuiList == "g_116") ; (116_1)(GUI Object: [cpl][mnu] List Full Across)
      {
        if (ThisType == "mnu")
        {
          if (IsSub == 1)
          {
            DataArray.302.3 := SelectedNum ; (302_3)([mnu] Menu Number X_#_X_[X])
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.302.3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := SelectedNum ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "mnu")
        else if (ThisType == "cpl")
        {
          if (IsSub == 1)
          {
            DataArray.300.3 := SelectedNum ; (300_3)([cpl] Menu Number X_#_[X])
            DataArray.300.4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.300.3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
            DataArray.300.4 := SelectedNum ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "cpl")
      } ; (116)_(mnu)(cpl)(List Full Across)_(2)Select_(3)ListBox
      ; -------------------------------------------
      else if (GuiList == "g_117") ; (117_1)(GUI Object: [cpl][mnu] List Right 2/3)
      {
        if (ThisType == "mnu")
        {
          if (IsSub == 1)
          {
            DataArray.302.4 := SelectedNum ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := SelectedNum ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "mnu")
        else if (ThisType == "cpl")
        {
          DataArray.300.4 := SelectedNum ; (300_4)([cpl] Menu Number X_X_[#])
        } ; End (ThisType == "cpl")
      } ; (117)_(mnu)(cpl)(List Right 2/3)_(2)Select_(3)ListBox
      ; -------------------------------------------
      else if (GuiList == "g_118") ; (118_1)(GUI Object: [cpl][mnu] List Left 1/3)
      {
        if (ThisType == "mnu")
        {
          if (IsSub == 1)
          {
            DataArray.302.3 := SelectedNum ; (302_3)([mnu] Menu Number X_#_X_[X])
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.302.3 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := SelectedNum ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "mnu")
        else if (ThisType == "cpl")
        {
          if (IsSub == 1)
          {
            DataArray.300.3 := SelectedNum ; (300_3)([cpl] Menu Number X_#_[X])
            DataArray.300.4 := 0 ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.300.3 := 0 ; (300_3)([cpl] Menu Number X_#_[X])
            DataArray.300.4 := SelectedNum ; (300_4)([cpl] Menu Number X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "cpl")
      } ; (118)_(mnu)(cpl)(List Left 1/3)_(2)Select_(3)ListBox
      ; -------------------------------------------
      else if (GuiList == "g_120") ; (120_1)(GUI Object: [mnu] List Center 1/3)
      {
        if (ThisType == "mnu")
        {
          if (IsSub == 1)
          {
            DataArray.302.4 := SelectedNum ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 1)
          else if (IsSub == 0)
          {
            DataArray.302.4 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
            DataArray.302.5 := SelectedNum ; (302_5)([mnu] Menu Number X_X_X_[#])
          } ; End (IsSub == 0)
        } ; End (ThisType == "mnu")
      } ; (120)_(mnu)(cpl)(List Center 1/3)_(2)Select_(3)ListBox
      ; -------------------------------------------
      else if (GuiList == "g_121") ; (121_1)(GUI Object: [mnu] List Right 1/3)
      {
        if (ThisType == "mnu")
        {
          DataArray.302.5 := SelectedNum ; (302_5)([mnu] Menu Number X_X_X_[#])
        } ; End (ThisType == "mnu")
      } ; (121)_(mnu)(cpl)(List Right 1/3)_(2)Select_(3)ListBox
      ; -------------------------------------------
    } ; End [UPDATE] SelectedNum > (MenuArrayNum2 / MenuArrayNum3 / MenuArrayNumSel) / (cplNum2 / cplNumSel)
    ; -------------------------------------------
  } ; End (InStr(SelectedItem, "--------") == 0)
  else
  {
    ; -------------------------------------------
    DataArray.366.4 := 1 ; (366_4)([cpl][mnu] Selected List Item is a Divider [0/1])
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
}
