﻿; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
f_072(DataArray) ; (072_1)(GUI Object: [key] Application Only)
{
  ; -------------------------------------------
  DataArray := Function_Flow("f_072", DataArray) ; (072_1)(GUI Object: [key] Application Only)
  ; -------------------------------------------
  {
    ; -------------------------------------------
    ; 1 = Any App
    ; 2 = App Only
    ; -------------------------------------------
    if (DataArray.72.2 == 1) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    {
      ; -------------------------------------------
      v_072_2 := 2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
      ; -------------------------------------------
      DataArray.301.5 := DataArray.367.4 ; (301_5)([key][mnu] [Line 4] Application Only Class)/(367_4)([Line 3] Active Process Class)
      DataArray.301.6 := DataArray.367.2 ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      ; -------------------------------------------
    } ; (072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    else if (DataArray.72.2 == 2) ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    {
      v_072_2 := 1 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    } ; (072_2)([key] Application Only: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis)
    ; -------------------------------------------
    DataArray.72.2 := v_072_2 ; (072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    DataArray := GuiControlImage_PopUpMenu("072", v_072_2, 1, DataArray) ; (072_1)(GUI Object: [key] Application Only)/(072_2)([key][mnu] Application Only: Select [0]Hide/[1]Nor/[2]Sel)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; (072_1)(GUI Object: [key] Application Only)/(114_1)(GUI Object: <Displayed Text> Title 1)/(141_1)(GUI Object: <Displayed Text> Title 3)
  LimitedArray := [["v_072_1"], ["v_114_1"], ["v_141_1"]] ; (072_1)(GUI Object: [key] Application Only)/(114_1)(GUI Object: <Displayed Text> Title 1)/(141_1)(GUI Object: <Displayed Text> Title 3)
  DataArray.363.9 := LimitedArray ; (363_9)(Limited DataArray)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
